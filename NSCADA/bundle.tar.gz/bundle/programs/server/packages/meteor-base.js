(function () {



/* Exports */
Package._define("meteor-base");

})();
