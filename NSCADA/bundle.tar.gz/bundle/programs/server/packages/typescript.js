(function () {



/* Exports */
Package._define("typescript");

})();
