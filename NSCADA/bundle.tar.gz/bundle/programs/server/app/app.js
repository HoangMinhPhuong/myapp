var require = meteorInstall({"imports":{"api":{"alarmevent.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/alarmevent.js                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  AlarmEvent: () => AlarmEvent
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
const AlarmEvent = new Mongo.Collection('alarmevent');

if (Meteor.isServer) {
  // This code only runs on the server
  Meteor.publish('alarmspublicationevent', function alarmsPublicationEvent(argumentsFind, argumentsOptions) {
    return AlarmEvent.find(argumentsFind, argumentsOptions);
  });
  Meteor.publish('alarmRealtime', function alarmRealtime(argumentsFind) {
    return AlarmEvent.find(argumentsFind);
  });
}

Meteor.methods({
  //================================================================================	 
  'alarmevent.getAlarmRealTime'(numAlarm) {
    var dataBlock = [];
    var dataResult = [];
    var index = 0;
    let options = {
      year: '2-digit',
      month: 'numeric',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    };
    var messageVSD = ["Lỗi Aptomat: không cấp nguồn biến tần", "Không có tín hiệu phản hồi khi chạy hoặc dừng", " Lỗi biến tần"];
    var messageValve = ["Lỗi Aptomat: không cấp nguồn chặn liệu", "Không có tín hiệu phản hồi khi mở", "Không có tín hiệu phản hồi khi đóng"];
    var messageWEI = ["Mất kết nối", "Quá tải hoặc thấp tải", "Cân không ổn định", "Lỗi khi lưu vào bộ nhớ PLC"];
    var messageVSDConnect = ["Mất truyền thông với biến tần BT1", "Mất truyền thông với biến tần BT2", "Mất truyền thông với biến tần BT3", "Mất truyền thông với biến tần BT4", "Mất truyền thông với biến tần BT5", "Mất truyền thông với biến tần BT6", "Mất truyền thông với biến tần BT7", "Mất truyền thông với biến tần BT8", "Mất truyền thông với biến tần BT9", "Mất truyền thông với biến tần BT10", "Mất truyền thông với biến tần BT11", "Mất truyền thông với biến tần BT12", "Mất truyền thông với biến tần BT13", "Mất truyền thông với biến tần BT14", "Mất truyền thông với biến tần BT15"];
    AlarmEvent.find({
      "stat": "active"
    }, {
      sort: {
        _id: -1
      },
      limit: numAlarm
    }).forEach(function (doc) {
      var name = doc.name;

      switch (doc.type) {
        case "VSD":
          dataBlock.push({
            _id: doc._id,
            objName: doc.name,
            stat: 'active',
            timestamp: new Date(doc.sTime).toLocaleString({}, options),
            message: messageVSD[doc.bit]
          });
          break;

        case "Alarm":
          dataBlock.push({
            _id: doc._id,
            objName: doc.name,
            stat: 'active',
            timestamp: new Date(doc.sTime).toLocaleString({}, options),
            message: messageVSDConnect[doc.bit]
          });
          break;

        case "Valve":
          dataBlock.push({
            _id: doc._id,
            objName: doc.name,
            stat: 'active',
            timestamp: new Date(doc.sTime).toLocaleString({}, options),
            message: messageValve[doc.bit]
          });
          break;

        case "Weighing":
          dataBlock.push({
            _id: doc._id,
            objName: doc.name,
            stat: 'active',
            timestamp: new Date(doc.sTime).toLocaleString({}, options),
            message: messageWEI[doc.bit]
          });
          break;

        case "EStop":
          var tag = doc.name.split("ESTOP")[1];

          if (tag == "MAIN" || tag == "DK01" || tag == "DK02" || tag == "DK03" || tag == "DK04") {
            dataBlock.push({
              _id: doc._id,
              objName: doc.name,
              stat: 'active',
              timestamp: new Date(doc.sTime).toLocaleString({}, options),
              message: tag.concat(": Dừng khẩn cấp tủ điều khiển")
            });
          } else {
            dataBlock.push({
              _id: doc._id,
              objName: doc.name,
              stat: 'active',
              timestamp: new Date(doc.sTime).toLocaleString({}, options),
              message: "Dây giật khẩn cấp"
            });
          }

          break;
      }
    });

    if (dataBlock.length > numAlarm) {
      dataResult = dataBlock.slice(0, numAlarm);
    } else {
      dataResult = dataBlock.slice();
    }

    return dataResult;
  },

  //================================================================================		
  'alarmevent.getHistorian'(site, startTimeParam, endTimeParam) {
    var dataBlock = [];
    var index = 0;
    var endTime = "";
    var timestamp = "";
    let options = {
      year: '2-digit',
      month: 'numeric',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    };
    var messageWEI = ["Mất kết nối", "Quá tải hoặc thấp tải", "Cân không ổn định", "Lỗi khi lưu vào bộ nhớ PLC"];
    var messageVSD = ["Lỗi Aptomat: không cấp nguồn biến tần", "Không có tín hiệu phản hồi khi chạy hoặc dừng", " Lỗi biến tần"];
    var messageValve = ["Lỗi Aptomat: không cấp nguồn chặn liệu", "Không có tín hiệu phản hồi khi mở", "Không có tín hiệu phản hồi khi đóng"];
    var messageVSDConnect = ["Mất truyền thông với biến tần BT1", "Mất truyền thông với biến tần BT2", "Mất truyền thông với biến tần BT3", "Mất truyền thông với biến tần BT4", "Mất truyền thông với biến tần BT5", "Mất truyền thông với biến tần BT6", "Mất truyền thông với biến tần BT7", "Mất truyền thông với biến tần BT8", "Mất truyền thông với biến tần BT9", "Mất truyền thông với biến tần BT10", "Mất truyền thông với biến tần BT11", "Mất truyền thông với biến tần BT12", "Mất truyền thông với biến tần BT13", "Mất truyền thông với biến tần BT14", "Mất truyền thông với biến tần BT15"];
    AlarmEvent.find({
      sTime: {
        $gte: startTimeParam,
        $lte: endTimeParam
      }
    }, {
      sort: {
        _id: -1
      }
    }).forEach(function (doc) {
      var name = doc.name;

      if (doc.eTime == 0) {
        endTime = "";
      } else {
        endTime = new Date(doc.eTime).toLocaleString({}, options);
      }

      timestamp = new Date(doc.sTime).toLocaleString({}, options);

      switch (doc.type) {
        case "VSD":
          dataBlock.push({
            _id: doc._id,
            objName: doc.name,
            typeData: doc.type,
            timestamp: new Date(doc.sTime).toLocaleString({}, options),
            endTime: endTime,
            message: messageVSD[doc.bit]
          });
          break;

        case "Alarm":
          dataBlock.push({
            _id: doc._id,
            objName: doc.name,
            typeData: doc.type,
            timestamp: new Date(doc.sTime).toLocaleString({}, options),
            endTime: endTime,
            message: messageVSDConnect[doc.bit]
          });
          break;

        case "Valve":
          dataBlock.push({
            _id: doc._id,
            objName: doc.name,
            typeData: doc.type,
            timestamp: new Date(doc.sTime).toLocaleString({}, options),
            endTime: endTime,
            message: messageValve[doc.bit]
          });
          break;

        case "Weighing":
          dataBlock.push({
            _id: doc._id,
            objName: doc.name,
            typeData: doc.type,
            timestamp: new Date(doc.sTime).toLocaleString({}, options),
            endTime: endTime,
            message: messageWEI[doc.bit]
          });
          break;

        case "EStop":
          var tag = doc.name.split("ESTOP")[1];

          if (tag == "MAIN" || tag == "DK01" || tag == "DK02" || tag == "DK03" || tag == "DK04") {
            dataBlock.push({
              _id: doc._id,
              objName: doc.name,
              typeData: doc.type,
              timestamp: new Date(doc.sTime).toLocaleString({}, options),
              endTime: endTime,
              message: tag.concat(": Dừng khẩn cấp tủ điều khiển")
            });
          } else {
            dataBlock.push({
              _id: doc._id,
              objName: doc.name,
              typeData: doc.type,
              timestamp: new Date(doc.sTime).toLocaleString({}, options),
              endTime: endTime,
              message: "Dây giật khẩn cấp"
            });
          }

          break;

        case "Instrument":
          dataBlock.push({
            _id: doc._id,
            plc: doc.plc,
            area: doc.area,
            objName: doc.name,
            typeData: doc.type,
            timestamp: new Date(doc.sTime).toLocaleString({}, options),
            endTime: endTime,
            message: name.concat(" ", ": sensor is open circuit or error")
          });
          break;
      }
    }); //console.log("dataBlock: " + dataBlock);

    return dataBlock;
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"biomasevent.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/biomasevent.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  BiomasEvent: () => BiomasEvent
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
const BiomasEvent = new Mongo.Collection('biomasevent');

if (Meteor.isServer) {
  Meteor.methods({
    //================================================================================
    'biomasevent.getMonthlyReport'(startTime, endTime) {
      return Promise.asyncApply(() => {
        var dataBlock = [];
        var resultArr = []; //console.log("startTimeParam " + startTime + ", endTimeParam " + endTime + ", selectBoiler " + selectBoiler);

        const result = Promise.await(BiomasEvent.rawCollection().aggregate([{
          $match: {
            sTime: {
              $gte: startTime,
              $lte: endTime
            }
          }
        }, {
          $set: {
            datesx: {
              $dateToString: {
                format: "%m-%d",
                date: {
                  $add: [new Date(0), "$sTime"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            }
          }
        }, {
          $set: {
            hoursx: {
              $dateToString: {
                format: "%Y-%m-%d %H",
                date: {
                  $add: [new Date(0), "$sTime"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            }
          }
        }, {
          $match: {
            valueE: {
              $gt: 0,
              $lte: 10000
            }
          }
        }, {
          $match: {
            valueS: {
              $gt: 0,
              $lte: 10000
            }
          }
        }, {
          $project: {
            _id: "$name",
            materialSum: {
              $subtract: ["$valueE", "$valueS"]
            },
            datesx: "$datesx",
            hoursx: "$hoursx",
            material: "$material",
            boiler: "$boiler"
          }
        }, {
          $match: {
            materialSum: {
              $gt: 0,
              $lte: 10000
            }
          }
        }, {
          $group: {
            _id: {
              hoursx: "$hoursx",
              name: "$_id"
            },
            sumPoints: {
              $sum: "$materialSum"
            },
            type: {
              $push: {
                "material": "$material",
                "boiler": "$boiler"
              }
            }
          }
        }, {
          $sort: {
            "_id.hoursx": 1
          }
        }, {
          $group: {
            _id: {
              hoursx: "$_id.hoursx"
            },
            sums: {
              $sum: "$sumPoints"
            },
            invoiceDate: {
              $push: {
                "myPlace": "$_id.name",
                "myStamp": "$sumPoints",
                "type": "$type"
              }
            }
          }
        }, {
          $sort: {
            "_id.hoursx": 1
          }
        }]).forEach(function (doc) {
          resultArr.push(doc);
        }));
        var loadcell01Prv = 0;
        var loadcell02Prv = 0;
        var firstOfDay = 0;
        var material = 0;
        var boiler = 0;
        var dateTime = 0;
        var dataLC01 = [];
        var dataLC02 = [];
        var dataTime = [];
        var dataReport = [];
        var totalLC01Than = 0;
        var totalLC02Than = 0;
        var totalLC01Biomas = 0;
        var totalLC02Biomas = 0;
        var total01lo1 = 0;
        var total01lo2 = 0;
        var total02lo1 = 0;
        var total02lo2 = 0;
        var total03lo1 = 0;
        var total03lo2 = 0;
        var total04lo1 = 0;
        var total04lo2 = 0;

        for (var k = 0; k < resultArr.length; k++) {
          var myArray = resultArr[k]._id.hoursx.split(" ");

          if (firstOfDay == 0 && parseInt(myArray[1]) >= 6) {
            dateTime = myArray[0];
            firstOfDay = 1;
          } else if (firstOfDay == 1) {
            if (dateTime != myArray[0] && parseInt(myArray[1]) >= 6) {
              var totalAll = loadcell01Prv + loadcell02Prv;
              const resultMaterial = Promise.await(Meteor.call('material.getMaterial', myArray[0]));

              if (resultMaterial != "") {
                // dataReport.push({
                // 'Thời gian' : dateTime,
                // 'Bộ cân01'  :loadcell01Prv,
                // 'Bộ cân02'  :loadcell02Prv,
                // 'Tổng'      :  totalAll,
                // 'Tổng Than': totalLC01Than + totalLC02Than,
                // 'Tổng Biomas':  totalLC01Biomas + totalLC02Biomas,									
                // 'Lò Tầng Sôi 1':  total01lo1 + total01lo2,										
                // 'Lò Tầng Sôi 2':  total02lo1 + total02lo2,										
                // 'Lò Tầng Sôi 3':  total03lo1 + total03lo2,										
                // 'Lò Tầng Sôi 4':  total04lo1 + total04lo2,			
                // 'Củi băm'	: parseFloat((totalAll * parseFloat(resultMaterial[0].cuibam)) / 100).toFixed(1),
                // 'Mùn cưa'	: parseFloat((totalAll * parseFloat(resultMaterial[0].muncua)) / 100).toFixed(1),
                // 'Hạt điều': parseFloat((totalAll * parseFloat(resultMaterial[0].hatdieu)) / 100).toFixed(1),
                // 'Dăm bào'	: parseFloat((totalAll * parseFloat(resultMaterial[0].dambao)) / 100).toFixed(1),
                // 'Vỏ cây nghiền':parseFloat((totalAll * parseFloat(resultMaterial[0].caynghien)) / 100).toFixed(1),
                // 'Bột xước'	: parseFloat((totalAll * parseFloat(resultMaterial[0].botxuoc)) / 100).toFixed(1),
                // 'Củi đốt'	: parseFloat((totalAll * parseFloat(resultMaterial[0].cuidot)) / 100).toFixed(1),
                // 'Trấu': parseFloat((totalAll * parseFloat(resultMaterial[0].trau)) / 100).toFixed(1),
                // 'Gùi bắp'	: parseFloat((totalAll * parseFloat(resultMaterial[0].guibap)) / 100).toFixed(1),						
                // }); 
                var basicReport = [];
                let searchCriteria = {};
                basicReport = [{
                  'desc': 'Thời gian',
                  'value': dateTime
                }, {
                  'desc': 'Bộ cân01',
                  'value': loadcell01Prv
                }, {
                  'desc': 'Bộ cân02',
                  'value': loadcell02Prv
                }, {
                  'desc': 'Tổng',
                  'value': totalAll
                }, {
                  'desc': 'Tổng Than',
                  'value': totalLC01Than + totalLC02Than
                }, {
                  'desc': 'Tổng Biomas',
                  'value': totalLC01Biomas + totalLC02Biomas
                }, {
                  'desc': 'Lò Tầng Sôi 1',
                  'value': total01lo1 + total01lo2
                }, {
                  'desc': 'Lò Tầng Sôi 2',
                  'value': total02lo1 + total02lo2
                }, {
                  'desc': 'Lò Tầng Sôi 3',
                  'value': total03lo1 + total03lo2
                }, {
                  'desc': 'Lò Tầng Sôi 4',
                  'value': total04lo1 + total04lo2
                }];
                resultMaterial[0].material.forEach((element, index) => {
                  let item = element.desc;
                  item = item.concat("(", element.value, ")"); //console.log("item " + item)

                  searchCriteria[item] = [];
                  searchCriteria[item].push(parseFloat(totalAll * parseFloat(element.value) / 100).toFixed(1));
                });
                basicReport.forEach((element, index) => {
                  searchCriteria[element.desc] = [];
                  searchCriteria[element.desc].push(element.value);
                });
                dataReport.push(searchCriteria);
              } else {
                dataReport.push({
                  'Thời gian': dateTime,
                  'Bộ cân01': loadcell01Prv,
                  'Bộ cân02': loadcell02Prv,
                  'Tổng': totalAll,
                  'Tổng Than': totalLC01Than + totalLC02Than,
                  'Tổng Biomas': totalLC01Biomas + totalLC02Biomas
                });
              }

              dataLC01.push(Number(loadcell01Prv));
              dataLC02.push(Number(loadcell02Prv));
              dataTime.push(dateTime.substring(5));
              dateTime = myArray[0];
              loadcell01Prv = 0;
              loadcell02Prv = 0;
              totalLC01Biomas = 0;
              totalLC02Biomas = 0;
              total01lo1 = 0;
              total01lo2 = 0;
              total02lo1 = 0;
              total02lo2 = 0;
              total03lo1 = 0;
              total03lo2 = 0;
              total04lo1 = 0;
              total04lo2 = 0;
            }
          }

          for (var m = 0; m < resultArr[k].invoiceDate.length; m++) {
            material = parseInt(resultArr[k].invoiceDate[m].type[0].material);
            boiler = parseInt(resultArr[k].invoiceDate[m].type[0].boiler);

            switch (resultArr[k].invoiceDate[m].myPlace) {
              case "Weighing1":
                //Biomas
                loadcell01Prv = loadcell01Prv + parseInt(resultArr[k].invoiceDate[m].myStamp);

                switch (material) {
                  case 0:
                    //Biomas
                    totalLC01Biomas = totalLC01Biomas + parseInt(resultArr[k].invoiceDate[m].myStamp);
                    break;

                  case 1:
                    //Than
                    totalLC01Than = totalLC02Than + parseInt(resultArr[k].invoiceDate[m].myStamp);
                    break;

                  default:
                    break;
                }

                switch (boiler) {
                  case 1:
                    //Lo 1
                    total01lo1 = total01lo1 + parseInt(resultArr[k].invoiceDate[m].myStamp);
                    break;

                  case 2:
                    //Lo 2
                    total02lo1 = total02lo1 + parseInt(resultArr[k].invoiceDate[m].myStamp);
                    break;

                  case 3:
                    //Lo 3
                    total03lo1 = total013o1 + parseInt(resultArr[k].invoiceDate[m].myStamp);
                    break;

                  case 4:
                    //Lo 4
                    total04lo1 = total04lo1 + parseInt(resultArr[k].invoiceDate[m].myStamp);
                    break;

                  default:
                    break;
                }

                break;

              case "Weighing2":
                //Than
                loadcell02Prv = loadcell02Prv + parseInt(resultArr[k].invoiceDate[m].myStamp);

                switch (material) {
                  case 0:
                    //Biomas			
                    totalLC02Biomas = totalLC02Biomas + parseInt(resultArr[k].invoiceDate[m].myStamp);
                    break;

                  case 1:
                    //Than		
                    totalLC02Than = totalLC02Than + parseInt(resultArr[k].invoiceDate[m].myStamp);
                    break;

                  default:
                    break;
                }

                switch (boiler) {
                  case 1:
                    //Lo 1
                    total01lo2 = total01lo2 + parseInt(resultArr[k].invoiceDate[m].myStamp);
                    break;

                  case 2:
                    //Lo 2
                    total02lo2 = total02lo2 + parseInt(resultArr[k].invoiceDate[m].myStamp);
                    break;

                  case 3:
                    //Lo 3
                    total03lo2 = total013o2 + parseInt(resultArr[k].invoiceDate[m].myStamp);
                    break;

                  case 4:
                    //Lo 4
                    total04lo2 = total04lo2 + parseInt(resultArr[k].invoiceDate[m].myStamp);
                    break;

                  default:
                    break;
                }

                break;

              default:
                break;
            }
          }
        }

        dataBlock.push({
          _id: "Bộ cân 1",
          type: 'bar',
          stack: 'Stack 0',
          data: dataLC01,
          time: dataTime
        });
        dataBlock.push({
          _id: "Bộ cân 2",
          type: 'bar',
          stack: 'Stack 0',
          data: dataLC02,
          time: dataTime
        });
        dataBlock.push({
          _id: "Report",
          data: dataReport
        });
        return dataBlock;
      });
    },

    //================================================================================
    'biomasevent.getBiomasInTime'(startTime, endTime) {
      return Promise.asyncApply(() => {
        var dataBlock = [];
        var resultArr = []; //console.log("startTimeParam " + startTime + ", endTimeParam " + endTime );

        const result = Promise.await(BiomasEvent.rawCollection().aggregate([{
          $match: {
            sTime: {
              $gte: startTime,
              $lte: endTime
            }
          }
        }, {
          $set: {
            datesx: {
              $dateToString: {
                format: "%m-%d",
                date: {
                  $add: [new Date(0), "$sTime"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            }
          }
        }, {
          $set: {
            hoursx: {
              $dateToString: {
                format: "%Y-%m-%d %H:%M",
                date: {
                  $add: [new Date(0), "$sTime"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            }
          }
        }, {
          $match: {
            valueE: {
              $gt: 0,
              $lte: 10000
            }
          }
        }, {
          $match: {
            valueS: {
              $gt: 0,
              $lte: 10000
            }
          }
        }, {
          $project: {
            _id: "$name",
            material: {
              $subtract: ["$valueE", "$valueS"]
            },
            datesx: "$datesx",
            hoursx: "$hoursx"
          }
        }, {
          $match: {
            material: {
              $gt: 0,
              $lte: 10000
            }
          }
        }, {
          $group: {
            _id: {
              hoursx: "$hoursx",
              name: "$_id"
            },
            sumPoints: {
              $sum: "$material"
            }
          }
        }, {
          $sort: {
            "_id.hoursx": 1
          }
        }, {
          $group: {
            _id: {
              hoursx: "$_id.hoursx"
            },
            sums: {
              $sum: "$sumPoints"
            },
            invoiceDate: {
              $push: {
                "myPlace": "$_id.name",
                "myStamp": "$sumPoints"
              }
            }
          }
        }, {
          $sort: {
            "_id.hoursx": 1
          }
        }]).forEach(function (doc) {
          resultArr.push(doc);
        }));
        var loadcell01Prv = 0;
        var loadcell02Prv = 0;
        var firstOfDay = 0;
        var dateTime = 0;
        var load = 0;
        var dateTime = 0;
        var dataLC01 = [];
        var dataLC02 = [];
        var dataTime = [];
        var dataReport = [];
        var totalAll = 0;

        for (var k = 0; k < resultArr.length; k++) {
          var myArray = resultArr[k]._id.hoursx.split(" ");

          if (firstOfDay == 0 && parseInt(myArray[1]) >= 6) {
            dateTime = myArray[0];
            firstOfDay = 1;
          } else if (firstOfDay == 1) {
            if (dateTime != myArray[0] && parseInt(myArray[1]) >= 6) {
              totalAll = parseInt((loadcell01Prv + loadcell02Prv) / 1000);
              dataReport.push(totalAll);
              dataTime.push(dateTime.substring(5));
              dateTime = myArray[0];
              loadcell01Prv = 0;
              loadcell02Prv = 0;
            }
          }

          for (var m = 0; m < resultArr[k].invoiceDate.length; m++) {
            switch (resultArr[k].invoiceDate[m].myPlace) {
              case "Weighing1":
                //Biomas
                loadcell01Prv = loadcell01Prv + parseInt(resultArr[k].invoiceDate[m].myStamp);
                break;

              case "Weighing2":
                //Than
                loadcell02Prv = loadcell02Prv + parseInt(resultArr[k].invoiceDate[m].myStamp);
                break;

              default:
                break;
            }
          }
        }

        totalAll = parseInt((loadcell01Prv + loadcell02Prv) / 1000);

        if (resultArr.length > 5 && totalAll > 0) {
          dataReport.push(parseInt((loadcell01Prv + loadcell02Prv) / 1000));
          dataTime.push(dateTime.substring(5));
        }

        dataBlock.push({
          _id: "Biomas(1000kg)",
          type: 'bar',
          data: dataReport,
          time: dataTime
        });
        return dataBlock;
      });
    },

    //================================================================================
    'biomasevent.getShiftWorkingDaily'(startTime, endTime, selectBoiler) {
      return Promise.asyncApply(() => {
        var dataBlock = [];
        var resultArr = []; //console.log("startTimeParam " + startTime + ", endTimeParam " + endTime + ", selectBoiler " + selectBoiler);

        const result = Promise.await(BiomasEvent.rawCollection().aggregate([{
          $match: {
            sTime: {
              $gte: startTime,
              $lte: endTime
            }
          }
        }, {
          $set: {
            datesx: {
              $dateToString: {
                format: "%m-%d",
                date: {
                  $add: [new Date(0), "$sTime"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            }
          }
        }, {
          $set: {
            hoursx: {
              $dateToString: {
                format: "%m-%d %H",
                date: {
                  $add: [new Date(0), "$sTime"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            }
          }
        }, {
          $match: {
            valueE: {
              $gt: 0,
              $lte: 10000
            }
          }
        }, {
          $match: {
            valueS: {
              $gt: 0,
              $lte: 10000
            }
          }
        }, {
          $project: {
            _id: "$name",
            material: {
              $subtract: ["$valueE", "$valueS"]
            },
            datesx: "$datesx",
            hoursx: "$hoursx"
          }
        }, {
          $match: {
            material: {
              $gt: 0,
              $lte: 4000
            }
          }
        }, {
          $group: {
            _id: {
              hoursx: "$hoursx",
              name: "$_id"
            },
            sumPoints: {
              $sum: "$material"
            }
          }
        }, {
          $sort: {
            "_id.hoursx": 1
          }
        }, {
          $group: {
            _id: {
              hoursx: "$_id.hoursx"
            },
            sums: {
              $sum: "$sumPoints"
            },
            invoiceDate: {
              $push: {
                "myPlace": "$_id.name",
                "myStamp": "$sumPoints"
              }
            }
          }
        }, {
          $sort: {
            "_id.hoursx": 1
          }
        }]).forEach(function (doc) {
          resultArr.push(doc);
        }));
        var loadcell01Prv = 0;
        var loadcell02Prv = 0;
        var firstOfDay = 0;
        var hoursx = 0;
        var datesx = "";
        var datetime = "";
        var dataLC01 = [];
        var dataLC02 = [];
        var dataTime = [];
        var dataReport = [];
        var total = 0;
        var loadcell01 = 0;
        var loadcell02 = 0;
        var shiftn = "Ca 1";

        for (var k = 0; k < resultArr.length; k++) {
          var myArray = resultArr[k]._id.hoursx.split(" ");

          hoursx = myArray[1];

          if (hoursx >= 6 && hoursx < 14) {
            shiftn = "Ca 1";
          } else if (hoursx >= 14 && hoursx < 22) {
            shiftn = "Ca 2";
          } else {
            shiftn = "Ca 3";
          }

          datetime = resultArr[k]._id.hoursx;
          loadcell01Prv = 0;
          loadcell02Prv = 0;

          for (var m = 0; m < resultArr[k].invoiceDate.length; m++) {
            switch (resultArr[k].invoiceDate[m].myPlace) {
              case "Weighing1":
                //Biomas
                loadcell01Prv = parseInt(resultArr[k].invoiceDate[m].myStamp);
                break;

              case "Weighing2":
                //Than
                loadcell02Prv = parseInt(resultArr[k].invoiceDate[m].myStamp);
                break;

              default:
                break;
            }
          }

          dataReport.push({
            time: datetime,
            shift: shiftn,
            bocan01: loadcell01Prv,
            bocan02: loadcell02Prv,
            total: resultArr[k].sums
          });
          total = total + parseInt(resultArr[k].sums);
          loadcell01 = loadcell01 + parseInt(loadcell01Prv);
          loadcell02 = loadcell02 + parseInt(loadcell02Prv);
          dataLC01.push(Number(loadcell01Prv));
          dataLC02.push(Number(loadcell02Prv));
          dataTime.push(datetime);
        }

        dataReport.push({
          time: "",
          shift: "Tổng",
          bocan01: loadcell01,
          bocan02: loadcell02,
          total: total
        });
        dataBlock.push({
          _id: "Bộ cân 1",
          type: 'bar',
          stack: 'Stack 0',
          data: dataLC01,
          time: dataTime
        });
        dataBlock.push({
          _id: "Bộ cân 2",
          type: 'bar',
          stack: 'Stack 0',
          data: dataLC02,
          time: dataTime
        });
        dataBlock.push({
          _id: "Report",
          data: dataReport
        });
        return dataBlock;
      });
    }

  });
}

Meteor.methods({
  //================================================================================		
  'biomasevent.getHistorian'(site, startTimeParam, endTimeParam) {
    var dataBlock = [];
    var index = 0;
    var endTime = "";
    var timestamp = "";
    let options = {
      year: '2-digit',
      month: 'numeric',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    };
    BiomasEvent.find({
      sTime: {
        $gte: startTimeParam,
        $lte: endTimeParam
      }
    }, {
      sort: {
        _id: -1
      }
    }).forEach(function (doc) {
      var name = doc.name;

      if (doc.eTime == 0) {
        endTime = "";
      } else {
        endTime = new Date(doc.eTime).toLocaleString({}, options);
      }

      timestamp = new Date(doc.sTime).toLocaleString({}, options);

      if (parseInt(doc.valueE) <= 0 || parseInt(doc.valueS) <= 0) {//
      } else {
        dataBlock.push({
          _id: doc._id,
          objName: doc.name,
          timestamp: new Date(doc.sTime).toLocaleString({}, options),
          endTime: endTime,
          valueS: doc.valueS,
          valueE: doc.valueE,
          total: parseInt(doc.valueE) - parseInt(doc.valueS)
        });
      }
    }); //console.log("dataBlock: " + dataBlock);

    return dataBlock;
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"biomasmaterial.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/biomasmaterial.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  BiomasMaterial: () => BiomasMaterial
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let Security;
module.link("./security", {
  default(v) {
    Security = v;
  }

}, 2);
const BiomasMaterial = new Mongo.Collection('biomasmaterial');

if (Meteor.isServer) {
  Meteor.methods({
    //================================================================================	
    'biomasmaterial.getdatablock'() {
      return Promise.asyncApply(() => {
        var dataBlock = [];
        Promise.await(BiomasMaterial.find({}, {
          sort: {
            startTime: 1
          }
        }).forEach(function (doc) {
          dataBlock.push({
            _id: doc._id,
            startTimedsc: new Date(doc.startTime).toLocaleDateString({
              timeZone: 'Asia/Ho_Chi_Minh'
            }),
            endTimedsc: new Date(doc.endTime).toLocaleDateString({
              timeZone: 'Asia/Ho_Chi_Minh'
            }),
            startTime: doc.startTime,
            endTime: doc.endTime,
            cuibam: doc.cuibam,
            muncua: doc.muncua,
            hatdieu: doc.hatdieu,
            dambao: doc.dambao,
            caynghien: doc.caynghien,
            botxuoc: doc.botxuoc,
            cuidot: doc.cuidot,
            trau: doc.trau,
            guibap: doc.guibap
          });
        }));
        return dataBlock;
      });
    },

    //================================================================================
    'biomasmaterial.getMaterial'(dateStr) {
      return Promise.asyncApply(() => {
        var dataBlock = [];
        const date = new Date(dateStr);
        console.log(date); // 👉️ Wed Jun 22 2022

        const timestampInMs = date.getTime();
        const result = Promise.await(BiomasMaterial.rawCollection().aggregate([{
          $match: {
            $expr: {
              $and: [{
                $lte: ["$startTime", timestampInMs]
              }, {
                $gte: ["$endTime", timestampInMs]
              }]
            }
          }
        }]).forEach(function (doc) {
          dataBlock.push(doc);
        }));
        return dataBlock;
      });
    },

    //================================================================================	
    'biomasmaterial.insert'(startTime, endTime, cuibam, muncua, hatdieu, dambao, caynghien, botxuoc, cuidot, trau, guibap) {
      return Promise.asyncApply(() => {
        if (!Security.checkRole(this.userId, 'Owner')) {
          throw new Meteor.Error("logged-in", "You are not permitted.");
        } else {
          const resultMaterials = Promise.await(Meteor.call('biomasmaterial.getMaterial', startTime));
          const resultMateriale = Promise.await(Meteor.call('biomasmaterial.getMaterial', endTime));

          if (resultMaterials != "" || resultMateriale != "") {
            throw new Meteor.Error("Trùng thời gian, hãy kiểm tra lại");
          } else {
            Promise.await(BiomasMaterial.insert({
              startTime,
              endTime,
              cuibam,
              muncua,
              hatdieu,
              dambao,
              caynghien,
              botxuoc,
              cuidot,
              trau,
              guibap
            }));
          }
        }

        return 0;
      });
    }

  });
} //================================================================================


Meteor.methods({
  //================================================================================		
  'biomasmaterial.findSite'(name) {
    var nameSite = BiomasMaterial.findOne({
      name: name
    });

    if (nameSite == null) {
      return 0;
    } else {
      return 1;
    }
  },

  //================================================================================	
  'biomasmaterial.remove'(taskId) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      BiomasMaterial.remove(taskId);
    }
  },

  //================================================================================	
  'biomasmaterial.update'(_id, cuibam, muncua, hatdieu, dambao, caynghien, botxuoc, cuidot, trau, guibap) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      BiomasMaterial.update(_id, {
        $set: {
          cuibam,
          muncua,
          hatdieu,
          dambao,
          caynghien,
          botxuoc,
          cuidot,
          trau,
          guibap
        }
      });
    }
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"cmdinterfaces.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/cmdinterfaces.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  CMDInterfaces: () => CMDInterfaces
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
const CMDInterfaces = new Mongo.Collection('cmdinterfaces');

if (Meteor.isServer) {
  Meteor.methods({
    //================================================================================
    'cmdinterfaces.getHistorianCmd'(startTimeParam, endTimeParam) {
      return Promise.asyncApply(() => {
        const result = Promise.await(CMDInterfaces.rawCollection().aggregate([{
          $match: {
            $and: [{
              createdAt: {
                $gte: startTimeParam,
                $lte: endTimeParam
              }
            }]
          }
        }, {
          $sort: {
            createdAt: -1
          }
        }, {
          $project: {
            "_id": "$_id",
            "obj": "$objName",
            "timestamp": {
              $dateToString: {
                format: "%Y-%m-%d %H:%M:%S",
                date: {
                  $add: [new Date(0), "$createdAt"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            },
            "cmd": "$name",
            "val": "$value",
            "username": "$username"
          }
        }]));
        return result.toArray();
      });
    }

  });
}

Meteor.methods({
  //================================================================================
  'cmdinterfaces.insert'(name, objName, plc, typedata, actions, address, value, length, username, createAt) {
    //Nothing
    address = parseInt(address);
    value = Number(value);
    CMDInterfaces.insert({
      name,
      objName,
      plc,
      actions,
      address,
      value,
      length,
      username,
      typedata //createAt

    });
  },

  //================================================================================
  'cmdinterfaces.insertLocal'(name, objName, plc, typedata, actions, address, value, length, username, createAt) {
    address = parseInt(address);
    value = Number(value);

    switch (parseInt(typedata)) {
      case 0:
        //Boolean
        value = parseInt(value);
        CMDInterfaces.insert({
          name,
          objName,
          plc,
          actions,
          address,
          value,
          length,
          username //createAt

        });
        break;

      case 1:
        //Integer
        value = parseInt(value);
        CMDInterfaces.insert({
          name,
          objName,
          plc,
          actions,
          address,
          value,
          length,
          username //createAt

        });
        break;

      case 2:
        //Double integer for PLC M241
        var low = parseInt(value) & 0xFFFF;
        var high = parseInt(value) >> 16;
        value = low;
        value = parseInt(value);
        CMDInterfaces.insert({
          name,
          objName,
          plc,
          actions,
          address,
          value,
          length,
          username //createAt	

        }); //console.log("dataBlock low: " + low + " value low: " + value);	

        value = high;
        value = parseInt(value);
        address = address + 1;
        CMDInterfaces.insert({
          name,
          objName,
          plc,
          actions,
          address,
          value,
          length,
          username //createAt	

        });
        break;

      case 4:
        //Double integer for Logo
        var high = parseInt(value) & 0xFFFF;
        var low = parseInt(value) >> 16;
        value = low;
        value = parseInt(value);
        CMDInterfaces.insert({
          name,
          objName,
          plc,
          actions,
          address,
          value,
          length,
          username //createAt	

        }); //console.log("dataBlock low: " + low + " value low: " + value);	

        value = high;
        value = parseInt(value);
        address = address + 1;
        CMDInterfaces.insert({
          name,
          objName,
          plc,
          actions,
          address,
          value,
          length,
          username //createAt	

        });
        break;

      case 3:
        //Real
        var f32 = new Float32Array(1);
        f32[0] = value;
        var ui16 = new Uint16Array(f32.buffer);
        value = ui16[0];
        value = parseInt(value);
        CMDInterfaces.insert({
          name,
          objName,
          plc,
          actions,
          address,
          value,
          length,
          username //createAt	

        });
        value = ui16[1];
        value = parseInt(value);
        address = address + 1;
        CMDInterfaces.insert({
          name,
          objName,
          plc,
          actions,
          address,
          value,
          length,
          username //createAt	

        });
        break;

      default:
        break;
    }
  },

  //================================================================================
  'cmdinterfaces.insertTMP'(name, objName, plc, typedata, actions, address, value, length, username, createAt) {
    address = parseInt(address);
    value = Number(value);

    switch (parseInt(typedata)) {
      case 0:
        //Boolean
        value = parseInt(value);
        CMDInterfaces.insert({
          name,
          objName,
          plc,
          actions,
          address,
          value,
          length,
          username //createAt

        });
        break;

      case 1:
        //Integer
        value = parseInt(value);
        CMDInterfaces.insert({
          name,
          objName,
          plc,
          actions,
          address,
          value,
          length,
          username //createAt

        });
        break;

      case 2:
        //Double integer for PLC M241
        var low = parseInt(value) & 0xFFFF;
        var high = parseInt(value) >> 16;
        value = low;
        value = parseInt(value);
        CMDInterfaces.insert({
          name,
          objName,
          plc,
          actions,
          address,
          value,
          length,
          username //createAt	

        }); //console.log("dataBlock low: " + low + " value low: " + value);	

        value = high;
        value = parseInt(value);
        address = address + 1;
        CMDInterfaces.insert({
          name,
          objName,
          plc,
          actions,
          address,
          value,
          length,
          username //createAt	

        });
        break;

      case 4:
        //Double integer for Logo
        var high = parseInt(value) & 0xFFFF;
        var low = parseInt(value) >> 16;
        value = low;
        value = parseInt(value);
        CMDInterfaces.insert({
          name,
          objName,
          plc,
          actions,
          address,
          value,
          length,
          username //createAt	

        }); //console.log("dataBlock low: " + low + " value low: " + value);	

        value = high;
        value = parseInt(value);
        address = address + 1;
        CMDInterfaces.insert({
          name,
          objName,
          plc,
          actions,
          address,
          value,
          length,
          username //createAt	

        });
        break;

      case 3:
        //Real
        var f32 = new Float32Array(1);
        f32[0] = value;
        var ui16 = new Uint16Array(f32.buffer);
        value = ui16[0];
        value = parseInt(value);
        CMDInterfaces.insert({
          name,
          objName,
          plc,
          actions,
          address,
          value,
          length,
          username //createAt	

        });
        value = ui16[1];
        value = parseInt(value);
        address = address + 1;
        CMDInterfaces.insert({
          name,
          objName,
          plc,
          actions,
          address,
          value,
          length,
          username //createAt	

        });
        break;

      default:
        break;
    }
  },

  //================================================================================		
  'cmdinterfaces.getdatahistorian'(startTimeParam) {
    var dataBlock = [];
    var index = 0;
    CMDInterfaces.find({
      createdAt: {
        $gte: startTimeParam
      }
    }, {
      sort: {
        createdAt: -1
      }
    }).forEach(function (doc) {
      dataBlock.push({
        _id: doc._id,
        index: index,
        obj: doc.objName,
        createdAt: new Date(doc.createdAt).toLocaleString(),
        command: doc.name,
        value: doc.value,
        username: doc.username
      });
      index = index + 1;
    });
    return dataBlock;
  },

  //================================================================================		
  'cmdinterfaces.getdatahistorianFrom'(startTimeParam, endTimeParam) {
    var dataBlock = [];
    var index = 0;
    CMDInterfaces.find({
      createdAt: {
        $gte: startTimeParam,
        $lte: endTimeParam
      }
    }, {
      sort: {
        createdAt: -1
      }
    }).forEach(function (doc) {
      dataBlock.push({
        _id: doc._id,
        index: index,
        obj: doc.objName,
        createdAt: new Date(doc.createdAt).toLocaleString(),
        command: doc.name,
        value: doc.value,
        username: doc.username
      });
      index = index + 1;
    });
    return dataBlock;
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"material.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/material.js                                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  Material: () => Material
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let Security;
module.link("./security", {
  default(v) {
    Security = v;
  }

}, 2);
const Material = new Mongo.Collection('material');

if (Meteor.isServer) {
  Meteor.methods({
    //================================================================================	
    'material.getdatablock'() {
      return Promise.asyncApply(() => {
        var dataBlock = [];
        Promise.await(Material.find({}, {
          sort: {
            startTime: 1
          }
        }).forEach(function (doc) {
          dataBlock.push({
            _id: doc._id,
            startTimedsc: new Date(doc.startTime).toLocaleDateString({
              timeZone: 'Asia/Ho_Chi_Minh'
            }),
            endTimedsc: new Date(doc.endTime).toLocaleDateString({
              timeZone: 'Asia/Ho_Chi_Minh'
            }),
            startTime: doc.startTime,
            endTime: doc.endTime,
            material: doc.material
          });
        }));
        return dataBlock;
      });
    },

    //================================================================================
    'material.getMaterial'(dateStr) {
      return Promise.asyncApply(() => {
        var dataBlock = [];
        const date = new Date(dateStr); //console.log(date); // 👉️ Wed Jun 22 2022

        const timestampInMs = date.getTime();
        const result = Promise.await(Material.rawCollection().aggregate([{
          $match: {
            $expr: {
              $and: [{
                $lte: ["$startTime", timestampInMs]
              }, {
                $gte: ["$endTime", timestampInMs]
              }]
            }
          }
        }]).forEach(function (doc) {
          //console.log("getMaterial " + doc.startTime + ", endTimeParam " + doc.endTime);
          dataBlock.push(doc);
        }));
        return dataBlock;
      });
    },

    //================================================================================
    'material.getMaterialTimes'(timestampInMs) {
      return Promise.asyncApply(() => {
        var dataBlock = [];
        const result = Promise.await(Material.rawCollection().aggregate([{
          $match: {
            $expr: {
              $and: [{
                $lte: ["$startTime", timestampInMs]
              }, {
                $gte: ["$endTime", timestampInMs]
              }]
            }
          }
        }]).forEach(function (doc) {
          //console.log("getMaterial " + doc.startTime + ", endTimeParam " + doc.endTime);
          dataBlock.push(doc);
        }));
        return dataBlock;
      });
    },

    //================================================================================	
    'material.insert'(startTime, endTime, material) {
      return Promise.asyncApply(() => {
        if (!Security.checkRole(this.userId, 'Owner')) {
          throw new Meteor.Error("logged-in", "You are not permitted.");
        } else {
          const resultMaterials = Promise.await(Meteor.call('material.getMaterial', startTime));
          const resultMateriale = Promise.await(Meteor.call('material.getMaterial', endTime));

          if (resultMaterials != "" || resultMateriale != "") {
            throw new Meteor.Error("Trùng thời gian, hãy kiểm tra lại");
          } else {
            Promise.await(Material.insert({
              startTime,
              endTime,
              material
            }));
          }
        }

        return 0;
      });
    }

  });
} //================================================================================


Meteor.methods({
  //================================================================================		
  'material.findSite'(name) {
    var nameSite = Material.findOne({
      name: name
    });

    if (nameSite == null) {
      return 0;
    } else {
      return 1;
    }
  },

  //================================================================================	
  'material.remove'(taskId) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      Material.remove(taskId);
    }
  },

  //================================================================================	
  'material.update'(_id, material) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      Material.update(_id, {
        $set: {
          material
        }
      });
    }
  },

  //================================================================================	
  'material.updateTime'(_id, startTime, endTime) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      Material.update(_id, {
        $set: {
          startTime,
          endTime
        }
      });
    }
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"modbusinterfaces.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/modbusinterfaces.js                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  ModbusInterfaces: () => ModbusInterfaces
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let Security;
module.link("./security", {
  default(v) {
    Security = v;
  }

}, 2);
let PLCInterfaces;
module.link("./plcinterfaces.js", {
  default(v) {
    PLCInterfaces = v;
  }

}, 3);
const ModbusInterfaces = new Mongo.Collection('modbusinterfaces');

if (Meteor.isServer) {
  Meteor.methods({
    'modbusinterfaces.getdatablockasync'() {
      return Promise.asyncApply(() => {
        var dataBlock = [];
        return Promise.await(ModbusInterfaces.rawCollection().aggregate([{
          $lookup: {
            from: "plcinterfaces",
            localField: "selectPLC",
            foreignField: "_id",
            as: "plc"
          }
        }, {
          $unwind: "$plc"
        }, {
          $lookup: {
            from: "siteinterfaces",
            localField: "plc.site",
            foreignField: "_id",
            as: "site"
          }
        }, {
          $unwind: "$site"
        }, {
          $project: {
            "_id": "$_id",
            "nsite": "$site.name",
            "idSite": "$site._id",
            "idPLC": "$plc._id",
            "selectPLC": "$plc.name",
            "datablock": "$datablock",
            "startaddress": "$startaddress",
            "quantity": "$quantity",
            "numTag": "$numTag"
          }
        }]).toArray());
      });
    }

  });
} //================================================================================


Meteor.methods({
  //================================================================================	
  'modbusinterfaces.getdatablock'() {
    var dataBlock = [];
    ModbusInterfaces.find({}, {
      sort: {
        createDate: -1
      }
    }).forEach(function (doc) {
      var plc = Meteor.call('plcinterfaces.findplc', doc.selectPLC);
      var nsite = Meteor.call('siteinterfaces.getname', plc.site);
      dataBlock.push({
        _id: doc._id,
        nsite: nsite,
        idSite: plc.site,
        selectPLC: plc.name,
        idPLC: doc.selectPLC,
        datablock: doc.datablock,
        startaddress: doc.startaddress,
        quantity: doc.quantity
      });
    });
    return dataBlock;
  },

  //================================================================================	
  'modbusinterfaces.getDatablockNumber'(id_plc, addressVar, typeData) {
    var address = 0;
    var setBlockNumber = 0;
    ModbusInterfaces.find({
      selectPLC: id_plc
    }).forEach(function (doc) {
      if (typeData == "Bool") {
        var words = 0;
        words = addressVar.split(".");
        address = parseInt(words[0]);
      } else {
        address = parseInt(addressVar);
      }

      var lastRead = parseInt(doc.startaddress) + parseInt(doc.quantity);

      if (address >= parseInt(doc.startaddress) && address <= lastRead) {
        setBlockNumber = doc.datablock;
      }
    });

    if (setBlockNumber == 0) {
      return null;
    }

    return setBlockNumber;
  },

  //================================================================================	
  'modbusinterfaces.insert'(selectPLC, datablock1, startaddress, quantity, datachange, createDate) {
    var datablock = 1;

    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      var data = ModbusInterfaces.findOne({
        selectPLC: selectPLC
      }, {
        sort: {
          datablock: -1
        },
        limit: 1
      });

      if (data == null) {//
      } else {
        datablock = parseInt(data.datablock) + 2; //console.log("dataBlock: " + data.datablock + ", " + datablock);
      }

      ModbusInterfaces.insert({
        selectPLC,
        datablock,
        startaddress,
        quantity,
        datachange,
        createDate
      });
    }

    return 0;
  },

  //================================================================================	
  'modbusinterfaces.remove'(taskId) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      ModbusInterfaces.remove(taskId);
    }
  },

  //================================================================================	
  'modbusinterfaces.update'(_id, startaddress, quantity, datachange, createDate) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      ModbusInterfaces.update(_id, {
        $set: {
          startaddress,
          quantity,
          datachange,
          createDate
        }
      });
    }
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"objectsinterfaces.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/objectsinterfaces.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  ObjectsInterfaces: () => ObjectsInterfaces
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let TagsInterface;
module.link("./taginterfaces.js", {
  default(v) {
    TagsInterface = v;
  }

}, 2);
let ScreenInterfaces;
module.link("./screeninterfaces.js", {
  ScreenInterfaces(v) {
    ScreenInterfaces = v;
  }

}, 3);
let Security;
module.link("./security", {
  default(v) {
    Security = v;
  }

}, 4);
const ObjectsInterfaces = new Mongo.Collection('objectsinterfaces');

if (Meteor.isServer) {
  //==============================================================================PLANT
  Meteor.publish('getObjectsStatic', function getObjectsStatic(argumentsFind) {
    console.log("getObjectsStatic ");
    return ObjectsInterfaces.find(argumentsFind);
  });
  Meteor.methods({
    //================================================================================	
    'objectsinterfaces.insertasync'(objName, assignmentTag, screen, xPositon, yPositon, xScale, yScale, createDate) {
      return Promise.asyncApply(() => {
        if (!Security.checkRole(this.userId, 'Owner')) {
          throw new Meteor.Error("logged-in", "You are not permitted.");
        } else {
          if (Promise.await(ObjectsInterfaces.findOne({
            $and: [{
              screen: {
                $eq: screen
              }
            }, {
              objName: {
                $eq: objName
              }
            }]
          })) != null) {
            throw new Meteor.Error("Duplicate tag, Please check name of Tag again");
          } else {
            Promise.await(ObjectsInterfaces.insert({
              objName,
              assignmentTag,
              screen,
              xPositon,
              yPositon,
              xScale,
              yScale,
              createDate
            }));
          }

          return 0;
        }
      });
    },

    //================================================================================	
    'objectsinterfaces.getdatablockasync'() {
      return Promise.asyncApply(() => {
        return Promise.await(ObjectsInterfaces.rawCollection().aggregate([{
          $lookup: {
            from: "taginterfaces",
            localField: "assignmentTag",
            foreignField: "_id",
            as: "tag"
          }
        }, {
          $unwind: "$tag"
        }, {
          $lookup: {
            from: "screeninterfaces",
            localField: "screen",
            foreignField: "_id",
            as: "screen"
          }
        }, {
          $unwind: "$screen"
        }, {
          $lookup: {
            from: "siteinterfaces",
            localField: "screen.site",
            foreignField: "_id",
            as: "site"
          }
        }, {
          $unwind: "$site"
        }, {
          $sort: {
            "screen.name": 1
          }
        }, {
          $project: {
            "_id": "$_id",
            "nsite": "$site.name",
            "idSite": "$site._id",
            "objName": "$objName",
            "id_tag": "$tag._id",
            "assignmentTag": "$tag.tagName",
            "id_screen": "$screen._id",
            "screen": "$screen.name",
            "xPositon": "$xPositon",
            "yPositon": "$yPositon",
            "xScale": "$xScale",
            "yScale": "$yScale",
            "rotate": "$rotate"
          }
        }]).toArray());
      });
    },

    //================================================================================	
    'objectsinterfaces.getObjectsasyncStatic'(screenName) {
      return Promise.asyncApply(() => {
        return Promise.await(ObjectsInterfaces.rawCollection().aggregate([{
          $match: {
            $and: [{
              screen: {
                $eq: screenName
              }
            }, {
              staticObj: {
                $eq: 1
              }
            }]
          }
        }, {
          $sort: {
            createDate: -1
          }
        }, {
          $lookup: {
            from: "taginterfaces",
            localField: "assignmentTag",
            foreignField: "_id",
            as: "tags"
          }
        }, {
          $unwind: "$tags"
        }]).toArray());
      });
    },

    //================================================================================	
    'objectsinterfaces.getObjectsasync'(screenName) {
      return Promise.asyncApply(() => {
        return Promise.await(ObjectsInterfaces.rawCollection().aggregate([{
          $match: {
            $and: [{
              screen: {
                $eq: screenName
              }
            }, {
              staticObj: {
                $eq: 0
              }
            }]
          }
        }, {
          $lookup: {
            from: "taginterfaces",
            localField: "assignmentTag",
            foreignField: "_id",
            as: "tags"
          }
        }, {
          $unwind: "$tags"
        }, {
          $sort: {
            "tags.tagName": 1
          }
        }]).toArray());
      });
    },

    //================================================================================	
    'objectsinterfaces.cntObjStatic'(screen, typeObjects) {
      return Promise.asyncApply(() => {
        return Promise.await(ObjectsInterfaces.find({
          $and: [{
            screen: {
              $eq: screen
            }
          }, {
            typeObjects: {
              $eq: typeObjects
            }
          }]
        }).count());
      });
    }

  });
}

Meteor.methods({
  //================================================================================	
  'objectsinterfaces.getdatablock'() {
    var dataBlock = [];
    ObjectsInterfaces.find({}, {
      sort: {
        createDate: -1
      }
    }).forEach(function (doc) {
      var nameTag = Meteor.call('taginterfaces.getname', doc.assignmentTag);
      var screen = Meteor.call('screeninterfaces.getscreen', doc.screen);
      var nsite = Meteor.call('siteinterfaces.getname', screen.site);
      dataBlock.push({
        _id: doc._id,
        nsite: nsite,
        idSite: screen.site,
        objName: doc.objName,
        id_tag: doc.assignmentTag,
        assignmentTag: nameTag,
        id_screen: doc.screen,
        screen: screen.name,
        xPositon: doc.xPositon,
        yPositon: doc.yPositon,
        rotate: doc.rotate,
        xScale: doc.xScale,
        yScale: doc.yScale,
        rotate: doc.rotate
      });
    });
    return dataBlock;
  },

  //================================================================================	
  'objectsinterfaces.getObjects'(screenName) {
    var dataBlock = [];
    var id_screen = Meteor.call('screeninterfaces.getid', screenName);
    ObjectsInterfaces.find({
      screen: id_screen
    }, {
      screen: 0,
      createDate: 0
    }).forEach(function (doc) {
      var tag = Meteor.call('taginterfaces.getTag', doc.assignmentTag);

      if (tag != null) {
        dataBlock.push({
          _id: doc._id,
          objName: doc.objName,
          assignmentTag: doc.assignmentTag,
          screen: doc.screen,
          tags: tag,
          xPositon: doc.xPositon,
          yPositon: doc.yPositon,
          xScale: doc.xScale,
          yScale: doc.yScale,
          rotate: doc.rotate
        });
      }
    });
    return dataBlock;
  },

  //================================================================================	
  'objectsinterfaces.insertStatic'(name, assignmentTag, screen, xPositon, yPositon, xScale, yScale, staticObj, typeObjects, createDate) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      var objName = "";
      var cntObj = 0;
      var cntObj = ObjectsInterfaces.find({
        $and: [{
          screen: {
            $eq: screen
          }
        }, {
          typeObjects: {
            $eq: typeObjects
          }
        }]
      }).count();
      cntObj = cntObj + 1;

      switch (typeObjects) {
        case "TCHObjs":
          if (cntObj < 10) {
            objName = objName.concat(name, "-00", cntObj);
          } else if (cntObj < 100) {
            objName = objName.concat(name, "-0", cntObj);
          } else {
            objName = objName.concat(name, "-", cntObj);
          }

          break;

        case "MPEObjs":
          if (cntObj < 10) {
            objName = objName.concat(name, "-0", cntObj);
          } else {
            objName = objName.concat(name, "-", cntObj);
          }

          break;

        default:
          objName = objName.concat(name, "-", cntObj);
          break;
      }

      if (ObjectsInterfaces.findOne({
        $and: [{
          screen: {
            $eq: screen
          }
        }, {
          objName: {
            $eq: objName
          }
        }]
      }) != null) {
        throw new Meteor.Error("Duplicate Object, Please check name of Object again");
      } else {
        ObjectsInterfaces.insert({
          objName,
          assignmentTag,
          screen,
          xPositon,
          yPositon,
          xScale,
          yScale,
          staticObj,
          typeObjects,
          createDate
        });
      }

      return 0;
    }
  },

  //================================================================================	
  'objectsinterfaces.insert'(objName, assignmentTag, screen, xPositon, yPositon, xScale, yScale, rotate, datachange, staticObj, createDate) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      if (ObjectsInterfaces.findOne({
        $and: [{
          screen: {
            $eq: screen
          }
        }, {
          objName: {
            $eq: objName
          }
        }]
      }) != null) {
        throw new Meteor.Error("Duplicate Object, Please check name of Object again");
      } else {
        ObjectsInterfaces.insert({
          objName,
          assignmentTag,
          screen,
          xPositon,
          yPositon,
          xScale,
          yScale,
          rotate,
          datachange,
          staticObj,
          createDate
        });
      }

      return 0;
    }
  },

  //================================================================================	
  'objectsinterfaces.update'(_id, objName, assignmentTag, screen, xPositon, yPositon, xScale, yScale, rotate, datachange, createDate) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      // if (ObjectsInterfaces.findOne({ $and: [ { screen: { $eq: screen } }, { objName: { $eq: objName }}]}) !=null)
      // {
      // throw new Meteor.Error("Duplicate Object, Please check name of Object again");
      // }
      // else 
      // {
      var rotate = parseInt(rotate);
      ObjectsInterfaces.update(_id, {
        $set: {
          objName,
          assignmentTag,
          screen,
          xPositon,
          yPositon,
          xScale,
          yScale,
          rotate,
          datachange,
          createDate
        }
      }); //}
    }
  },

  //================================================================================	
  'objectsinterfaces.remove'(taskId) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      ObjectsInterfaces.remove(taskId);
    }
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"plcinterfaces.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/plcinterfaces.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  PLCInterfaces: () => PLCInterfaces
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let Security;
module.link("./security", {
  default(v) {
    Security = v;
  }

}, 2);
let SITEInterfaces;
module.link("./siteinterfaces.js", {
  default(v) {
    SITEInterfaces = v;
  }

}, 3);
const PLCInterfaces = new Mongo.Collection('plcinterfaces');

if (Meteor.isServer) {
  Meteor.methods({
    // This code only runs on the server
    'plcinterfaces.getdatablockasync'() {
      return Promise.asyncApply(() => {
        var dataBlock = [];
        Promise.await(PLCInterfaces.rawCollection().aggregate([{
          $lookup: {
            from: "siteinterfaces",
            localField: "site",
            foreignField: "_id",
            as: "sitename"
          }
        }, {
          $unwind: "$sitename"
        }, {
          $replaceRoot: {
            newRoot: {
              $mergeObjects: [{
                nplc: "$name"
              }, {
                id_plc: "$_id"
              }, {
                protocol: "$protocol"
              }, {
                ipaddress: "$ipaddress"
              }, "$sitename"]
            }
          }
        }]).forEach(function (doc) {
          dataBlock.push({
            _id: doc.id_plc,
            nsite: doc.name,
            idSite: doc._id,
            name: doc.nplc,
            protocol: doc.protocol,
            ipaddress: doc.ipaddress
          });
        }));
        return dataBlock;
      });
    }

  });
} //================================================================================


Meteor.methods({
  //================================================================================	
  'plcinterfaces.getdatablock'() {
    var dataBlock = [];
    PLCInterfaces.find({}, {
      sort: {
        name: 1
      }
    }).forEach(function (doc) {
      var nsite = Meteor.call('siteinterfaces.getname', doc.site);
      dataBlock.push({
        _id: doc._id,
        nsite: nsite,
        idSite: doc.site,
        name: doc.name,
        protocol: doc.protocol,
        ipaddress: doc.ipaddress
      });
    });
    return dataBlock;
  },

  'plcinterfaces.findplc'(idPLC) {
    return PLCInterfaces.findOne({
      _id: idPLC
    });
  },

  //================================================================================		
  'plcinterfaces.getname'(idPLC) {
    var namePLC = PLCInterfaces.findOne({
      _id: idPLC
    });

    if (namePLC == null) {
      return null;
    } else {
      return namePLC.name;
    }
  },

  //================================================================================		
  'plcinterfaces.getsite'(idPLC) {
    var plc = PLCInterfaces.findOne({
      _id: idPLC
    });

    if (plc == null) {
      return null;
    } else {
      return plc.site;
    }
  },

  //================================================================================	
  'plcinterfaces.insert'(site, name, protocol, ipaddress, datachange, createDate) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      if (PLCInterfaces.findOne({
        $and: [{
          site: {
            $eq: site
          }
        }, {
          name: {
            $eq: name
          }
        }]
      }) != null) {
        throw new Meteor.Error("Duplicate PLC, Please check name or address of PLC again");
      } else {
        PLCInterfaces.insert({
          site,
          name,
          protocol,
          ipaddress,
          datachange,
          createDate
        });
      }
    }
  },

  //================================================================================	
  'plcinterfaces.remove'(taskId) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      PLCInterfaces.remove(taskId);
    }
  },

  //================================================================================	
  'plcinterfaces.update'(_id, protocol, ipaddress, datachange, createDate) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      PLCInterfaces.update(_id, {
        $set: {
          protocol,
          ipaddress,
          datachange,
          createDate
        }
      });
    }
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"roles.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/roles.js                                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
const ROLES = {
  Owner: 'Owner',
  Administrator: 'Administrator',
  Operator: 'Operator',
  View: 'View',
  NScope: 'NRole'
};
module.exportDefault(ROLES);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routeinterface.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/routeinterface.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  RouteInterface: () => RouteInterface
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let Security;
module.link("./security", {
  default(v) {
    Security = v;
  }

}, 2);
const RouteInterface = new Mongo.Collection('routeinterface');
//================================================================================
Meteor.methods({
  //================================================================================	
  'routeinterface.getdatablock'() {
    var dataBlock = [];
    RouteInterface.find({}, {
      sort: {
        scope: 1
      }
    }).forEach(function (doc) {
      dataBlock.push({
        _id: doc._id,
        path: doc.path,
        name: doc.name,
        component: doc.component,
        scope: doc.scope,
        except: doc.except
      });
    });
    return dataBlock;
  },

  //================================================================================	
  'routeinterface.insert'(path, component, scope, except) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      if (RouteInterface.findOne({
        name: name
      }) != null) {
        throw new Meteor.Error("Duplicate Site, Please check name of Site again");
      } else {
        RouteInterface.insert({
          path,
          component,
          scope,
          except
        });
      }
    }
  },

  //================================================================================	
  'routeinterface.remove'(taskId) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      RouteInterface.remove(taskId);
    }
  },

  //================================================================================	
  'routeinterface.addExcept'(_id, except) {
    console.log("============except " + except);

    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      RouteInterface.update(_id, {
        $set: {
          except
        }
      });
    }
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"screeninterfaces.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/screeninterfaces.js                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  ScreenInterfaces: () => ScreenInterfaces
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let SITEInterfaces;
module.link("./siteinterfaces.js", {
  default(v) {
    SITEInterfaces = v;
  }

}, 2);
let Security;
module.link("./security", {
  default(v) {
    Security = v;
  }

}, 3);
const ScreenInterfaces = new Mongo.Collection('screeninterfaces');

if (Meteor.isServer) {
  // This code only runs on the server
  Meteor.publish('screenControlSub', function screenControlSub(argumentsFind, argumentsOptions) {
    return ScreenInterfaces.find(argumentsFind, argumentsOptions);
  });
  Meteor.methods({
    //================================================================================	
    'screeninterfaces.insertasync'(site, name, createDate) {
      return Promise.asyncApply(() => {
        if (!Security.checkRole(this.userId, 'Owner')) {
          throw new Meteor.Error("logged-in", "You are not permitted.");
        } else {
          if (Promise.await(ScreenInterfaces.findOne({
            $and: [{
              site: {
                $eq: site
              }
            }, {
              name: {
                $eq: name
              }
            }]
          })) != null) {
            throw new Meteor.Error("Duplicate Screen, Please check name of Screen again");
          } else {
            Promise.await(ScreenInterfaces.insert({
              site,
              name,
              createDate
            }));
          }

          return 0;
        }
      });
    }

  });
}

Meteor.methods({
  //================================================================================	
  // 'screeninterfaces.insert'(
  // name,
  // datachange,
  // createDate) 
  // {
  // if (!Security.checkRole(this.userId,'Owner'))
  // {
  // throw new Meteor.Error("logged-in","You are not permitted.");
  // }
  // else
  // {
  // ScreenInterfaces.insert({
  // name,
  // datachange,
  // createDate
  // });
  // }
  // },
  'screeninterfaces.insert'(site, name, createDate) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      if (ScreenInterfaces.findOne({
        $and: [{
          site: {
            $eq: site
          }
        }, {
          name: {
            $eq: name
          }
        }]
      }) != null) {
        throw new Meteor.Error("Duplicate Screen, Please check name of Screen again");
      } else {
        ScreenInterfaces.insert({
          site,
          name,
          createDate
        });
      }

      return 0;
    }
  },

  //================================================================================	
  'screeninterfaces.update'(_id, name, datachange, createDate) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      ScreenInterfaces.update(_id, {
        $set: {
          name,
          datachange,
          createDate
        }
      });
    }
  },

  //================================================================================	
  'screeninterfaces.remove'(taskId) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      ScreenInterfaces.remove(taskId);
    }
  },

  //================================================================================	
  'screeninterfaces.get'() {
    var dataBlock = [];
    ScreenInterfaces.find({}, {
      sort: {
        site: -1
      }
    }).forEach(function (doc) {
      var nsite = Meteor.call('siteinterfaces.getname', doc.site);
      var idkey = nsite.concat("-", doc.name);
      dataBlock.push({
        _id: doc._id,
        nsite: nsite,
        idSite: doc.site,
        idkey: idkey,
        name: doc.name,
        createDate: doc.createDate
      });
    });
    return dataBlock;
  },

  //================================================================================		
  'screeninterfaces.getscreen'(id_screen) {
    return ScreenInterfaces.findOne({
      _id: id_screen
    });
  },

  //================================================================================		
  'screeninterfaces.getname'(id_screen) {
    var nameScreen = ScreenInterfaces.findOne({
      _id: id_screen
    });

    if (nameScreen == null) {
      return null;
    } else {
      return nameScreen.name;
    }
  },

  //================================================================================		
  'screeninterfaces.getid'(screen) {
    var id_screen = ScreenInterfaces.findOne({
      name: screen
    });

    if (id_screen == null) {
      return null;
    } else {
      return id_screen._id;
    }
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"screvent.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/screvent.js                                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  SCREvent: () => SCREvent
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
const SCREvent = new Mongo.Collection('screvent');

if (Meteor.isServer) {
  Meteor.methods({
    //================================================================================
    'screvent.getCMDEvents'(startTimeParam, endTimeParam) {
      return Promise.asyncApply(() => {
        const result = Promise.await(SCREvent.rawCollection().aggregate([{
          $match: {
            $and: [{
              timestamp: {
                $gte: startTimeParam,
                $lte: endTimeParam
              }
            }]
          }
        }, {
          $sort: {
            timestamp: -1
          }
        }, {
          $project: {
            "_id": "$_id",
            "obj": "$obj",
            "timestamp": {
              $dateToString: {
                format: "%m-%d-%Y %H:%M",
                date: {
                  $add: [new Date(0), "$timestamp"]
                },
                timezone: "Asia/Tokyo"
              }
            },
            "cmd": "$cmd",
            "val": "$val"
          }
        }]));
        return result.toArray();
      });
    }

  });
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"security.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/security.js                                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  default: () => Security
});
let Roles;
module.link("meteor/alanning:roles", {
  Roles(v) {
    Roles = v;
  }

}, 0);

class Security {
  static checkRole(userId, role) {
    //check(scope, String);
    //console.log("hasRole: ", role);	
    //console.log("userId: " + userId + " Meteor.userId(): " + Meteor.userId() + " hasRole: " + Roles.userIsInRole(Meteor.userId(), ['Owner']));
    // if (!this.hasRole(userId, role)) 
    // {
    // //throw new Meteor.Error('not-authorized');
    // return 0;
    // } else
    // {
    // //console.log("userId " + Meteor.userId() + " hasRole 0" + Roles.getRolesForUser( Meteor.userId() ));	
    // return 1;
    // }
    return 1;
  }

  static hasRole(userId, role) {
    return Roles.userIsInRole(Meteor.userId(), role);
  }

  static checkLoggedIn(userId) {
    if (!userId) {
      throw new Meteor.Error('not-authorized', 'You are not authorized');
    }

    ;
  } // add other business logic checks here that you use throughout the app
  // something like: isUserAllowedToSeeDocument()
  // always keep decoupling your code if this class gets huge.


}

if (Meteor.isServer) {
  Meteor.methods({
    'getCurrentUser'() {
      return Promise.asyncApply(() => {
        var loggedInUser = Meteor.user();

        if (loggedInUser) {
          return loggedInUser;
        } else {
          return "";
        }
      });
    },

    //================================================================================	  
    'checkRolesN'() {
      return Promise.asyncApply(() => {
        var loggedInUser = Meteor.user();
        console.log("loggedInUser: ", loggedInUser);

        if (Roles.userIsInRole(loggedInUser, ['Owner', 'Administrator'])) {
          return true;
        }

        throw new Meteor.Error('unauthorized', "Not authorized to create new users");
        console.log("hasRole ");
      });
    }

  });
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"shifthoursinterface.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/shifthoursinterface.js                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  ShifthoursInterface: () => ShifthoursInterface
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let Security;
module.link("./security", {
  default(v) {
    Security = v;
  }

}, 2);
const ShifthoursInterface = new Mongo.Collection('shifthoursinterface');

if (Meteor.isServer) {
  Meteor.methods({
    //================================================================================	
    'shifthoursinterface.getEVNSiteYears'() {
      return Promise.asyncApply(() => {
        var dataBlock = [];
        var index = 0;
        Promise.await(ShifthoursInterface.rawCollection().aggregate([{
          $group: {
            "_id": {
              "site": "$site",
              "year": "$year"
            }
          }
        }, {
          $lookup: {
            from: "siteinterfaces",
            localField: "_id.site",
            foreignField: "_id",
            as: "datasite"
          }
        }, {
          $unwind: "$datasite"
        }, {
          $project: {
            _id: "$datasite._id",
            nsite: "$datasite.desc",
            year: "$_id.year"
          }
        }]).forEach(function (doc) {
          dataBlock.push({
            _id: index,
            site: doc._id,
            nsite: doc.nsite,
            year: doc.year
          });
          index = index + 1;
        }));
        return dataBlock;
      });
    }

  });
} //================================================================================


Meteor.methods({
  //================================================================================	
  'shifthoursinterface.getdatablock'(site, year) {
    var dataBlock = [];
    var evn = "Lỗi";
    var dayInWeek = "Lỗi";
    ShifthoursInterface.find({
      "site": site,
      "year": year
    }, {
      sort: {
        hourStr: 1
      }
    }).forEach(function (doc) {
      evn = "Lỗi";

      switch (doc.shiftNumber) {
        case "1":
          evn = "Giờ bình thường";
          break;

        case "2":
          evn = "Giờ cao điểm";
          break;

        case "3":
          evn = "Giờ thấp điểm";
          break;

        default:
          break;
      }

      var nsite = Meteor.call('siteinterfaces.getname', doc.site);
      dataBlock.push({
        _id: doc._id,
        site: doc.site,
        nsite: nsite,
        year: doc.year,
        shiftNumber: doc.shiftNumber,
        hourStr: doc.hourStr,
        hourEnd: doc.hourEnd
      });
    });
    return dataBlock;
  },

  //================================================================================	
  'shifthoursinterface.insert'(site, year, shiftNumber, hourStr, hourEnd, createDate) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      ShifthoursInterface.insert({
        site,
        year,
        shiftNumber,
        hourStr,
        hourEnd,
        createDate
      });
    }

    return 0;
  },

  //================================================================================	
  'shifthoursinterface.remove'(taskId) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      ShifthoursInterface.remove(taskId);
    }
  },

  //================================================================================	
  'shifthoursinterface.update'(_id, site, year, shiftNumber, hourStr, hourEnd, createDate) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      ShifthoursInterface.update(_id, {
        $set: {
          site,
          year,
          shiftNumber,
          hourStr,
          hourEnd,
          createDate
        }
      });
    }
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"siteinterfaces.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/siteinterfaces.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  SITEInterfaces: () => SITEInterfaces
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let Security;
module.link("./security", {
  default(v) {
    Security = v;
  }

}, 2);
const SITEInterfaces = new Mongo.Collection('siteinterfaces');

if (Meteor.isServer) {
  // This code only runs on the server
  Meteor.publish('siteControlSub', function siteControlSub(argumentsFind) {
    console.log("=======================argumentsFind " + argumentsFind);
    return SITEInterfaces.find(argumentsFind);
  });
} //================================================================================


Meteor.methods({
  //================================================================================	
  'siteinterfaces.getdatablock'() {
    var dataBlock = [];
    SITEInterfaces.find({}, {
      sort: {
        desc: 1
      }
    }).forEach(function (doc) {
      dataBlock.push({
        _id: doc._id,
        name: doc.name,
        desc: doc.desc,
        datachange: doc.datachange
      });
    });
    return dataBlock;
  },

  //================================================================================	
  'siteinterfaces.getdatablockLocal'() {
    var dataBlock = [];
    SITEInterfaces.find({}, {
      sort: {
        desc: 1
      }
    }).forEach(function (doc) {
      if (doc.name == "kuwana") {
        dataBlock.push({
          _id: doc._id,
          name: doc.name,
          desc: doc.desc,
          datachange: doc.datachange
        });
      }
    });
    return dataBlock;
  },

  //================================================================================		
  'siteinterfaces.findSite'(name) {
    var nameSite = SITEInterfaces.findOne({
      name: name
    });

    if (nameSite == null) {
      return 0;
    } else {
      return 1;
    }
  },

  //================================================================================		
  'siteinterfaces.getname'(idSite) {
    var nameSite = SITEInterfaces.findOne({
      _id: idSite
    });

    if (nameSite == null) {
      return null;
    } else {
      return nameSite.name;
    }
  },

  //================================================================================	
  'siteinterfaces.insert'(name, datachange, desc) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      if (SITEInterfaces.findOne({
        name: name
      }) != null) {
        throw new Meteor.Error("Duplicate Site, Please check name of Site again");
      } else {
        SITEInterfaces.insert({
          name,
          datachange,
          desc
        });
      }
    }
  },

  //================================================================================	
  'siteinterfaces.remove'(taskId) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      SITEInterfaces.remove(taskId);
    }
  },

  //================================================================================	
  'siteinterfaces.update'(_id, datachange, desc) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      SITEInterfaces.update(_id, {
        $set: {
          datachange,
          desc
        }
      });
    }
  },

  //================================================================================	
  'siteinterfaces.updateControl'(_id, lock, typeControl) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      SITEInterfaces.update(_id, {
        $set: {
          lock,
          typeControl
        }
      });
    }
  },

  //================================================================================	
  'siteinterfaces.updateTags'(_id, update) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      SITEInterfaces.update(_id, {
        $set: {
          update
        }
      });
    }
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tagdatahistorian.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/tagdatahistorian.js                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  TagDataHistorian: () => TagDataHistorian
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let BiomasMaterial;
module.link("./biomasmaterial.js", {
  default(v) {
    BiomasMaterial = v;
  }

}, 2);
const TagDataHistorian = new Mongo.Collection('tagdatahistorian');

if (Meteor.isServer) {
  Meteor.methods({
    //================================================================================
    'tagdatahistorian.getBiomasInTime'(startTime, endTime) {
      return Promise.asyncApply(() => {
        var dataBlock = [];
        var resultArr = [];
        const result = Promise.await(TagDataHistorian.rawCollection().aggregate([{
          $match: {
            timestamp: {
              $gte: startTime,
              $lte: endTime
            }
          }
        }, {
          $set: {
            datesx: {
              $dateToString: {
                format: "%m-%d %H:%M",
                date: {
                  $add: [new Date(0), "$timestamp"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            }
          }
        }, {
          $set: {
            dateDisp: {
              $dateToString: {
                format: "%m-%d",
                date: {
                  $add: [new Date(0), "$timestamp"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            }
          }
        }, {
          $project: {
            _id: "$datesx",
            loadcell01: {
              $filter: {
                input: "$data",
                as: "data",
                cond: {
                  $in: ["$$data.n", [1]]
                }
              }
            },
            loadcell02: {
              $filter: {
                input: "$data",
                as: "data",
                cond: {
                  $in: ["$$data.n", [2]]
                }
              }
            },
            material: {
              $filter: {
                input: "$data",
                as: "data",
                cond: {
                  $in: ["$$data.n", [3]]
                }
              }
            },
            lo: {
              $filter: {
                input: "$data",
                as: "data",
                cond: {
                  $in: ["$$data.n", [4]]
                }
              }
            },
            time: "$timestamp",
            dateDisp: "$dateDisp"
          }
        }, {
          $sort: {
            "time": 1
          }
        }, {
          $project: {
            _id: "$_id",
            loadcell01: {
              $sum: "$loadcell01.v"
            },
            loadcell02: {
              $sum: "$loadcell02.v"
            },
            material: {
              $sum: "$material.v"
            },
            lo: {
              $sum: "$lo.v"
            },
            time: "$time",
            dateDisp: "$dateDisp",
            hoursx: {
              $hour: {
                date: {
                  $add: [new Date(0), "$time"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            },
            minutesx: {
              $minute: {
                date: {
                  $add: [new Date(0), "$time"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            }
          }
        }]).forEach(function (doc) {
          resultArr.push(doc);
        }));
        var loadcell01Prv = 0;
        var loadcell02Prv = 0;
        var hourPrv = 0;
        var firstOfDay = 0;
        var totalLC01Hour = 0;
        var totalLC02Hour = 0;
        var time = "";
        var dataTime = [];
        var dataReport = [];

        for (var k = 0; k < resultArr.length; k++) {
          if (firstOfDay == 0 && resultArr[k].minutesx == 45 && resultArr[k].hoursx == 5) {
            hourPrv = resultArr[k].hoursx;
            time = resultArr[k].dateDisp;
            loadcell01Prv = parseInt(resultArr[k].loadcell01);
            loadcell02Prv = parseInt(resultArr[k].loadcell02);
            firstOfDay = 1;
          } else if (firstOfDay == 1) {
            if (Math.abs(parseInt(resultArr[k].loadcell01) - loadcell01Prv) > 10000) {//				
            } else {
              totalLC01Hour = totalLC01Hour + Math.abs(parseInt(resultArr[k].loadcell01) - loadcell01Prv);
            }

            if (Math.abs(parseInt(resultArr[k].loadcell02) - loadcell02Prv) > 10000) {//	
            } else {
              totalLC02Hour = totalLC02Hour + Math.abs(parseInt(resultArr[k].loadcell02) - loadcell02Prv);
            }

            if (resultArr[k].minutesx == 45 && resultArr[k].hoursx == 5 || k == resultArr.length - 1) {
              total = totalLC01Hour + totalLC02Hour;
              dataReport.push(parseFloat(Number(total) / 1000).toFixed(1));
              dataTime.push(time);
              totalLC01Hour = 0;
              totalLC02Hour = 0;
              hourPrv = resultArr[k].hoursx;
              time = resultArr[k].dateDisp;
            }

            loadcell01Prv = parseInt(resultArr[k].loadcell01);
            loadcell02Prv = parseInt(resultArr[k].loadcell02);
          }
        }

        dataBlock.push({
          _id: "Biomas(1000kg)",
          type: 'bar',
          data: dataReport,
          time: dataTime
        });
        return dataBlock;
      });
    },

    //================================================================================
    'tagdatahistorian.getMonthlyReport14h'(startTime, endTime, selectBoiler) {
      return Promise.asyncApply(() => {
        var dataBlock = [];
        var resultArr = []; //console.log("startTimeParam " + startTime + ", endTimeParam " + endTime + ", selectBoiler " + selectBoiler);

        const result = Promise.await(TagDataHistorian.rawCollection().aggregate([{
          $match: {
            timestamp: {
              $gte: startTime,
              $lte: endTime
            }
          }
        }, {
          $set: {
            datesx: {
              $dateToString: {
                format: "%m-%d %H:%M",
                date: {
                  $add: [new Date(0), "$timestamp"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            }
          }
        }, {
          $project: {
            _id: "$datesx",
            loadcell01: {
              $filter: {
                input: "$data",
                as: "data",
                cond: {
                  $in: ["$$data.n", [1]]
                }
              }
            },
            loadcell02: {
              $filter: {
                input: "$data",
                as: "data",
                cond: {
                  $in: ["$$data.n", [2]]
                }
              }
            },
            material: {
              $filter: {
                input: "$data",
                as: "data",
                cond: {
                  $in: ["$$data.n", [3]]
                }
              }
            },
            lo: {
              $filter: {
                input: "$data",
                as: "data",
                cond: {
                  $in: ["$$data.n", [4]]
                }
              }
            },
            time: "$timestamp"
          }
        }, {
          $sort: {
            "time": 1
          }
        }, {
          $project: {
            _id: "$_id",
            loadcell01: {
              $sum: "$loadcell01.v"
            },
            loadcell02: {
              $sum: "$loadcell02.v"
            },
            material: {
              $sum: "$material.v"
            },
            load: {
              $sum: "$lo.v"
            },
            time: "$time",
            hoursx: {
              $hour: {
                date: {
                  $add: [new Date(0), "$time"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            },
            minutesx: {
              $minute: {
                date: {
                  $add: [new Date(0), "$time"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            }
          }
        }]).forEach(function (doc) {
          resultArr.push(doc);
        }));
        var loadcell01Prv = 0;
        var loadcell02Prv = 0;
        var hourPrv = 0;
        var firstOfDay = 0;
        var totalLC01Hour = 0;
        var totalLC02Hour = 0;
        var totalLC01Than = 0;
        var totalLC02Than = 0;
        var totalLC01Biomas = 0;
        var totalLC02Biomas = 0;
        var time = "";
        var dateTime = 0;
        var load = 0;
        var dateTime = 0;
        var dataLC01 = [];
        var dataLC02 = [];
        var dataTime = [];
        var dataReport = [];
        var total01lo1 = 0;
        var total01lo2 = 0;
        var total02lo1 = 0;
        var total02lo2 = 0;
        var total03lo1 = 0;
        var total03lo2 = 0;
        var total04lo1 = 0;
        var total04lo2 = 0;

        for (var k = 0; k < resultArr.length; k++) {
          if (firstOfDay == 0 && resultArr[k].minutesx == 0 && resultArr[k].hoursx == 14) {
            hourPrv = resultArr[k].hoursx;
            time = resultArr[k]._id;
            dateTime = resultArr[k].time;
            material = parseInt(resultArr[k].material);
            load = parseInt(resultArr[k].load);
            loadcell01Prv = parseInt(resultArr[k].loadcell01);
            loadcell02Prv = parseInt(resultArr[k].loadcell02);
            firstOfDay = 1;
          } else if (firstOfDay == 1) {
            totalLC01Hour = totalLC01Hour + Math.abs(parseInt(resultArr[k].loadcell01) - loadcell01Prv);
            totalLC02Hour = totalLC02Hour + Math.abs(parseInt(resultArr[k].loadcell02) - loadcell02Prv);

            switch (material) {
              case 0:
                //Biomas
                totalLC01Biomas = totalLC01Biomas + Math.abs(parseInt(resultArr[k].loadcell01) - loadcell01Prv);
                totalLC02Biomas = totalLC02Biomas + Math.abs(parseInt(resultArr[k].loadcell02) - loadcell02Prv);
                break;

              case 1:
                //Than
                totalLC01Than = totalLC02Than + Math.abs(parseInt(resultArr[k].loadcell01) - loadcell01Prv);
                totalLC02Than = totalLC02Than + Math.abs(parseInt(resultArr[k].loadcell02) - loadcell02Prv);
                break;

              default:
                break;
            }

            switch (load) {
              case 1:
                //Lo 1
                total01lo1 = total01lo1 + Math.abs(parseInt(resultArr[k].loadcell01) - loadcell01Prv);
                total01lo2 = total01lo2 + Math.abs(parseInt(resultArr[k].loadcell02) - loadcell02Prv);
                break;

              case 2:
                //Lo 2
                total02lo1 = total02lo1 + Math.abs(parseInt(resultArr[k].loadcell01) - loadcell01Prv);
                total02lo2 = total02lo2 + Math.abs(parseInt(resultArr[k].loadcell02) - loadcell02Prv);
                break;

              case 3:
                //Lo 3
                total03lo1 = total013o1 + Math.abs(parseInt(resultArr[k].loadcell01) - loadcell01Prv);
                total03lo2 = total013o2 + Math.abs(parseInt(resultArr[k].loadcell02) - loadcell02Prv);
                break;

              case 4:
                //Lo 4
                total04lo1 = total04lo1 + Math.abs(parseInt(resultArr[k].loadcell01) - loadcell01Prv);
                total04lo2 = total04lo2 + Math.abs(parseInt(resultArr[k].loadcell02) - loadcell02Prv);
                break;

              default:
                break;
            }

            if (resultArr[k].minutesx == 0 && resultArr[k].hoursx == 14) {
              const resultMaterial = Promise.await(Meteor.call('biomasmaterial.getMaterial', resultArr[k].time));

              if (resultMaterial != "") {
                // 'Lò Tầng Sôi 1':  total01lo1 + total01lo2,										
                // 'Lò Tầng Sôi 2':  total02lo1 + total02lo2,										
                // 'Lò Tầng Sôi 3':  total03lo1 + total03lo2,										
                // 'Lò Tầng Sôi 4':  total04lo1 + total04lo2,										
                var totalAll = totalLC01Hour + totalLC02Hour;
                var total = 0;

                switch (parseInt(selectBoiler)) {
                  case 0:
                    total = totalLC01Hour + totalLC02Hour;
                    break;

                  case 1:
                    total = total01lo1 + total01lo2;
                    break;

                  case 2:
                    total = total02lo1 + total02lo2;
                    break;

                  case 3:
                    total = total03lo1 + total03lo2;
                    break;

                  case 4:
                    total = total04lo1 + total04lo2;
                    break;
                } // dataReport.push({
                // 'Thời gian': time.concat("  -  ",resultArr[k]._id),
                // 'Bộ cân01' :totalLC01Hour,
                // 'Bộ cân02' :totalLC02Hour,
                // 'Tổng':  total,
                // 'Tổng Than': totalLC01Than + totalLC02Than,
                // 'Tổng Biomas':  totalLC01Biomas + totalLC02Biomas,									
                // 'Lò Tầng Sôi 1':  total01lo1 + total01lo2,										
                // 'Lò Tầng Sôi 2':  total02lo1 + total02lo2,										
                // 'Lò Tầng Sôi 3':  total03lo1 + total03lo2,										
                // 'Lò Tầng Sôi 4':  total04lo1 + total04lo2,									
                // '% Củi băm'	: resultMaterial[0].cuibam,
                // 'Củi băm'	: parseFloat((total * parseFloat(resultMaterial[0].cuibam)) / 100).toFixed(1),
                // '% Mùn cưa'	: resultMaterial[0].muncua,
                // 'Mùn cưa'	: parseFloat((total * parseFloat(resultMaterial[0].muncua)) / 100).toFixed(1),
                // '% Hạt điều': resultMaterial[0].hatdieu,
                // 'Hạt điều': parseFloat((total * parseFloat(resultMaterial[0].hatdieu)) / 100).toFixed(1),
                // '% Dăm bào'	: resultMaterial[0].dambao,
                // 'Dăm bào'	: parseFloat((total * parseFloat(resultMaterial[0].dambao)) / 100).toFixed(1),
                // '% Vỏ cây nghiền':resultMaterial[0].caynghien,
                // 'Vỏ cây nghiền':parseFloat((total * parseFloat(resultMaterial[0].caynghien)) / 100).toFixed(1),
                // '% Bột xước'	: resultMaterial[0].botxuoc,
                // 'Bột xước'	: parseFloat((total * parseFloat(resultMaterial[0].botxuoc)) / 100).toFixed(1),
                // '% Củi đốt'	: resultMaterial[0].cuidot,
                // 'Củi đốt'	: parseFloat((total * parseFloat(resultMaterial[0].cuidot)) / 100).toFixed(1),
                // '% Trấu': resultMaterial[0].trau,
                // 'Trấu': parseFloat((total * parseFloat(resultMaterial[0].trau)) / 100).toFixed(1),
                // '% Gùi bắp'	: resultMaterial[0].guibap,		
                // 'Gùi bắp'	: parseFloat((total * parseFloat(resultMaterial[0].guibap)) / 100).toFixed(1),						
                // }); 


                dataReport.push({
                  'Thời gian': time.concat("  -  ", resultArr[k]._id),
                  'Bộ cân01': totalLC01Hour,
                  'Bộ cân02': totalLC02Hour,
                  'Tổng': totalAll,
                  'Tổng Than': totalLC01Than + totalLC02Than,
                  'Tổng Biomas': totalLC01Biomas + totalLC02Biomas,
                  'Lò Tầng Sôi 1': total01lo1 + total01lo2,
                  'Lò Tầng Sôi 2': total02lo1 + total02lo2,
                  'Lò Tầng Sôi 3': total03lo1 + total03lo2,
                  'Lò Tầng Sôi 4': total04lo1 + total04lo2,
                  'Củi băm': parseFloat(total * parseFloat(resultMaterial[0].cuibam) / 100).toFixed(1),
                  'Mùn cưa': parseFloat(total * parseFloat(resultMaterial[0].muncua) / 100).toFixed(1),
                  'Hạt điều': parseFloat(total * parseFloat(resultMaterial[0].hatdieu) / 100).toFixed(1),
                  'Dăm bào': parseFloat(total * parseFloat(resultMaterial[0].dambao) / 100).toFixed(1),
                  'Vỏ cây nghiền': parseFloat(total * parseFloat(resultMaterial[0].caynghien) / 100).toFixed(1),
                  'Bột xước': parseFloat(total * parseFloat(resultMaterial[0].botxuoc) / 100).toFixed(1),
                  'Củi đốt': parseFloat(total * parseFloat(resultMaterial[0].cuidot) / 100).toFixed(1),
                  'Trấu': parseFloat(total * parseFloat(resultMaterial[0].trau) / 100).toFixed(1),
                  'Gùi bắp': parseFloat(total * parseFloat(resultMaterial[0].guibap) / 100).toFixed(1)
                });
              } else {
                dataReport.push({
                  'Thời gian': time.concat("  -  ", resultArr[k]._id),
                  'Bộ cân01': totalLC01Hour,
                  'Bộ cân02': totalLC02Hour,
                  'Tổng': totalAll,
                  'Tổng Than': totalLC01Than + totalLC02Than,
                  'Tổng Biomas': totalLC01Biomas + totalLC02Biomas,
                  'Lò Tầng Sôi 1': total01lo1 + total01lo2,
                  'Lò Tầng Sôi 2': total02lo1 + total02lo2,
                  'Lò Tầng Sôi 3': total03lo1 + total03lo2,
                  'Lò Tầng Sôi 4': total04lo1 + total04lo2
                });
              }

              dataLC01.push(Number(totalLC01Hour));
              dataLC02.push(Number(totalLC02Hour));
              dataTime.push(time);
              totalLC01Hour = 0;
              totalLC02Hour = 0;
              totalLC01Than = 0;
              totalLC02Than = 0;
              totalLC01Biomas = 0;
              totalLC02Biomas = 0;
              total01lo1 = 0;
              total01lo2 = 0;
              total02lo1 = 0;
              total02lo2 = 0;
              total03lo1 = 0;
              total03lo2 = 0;
              total04lo1 = 0;
              total04lo2 = 0;
              hourPrv = resultArr[k].hoursx;
              time = resultArr[k]._id;
              dateTime = resultArr[k].time;
              material = parseInt(resultArr[k].material);
              load = parseInt(resultArr[k].load);
              loadcell01Prv = parseInt(resultArr[k].loadcell01);
              loadcell02Prv = parseInt(resultArr[k].loadcell02);
            }
          }
        }

        dataBlock.push({
          _id: "Bộ cân 1",
          type: 'bar',
          stack: 'Stack 0',
          data: dataLC01,
          time: dataTime
        });
        dataBlock.push({
          _id: "Bộ cân 2",
          type: 'bar',
          stack: 'Stack 0',
          data: dataLC02,
          time: dataTime
        });
        dataBlock.push({
          _id: "Report",
          data: dataReport
        });
        return dataBlock;
      });
    },

    //================================================================================
    'tagdatahistorian.getMonthlyReport'(startTime, endTime, selectBoiler) {
      return Promise.asyncApply(() => {
        var dataBlock = [];
        var resultArr = []; //console.log("startTimeParam " + startTime + ", endTimeParam " + endTime + ", selectBoiler " + selectBoiler);

        const result = Promise.await(TagDataHistorian.rawCollection().aggregate([{
          $match: {
            timestamp: {
              $gte: startTime,
              $lte: endTime
            }
          }
        }, {
          $set: {
            datesx: {
              $dateToString: {
                format: "%m-%d %H:%M",
                date: {
                  $add: [new Date(0), "$timestamp"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            }
          }
        }, {
          $set: {
            dateDisp: {
              $dateToString: {
                format: "%m-%d",
                date: {
                  $add: [new Date(0), "$timestamp"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            }
          }
        }, {
          $project: {
            _id: "$datesx",
            loadcell01: {
              $filter: {
                input: "$data",
                as: "data",
                cond: {
                  $in: ["$$data.n", [1]]
                }
              }
            },
            loadcell02: {
              $filter: {
                input: "$data",
                as: "data",
                cond: {
                  $in: ["$$data.n", [2]]
                }
              }
            },
            material: {
              $filter: {
                input: "$data",
                as: "data",
                cond: {
                  $in: ["$$data.n", [3]]
                }
              }
            },
            lo: {
              $filter: {
                input: "$data",
                as: "data",
                cond: {
                  $in: ["$$data.n", [4]]
                }
              }
            },
            time: "$timestamp",
            dateDisp: "$dateDisp"
          }
        }, {
          $sort: {
            "time": 1
          }
        }, {
          $project: {
            _id: "$_id",
            loadcell01: {
              $sum: "$loadcell01.v"
            },
            loadcell02: {
              $sum: "$loadcell02.v"
            },
            material: {
              $sum: "$material.v"
            },
            load: {
              $sum: "$lo.v"
            },
            time: "$time",
            dateDisp: "$dateDisp",
            hoursx: {
              $hour: {
                date: {
                  $add: [new Date(0), "$time"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            },
            minutesx: {
              $minute: {
                date: {
                  $add: [new Date(0), "$time"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            }
          }
        }]).forEach(function (doc) {
          resultArr.push(doc);
        }));
        var loadcell01Prv = 0;
        var loadcell02Prv = 0;
        var hourPrv = 0;
        var firstOfDay = 0;
        var totalLC01Hour = 0;
        var totalLC02Hour = 0;
        var totalLC01Than = 0;
        var totalLC02Than = 0;
        var totalLC01Biomas = 0;
        var totalLC02Biomas = 0;
        var time = "";
        var dateTime = 0;
        var load = 0;
        var dateTime = 0;
        var dataLC01 = [];
        var dataLC02 = [];
        var dataTime = [];
        var dataReport = [];
        var total01lo1 = 0;
        var total01lo2 = 0;
        var total02lo1 = 0;
        var total02lo2 = 0;
        var total03lo1 = 0;
        var total03lo2 = 0;
        var total04lo1 = 0;
        var total04lo2 = 0;
        var dateDisp = "";

        for (var k = 0; k < resultArr.length; k++) {
          if (firstOfDay == 0 && resultArr[k].minutesx == 45 && resultArr[k].hoursx == 5) {
            hourPrv = resultArr[k].hoursx;
            time = resultArr[k]._id;
            dateTime = resultArr[k].time;
            dateDisp = resultArr[k].dateDisp;
            material = parseInt(resultArr[k].material);
            load = parseInt(resultArr[k].load);
            loadcell01Prv = parseInt(resultArr[k].loadcell01);
            loadcell02Prv = parseInt(resultArr[k].loadcell02);
            firstOfDay = 1;
          } else if (firstOfDay == 1) {
            if (Math.abs(parseInt(resultArr[k].loadcell01) - loadcell01Prv) > 10000) {//				
            } else {
              totalLC01Hour = totalLC01Hour + Math.abs(parseInt(resultArr[k].loadcell01) - loadcell01Prv);

              switch (material) {
                case 0:
                  //Biomas
                  totalLC01Biomas = totalLC01Biomas + Math.abs(parseInt(resultArr[k].loadcell01) - loadcell01Prv);
                  break;

                case 1:
                  //Than
                  totalLC01Than = totalLC02Than + Math.abs(parseInt(resultArr[k].loadcell01) - loadcell01Prv);
                  break;

                default:
                  break;
              }

              switch (load) {
                case 1:
                  //Lo 1
                  total01lo1 = total01lo1 + Math.abs(parseInt(resultArr[k].loadcell01) - loadcell01Prv);
                  break;

                case 2:
                  //Lo 2
                  total02lo1 = total02lo1 + Math.abs(parseInt(resultArr[k].loadcell01) - loadcell01Prv);
                  break;

                case 3:
                  //Lo 3
                  total03lo1 = total013o1 + Math.abs(parseInt(resultArr[k].loadcell01) - loadcell01Prv);
                  break;

                case 4:
                  //Lo 4
                  total04lo1 = total04lo1 + Math.abs(parseInt(resultArr[k].loadcell01) - loadcell01Prv);
                  break;

                default:
                  break;
              }
            }

            if (Math.abs(parseInt(resultArr[k].loadcell02) - loadcell02Prv) > 10000) {//	
            } else {
              totalLC02Hour = totalLC02Hour + Math.abs(parseInt(resultArr[k].loadcell02) - loadcell02Prv);

              switch (material) {
                case 0:
                  //Biomas			
                  totalLC02Biomas = totalLC02Biomas + Math.abs(parseInt(resultArr[k].loadcell02) - loadcell02Prv);
                  break;

                case 1:
                  //Than				
                  totalLC02Than = totalLC02Than + Math.abs(parseInt(resultArr[k].loadcell02) - loadcell02Prv);
                  break;

                default:
                  break;
              }

              switch (load) {
                case 1:
                  //Lo 1			
                  total01lo2 = total01lo2 + Math.abs(parseInt(resultArr[k].loadcell02) - loadcell02Prv);
                  break;

                case 2:
                  //Lo 2				
                  total02lo2 = total02lo2 + Math.abs(parseInt(resultArr[k].loadcell02) - loadcell02Prv);
                  break;

                case 3:
                  //Lo 3			
                  total03lo2 = total013o2 + Math.abs(parseInt(resultArr[k].loadcell02) - loadcell02Prv);
                  break;

                case 4:
                  //Lo 4			
                  total04lo2 = total04lo2 + Math.abs(parseInt(resultArr[k].loadcell02) - loadcell02Prv);
                  break;

                default:
                  break;
              }
            }

            if (resultArr[k].minutesx == 45 && resultArr[k].hoursx == 5) {
              const resultMaterial = Promise.await(Meteor.call('biomasmaterial.getMaterial', resultArr[k].time));
              var totalAll = totalLC01Hour + totalLC02Hour;

              if (resultMaterial != "") {
                // 'Lò Tầng Sôi 1':  total01lo1 + total01lo2,										
                // 'Lò Tầng Sôi 2':  total02lo1 + total02lo2,										
                // 'Lò Tầng Sôi 3':  total03lo1 + total03lo2,										
                // 'Lò Tầng Sôi 4':  total04lo1 + total04lo2,										
                var totalAll = totalLC01Hour + totalLC02Hour;
                var total = 0;

                switch (parseInt(selectBoiler)) {
                  case 0:
                    total = totalLC01Hour + totalLC02Hour;
                    break;

                  case 1:
                    total = total01lo1 + total01lo2;
                    break;

                  case 2:
                    total = total02lo1 + total02lo2;
                    break;

                  case 3:
                    total = total03lo1 + total03lo2;
                    break;

                  case 4:
                    total = total04lo1 + total04lo2;
                    break;
                }

                dataReport.push({
                  'Thời gian': time.concat("  -  ", resultArr[k]._id),
                  'Bộ cân01': totalLC01Hour,
                  'Bộ cân02': totalLC02Hour,
                  'Tổng': totalAll,
                  'Tổng Than': totalLC01Than + totalLC02Than,
                  'Tổng Biomas': totalLC01Biomas + totalLC02Biomas,
                  'Lò Tầng Sôi 1': total01lo1 + total01lo2,
                  'Lò Tầng Sôi 2': total02lo1 + total02lo2,
                  'Lò Tầng Sôi 3': total03lo1 + total03lo2,
                  'Lò Tầng Sôi 4': total04lo1 + total04lo2,
                  'Củi băm': parseFloat(total * parseFloat(resultMaterial[0].cuibam) / 100).toFixed(1),
                  'Mùn cưa': parseFloat(total * parseFloat(resultMaterial[0].muncua) / 100).toFixed(1),
                  'Hạt điều': parseFloat(total * parseFloat(resultMaterial[0].hatdieu) / 100).toFixed(1),
                  'Dăm bào': parseFloat(total * parseFloat(resultMaterial[0].dambao) / 100).toFixed(1),
                  'Vỏ cây nghiền': parseFloat(total * parseFloat(resultMaterial[0].caynghien) / 100).toFixed(1),
                  'Bột xước': parseFloat(total * parseFloat(resultMaterial[0].botxuoc) / 100).toFixed(1),
                  'Củi đốt': parseFloat(total * parseFloat(resultMaterial[0].cuidot) / 100).toFixed(1),
                  'Trấu': parseFloat(total * parseFloat(resultMaterial[0].trau) / 100).toFixed(1),
                  'Gùi bắp': parseFloat(total * parseFloat(resultMaterial[0].guibap) / 100).toFixed(1)
                });
              } else {
                dataReport.push({
                  'Thời gian': time.concat("  -  ", resultArr[k]._id),
                  'Bộ cân01': totalLC01Hour,
                  'Bộ cân02': totalLC02Hour,
                  'Tổng': totalAll,
                  'Tổng Than': totalLC01Than + totalLC02Than,
                  'Tổng Biomas': totalLC01Biomas + totalLC02Biomas,
                  'Lò Tầng Sôi 1': total01lo1 + total01lo2,
                  'Lò Tầng Sôi 2': total02lo1 + total02lo2,
                  'Lò Tầng Sôi 3': total03lo1 + total03lo2,
                  'Lò Tầng Sôi 4': total04lo1 + total04lo2
                });
              }

              dataLC01.push(Number(totalLC01Hour));
              dataLC02.push(Number(totalLC02Hour));
              dataTime.push(dateDisp);
              totalLC01Hour = 0;
              totalLC02Hour = 0;
              totalLC01Than = 0;
              totalLC02Than = 0;
              totalLC01Biomas = 0;
              totalLC02Biomas = 0;
              total01lo1 = 0;
              total01lo2 = 0;
              total02lo1 = 0;
              total02lo2 = 0;
              total03lo1 = 0;
              total03lo2 = 0;
              total04lo1 = 0;
              total04lo2 = 0;
              hourPrv = resultArr[k].hoursx;
              time = resultArr[k]._id;
              dateTime = resultArr[k].time;
              dateDisp = resultArr[k].dateDisp;
              material = parseInt(resultArr[k].material);
              load = parseInt(resultArr[k].load);
              loadcell01Prv = parseInt(resultArr[k].loadcell01);
              loadcell02Prv = parseInt(resultArr[k].loadcell02);
            }

            hourPrv = parseInt(resultArr[k].hoursx);
            loadcell01Prv = parseInt(resultArr[k].loadcell01);
            loadcell02Prv = parseInt(resultArr[k].loadcell02);
          }
        }

        dataBlock.push({
          _id: "Bộ cân 1",
          type: 'bar',
          stack: 'Stack 0',
          data: dataLC01,
          time: dataTime
        });
        dataBlock.push({
          _id: "Bộ cân 2",
          type: 'bar',
          stack: 'Stack 0',
          data: dataLC02,
          time: dataTime
        });
        dataBlock.push({
          _id: "Report",
          data: dataReport
        });
        return dataBlock;
      });
    },

    //================================================================================
    'tagdatahistorian.getShiftWorkingDaily14h'(startTime, endTime) {
      return Promise.asyncApply(() => {
        var dataBlock = [];
        var resultArr = []; //console.log("startTimeParam " + startTime + ", endTimeParam " + endTime);

        const result = Promise.await(TagDataHistorian.rawCollection().aggregate([{
          $match: {
            timestamp: {
              $gte: startTime,
              $lte: endTime
            }
          }
        }, {
          $set: {
            datesx: {
              $dateToString: {
                format: "%m-%d %H:%M",
                date: {
                  $add: [new Date(0), "$timestamp"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            }
          }
        }, {
          $project: {
            _id: "$datesx",
            loadcell01: {
              $filter: {
                input: "$data",
                as: "data",
                cond: {
                  $in: ["$$data.n", [1]]
                }
              }
            },
            loadcell02: {
              $filter: {
                input: "$data",
                as: "data",
                cond: {
                  $in: ["$$data.n", [2]]
                }
              }
            },
            time: "$timestamp"
          }
        }, {
          $sort: {
            "time": 1
          }
        }, {
          $project: {
            _id: "$_id",
            loadcell01: {
              $sum: "$loadcell01.v"
            },
            loadcell02: {
              $sum: "$loadcell02.v"
            },
            time: "$time",
            hoursx: {
              $hour: {
                date: {
                  $add: [new Date(0), "$time"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            },
            minutesx: {
              $minute: {
                date: {
                  $add: [new Date(0), "$time"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            }
          }
        }]).forEach(function (doc) {
          resultArr.push(doc);
        }));
        var loadcell01Prv = 0;
        var loadcell02Prv = 0;
        var hourPrv = 0;
        var firstOfDay = 0;
        var totalLC01 = 0;
        var totalLC02 = 0;
        var totalLC01Hour = 0;
        var totalLC02Hour = 0;
        var total = 0;
        var time = "";
        var dataLC01 = [];
        var dataLC02 = [];
        var dataTime = [];
        var dataReport = [];

        for (var k = 0; k < resultArr.length; k++) {
          if (firstOfDay == 0 && resultArr[k].hoursx == 14) {
            hourPrv = resultArr[k].hoursx;
            time = resultArr[k]._id;
            loadcell01Prv = parseInt(resultArr[k].loadcell01);
            loadcell02Prv = parseInt(resultArr[k].loadcell02);
            firstOfDay = 1;
          } else if (firstOfDay == 1) {
            //if (parseInt(resultArr[k].loadcell01) - loadcell01Prv >0)
            //{
            totalLC01Hour = totalLC01Hour + Math.abs(parseInt(resultArr[k].loadcell01) - loadcell01Prv); //}		
            //if (parseInt(resultArr[k].loadcell02) - loadcell02Prv >0)
            //{

            totalLC02Hour = totalLC02Hour + Math.abs(parseInt(resultArr[k].loadcell02) - loadcell02Prv); //}
            //console.log(", hoursx " + resultArr[k].hoursx);

            if (resultArr[k].minutesx == 0) {
              dataReport.push({
                time: time.concat("  -  ", resultArr[k]._id),
                shift: "",
                bocan01: totalLC01Hour,
                bocan02: totalLC02Hour,
                total: ""
              });
              totalLC01 = totalLC01 + totalLC01Hour;
              totalLC02 = totalLC02 + totalLC02Hour;
              total = totalLC01 + totalLC02;
              dataLC01.push(Number(totalLC01Hour));
              dataLC02.push(Number(totalLC02Hour));
              dataTime.push(hourPrv); //console.log(", hoursx " + resultArr[k].hoursx);

              if (resultArr[k].hoursx == 22) {
                dataReport.push({
                  time: 'Ca Chiều 14h đến 20h',
                  shift: 'Tổng',
                  bocan01: totalLC01,
                  bocan02: totalLC02,
                  total: total
                });
                totalLC01 = 0;
                totalLC02 = 0;
              } else if (resultArr[k].hoursx == 6) {
                dataReport.push({
                  time: 'Ca Tối 20h đến 6h',
                  shift: 'Tổng',
                  bocan01: totalLC01,
                  bocan02: totalLC02,
                  total: total
                });
                totalLC01 = 0;
                totalLC02 = 0;
              }

              if (resultArr[k].hoursx == 14) {
                dataReport.push({
                  time: 'Ca Sáng 6h đến 14h',
                  shift: 'Tổng',
                  bocan01: totalLC01,
                  bocan02: totalLC02,
                  total: total
                });
                totalLC01 = 0;
                totalLC02 = 0;
              }

              totalLC01Hour = 0;
              totalLC02Hour = 0;
              time = resultArr[k]._id;
            }

            hourPrv = parseInt(resultArr[k].hoursx);
            loadcell01Prv = parseInt(resultArr[k].loadcell01);
            loadcell02Prv = parseInt(resultArr[k].loadcell02);
          }
        }

        dataBlock.push({
          _id: "Bộ cân 1",
          type: 'bar',
          stack: 'Stack 0',
          data: dataLC01,
          time: dataTime
        });
        dataBlock.push({
          _id: "Bộ cân 2",
          type: 'bar',
          stack: 'Stack 0',
          data: dataLC02,
          time: dataTime
        });
        dataBlock.push({
          _id: "Report",
          data: dataReport
        });
        return dataBlock;
      });
    },

    //================================================================================
    'tagdatahistorian.getShiftWorkingDaily5h'(startTime, endTime) {
      return Promise.asyncApply(() => {
        var dataBlock = [];
        var resultArr = []; //console.log("startTimeParam " + startTime + ", endTimeParam " + endTime);

        const result = Promise.await(TagDataHistorian.rawCollection().aggregate([{
          $match: {
            timestamp: {
              $gte: startTime,
              $lte: endTime
            }
          }
        }, {
          $set: {
            datesx: {
              $dateToString: {
                format: "%m-%d %H:%M",
                date: {
                  $add: [new Date(0), "$timestamp"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            }
          }
        }, {
          $project: {
            _id: "$datesx",
            loadcell01: {
              $filter: {
                input: "$data",
                as: "data",
                cond: {
                  $in: ["$$data.n", [1]]
                }
              }
            },
            loadcell02: {
              $filter: {
                input: "$data",
                as: "data",
                cond: {
                  $in: ["$$data.n", [2]]
                }
              }
            },
            time: "$timestamp"
          }
        }, {
          $sort: {
            "time": 1
          }
        }, {
          $project: {
            _id: "$_id",
            loadcell01: {
              $sum: "$loadcell01.v"
            },
            loadcell02: {
              $sum: "$loadcell02.v"
            },
            time: "$time",
            hoursx: {
              $hour: {
                date: {
                  $add: [new Date(0), "$time"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            },
            minutesx: {
              $minute: {
                date: {
                  $add: [new Date(0), "$time"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            }
          }
        }]).forEach(function (doc) {
          resultArr.push(doc);
        }));
        var loadcell01Prv = 0;
        var loadcell02Prv = 0;
        var hourPrv = 0;
        var firstOfDay = 0;
        var totalLC01 = 0;
        var totalLC02 = 0;
        var totalLC01Hour = 0;
        var totalLC02Hour = 0;
        var total = 0;
        var time = "";
        var dataLC01 = [];
        var dataLC02 = [];
        var dataTime = [];
        var dataReport = [];

        for (var k = 0; k < resultArr.length; k++) {
          if (firstOfDay == 0 && resultArr[k].hoursx == 5 && resultArr[k].minutesx == 45) {
            hourPrv = resultArr[k].hoursx;
            time = resultArr[k]._id;
            loadcell01Prv = parseInt(resultArr[k].loadcell01);
            loadcell02Prv = parseInt(resultArr[k].loadcell02);
            firstOfDay = 1;
          } else if (firstOfDay == 1) {
            if (Math.abs(parseInt(resultArr[k].loadcell01) - loadcell01Prv) > 10000) {//				
            } else {
              totalLC01Hour = totalLC01Hour + Math.abs(parseInt(resultArr[k].loadcell01) - loadcell01Prv);
            }

            if (Math.abs(parseInt(resultArr[k].loadcell02) - loadcell02Prv) > 10000) {//	
            } else {
              totalLC02Hour = totalLC02Hour + Math.abs(parseInt(resultArr[k].loadcell02) - loadcell02Prv);
            }

            if (resultArr[k].minutesx == 45) {
              dataReport.push({
                time: time.concat("  -  ", resultArr[k]._id),
                shift: "",
                bocan01: totalLC01Hour,
                bocan02: totalLC02Hour,
                total: ""
              });
              totalLC01 = totalLC01 + totalLC01Hour;
              totalLC02 = totalLC02 + totalLC02Hour;
              total = totalLC01 + totalLC02;
              dataLC01.push(Number(totalLC01Hour));
              dataLC02.push(Number(totalLC02Hour));
              dataTime.push(hourPrv); //console.log(", hoursx " + resultArr[k].hoursx);

              if (resultArr[k].hoursx == 13) {
                dataReport.push({
                  time: 'Ca 1',
                  shift: 'Tổng',
                  bocan01: totalLC01,
                  bocan02: totalLC02,
                  total: total
                });
                totalLC01 = 0;
                totalLC02 = 0;
              } else if (resultArr[k].hoursx == 21) {
                dataReport.push({
                  time: 'Ca 2',
                  shift: 'Tổng',
                  bocan01: totalLC01,
                  bocan02: totalLC02,
                  total: total
                });
                totalLC01 = 0;
                totalLC02 = 0;
              }

              if (resultArr[k].hoursx == 5) {
                dataReport.push({
                  time: 'Ca 3',
                  shift: 'Tổng',
                  bocan01: totalLC01,
                  bocan02: totalLC02,
                  total: total
                });
                totalLC01 = 0;
                totalLC02 = 0;
              }

              totalLC01Hour = 0;
              totalLC02Hour = 0;
              time = resultArr[k]._id;
            }

            hourPrv = parseInt(resultArr[k].hoursx);
            loadcell01Prv = parseInt(resultArr[k].loadcell01);
            loadcell02Prv = parseInt(resultArr[k].loadcell02);
          }
        }

        dataBlock.push({
          _id: "Bộ cân 1",
          type: 'bar',
          stack: 'Stack 0',
          data: dataLC01,
          time: dataTime
        });
        dataBlock.push({
          _id: "Bộ cân 2",
          type: 'bar',
          stack: 'Stack 0',
          data: dataLC02,
          time: dataTime
        });
        dataBlock.push({
          _id: "Report",
          data: dataReport
        });
        return dataBlock;
      });
    },

    //================================================================================
    'tagdatahistorian.getShiftWorkingDaily'(startTime, endTime) {
      return Promise.asyncApply(() => {
        var dataBlock = [];
        var resultArr = []; //console.log("startTimeParam " + startTime + ", endTimeParam " + endTime);

        const result = Promise.await(TagDataHistorian.rawCollection().aggregate([{
          $match: {
            timestamp: {
              $gte: startTime,
              $lte: endTime
            }
          }
        }, {
          $set: {
            datesx: {
              $dateToString: {
                format: "%m-%d %H:%M",
                date: {
                  $add: [new Date(0), "$timestamp"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            }
          }
        }, {
          $project: {
            _id: "$datesx",
            loadcell01: {
              $filter: {
                input: "$data",
                as: "data",
                cond: {
                  $in: ["$$data.n", [1]]
                }
              }
            },
            loadcell02: {
              $filter: {
                input: "$data",
                as: "data",
                cond: {
                  $in: ["$$data.n", [2]]
                }
              }
            },
            time: "$timestamp"
          }
        }, {
          $sort: {
            "time": 1
          }
        }, {
          $project: {
            _id: "$_id",
            loadcell01: {
              $sum: "$loadcell01.v"
            },
            loadcell02: {
              $sum: "$loadcell02.v"
            },
            time: "$time",
            hoursx: {
              $hour: {
                date: {
                  $add: [new Date(0), "$time"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            },
            minutesx: {
              $minute: {
                date: {
                  $add: [new Date(0), "$time"]
                },
                timezone: "Asia/Ho_Chi_Minh"
              }
            }
          }
        }]).forEach(function (doc) {
          resultArr.push(doc);
        }));
        var loadcell01Prv = 0;
        var loadcell02Prv = 0;
        var hourPrv = 0;
        var firstOfDay = 0;
        var totalLC01 = 0;
        var totalLC02 = 0;
        var totalLC01Hour = 0;
        var totalLC02Hour = 0;
        var total = 0;
        var time = "";
        var dataLC01 = [];
        var dataLC02 = [];
        var dataTime = [];
        var dataReport = [];

        for (var k = 0; k < resultArr.length; k++) {
          if (firstOfDay == 0 && resultArr[k].hoursx == 17 && resultArr[k].minutesx == 45) {
            hourPrv = resultArr[k].hoursx;
            time = resultArr[k]._id;
            loadcell01Prv = parseInt(resultArr[k].loadcell01);
            loadcell02Prv = parseInt(resultArr[k].loadcell02);
            firstOfDay = 1;
          } else if (firstOfDay == 1) {
            //if (parseInt(resultArr[k].loadcell01) - loadcell01Prv >0)
            //{
            totalLC01Hour = totalLC01Hour + Math.abs(parseInt(resultArr[k].loadcell01) - loadcell01Prv); //}		
            //if (parseInt(resultArr[k].loadcell02) - loadcell02Prv >0)
            //{

            totalLC02Hour = totalLC02Hour + Math.abs(parseInt(resultArr[k].loadcell02) - loadcell02Prv); //}
            //console.log(", hoursx " + resultArr[k].hoursx);

            if (resultArr[k].minutesx == 45) {
              dataReport.push({
                time: time.concat("  -  ", resultArr[k]._id),
                shift: "",
                bocan01: totalLC01Hour,
                bocan02: totalLC02Hour,
                total: ""
              });
              totalLC01 = totalLC01 + totalLC01Hour;
              totalLC02 = totalLC02 + totalLC02Hour;
              total = totalLC01 + totalLC02;
              dataLC01.push(Number(totalLC01Hour));
              dataLC02.push(Number(totalLC02Hour));
              dataTime.push(hourPrv);

              if (resultArr[k].hoursx == 17) {
                dataReport.push({
                  time: '17h45 ngày trước đến 17h45 ngày sau',
                  shift: 'Tổng',
                  bocan01: totalLC01,
                  bocan02: totalLC02,
                  total: total
                });
                totalLC01 = 0;
                totalLC02 = 0;
              }

              totalLC01Hour = 0;
              totalLC02Hour = 0;
              time = resultArr[k]._id;
            }

            hourPrv = parseInt(resultArr[k].hoursx);
            loadcell01Prv = parseInt(resultArr[k].loadcell01);
            loadcell02Prv = parseInt(resultArr[k].loadcell02);
          }
        }

        dataBlock.push({
          _id: "Bộ cân 1",
          type: 'bar',
          stack: 'Stack 0',
          data: dataLC01,
          time: dataTime
        });
        dataBlock.push({
          _id: "Bộ cân 2",
          type: 'bar',
          stack: 'Stack 0',
          data: dataLC02,
          time: dataTime
        });
        dataBlock.push({
          _id: "Report",
          data: dataReport
        });
        return dataBlock;
      });
    }

  });
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"taghistorian.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/taghistorian.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  TagHistorian: () => TagHistorian
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let Security;
module.link("./security", {
  default(v) {
    Security = v;
  }

}, 2);
let TagsInterface;
module.link("./taginterfaces.js", {
  default(v) {
    TagsInterface = v;
  }

}, 3);
const TagHistorian = new Mongo.Collection('taghistorian');

if (Meteor.isServer) {
  //================================================================================
  Meteor.publish('tagHistorianRTime', function tagHistorianRTime(find, options) {
    return TagHistorian.find(find, options);
  });
  Meteor.methods({
    'taghistorian.getOperatingHours'() {
      return Promise.asyncApply(() => {
        return TagHistorian.aggregate([{
          $match: {
            typeReport: {
              $eq: "OperatingHours"
            }
          }
        }, {
          $project: {
            _id: 0,
            assignmentTag: 1,
            area: 1
          }
        }]).toArray();
      });
    },

    //================================================================================	
    'taghistorian.getdatablockasyncAxis'(axisid) {
      return Promise.asyncApply(() => {
        return Promise.await(TagHistorian.rawCollection().aggregate([{
          $lookup: {
            from: "siteinterfaces",
            localField: "site",
            foreignField: "_id",
            as: "site"
          }
        }, {
          $unwind: "$site"
        }, {
          $match: {
            axisid: {
              $in: axisid
            }
          }
        }, {
          $sort: {
            "uniqueID": 1
          }
        }, {
          $project: {
            "_id": "$_id",
            "nsite": "$site.name",
            "idSite": "$site._id",
            "assignmentTag": "$assignmentTag",
            "typeReport": "$typeReport",
            "axisid": "$axisid",
            "desc": "$desc",
            "typeHist": "$typeHist",
            "scale": "$scale",
            "uniqueID": "$uniqueID"
          }
        }]).toArray());
      });
    },

    //================================================================================	
    'taghistorian.getdatablockasyncDesc'(desc) {
      return Promise.asyncApply(() => {
        return Promise.await(TagHistorian.rawCollection().aggregate([{
          $lookup: {
            from: "siteinterfaces",
            localField: "site",
            foreignField: "_id",
            as: "site"
          }
        }, {
          $unwind: "$site"
        }, {
          $match: {
            desc: {
              $in: desc
            }
          }
        }, {
          $sort: {
            "uniqueID": 1
          }
        }, {
          $project: {
            "_id": "$_id",
            "nsite": "$site.name",
            "idSite": "$site._id",
            "assignmentTag": "$assignmentTag",
            "typeReport": "$typeReport",
            "axisid": "$axisid",
            "desc": "$desc",
            "typeHist": "$typeHist",
            "scale": "$scale",
            "uniqueID": "$uniqueID"
          }
        }]).toArray());
      });
    },

    //================================================================================	
    'taghistorian.getdatablockasync'() {
      return Promise.asyncApply(() => {
        return Promise.await(TagHistorian.rawCollection().aggregate([{
          $lookup: {
            from: "siteinterfaces",
            localField: "site",
            foreignField: "_id",
            as: "site"
          }
        }, {
          $unwind: "$site"
        }, {
          $sort: {
            "uniqueID": 1
          }
        }, {
          $project: {
            "_id": "$_id",
            "nsite": "$site.name",
            "idSite": "$site._id",
            "assignmentTag": "$assignmentTag",
            "typeReport": "$typeReport",
            "axisid": "$axisid",
            "desc": "$desc",
            "typeHist": "$typeHist",
            "scale": "$scale",
            "uniqueID": "$uniqueID"
          }
        }]).toArray());
      });
    }

  });
}

Meteor.methods({
  //{ "_id" : "zgZKqPcdcBqyH4rT2", "site" : "LagzTsz935ExnArko", "desc" : "note", "typeReport" : 2, "uniqueID" : 105, "assignmentTag" : "4PT3.VALUE", "createDate" : ISODate("2019-06-07T07:48:00.656Z") }	 
  //================================================================================	 
  'taghistorian.insert'(site, assignmentTag, typeReport, desc, axisid, scale, typeHist, datachange) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      if (TagHistorian.findOne({
        $and: [{
          site: {
            $eq: site
          }
        }, {
          typeHist: {
            $eq: typeHist
          }
        }, {
          assignmentTag: {
            $eq: assignmentTag
          }
        }]
      }) != null) {
        throw new Meteor.Error("Duplicate Tag historian");
      } else {
        var uniqueID = 1;
        var data = TagHistorian.findOne({
          site: site
        }, {
          sort: {
            uniqueID: -1
          },
          limit: 1
        });

        if (data == null) {//
        } else {
          uniqueID = parseInt(data.uniqueID) + 1;
        }

        TagHistorian.insert({
          site,
          assignmentTag,
          typeReport,
          desc,
          axisid,
          scale,
          typeHist,
          datachange,
          uniqueID
        });
      }
    }
  },

  //================================================================================	
  'taghistorian.update'(_id, site, assignmentTag, typeReport, desc, axisid, scale, typeHist, datachange) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      // if (TagHistorian.findOne({ $and: [ { site: { $eq: site } }, { assignmentTag: { $eq: assignmentTag }}]}) !=null)
      // {
      // throw new Meteor.Error("Duplicate Tag historian");
      // }
      // else 
      // {			
      TagHistorian.update(_id, {
        $set: {
          assignmentTag,
          desc,
          typeReport,
          axisid,
          scale,
          typeHist,
          datachange
        }
      }); //}
    }
  },

  //================================================================================	
  'taghistorian.remove'(taskId) {
    if (!Security.checkRole(this.userId, 'Owner')) {
      throw new Meteor.Error("logged-in", "You are not permitted.");
    } else {
      TagHistorian.remove(taskId);
    }
  },

  //================================================================================	
  'taghistorian.getdatablock'() {
    var dataBlock = [];
    var index = 0;
    TagHistorian.find().forEach(function (doc) {
      dataBlock.push({
        _id: doc._id,
        index: index,
        assignmentTag: doc.assignmentTag,
        desc: doc.desc,
        typeReport: doc.typeReport
      });
      index = index + 1;
    });
    return dataBlock;
  },

  //================================================================================	
  'taghistorian.getOperatingHour'() {
    var dataBlock = [];
    TagHistorian.find({
      typeReport: "OperatingHours"
    }).forEach(function (doc) {
      dataBlock.push({
        assignmentTag: doc.assignmentTag.split(".", 1)[0],
        desc: doc.desc
      });
    });
    return dataBlock;
  },

  //================================================================================	
  'taghistorian.getProcessData'() {
    var dataBlock = [];
    TagHistorian.find({
      typeReport: "ProcessData"
    }).forEach(function (doc) {
      var tagName = doc.assignmentTag.split(".", 1)[0];
      var unit = Meteor.call('taginterfaces.getUnit', tagName);
      dataBlock.push({
        assignmentTag: tagName,
        desc: doc.desc,
        unit: unit
      });
    });
    return dataBlock;
  },

  //================================================================================	
  'taghistorian.getElectricalSystem'() {
    var dataBlock = [];
    TagHistorian.find({
      typeReport: "ElectricalSystem"
    }).forEach(function (doc) {
      var tagName = doc.assignmentTag.split(".", 1)[0];
      var unit = Meteor.call('taginterfaces.getUnit', tagName);
      dataBlock.push({
        assignmentTag: tagName,
        desc: doc.desc,
        unit: unit
      });
    });
    return dataBlock;
  },

  //================================================================================	
  'taghistorian.findTags'() {
    var arrayData = ["FIT_10301_VALUE.VALUE"];
    var dataBlock = [];
    TagHistorian.find({
      assignmentTag: {
        $in: arrayData
      }
    }).forEach(function (doc) {
      var tagName = doc.assignmentTag.split(".", 1)[0];
      var unit = Meteor.call('taginterfaces.getUnit', tagName);
      dataBlock.push({
        assignmentTag: tagName,
        desc: doc.desc
      });
    });
    return dataBlock;
  },

  //================================================================================	
  'taghistorian.getTag'(dataarr, site) {
    var dataBlock = [];
    var position = 'left';
    var unique = 'Hello';
    var gridLines = true;
    TagHistorian.find({
      uniqueID: {
        $in: dataarr
      },
      site: site
    }, {
      sort: {
        axisid: -1
      }
    }).forEach(function (doc) {
      if (unique == doc.axisid) {//
      } else if (unique != '') {
        dataBlock.push({
          uniqueID: doc.uniqueID,
          axisid: doc.axisid,
          desc: doc.desc,
          gridLines: gridLines,
          position: position
        });

        if (position == 'left') {
          position = 'right';
        } else {
          position = 'left';
        }

        gridLines = false;
      }

      unique = doc.axisid;
    });
    return dataBlock;
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"taginterfaces.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/taginterfaces.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  TagsInterface: () => TagsInterface
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let PLCInterfaces;
module.link("./plcinterfaces.js", {
  default(v) {
    PLCInterfaces = v;
  }

}, 2);
const TagsInterface = new Mongo.Collection('taginterfaces');

//postM@2020
//https://www.codementor.io/@codeforgeek/rest-crud-operation-using-meteor-du10808m5
if (Meteor.isServer) {
  Meteor.publish('taginterfacesNMSetting', function taginterfacesNMSetting(argumentsFind, argumentsOptions) {
    return TagsInterface.find(argumentsFind, argumentsOptions);
  }); //==============================================================================PLANT

  Meteor.publish('tagAlarmEvent', function tagAlarmEvent(argumentsFind, argumentsOptions) {
    return TagsInterface.find(argumentsFind, argumentsOptions);
  }); //This code only runs on the server for PLANT
  //=============================================================================Objects

  Meteor.publish('taginterfacesNMControl', function taginterfacesNMControl(argumentsFind, argumentsOptions) {
    return TagsInterface.find(argumentsFind, argumentsOptions);
  }); //=============================================================================Objects

  Meteor.publish('objectsTMPRealTime', function objectsTMPRealTime(argumentsFind, argumentsOptions) {
    return TagsInterface.find(argumentsFind, argumentsOptions);
  });
  Meteor.publish('objecstDOLRealtime', function objecstDOLRealtime(argumentsFind, argumentsOptions) {
    return TagsInterface.find(argumentsFind, argumentsOptions);
  });
  Meteor.publish('objecstValveRealtime', function objecstValveRealtime(argumentsFind, argumentsOptions) {
    return TagsInterface.find(argumentsFind, argumentsOptions);
  });
  Meteor.publish('objecstVSDrealtime', function objecstVSDrealtime(argumentsFind, argumentsOptions) {
    return TagsInterface.find(argumentsFind, argumentsOptions);
  });
  Meteor.publish('objecstInstrumentRealtime', function objecstInstrumentRealtime(argumentsFind, argumentsOptions) {
    return TagsInterface.find(argumentsFind, argumentsOptions);
  });
  Meteor.publish('objecstLevelRealtime', function objecstLevelRealtime(argumentsFind, argumentsOptions) {
    return TagsInterface.find(argumentsFind, argumentsOptions);
  });
  Meteor.publish('objecstPIDRealtime', function objecstPIDRealtime(argumentsFind, argumentsOptions) {
    return TagsInterface.find(argumentsFind, argumentsOptions);
  });
  Meteor.publish('objecstTextrealtime', function objecstTextrealtime(argumentsFind, argumentsOptions) {
    return TagsInterface.find(argumentsFind, argumentsOptions);
  });
  Meteor.methods({
    //================================================================================	
    'getdatablockObjasync'() {
      return Promise.asyncApply(() => {
        return Promise.await(TagsInterface.rawCollection().aggregate([{
          $lookup: {
            from: "plcinterfaces",
            localField: "selectPLC",
            foreignField: "_id",
            as: "plc"
          }
        }, {
          $unwind: "$plc"
        }, {
          $lookup: {
            from: "siteinterfaces",
            localField: "plc.site",
            foreignField: "_id",
            as: "site"
          }
        }, {
          $unwind: "$site"
        }, {
          $sort: {
            selectPLC: 1
          }
        }, {
          $project: {
            "_id": "$_id",
            "nsite": "$site.name",
            "idSite": "$site._id",
            "value": "$_id",
            "selectPLC": "$plc.name",
            "label": "$tagName"
          }
        }]).toArray());
      });
    }

  });
  Meteor.methods({
    'taginterfaces.getdatablockObjasync'() {
      return Promise.asyncApply(() => {
        return Promise.await(TagsInterface.rawCollection().aggregate([{
          $lookup: {
            from: "plcinterfaces",
            localField: "selectPLC",
            foreignField: "_id",
            as: "plc"
          }
        }, {
          $unwind: "$plc"
        }, {
          $lookup: {
            from: "siteinterfaces",
            localField: "plc.site",
            foreignField: "_id",
            as: "site"
          }
        }, {
          $unwind: "$site"
        }, {
          $sort: {
            selectPLC: 1
          }
        }, {
          $project: {
            "_id": "$_id",
            "nsite": "$site.name",
            "idSite": "$site._id",
            "value": "$_id",
            "selectPLC": "$plc.name",
            "label": "$tagName"
          }
        }]).toArray());
      });
    },

    //================================================================================	
    'taginterfaces.getdatablockasync'() {
      return Promise.asyncApply(() => {
        return Promise.await(TagsInterface.rawCollection().aggregate([{
          $lookup: {
            from: "plcinterfaces",
            localField: "selectPLC",
            foreignField: "_id",
            as: "plc"
          }
        }, {
          $unwind: "$plc"
        }, {
          $lookup: {
            from: "siteinterfaces",
            localField: "plc.site",
            foreignField: "_id",
            as: "site"
          }
        }, {
          $unwind: "$site"
        }, {
          $sort: {
            selectPLC: 1
          }
        }, {
          $project: {
            "_id": "$_id",
            "nsite": "$site.name",
            "idSite": "$site._id",
            "idPLC": "$plc._id",
            "selectPLC": "$plc.name",
            "tagName": "$tagName",
            "description": "$description",
            "dataBlock": "$dataBlock",
            "typeData": "$typeData",
            "typeObject": "$typeObject",
            "addressModbus": "$addressModbus",
            "alarmEnable": "$alarmEnable",
            "status": "$status",
            "quantity": "$quantity",
            "attribute": "$attribute",
            "value": "$_id",
            "label": "$tagName"
          }
        }]).toArray());
      });
    },

    //================================================================================	
    'taginterfaces.getattributeasync'() {
      return Promise.asyncApply(() => {
        var dataBlock = [];
        Promise.await(TagsInterface.rawCollection().aggregate([{
          $lookup: {
            from: "plcinterfaces",
            localField: "selectPLC",
            foreignField: "_id",
            as: "plc"
          }
        }, {
          $unwind: "$plc"
        }, {
          $project: {
            "idSite": "$plc.site",
            "tagName": "$tagName",
            "attribute": "$attribute"
          }
        }]).forEach(function (doc) {
          for (var prop in doc.attribute) {
            if (doc.attribute.hasOwnProperty(prop)) {
              var name = doc.tagName + "." + prop;
              dataBlock.push({
                idSite: doc.idSite,
                name: name
              });
            }
          }
        }));
        return dataBlock;
      });
    },

    //================================================================================		
    'taginterfaces.getPowerRateDaily'() {
      return Promise.asyncApply(() => {
        var loadPower = 0;
        Promise.await(TagsInterface.rawCollection().aggregate([{
          $match: {
            typeData: "SCRObject"
          }
        }]).forEach(function (doc) {
          loadPower = loadPower + parseInt(doc.attribute.LoadPower[0]);
        })); //W unit to kW

        loadPower = parseFloat(loadPower / 1000).toFixed(2);
        return loadPower;
      });
    }

  });
}

; //================================================================================

Meteor.methods({
  //================================================================================		
  'taginterfaces.getname'(id_tag) {
    var tagName = TagsInterface.findOne({
      _id: id_tag
    });

    if (tagName == null) {
      return null;
    } else {
      return tagName.tagName;
    }
  },

  //================================================================================		
  'taginterfaces.getTag'(id_tag) {
    var tag = TagsInterface.findOne({
      _id: id_tag
    }, {
      _id: 0,
      tagName: 0,
      description: 0,
      dataBlock: 0,
      createDate: 0,
      quantity: 0
    });

    if (tag == null) {
      return null;
    } else {
      return tag;
    }
  },

  //================================================================================		
  'taginterfaces.getdatablock'() {
    var dataBlock1 = [];
    TagsInterface.find({}, {
      sort: {
        createDate: -1
      }
    }).forEach(function (doc) {
      var plc = Meteor.call('plcinterfaces.findplc', doc.selectPLC);
      var nsite = Meteor.call('siteinterfaces.getname', plc.site);
      var dataExpand = []; // var addr = parseInt(doc.addressModbus);
      // for (var prop in doc.attribute) {
      // if (doc.attribute.hasOwnProperty(prop)) {
      // var name = doc.tagName + "." + prop;
      // dataExpand.push({
      // fieldA: prop,
      // fieldB: addr,
      // fieldC: doc.attribute[prop][0]
      // });	
      // addr = addr + parseInt(doc.attribute[prop][1]);
      // }
      // }	

      dataBlock1.push({
        _id: doc._id,
        idSite: plc.site,
        nsite: nsite,
        idPLC: doc.selectPLC,
        selectPLC: plc.name,
        tagName: doc.tagName,
        description: doc.description,
        dataBlock: doc.dataBlock,
        typeData: doc.typeData,
        typeObject: doc.typeObject,
        addressModbus: doc.addressModbus,
        alarmEnable: doc.alarmEnable,
        status: doc.status,
        quantity: doc.quantity,
        attribute: doc.attribute,
        expand: dataExpand
      });
    });
    return dataBlock1;
  },

  //================================================================================		
  'taginterfaces.getdatablockObj'() {
    var dataBlock1 = [];
    TagsInterface.find({}, {
      sort: {
        createDate: -1
      }
    }).forEach(function (doc) {
      var idSite = Meteor.call('plcinterfaces.getsite', doc.selectPLC);
      dataBlock1.push({
        _id: doc._id,
        idSite: idSite,
        tagName: doc.tagName
      });
    });
    return dataBlock1;
  },

  //================================================================================	
  'taginterfaces.getattribute'() {
    var dataBlock = [];
    TagsInterface.find().forEach(function (doc) {
      for (var prop in doc.attribute) {
        if (doc.attribute.hasOwnProperty(prop)) {
          var name = doc.tagName + "." + prop;
          dataBlock.push({
            name: name,
            name: name
          });
        }
      }
    });
    return dataBlock;
  },

  //================================================================================	
  'getObjects'(tagName) {
    var dataBlock = [];
    TagsInterface.find({
      tagName: tagName
    }).forEach(function (doc) {
      dataBlock.push({
        CTDEM: doc.attribute.CTDEM[0],
        CTM: doc.attribute.CTM[0],
        CTMJ: doc.attribute.CTMJ[0],
        TMS: doc.attribute.TMS[0],
        ETAT_MODE: doc.attribute.ETAT_MODE[0],
        ETAT_RUNNING: doc.attribute.ETAT_RUNNING[0],
        CMD: doc.attribute.CMD[0],
        ETAT: doc.attribute.ETAT[0]
      });
    });
    return dataBlock;
  },

  //================================================================================	
  'taginterfaces.insert'(tagName, description, selectPLC, dataBlock, typeData, typeObject, addressModbus, alarmEnable, site, datachange, createDate) {
    var quantity = 10;
    var status = "good";
    var attribute = [];
    var unvalid = 0;

    switch (typeData) {
      case "Alarm":
        switch (typeObject) {
          case "Bool":
            attribute = {
              REG: [0, 1],
              VALUE: [0, 1]
            };
            quantity = 2;
            break;

          case "Integer":
            attribute = {
              VALUE: [0, 1]
            };
            quantity = 1;
            break;

          default:
            unvalid = 1;
            break;
        }

        break;

      case "TMPObject":
        attribute = {
          VALUE0: [21, 2],
          VALUE1: [22, 2],
          VALUE2: [23, 2],
          VALUE3: [24, 2],
          VALUE4: [25, 2],
          VALUE5: [26, 2],
          VALUE6: [27, 2],
          VALUE7: [28, 2],
          VALUE8: [24.5, 2],
          ETAT: [0, 1],
          ALARM_USRER: [0, 2]
        };
        quantity = 19;
        break;

      case "SCRObject":
        attribute = {
          LocalRemote: [0, 1],
          CMDRemote: [0, 1],
          ClearErrorLatch: [0, 1],
          Setpoint: [0, 2],
          LineFrequency: [0, 2],
          LineVoltageA: [0, 2],
          LoadVoltageA: [0, 2],
          LoadCurrentA: [0, 2],
          HeatsinkTempA: [0, 2],
          LineVoltageB: [0, 2],
          LoadVoltageB: [0, 2],
          LoadCurrentB: [0, 2],
          HeatsinkTempB: [0, 2],
          LineVoltageC: [0, 2],
          LoadVoltageC: [0, 2],
          LoadCurrentC: [0, 2],
          HeatsinkTempC: [0, 2],
          ControllerState: [0, 1],
          WarningAlarm: [0, 1],
          Duty: [0, 2],
          LoadPower: [0, 2],
          Inhibit: [0, 2],
          Energy: [0, 2],
          ALostCommunication: [0, 2]
        };
        quantity = 37;
        break;

      case "VSD":
        attribute = {
          CTDEM: [0, 2],
          CTM: [0, 2],
          CTMJ: [0, 2],
          TMS: [0, 1],
          ETAT_MODE: [0, 1],
          ETAT_RUNNING: [0, 1],
          FEEDBACK: [0, 1],
          CMD: [0, 1],
          ETAT: [0, 1]
        };
        quantity = 12;
        break;

      case "DOL":
        attribute = {
          CTDEM: [0, 2],
          CTM: [0, 2],
          CTMJ: [0, 2],
          TMS: [0, 1],
          ETAT_MODE: [0, 1],
          ETAT_RUNNING: [0, 1],
          CMD: [0, 1],
          ETAT: [0, 1]
        };
        quantity = 11;
        break;

      case "Valve":
        switch (typeObject) {
          case "AnalogValve":
          case "AnalogValve90":
          case "AnalogValveControl": //Scale from 0-10

          case "AnalogValveControl02": //Scale from 0-20

          case "AnalogValveControl03": //Scale from 0-100

          case "AnalogGateValve":
            attribute = {
              ETAT: [0, 1],
              CMD: [0, 1],
              TMS: [0, 1],
              ETAT_MODE: [0, 1],
              ETAT_RUNNING: [0, 1],
              FEEDBACK: [0, 1]
            };
            quantity = 6;
            break;

          case "AnalogGateValve":
            attribute = {
              ETAT: [0, 1],
              CMD: [0, 1],
              TMS: [0, 1],
              ETAT_MODE: [0, 1],
              ETAT_RUNNING: [0, 1],
              FEEDBACK: [0, 1]
            };
            quantity = 6;
            break;

          case "DigitalValve":
          case "DigitalValve90":
          case "DigitalValve90Left":
          case "GateValve":
          case "CuaPhaiOIK":
          case "CuaPhaiOIK90":
            attribute = {
              ETAT: [0, 1],
              CMD: [0, 1],
              TMS: [0, 1],
              ETAT_MODE: [0, 1],
              ETAT_RUNNING: [0, 1]
            };
            quantity = 5;
            break;

          case "GateValveLong":
            attribute = {
              ETAT: [0, 1],
              CMD: [0, 1],
              TMS: [0, 1],
              ETAT_MODE: [0, 1],
              ETAT_RUNNING: [0, 1]
            };
            quantity = 5;
            break;

          default:
            unvalid = 1;
            break;
        }

        break;

      case "Instrument":
        switch (typeObject) {
          case "CommonInstrument":
            attribute = {
              HHV: [0, 2],
              HV: [0, 2],
              LLV: [0, 2],
              LV: [0, 2],
              VALUE: [0, 2],
              ETAT: [0, 1]
            };
            quantity = 11;
            break;

          case "FITInstrument":
            attribute = {
              HHV: [0, 2],
              HV: [0, 2],
              LLV: [0, 2],
              LV: [0, 2],
              VALUE: [0, 2],
              TOTAL: [0, 2],
              ETAT: [0, 1]
            };
            quantity = 13;
            break;

          default:
            unvalid = 1;
            break;
        }

        break;

      case "Level":
        attribute = {
          ETAT: [0, 1]
        };
        quantity = 1;
        break;

      case "Weighing":
        attribute = {
          VALUE: [0, 2],
          VALUE_SAVE: [0, 2],
          HRV: [0, 2],
          LRV: [0, 2],
          TLG: [0, 2],
          ETAT: [0, 2],
          CMD: [0, 2]
        };
        quantity = 12;
        break;

      case "ELECTRIC":
        attribute = {
          ETAT: [0, 1]
        };
        quantity = 1;
        break;

      case "Number":
        switch (typeObject) {
          case "Bool":
            attribute = {
              REG: [0, 1],
              VALUE: [0, 1]
            };
            quantity = 2;
            break;

          case "Integer":
            attribute = {
              VALUE: [0, 1]
            };
            quantity = 1;
            break;

          case "DoubleInteger":
            attribute = {
              VALUE: [0, 2]
            };
            quantity = 2;
            break;

          case "Real":
            attribute = {
              VALUE: [0, 2]
            };
            quantity = 2;
            break;

          default:
            unvalid = 1;
            break;
        }

        break;

      case "POWERMETER":
        switch (typeObject) {
          case "PowerMeter":
          case "PowerMeter2200":
            attribute = {
              P1: [0, 2],
              P2: [0, 2],
              P3: [0, 2],
              P_TOTAL: [0, 2],
              Q1: [0, 2],
              Q2: [0, 2],
              Q3: [0, 2],
              Q_TOTAL: [0, 2],
              S1: [0, 2],
              S2: [0, 2],
              S3: [0, 2],
              S_TOTAL: [0, 2],
              POWERFACTOR1: [0, 2],
              POWERFACTOR2: [0, 2],
              POWERFACTOR3: [0, 2],
              POWERFACTOR_AVG: [0, 2],
              I1: [0, 2],
              I2: [0, 2],
              I3: [0, 2],
              I_AVG: [0, 2],
              FREQ: [0, 2],
              U12: [0, 2],
              U23: [0, 2],
              U31: [0, 2],
              U_AVG: [0, 2],
              V1: [0, 2],
              V2: [0, 2],
              V3: [0, 2],
              V_AVG: [0, 2],
              ENERGY: [0, 2]
            };
            quantity = 60;
            break;

          default:
            unvalid = 1;
            break;
        }

        break;

      default:
        unvalid = 1;
        break;
    }

    if (unvalid == 1) {//Nothing
    } else {
      if (TagsInterface.findOne({
        $and: [{
          selectPLC: {
            $eq: selectPLC
          }
        }, {
          tagName: {
            $eq: tagName
          }
        }]
      }) != null) {
        throw new Meteor.Error("Duplicate Tagname, Please check again");
      } else {
        TagsInterface.insert({
          tagName,
          description,
          selectPLC,
          dataBlock,
          typeData,
          typeObject,
          addressModbus,
          alarmEnable,
          status,
          quantity,
          attribute,
          site,
          datachange,
          createDate
        });
      }
    }
  },

  //================================================================================	
  'taginterfaces.updateAttribute'(_id, typeData, typeObject, valuecmd, createDate) {
    //console.log("typeData: " + typeData + ", typeObject: " + typeObject)
    var attribute = [];
    var unvalid = 0;

    switch (typeData) {
      case "Number":
        switch (typeObject) {
          case "Integer":
            attribute = {
              VALUE: [valuecmd, 1]
            };
            quantity = 1;
            break;

          case "DoubleInteger":
            attribute = {
              VALUE: [valuecmd, 2]
            };
            quantity = 2;
            break;

          default:
            unvalid = 1;
            break;
        }

        break;

      default:
        unvalid = 1;
        break;
    }

    if (unvalid == 1) {//Nothing
    } else {
      TagsInterface.update(_id, {
        $set: {
          attribute,
          createDate
        }
      });
    }
  },

  //================================================================================	
  'taginterfaces.update'(_id, tagName, description, selectPLC, dataBlock, typeData, typeObject, addressModbus, alarmEnable, site, datachange, createDate) {
    var quantity = 10;
    var status = "good";
    var attribute = [];
    var unvalid = 0; //console.log("typeData " + typeData + " " + "addressModbus " + addressModbus);

    switch (typeData) {
      case "Alarm":
        switch (typeObject) {
          case "Bool":
            attribute = {
              REG: [0, 1],
              VALUE: [0, 1]
            };
            quantity = 2;
            break;

          case "Integer":
            attribute = {
              VALUE: [0, 1]
            };
            quantity = 1;
            break;

          default:
            unvalid = 1;
            break;
        }

        break;

      case "TMPObject":
        attribute = {
          VALUE0: [21, 2],
          VALUE1: [22, 2],
          VALUE2: [23, 2],
          VALUE3: [24, 2],
          VALUE4: [25, 2],
          VALUE5: [26, 2],
          VALUE6: [27, 2],
          VALUE7: [28, 2],
          VALUE8: [24.5, 2],
          ETAT: [0, 1],
          ALARM_USRER: [0, 2]
        };
        quantity = 19;
        break;

      case "SCRObject":
        attribute = {
          LocalRemote: [0, 1],
          CMDRemote: [0, 1],
          ClearErrorLatch: [0, 1],
          Setpoint: [0, 2],
          LineFrequency: [0, 2],
          LineVoltageA: [0, 2],
          LoadVoltageA: [0, 2],
          LoadCurrentA: [0, 2],
          HeatsinkTempA: [0, 2],
          LineVoltageB: [0, 2],
          LoadVoltageB: [0, 2],
          LoadCurrentB: [0, 2],
          HeatsinkTempB: [0, 2],
          LineVoltageC: [0, 2],
          LoadVoltageC: [0, 2],
          LoadCurrentC: [0, 2],
          HeatsinkTempC: [0, 2],
          ControllerState: [0, 1],
          WarningAlarm: [0, 2],
          Duty: [0, 2],
          LoadPower: [0, 2],
          Inhibit: [0, 2],
          Energy: [0, 2],
          ALostCommunication: [0, 2]
        };
        quantity = 37;
        break;

      case "VSD":
        attribute = {
          CTDEM: [0, 2],
          CTM: [0, 2],
          CTMJ: [0, 2],
          TMS: [0, 1],
          ETAT_MODE: [0, 1],
          ETAT_RUNNING: [0, 1],
          FEEDBACK: [0, 1],
          CMD: [0, 1],
          ETAT: [0, 1]
        };
        quantity = 12;
        break;

      case "DOL":
        attribute = {
          CTDEM: [0, 2],
          CTM: [0, 2],
          CTMJ: [0, 2],
          TMS: [0, 1],
          ETAT_MODE: [0, 1],
          ETAT_RUNNING: [0, 1],
          CMD: [0, 1],
          ETAT: [0, 1]
        };
        quantity = 11;
        break;

      case "Valve":
        switch (typeObject) {
          case "AnalogValve":
          case "AnalogValve90":
          case "AnalogValveControl": //Scale from 0-10

          case "AnalogValveControl02": //Scale from 0-20

          case "AnalogValveControl03": //Scale from 0-100

          case "AnalogGateValve":
            attribute = {
              ETAT: [0, 1],
              CMD: [0, 1],
              TMS: [0, 1],
              ETAT_MODE: [0, 1],
              ETAT_RUNNING: [0, 1],
              FEEDBACK: [0, 1]
            };
            quantity = 6;
            break;

          case "DigitalValve":
          case "DigitalValve90":
          case "GateValve":
          case "CuaPhaiOIK":
          case "CuaPhaiOIK90":
            attribute = {
              ETAT: [0, 1],
              CMD: [0, 1],
              TMS: [0, 1],
              ETAT_MODE: [0, 1],
              ETAT_RUNNING: [0, 1]
            };
            quantity = 5;

          case "GateValveLong":
            attribute = {
              ETAT: [0, 1],
              CMD: [0, 1],
              TMS: [0, 1],
              ETAT_MODE: [0, 1],
              ETAT_RUNNING: [0, 1]
            };
            quantity = 5;
            break;

          default:
            unvalid = 1;
            break;
        }

        break;

      case "Instrument":
        switch (typeObject) {
          case "CommonInstrument":
            attribute = {
              HHV: [0, 2],
              HV: [0, 2],
              LLV: [0, 2],
              LV: [0, 2],
              VALUE: [0, 2],
              ETAT: [0, 1]
            };
            quantity = 11;
            break;

          case "BackGroundGreen":
            attribute = {
              HHV: [0, 2],
              HV: [0, 2],
              LLV: [0, 2],
              LV: [0, 2],
              VALUE: [0, 2],
              ETAT: [0, 1]
            };
            quantity = 11;
            break;

          case "FITInstrument":
            attribute = {
              HHV: [0, 2],
              HV: [0, 2],
              LLV: [0, 2],
              LV: [0, 2],
              VALUE: [0, 2],
              TOTAL: [0, 2],
              ETAT: [0, 1]
            };
            quantity = 13;
            break;

          default:
            unvalid = 1;
            break;
        }

        break;

      case "Level":
        attribute = {
          ETAT: [0, 1]
        };
        quantity = 1;
        break;

      case "Weighing":
        attribute = {
          VALUE: [0, 2],
          VALUE_SAVE: [0, 2],
          DATE: [0, 2],
          TIME: [0, 2],
          HRV: [0, 1],
          LRV: [0, 1],
          ETAT: [0, 1],
          CMD: [0, 1],
          MATERIAL: [0, 1],
          BOILER: [0, 1]
        };
        quantity = 12;
        break;

      case "Number":
        switch (typeObject) {
          case "Bool":
            attribute = {
              REG: [0, 1],
              VALUE: [0, 1]
            };
            quantity = 2;
            break;

          case "Integer":
            attribute = {
              VALUE: [0, 1]
            };
            quantity = 1;
            break;

          case "DoubleInteger":
            attribute = {
              VALUE: [0, 2]
            };
            quantity = 2;
            break;

          case "Real":
            attribute = {
              VALUE: [0, 2]
            };
            quantity = 2;
            break;

          default:
            unvalid = 1;
            break;
        }

        break;

      case "ELECTRIC":
        attribute = {
          ETAT: [0, 1]
        };
        quantity = 1;
        break;

      case "POWERMETER":
        switch (typeObject) {
          case "PowerMeter":
          case "PowerMeter2200":
            attribute = {
              P1: [0, 2],
              P2: [0, 2],
              P3: [0, 2],
              P_TOTAL: [0, 2],
              Q1: [0, 2],
              Q2: [0, 2],
              Q3: [0, 2],
              Q_TOTAL: [0, 2],
              S1: [0, 2],
              S2: [0, 2],
              S3: [0, 2],
              S_TOTAL: [0, 2],
              POWERFACTOR1: [0, 2],
              POWERFACTOR2: [0, 2],
              POWERFACTOR3: [0, 2],
              POWERFACTOR_AVG: [0, 2],
              I1: [0, 2],
              I2: [0, 2],
              I3: [0, 2],
              I_AVG: [0, 2],
              FREQ: [0, 2],
              U12: [0, 2],
              U23: [0, 2],
              U31: [0, 2],
              U_AVG: [0, 2],
              V1: [0, 2],
              V2: [0, 2],
              V3: [0, 2],
              V_AVG: [0, 2],
              ENERGY: [0, 2]
            };
            quantity = 60;
            break;

          default:
            unvalid = 1;
            break;
        }

        break;

      default:
        unvalid = 1;
        break;
    }

    if (unvalid == 1) {//Nothing
    } else {
      //console.log("tag description" + description);
      TagsInterface.update(_id, {
        $set: {
          tagName,
          description,
          selectPLC,
          dataBlock,
          typeData,
          typeObject,
          addressModbus,
          alarmEnable,
          attribute,
          createDate,
          quantity,
          site,
          datachange
        }
      });
    }
  },

  'taginterfaces.remove'(taskId) {
    TagsInterface.remove(taskId);
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"userlogin.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/userlogin.js                                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  userLogin: () => userLogin
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let axios;
module.link("axios", {
  default(v) {
    axios = v;
  }

}, 2);
const userLogin = new Mongo.Collection('userLogin');

if (Meteor.isServer) {
  Meteor.methods({
    //================================================================================			
    geolocationTmp(userLoging) {
      return Promise.asyncApply(() => {
        var guestAddress = Promise.await(axios.get('https://api.ipify.org?format=json'));

        if (guestAddress != null) {
          var para = 'https://geolocation-db.com/json/' + guestAddress.data.ip;
          const res = Promise.await(axios.get(para)); //console.log(res.data);

          if (res != null) {
            var country_name = res.data.country_name;
            var city = res.data.city;
            var state = res.data.state;
            var latitude = res.data.latitude;
            var longitude = res.data.longitude;
            var IPv4 = res.data.IPv4;
            var here = new Date(); // suppose the date is 7:00 UTC

            var timestamp = new Date(here.toLocaleString('en-US', {
              timeZone: 'Asia/Tokyo'
            })).getTime();
            userLogin.insert({
              timestamp,
              userLoging,
              country_name,
              city,
              state,
              latitude,
              longitude,
              IPv4
            });
          }
        }
      });
    },

    //================================================================================			
    geolocation(userLoging) {
      return Promise.asyncApply(() => {
        const res = Promise.await(axios.get('https://ipinfo.io/')); //console.log(res);

        if (res != null) {
          var location = res.data.loc.split(",");
          var country_name = res.data.country;
          var city = res.data.city;
          var state = res.data.region;
          var latitude = "";
          var longitude = "";

          if (location.length > 1) {
            latitude = location[0];
            longitude = location[1];
          }

          var IPv4 = res.data.ip;
          var here = new Date(); // suppose the date is 7:00 UTC

          var timestamp = new Date(here.toLocaleString('en-US', {
            timeZone: 'Asia/Tokyo'
          })).getTime();
          userLogin.insert({
            timestamp,
            userLoging,
            country_name,
            city,
            state,
            latitude,
            longitude,
            IPv4
          });
        }
      });
    },

    //================================================================================			
    'getuserLoginasync'() {
      return Promise.asyncApply(() => {
        return Promise.await(userLogin.rawCollection().aggregate([{
          $sort: {
            timestamp: -1
          }
        }, {
          $project: {
            "timestamp": {
              $dateToString: {
                format: "%m-%d %H:%M",
                date: {
                  $add: [new Date(0), "$timestamp"]
                },
                timezone: "Asia/Tokyo"
              }
            },
            "userLoging": "$userLoging",
            "country_name": "$country_name",
            "city": "$city",
            "state": "$state",
            "latitude": "$latitude",
            "longitude": "$longitude",
            "IPv4": "$IPv4"
          }
        }]).toArray());
      });
    }

  });
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/users.js                                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 2);
let Roles;
module.link("meteor/alanning:roles", {
  Roles(v) {
    Roles = v;
  }

}, 3);
let ROLES;
module.link("./roles.js", {
  default(v) {
    ROLES = v;
  }

}, 4);
let axios;
module.link("axios", {
  default(v) {
    axios = v;
  }

}, 5);

//https://github.com/Meteor-Community-Packages/meteor-roles
if (Meteor.isServer) {
  // This code only runs on the server
  Meteor.publish('userData', function () {
    if (!this.userId) {
      return null;
    }

    return Meteor.users.find(this.userId, {});
  });
  Meteor.publish(null, function () {
    if (this.userId) {
      return Meteor.roleAssignment.find({
        'user._id': this.userId
      });
    } else {
      this.ready();
    }
  });
  Meteor.methods({
    getClientIP() {
      return this.connection.clientAddress;
    },

    //================================================================================		
    authenticateRoute(site) {
      if (!this.userId) {
        return 0;
      }

      var flag = false;
      Roles.getGroupsForUser(this.userId).forEach(function (scope) {
        var role = Roles.getRolesForUser(this.userId, scope);

        if (Roles.userIsInRole(this.userId, role, site)) {
          flag = true;
          return;
        }
      });
      if (flag) return 1;
      return 0;
    },

    //================================================================================	
    authenticateRole() {
      if (!this.userId) {
        return ROLES.NScope;
      }

      if (Meteor.user() && Meteor.user().profile) {
        if (Roles.userIsInRole(Meteor.userId(), ROLES.Operator, Meteor.user().profile.site)) {
          return ROLES.Operator;
        } else if (Roles.userIsInRole(Meteor.userId(), ROLES.View, Meteor.user().profile.site)) {
          return ROLES.View;
        } else if (Roles.userIsInRole(Meteor.userId(), ROLES.Administrator, Meteor.user().profile.site)) {
          return ROLES.Administrator;
        } else if (Roles.userIsInRole(Meteor.userId(), ROLES.Owner, Meteor.user().profile.site)) {
          return ROLES.Owner;
        }
      }

      return ROLES.NScope;
    },

    //================================================================================			
    authenticateRoleasync(roles, site) {
      return Promise.asyncApply(() => {
        if (!this.userId) {
          throw new Meteor.Error('not-authorized');
        }

        if ('*' === roles) {
          // allow any logged user
          return 1;
        }

        return Promise.await(Roles.userIsInRole(Meteor.userId(), ['Owner'], site));
      });
    },

    //================================================================================	
    'mGetUser'() {
      return Promise.asyncApply(() => {
        if (!this.userId) {
          throw new Meteor.Error('not-authorized');
        }

        var user = '';
        Meteor.users.find({
          _id: this.userId
        }).forEach(function (doc) {
          user = doc.username;
        });
        return user;
      });
    },

    //================================================================================		
    'mCreateUserasync'(user) {
      if (user.username) {
        if (!Roles.userIsInRole(Meteor.userId(), ROLES.Owner, null)) {
          throw new Meteor.Error("Warning: You are not authorized to perform this action");
        } else {
          if (Meteor.users.findOne({
            username: user.username
          }) != null) {
            throw new Meteor.Error("Tài khoản đã có. Bạn nhập tài khoản khác.");
          } else {
            var id = Accounts.createUser({
              username: user.username,
              password: user.password,
              profile: {
                contact: user.contact
              }
            }); // if (Meteor.roleAssignment.find({ 'user._id': id }).count() === 0) {				
            // Roles.createRole(user.myrole, {unlessExists: true});
            // Roles.addUsersToRoles(id, user.myrole, user.site);						
            // }
          }
        }
      }
    },

    //================================================================================	
    'mUpdateUserasync'(userID, user) {
      if (!Roles.userIsInRole(Meteor.userId(), ROLES.Owner, null)) {
        throw new Meteor.Error("Warning: You are not authorized to perform this action");
      } else {
        if (!this.userId) {
          throw new Meteor.Error('not-authorized');
        }

        var username = Meteor.users.findOne(this.userId).username;

        if (user.username == username || username == "myowner") {
          // Update account
          Meteor.users.update(userID, {
            $set: {
              profile: {
                contact: user.contact
              }
            }
          }); // Update password

          if (user.password != '') {
            // browser's console
            Accounts.setPassword(userID, user.password, function (err) {
              if (!err) {//console.log('Change password was a success!')
              } else {//console.log(err);
                }
            });
          }
        } else {
          throw new Meteor.Error("Warning: You are not authorized to perform this action");
        }
      }
    },

    //================================================================================		
    'mRemoveUser'(taskId) {
      if (!Roles.userIsInRole(Meteor.userId(), ROLES.Owner, null)) {
        throw new Meteor.Error("Warning: You are not authorized to perform this action");
      } else {
        var username = Meteor.users.findOne(taskId).username;

        if (username == "admin" || username == "myowner") {
          throw new Meteor.Error("Bạn không thể xóa Tài khoản này");
        } else {
          Meteor.users.remove(taskId);
        }
      }
    },

    //================================================================================	
    'mAddScope'(taskId, user) {
      if (!Roles.userIsInRole(Meteor.userId(), ROLES.Owner, null)) {
        throw new Meteor.Error("Warning: You are not authorized to perform this action");
      } else {
        if (!this.userId) {
          throw new Meteor.Error('not-authorized');
        }

        if (!Roles.userIsInRole(taskId, user.myrole, user.site)) {
          Roles.createRole(user.myrole, {
            unlessExists: true
          });
          Roles.addUsersToRoles(taskId, user.myrole, user.site);
        } else {
          throw new Meteor.Error("Warning: The role assignment already exists");
        }
      }
    },

    //================================================================================		
    'mRemoveScope'(taskId, user) {
      if (!Roles.userIsInRole(Meteor.userId(), ROLES.Owner, null)) {
        throw new Meteor.Error("logged-in", "You are not permitted.");
      } else {
        var username = Meteor.users.findOne(taskId).username;

        if (username == "admin" || username == "myowner") {
          throw new Meteor.Error("Warning: You are not authorized to perform this action");
        } else {
          Roles.removeUsersFromRoles(taskId, user.myrole, user.site);
        }
      }
    }

  });
}

Meteor.methods({
  //================================================================================	
  'getRolesUser'() {
    var dataBlock = [];
    var myTestCollection = Mongo.Collections.lookup('role-assignment');
    Meteor.myTestCollection.find({
      'user._id': this.userId
    }).forEach(function (doc) {
      dataBlock.push({
        _id: doc._id,
        role: doc.role._id,
        site: doc.scope
      });
    });
    return dataBlock;
  },

  //================================================================================	
  'mdatablockUser'() {
    var dataBlock = [];
    Meteor.users.find({}).forEach(function (doc) {
      // if (doc.username=="myowner")
      // {
      // //
      // } else
      {
        dataBlock.push({
          _id: doc._id,
          username: doc.username,
          contact: doc.profile.contact
        });
      }
    });
    return dataBlock;
  },

  //================================================================================	
  'mdatablockUserLocal'() {
    var dataBlock = [];
    Meteor.users.find({}).forEach(function (doc) {
      if (doc.username == "myowner" || doc.username == "administrator") {//
      } else {
        dataBlock.push({
          _id: doc._id,
          username: doc.username,
          contact: doc.profile.contact
        });
      }
    });
    return dataBlock;
  },

  //================================================================================	
  'mdatablockRole'() {
    var dataBlock = [];
    var index = 0;
    Meteor.users.find({}).forEach(function (doc) {
      Roles.getGroupsForUser(doc._id).forEach(function (scope) {
        var role = Roles.getRolesForUser(doc._id, scope);
        dataBlock.push({
          index: index,
          _id: doc._id,
          username: doc.username,
          site: scope,
          contact: doc.profile.contact,
          myrole: role
        });
        index++;
      });
    });
    return dataBlock;
  },

  //================================================================================	
  'mdatablockRoleLocal'() {
    var dataBlock = [];
    var index = 0;
    Meteor.users.find({}).forEach(function (doc) {
      if (doc.username == "myowner" || doc.username == "administrator") {//
      } else {
        Roles.getGroupsForUser(doc._id).forEach(function (scope) {
          var role = Roles.getRolesForUser(doc._id, scope);
          dataBlock.push({
            index: index,
            _id: doc._id,
            username: doc.username,
            site: scope,
            contact: doc.profile.contact,
            myrole: role
          });
          index++;
        });
      }
    });
    return dataBlock;
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
module.link("/imports/api/siteinterfaces.js");
module.link("/imports/api/plcinterfaces.js");
module.link("/imports/api/modbusinterfaces.js");
module.link("/imports/api/taginterfaces.js");
module.link("/imports/api/cmdinterfaces.js");
module.link("/imports/api/objectsinterfaces.js");
module.link("/imports/api/screeninterfaces.js");
module.link("/imports/api/alarmevent.js");
module.link("/imports/api/taghistorian.js");
module.link("/imports/api/tagdatahistorian.js");
module.link("/imports/api/shifthoursinterface.js");
module.link("/imports/api/biomasevent.js");
module.link("/imports/api/biomasmaterial.js");
module.link("/imports/api/material.js");
module.link("/imports/api/users.js");
let ROLES;
module.link("/imports/api/roles.js", {
  default(v) {
    ROLES = v;
  }

}, 2);
module.link("/imports/api/routeinterface.js");
module.link("/imports/api/screvent.js");
module.link("/imports/api/userlogin.js");
Meteor.startup(() => {
  // code to run on server at startup
  if (Meteor.users.find().fetch().length === 0) {
    console.log('Creating users: ');
    var users = [{
      username: "myowner",
      password: "server@2021",
      roles: [ROLES.Owner],
      profile: {
        contact: "Enginner...."
      }
    }, {
      username: "administrator",
      password: "biomas@2021",
      roles: [ROLES.Owner],
      profile: {
        contact: "Admin.."
      }
    }]; //_.each(users, function (userData) {

    users.forEach(function (user) {
      var id;
      console.log(user);
      id = Accounts.createUser({
        username: user.username,
        password: user.password,
        profile: {
          contact: user.profile.contact
        }
      });

      if (Meteor.roleAssignment.find({
        'user._id': id
      }).count() === 0) {
        user.roles.forEach(function (role) {
          Roles.createRole(role, {
            unlessExists: true
          });
        });
        Roles.addUsersToRoles(id, user.roles, "manager");
        Roles.addUsersToRoles(id, user.roles, null);
      }
    });
  }

  ;
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".mjs",
    ".tsx"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYWxhcm1ldmVudC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYmlvbWFzZXZlbnQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2Jpb21hc21hdGVyaWFsLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jbWRpbnRlcmZhY2VzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9tYXRlcmlhbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvbW9kYnVzaW50ZXJmYWNlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvb2JqZWN0c2ludGVyZmFjZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3BsY2ludGVyZmFjZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3JvbGVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9yb3V0ZWludGVyZmFjZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc2NyZWVuaW50ZXJmYWNlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc2NyZXZlbnQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3NlY3VyaXR5LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9zaGlmdGhvdXJzaW50ZXJmYWNlLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9zaXRlaW50ZXJmYWNlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdGFnZGF0YWhpc3Rvcmlhbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdGFnaGlzdG9yaWFuLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS90YWdpbnRlcmZhY2VzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS91c2VybG9naW4uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3VzZXJzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnQiLCJBbGFybUV2ZW50IiwiTWV0ZW9yIiwibGluayIsInYiLCJNb25nbyIsIkNvbGxlY3Rpb24iLCJpc1NlcnZlciIsInB1Ymxpc2giLCJhbGFybXNQdWJsaWNhdGlvbkV2ZW50IiwiYXJndW1lbnRzRmluZCIsImFyZ3VtZW50c09wdGlvbnMiLCJmaW5kIiwiYWxhcm1SZWFsdGltZSIsIm1ldGhvZHMiLCJudW1BbGFybSIsImRhdGFCbG9jayIsImRhdGFSZXN1bHQiLCJpbmRleCIsIm9wdGlvbnMiLCJ5ZWFyIiwibW9udGgiLCJkYXkiLCJob3VyIiwibWludXRlIiwic2Vjb25kIiwibWVzc2FnZVZTRCIsIm1lc3NhZ2VWYWx2ZSIsIm1lc3NhZ2VXRUkiLCJtZXNzYWdlVlNEQ29ubmVjdCIsInNvcnQiLCJfaWQiLCJsaW1pdCIsImZvckVhY2giLCJkb2MiLCJuYW1lIiwidHlwZSIsInB1c2giLCJvYmpOYW1lIiwic3RhdCIsInRpbWVzdGFtcCIsIkRhdGUiLCJzVGltZSIsInRvTG9jYWxlU3RyaW5nIiwibWVzc2FnZSIsImJpdCIsInRhZyIsInNwbGl0IiwiY29uY2F0IiwibGVuZ3RoIiwic2xpY2UiLCJzaXRlIiwic3RhcnRUaW1lUGFyYW0iLCJlbmRUaW1lUGFyYW0iLCJlbmRUaW1lIiwiJGd0ZSIsIiRsdGUiLCJlVGltZSIsInR5cGVEYXRhIiwicGxjIiwiYXJlYSIsIkJpb21hc0V2ZW50Iiwic3RhcnRUaW1lIiwicmVzdWx0QXJyIiwicmVzdWx0IiwicmF3Q29sbGVjdGlvbiIsImFnZ3JlZ2F0ZSIsIiRtYXRjaCIsIiRzZXQiLCJkYXRlc3giLCIkZGF0ZVRvU3RyaW5nIiwiZm9ybWF0IiwiZGF0ZSIsIiRhZGQiLCJ0aW1lem9uZSIsImhvdXJzeCIsInZhbHVlRSIsIiRndCIsInZhbHVlUyIsIiRwcm9qZWN0IiwibWF0ZXJpYWxTdW0iLCIkc3VidHJhY3QiLCJtYXRlcmlhbCIsImJvaWxlciIsIiRncm91cCIsInN1bVBvaW50cyIsIiRzdW0iLCIkcHVzaCIsIiRzb3J0Iiwic3VtcyIsImludm9pY2VEYXRlIiwibG9hZGNlbGwwMVBydiIsImxvYWRjZWxsMDJQcnYiLCJmaXJzdE9mRGF5IiwiZGF0ZVRpbWUiLCJkYXRhTEMwMSIsImRhdGFMQzAyIiwiZGF0YVRpbWUiLCJkYXRhUmVwb3J0IiwidG90YWxMQzAxVGhhbiIsInRvdGFsTEMwMlRoYW4iLCJ0b3RhbExDMDFCaW9tYXMiLCJ0b3RhbExDMDJCaW9tYXMiLCJ0b3RhbDAxbG8xIiwidG90YWwwMWxvMiIsInRvdGFsMDJsbzEiLCJ0b3RhbDAybG8yIiwidG90YWwwM2xvMSIsInRvdGFsMDNsbzIiLCJ0b3RhbDA0bG8xIiwidG90YWwwNGxvMiIsImsiLCJteUFycmF5IiwicGFyc2VJbnQiLCJ0b3RhbEFsbCIsInJlc3VsdE1hdGVyaWFsIiwiY2FsbCIsImJhc2ljUmVwb3J0Iiwic2VhcmNoQ3JpdGVyaWEiLCJlbGVtZW50IiwiaXRlbSIsImRlc2MiLCJ2YWx1ZSIsInBhcnNlRmxvYXQiLCJ0b0ZpeGVkIiwiTnVtYmVyIiwic3Vic3RyaW5nIiwibSIsIm15UGxhY2UiLCJteVN0YW1wIiwidG90YWwwMTNvMSIsInRvdGFsMDEzbzIiLCJzdGFjayIsImRhdGEiLCJ0aW1lIiwibG9hZCIsInNlbGVjdEJvaWxlciIsImRhdGV0aW1lIiwidG90YWwiLCJsb2FkY2VsbDAxIiwibG9hZGNlbGwwMiIsInNoaWZ0biIsInNoaWZ0IiwiYm9jYW4wMSIsImJvY2FuMDIiLCJCaW9tYXNNYXRlcmlhbCIsIlNlY3VyaXR5IiwiZGVmYXVsdCIsInN0YXJ0VGltZWRzYyIsInRvTG9jYWxlRGF0ZVN0cmluZyIsInRpbWVab25lIiwiZW5kVGltZWRzYyIsImN1aWJhbSIsIm11bmN1YSIsImhhdGRpZXUiLCJkYW1iYW8iLCJjYXluZ2hpZW4iLCJib3R4dW9jIiwiY3VpZG90IiwidHJhdSIsImd1aWJhcCIsImRhdGVTdHIiLCJjb25zb2xlIiwibG9nIiwidGltZXN0YW1wSW5NcyIsImdldFRpbWUiLCIkZXhwciIsIiRhbmQiLCJjaGVja1JvbGUiLCJ1c2VySWQiLCJFcnJvciIsInJlc3VsdE1hdGVyaWFscyIsInJlc3VsdE1hdGVyaWFsZSIsImluc2VydCIsIm5hbWVTaXRlIiwiZmluZE9uZSIsInRhc2tJZCIsInJlbW92ZSIsInVwZGF0ZSIsIkNNREludGVyZmFjZXMiLCJjcmVhdGVkQXQiLCJ0b0FycmF5IiwidHlwZWRhdGEiLCJhY3Rpb25zIiwiYWRkcmVzcyIsInVzZXJuYW1lIiwiY3JlYXRlQXQiLCJsb3ciLCJoaWdoIiwiZjMyIiwiRmxvYXQzMkFycmF5IiwidWkxNiIsIlVpbnQxNkFycmF5IiwiYnVmZmVyIiwib2JqIiwiY29tbWFuZCIsIk1hdGVyaWFsIiwiTW9kYnVzSW50ZXJmYWNlcyIsIlBMQ0ludGVyZmFjZXMiLCIkbG9va3VwIiwiZnJvbSIsImxvY2FsRmllbGQiLCJmb3JlaWduRmllbGQiLCJhcyIsIiR1bndpbmQiLCJjcmVhdGVEYXRlIiwic2VsZWN0UExDIiwibnNpdGUiLCJpZFNpdGUiLCJpZFBMQyIsImRhdGFibG9jayIsInN0YXJ0YWRkcmVzcyIsInF1YW50aXR5IiwiaWRfcGxjIiwiYWRkcmVzc1ZhciIsInNldEJsb2NrTnVtYmVyIiwid29yZHMiLCJsYXN0UmVhZCIsImRhdGFibG9jazEiLCJkYXRhY2hhbmdlIiwiT2JqZWN0c0ludGVyZmFjZXMiLCJUYWdzSW50ZXJmYWNlIiwiU2NyZWVuSW50ZXJmYWNlcyIsImdldE9iamVjdHNTdGF0aWMiLCJhc3NpZ25tZW50VGFnIiwic2NyZWVuIiwieFBvc2l0b24iLCJ5UG9zaXRvbiIsInhTY2FsZSIsInlTY2FsZSIsIiRlcSIsInNjcmVlbk5hbWUiLCJzdGF0aWNPYmoiLCJ0eXBlT2JqZWN0cyIsImNvdW50IiwibmFtZVRhZyIsImlkX3RhZyIsImlkX3NjcmVlbiIsInJvdGF0ZSIsInRhZ3MiLCJjbnRPYmoiLCJTSVRFSW50ZXJmYWNlcyIsIiRyZXBsYWNlUm9vdCIsIm5ld1Jvb3QiLCIkbWVyZ2VPYmplY3RzIiwibnBsYyIsInByb3RvY29sIiwiaXBhZGRyZXNzIiwibmFtZVBMQyIsIlJPTEVTIiwiT3duZXIiLCJBZG1pbmlzdHJhdG9yIiwiT3BlcmF0b3IiLCJWaWV3IiwiTlNjb3BlIiwiZXhwb3J0RGVmYXVsdCIsIlJvdXRlSW50ZXJmYWNlIiwic2NvcGUiLCJwYXRoIiwiY29tcG9uZW50IiwiZXhjZXB0Iiwic2NyZWVuQ29udHJvbFN1YiIsImlka2V5IiwibmFtZVNjcmVlbiIsIlNDUkV2ZW50IiwiUm9sZXMiLCJyb2xlIiwiaGFzUm9sZSIsInVzZXJJc0luUm9sZSIsImNoZWNrTG9nZ2VkSW4iLCJsb2dnZWRJblVzZXIiLCJ1c2VyIiwiU2hpZnRob3Vyc0ludGVyZmFjZSIsImV2biIsImRheUluV2VlayIsImhvdXJTdHIiLCJzaGlmdE51bWJlciIsImhvdXJFbmQiLCJzaXRlQ29udHJvbFN1YiIsImxvY2siLCJ0eXBlQ29udHJvbCIsIlRhZ0RhdGFIaXN0b3JpYW4iLCJkYXRlRGlzcCIsIiRmaWx0ZXIiLCJpbnB1dCIsImNvbmQiLCIkaW4iLCJsbyIsIiRob3VyIiwibWludXRlc3giLCIkbWludXRlIiwiaG91clBydiIsInRvdGFsTEMwMUhvdXIiLCJ0b3RhbExDMDJIb3VyIiwiTWF0aCIsImFicyIsInRvdGFsTEMwMSIsInRvdGFsTEMwMiIsIlRhZ0hpc3RvcmlhbiIsInRhZ0hpc3RvcmlhblJUaW1lIiwidHlwZVJlcG9ydCIsImF4aXNpZCIsInNjYWxlIiwidHlwZUhpc3QiLCJ1bmlxdWVJRCIsInRhZ05hbWUiLCJ1bml0IiwiYXJyYXlEYXRhIiwiZGF0YWFyciIsInBvc2l0aW9uIiwidW5pcXVlIiwiZ3JpZExpbmVzIiwidGFnaW50ZXJmYWNlc05NU2V0dGluZyIsInRhZ0FsYXJtRXZlbnQiLCJ0YWdpbnRlcmZhY2VzTk1Db250cm9sIiwib2JqZWN0c1RNUFJlYWxUaW1lIiwib2JqZWNzdERPTFJlYWx0aW1lIiwib2JqZWNzdFZhbHZlUmVhbHRpbWUiLCJvYmplY3N0VlNEcmVhbHRpbWUiLCJvYmplY3N0SW5zdHJ1bWVudFJlYWx0aW1lIiwib2JqZWNzdExldmVsUmVhbHRpbWUiLCJvYmplY3N0UElEUmVhbHRpbWUiLCJvYmplY3N0VGV4dHJlYWx0aW1lIiwicHJvcCIsImF0dHJpYnV0ZSIsImhhc093blByb3BlcnR5IiwibG9hZFBvd2VyIiwiTG9hZFBvd2VyIiwiZGVzY3JpcHRpb24iLCJkYXRhQmxvY2sxIiwiZGF0YUV4cGFuZCIsInR5cGVPYmplY3QiLCJhZGRyZXNzTW9kYnVzIiwiYWxhcm1FbmFibGUiLCJzdGF0dXMiLCJleHBhbmQiLCJDVERFTSIsIkNUTSIsIkNUTUoiLCJUTVMiLCJFVEFUX01PREUiLCJFVEFUX1JVTk5JTkciLCJDTUQiLCJFVEFUIiwidW52YWxpZCIsIlJFRyIsIlZBTFVFIiwiVkFMVUUwIiwiVkFMVUUxIiwiVkFMVUUyIiwiVkFMVUUzIiwiVkFMVUU0IiwiVkFMVUU1IiwiVkFMVUU2IiwiVkFMVUU3IiwiVkFMVUU4IiwiQUxBUk1fVVNSRVIiLCJMb2NhbFJlbW90ZSIsIkNNRFJlbW90ZSIsIkNsZWFyRXJyb3JMYXRjaCIsIlNldHBvaW50IiwiTGluZUZyZXF1ZW5jeSIsIkxpbmVWb2x0YWdlQSIsIkxvYWRWb2x0YWdlQSIsIkxvYWRDdXJyZW50QSIsIkhlYXRzaW5rVGVtcEEiLCJMaW5lVm9sdGFnZUIiLCJMb2FkVm9sdGFnZUIiLCJMb2FkQ3VycmVudEIiLCJIZWF0c2lua1RlbXBCIiwiTGluZVZvbHRhZ2VDIiwiTG9hZFZvbHRhZ2VDIiwiTG9hZEN1cnJlbnRDIiwiSGVhdHNpbmtUZW1wQyIsIkNvbnRyb2xsZXJTdGF0ZSIsIldhcm5pbmdBbGFybSIsIkR1dHkiLCJJbmhpYml0IiwiRW5lcmd5IiwiQUxvc3RDb21tdW5pY2F0aW9uIiwiRkVFREJBQ0siLCJISFYiLCJIViIsIkxMViIsIkxWIiwiVE9UQUwiLCJWQUxVRV9TQVZFIiwiSFJWIiwiTFJWIiwiVExHIiwiUDEiLCJQMiIsIlAzIiwiUF9UT1RBTCIsIlExIiwiUTIiLCJRMyIsIlFfVE9UQUwiLCJTMSIsIlMyIiwiUzMiLCJTX1RPVEFMIiwiUE9XRVJGQUNUT1IxIiwiUE9XRVJGQUNUT1IyIiwiUE9XRVJGQUNUT1IzIiwiUE9XRVJGQUNUT1JfQVZHIiwiSTEiLCJJMiIsIkkzIiwiSV9BVkciLCJGUkVRIiwiVTEyIiwiVTIzIiwiVTMxIiwiVV9BVkciLCJWMSIsIlYyIiwiVjMiLCJWX0FWRyIsIkVORVJHWSIsInZhbHVlY21kIiwiREFURSIsIlRJTUUiLCJNQVRFUklBTCIsIkJPSUxFUiIsInVzZXJMb2dpbiIsImF4aW9zIiwiZ2VvbG9jYXRpb25UbXAiLCJ1c2VyTG9naW5nIiwiZ3Vlc3RBZGRyZXNzIiwiZ2V0IiwicGFyYSIsImlwIiwicmVzIiwiY291bnRyeV9uYW1lIiwiY2l0eSIsInN0YXRlIiwibGF0aXR1ZGUiLCJsb25naXR1ZGUiLCJJUHY0IiwiaGVyZSIsImdlb2xvY2F0aW9uIiwibG9jYXRpb24iLCJsb2MiLCJjb3VudHJ5IiwicmVnaW9uIiwiQWNjb3VudHMiLCJ1c2VycyIsInJvbGVBc3NpZ25tZW50IiwicmVhZHkiLCJnZXRDbGllbnRJUCIsImNvbm5lY3Rpb24iLCJjbGllbnRBZGRyZXNzIiwiYXV0aGVudGljYXRlUm91dGUiLCJmbGFnIiwiZ2V0R3JvdXBzRm9yVXNlciIsImdldFJvbGVzRm9yVXNlciIsImF1dGhlbnRpY2F0ZVJvbGUiLCJwcm9maWxlIiwiYXV0aGVudGljYXRlUm9sZWFzeW5jIiwicm9sZXMiLCJpZCIsImNyZWF0ZVVzZXIiLCJwYXNzd29yZCIsImNvbnRhY3QiLCJ1c2VySUQiLCJzZXRQYXNzd29yZCIsImVyciIsIm15cm9sZSIsImNyZWF0ZVJvbGUiLCJ1bmxlc3NFeGlzdHMiLCJhZGRVc2Vyc1RvUm9sZXMiLCJyZW1vdmVVc2Vyc0Zyb21Sb2xlcyIsIm15VGVzdENvbGxlY3Rpb24iLCJDb2xsZWN0aW9ucyIsImxvb2t1cCIsInN0YXJ0dXAiLCJmZXRjaCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQUEsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ0MsWUFBVSxFQUFDLE1BQUlBO0FBQWhCLENBQWQ7QUFBMkMsSUFBSUMsTUFBSjtBQUFXSCxNQUFNLENBQUNJLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxLQUFKO0FBQVVOLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0UsT0FBSyxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsU0FBSyxHQUFDRCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRzlHLE1BQU1ILFVBQVUsR0FBRyxJQUFJSSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsWUFBckIsQ0FBbkI7O0FBRVAsSUFBSUosTUFBTSxDQUFDSyxRQUFYLEVBQXFCO0FBQ3BCO0FBQ0FMLFFBQU0sQ0FBQ00sT0FBUCxDQUFlLHdCQUFmLEVBQXlDLFNBQVNDLHNCQUFULENBQWdDQyxhQUFoQyxFQUE4Q0MsZ0JBQTlDLEVBQWdFO0FBQ3hHLFdBQU9WLFVBQVUsQ0FBQ1csSUFBWCxDQUFnQkYsYUFBaEIsRUFBOEJDLGdCQUE5QixDQUFQO0FBQ0EsR0FGRDtBQUlBVCxRQUFNLENBQUNNLE9BQVAsQ0FBZSxlQUFmLEVBQWdDLFNBQVNLLGFBQVQsQ0FBdUJILGFBQXZCLEVBQXNDO0FBQ3JFLFdBQU9ULFVBQVUsQ0FBQ1csSUFBWCxDQUFnQkYsYUFBaEIsQ0FBUDtBQUNBLEdBRkQ7QUFHQzs7QUFFRFIsTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDaEI7QUFDQyxnQ0FBOEJDLFFBQTlCLEVBQ0E7QUFDQyxRQUFJQyxTQUFTLEdBQUcsRUFBaEI7QUFDQSxRQUFJQyxVQUFVLEdBQUcsRUFBakI7QUFDQSxRQUFJQyxLQUFLLEdBQUcsQ0FBWjtBQUNBLFFBQUlDLE9BQU8sR0FBRztBQUFDQyxVQUFJLEVBQUUsU0FBUDtBQUFrQkMsV0FBSyxFQUFFLFNBQXpCO0FBQW9DQyxTQUFHLEVBQUUsU0FBekM7QUFBb0RDLFVBQUksRUFBRSxTQUExRDtBQUFvRUMsWUFBTSxFQUFFLFNBQTVFO0FBQXNGQyxZQUFNLEVBQUU7QUFBOUYsS0FBZDtBQUVBLFFBQUlDLFVBQVUsR0FBRyxDQUFDLHVDQUFELEVBQTBDLCtDQUExQyxFQUEyRixlQUEzRixDQUFqQjtBQUNBLFFBQUlDLFlBQVksR0FBRyxDQUFDLHdDQUFELEVBQTJDLG1DQUEzQyxFQUFnRixxQ0FBaEYsQ0FBbkI7QUFDQSxRQUFJQyxVQUFVLEdBQUcsQ0FBQyxhQUFELEVBQWdCLHVCQUFoQixFQUF5QyxtQkFBekMsRUFBOEQsNEJBQTlELENBQWpCO0FBQ0EsUUFBSUMsaUJBQWlCLEdBQUcsQ0FBQyxtQ0FBRCxFQUFxQyxtQ0FBckMsRUFBeUUsbUNBQXpFLEVBQTZHLG1DQUE3RyxFQUFpSixtQ0FBakosRUFBcUwsbUNBQXJMLEVBQXlOLG1DQUF6TixFQUE2UCxtQ0FBN1AsRUFBaVMsbUNBQWpTLEVBQXFVLG9DQUFyVSxFQUEwVyxvQ0FBMVcsRUFBK1ksb0NBQS9ZLEVBQW9iLG9DQUFwYixFQUF5ZCxvQ0FBemQsRUFBOGYsb0NBQTlmLENBQXhCO0FBRUE1QixjQUFVLENBQUNXLElBQVgsQ0FBZ0I7QUFBQyxjQUFTO0FBQVYsS0FBaEIsRUFBb0M7QUFBRWtCLFVBQUksRUFBRTtBQUFFQyxXQUFHLEVBQUUsQ0FBQztBQUFSLE9BQVI7QUFBcUJDLFdBQUssRUFBQ2pCO0FBQTNCLEtBQXBDLEVBQTBFa0IsT0FBMUUsQ0FBa0YsVUFBU0MsR0FBVCxFQUFjO0FBQy9GLFVBQUlDLElBQUksR0FBR0QsR0FBRyxDQUFDQyxJQUFmOztBQUNBLGNBQVFELEdBQUcsQ0FBQ0UsSUFBWjtBQUVDLGFBQUssS0FBTDtBQUNDcEIsbUJBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkTixlQUFHLEVBQUdHLEdBQUcsQ0FBQ0gsR0FESTtBQUVkTyxtQkFBTyxFQUFHSixHQUFHLENBQUNDLElBRkE7QUFHZEksZ0JBQUksRUFBSSxRQUhNO0FBSWRDLHFCQUFTLEVBQUUsSUFBSUMsSUFBSixDQUFTUCxHQUFHLENBQUNRLEtBQWIsRUFBb0JDLGNBQXBCLENBQW1DLEVBQW5DLEVBQXNDeEIsT0FBdEMsQ0FKRztBQUtkeUIsbUJBQU8sRUFBR2xCLFVBQVUsQ0FBQ1EsR0FBRyxDQUFDVyxHQUFMO0FBTE4sV0FBZjtBQU9BOztBQUNELGFBQUssT0FBTDtBQUNDN0IsbUJBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkTixlQUFHLEVBQUdHLEdBQUcsQ0FBQ0gsR0FESTtBQUVkTyxtQkFBTyxFQUFHSixHQUFHLENBQUNDLElBRkE7QUFHZEksZ0JBQUksRUFBSSxRQUhNO0FBSWRDLHFCQUFTLEVBQUUsSUFBSUMsSUFBSixDQUFTUCxHQUFHLENBQUNRLEtBQWIsRUFBb0JDLGNBQXBCLENBQW1DLEVBQW5DLEVBQXNDeEIsT0FBdEMsQ0FKRztBQUtkeUIsbUJBQU8sRUFBR2YsaUJBQWlCLENBQUNLLEdBQUcsQ0FBQ1csR0FBTDtBQUxiLFdBQWY7QUFPQTs7QUFDRCxhQUFLLE9BQUw7QUFDQzdCLG1CQUFTLENBQUNxQixJQUFWLENBQWU7QUFDZE4sZUFBRyxFQUFHRyxHQUFHLENBQUNILEdBREk7QUFFZE8sbUJBQU8sRUFBR0osR0FBRyxDQUFDQyxJQUZBO0FBR2RJLGdCQUFJLEVBQUksUUFITTtBQUlkQyxxQkFBUyxFQUFFLElBQUlDLElBQUosQ0FBU1AsR0FBRyxDQUFDUSxLQUFiLEVBQW9CQyxjQUFwQixDQUFtQyxFQUFuQyxFQUFzQ3hCLE9BQXRDLENBSkc7QUFLZHlCLG1CQUFPLEVBQUdqQixZQUFZLENBQUNPLEdBQUcsQ0FBQ1csR0FBTDtBQUxSLFdBQWY7QUFPQTs7QUFDRCxhQUFLLFVBQUw7QUFDRTdCLG1CQUFTLENBQUNxQixJQUFWLENBQWU7QUFDZk4sZUFBRyxFQUFHRyxHQUFHLENBQUNILEdBREs7QUFFZE8sbUJBQU8sRUFBR0osR0FBRyxDQUFDQyxJQUZBO0FBR2RJLGdCQUFJLEVBQUksUUFITTtBQUlkQyxxQkFBUyxFQUFFLElBQUlDLElBQUosQ0FBU1AsR0FBRyxDQUFDUSxLQUFiLEVBQW9CQyxjQUFwQixDQUFtQyxFQUFuQyxFQUFzQ3hCLE9BQXRDLENBSkc7QUFLZHlCLG1CQUFPLEVBQUdoQixVQUFVLENBQUNNLEdBQUcsQ0FBQ1csR0FBTDtBQUxOLFdBQWY7QUFPRDs7QUFDRCxhQUFLLE9BQUw7QUFDQyxjQUFJQyxHQUFHLEdBQUdaLEdBQUcsQ0FBQ0MsSUFBSixDQUFTWSxLQUFULENBQWUsT0FBZixFQUF3QixDQUF4QixDQUFWOztBQUNBLGNBQUtELEdBQUcsSUFBSSxNQUFSLElBQW9CQSxHQUFHLElBQUksTUFBM0IsSUFBdUNBLEdBQUcsSUFBSSxNQUE5QyxJQUEwREEsR0FBRyxJQUFJLE1BQWpFLElBQTZFQSxHQUFHLElBQUksTUFBeEYsRUFDQTtBQUNDOUIscUJBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkTixpQkFBRyxFQUFHRyxHQUFHLENBQUNILEdBREk7QUFFZE8scUJBQU8sRUFBR0osR0FBRyxDQUFDQyxJQUZBO0FBR2RJLGtCQUFJLEVBQUksUUFITTtBQUlkQyx1QkFBUyxFQUFFLElBQUlDLElBQUosQ0FBU1AsR0FBRyxDQUFDUSxLQUFiLEVBQW9CQyxjQUFwQixDQUFtQyxFQUFuQyxFQUFzQ3hCLE9BQXRDLENBSkc7QUFLZHlCLHFCQUFPLEVBQUdFLEdBQUcsQ0FBQ0UsTUFBSixDQUFXLCtCQUFYO0FBTEksYUFBZjtBQU9BLFdBVEQsTUFXQTtBQUNDaEMscUJBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkTixpQkFBRyxFQUFHRyxHQUFHLENBQUNILEdBREk7QUFFZE8scUJBQU8sRUFBR0osR0FBRyxDQUFDQyxJQUZBO0FBR2RJLGtCQUFJLEVBQUksUUFITTtBQUlkQyx1QkFBUyxFQUFFLElBQUlDLElBQUosQ0FBU1AsR0FBRyxDQUFDUSxLQUFiLEVBQW9CQyxjQUFwQixDQUFtQyxFQUFuQyxFQUFzQ3hCLE9BQXRDLENBSkc7QUFLZHlCLHFCQUFPLEVBQUc7QUFMSSxhQUFmO0FBT0E7O0FBQ0Q7QUE1REY7QUE4REEsS0FoRUQ7O0FBaUVBLFFBQUk1QixTQUFTLENBQUNpQyxNQUFWLEdBQW1CbEMsUUFBdkIsRUFDQTtBQUNDRSxnQkFBVSxHQUFHRCxTQUFTLENBQUNrQyxLQUFWLENBQWdCLENBQWhCLEVBQWtCbkMsUUFBbEIsQ0FBYjtBQUNBLEtBSEQsTUFJQTtBQUNDRSxnQkFBVSxHQUFHRCxTQUFTLENBQUNrQyxLQUFWLEVBQWI7QUFDQTs7QUFDRCxXQUFPakMsVUFBUDtBQUNBLEdBdkZjOztBQXdGaEI7QUFDQyw0QkFBMEJrQyxJQUExQixFQUErQkMsY0FBL0IsRUFBOENDLFlBQTlDLEVBQ0E7QUFDQyxRQUFJckMsU0FBUyxHQUFJLEVBQWpCO0FBQ0EsUUFBSUUsS0FBSyxHQUFLLENBQWQ7QUFDQSxRQUFJb0MsT0FBTyxHQUFJLEVBQWY7QUFDQSxRQUFJZCxTQUFTLEdBQUksRUFBakI7QUFFQSxRQUFJckIsT0FBTyxHQUFHO0FBQUNDLFVBQUksRUFBRSxTQUFQO0FBQWtCQyxXQUFLLEVBQUUsU0FBekI7QUFBb0NDLFNBQUcsRUFBRSxTQUF6QztBQUFtREMsVUFBSSxFQUFFLFNBQXpEO0FBQW1FQyxZQUFNLEVBQUUsU0FBM0U7QUFBcUZDLFlBQU0sRUFBRTtBQUE3RixLQUFkO0FBRUEsUUFBSUcsVUFBVSxHQUFHLENBQUMsYUFBRCxFQUFnQix1QkFBaEIsRUFBeUMsbUJBQXpDLEVBQThELDRCQUE5RCxDQUFqQjtBQUNBLFFBQUlGLFVBQVUsR0FBRyxDQUFDLHVDQUFELEVBQTBDLCtDQUExQyxFQUEyRixlQUEzRixDQUFqQjtBQUNBLFFBQUlDLFlBQVksR0FBRyxDQUFDLHdDQUFELEVBQTJDLG1DQUEzQyxFQUFnRixxQ0FBaEYsQ0FBbkI7QUFDQSxRQUFJRSxpQkFBaUIsR0FBRyxDQUFDLG1DQUFELEVBQXFDLG1DQUFyQyxFQUF5RSxtQ0FBekUsRUFBNkcsbUNBQTdHLEVBQWlKLG1DQUFqSixFQUFxTCxtQ0FBckwsRUFBeU4sbUNBQXpOLEVBQTZQLG1DQUE3UCxFQUFpUyxtQ0FBalMsRUFBcVUsb0NBQXJVLEVBQTBXLG9DQUExVyxFQUErWSxvQ0FBL1ksRUFBb2Isb0NBQXBiLEVBQXlkLG9DQUF6ZCxFQUE4ZixvQ0FBOWYsQ0FBeEI7QUFFQTVCLGNBQVUsQ0FBQ1csSUFBWCxDQUFnQjtBQUFDOEIsV0FBSyxFQUFDO0FBQUNhLFlBQUksRUFBRUgsY0FBUDtBQUFzQkksWUFBSSxFQUFDSDtBQUEzQjtBQUFQLEtBQWhCLEVBQWlFO0FBQUV2QixVQUFJLEVBQUU7QUFBRUMsV0FBRyxFQUFFLENBQUM7QUFBUjtBQUFSLEtBQWpFLEVBQXVGRSxPQUF2RixDQUErRixVQUFTQyxHQUFULEVBQWM7QUFDNUcsVUFBSUMsSUFBSSxHQUFHRCxHQUFHLENBQUNDLElBQWY7O0FBQ0EsVUFBSUQsR0FBRyxDQUFDdUIsS0FBSixJQUFZLENBQWhCLEVBQ0E7QUFDQ0gsZUFBTyxHQUFHLEVBQVY7QUFDQSxPQUhELE1BS0E7QUFDQ0EsZUFBTyxHQUFHLElBQUliLElBQUosQ0FBU1AsR0FBRyxDQUFDdUIsS0FBYixFQUFvQmQsY0FBcEIsQ0FBbUMsRUFBbkMsRUFBc0N4QixPQUF0QyxDQUFWO0FBQ0E7O0FBQ0RxQixlQUFTLEdBQUcsSUFBSUMsSUFBSixDQUFTUCxHQUFHLENBQUNRLEtBQWIsRUFBb0JDLGNBQXBCLENBQW1DLEVBQW5DLEVBQXNDeEIsT0FBdEMsQ0FBWjs7QUFFQSxjQUFRZSxHQUFHLENBQUNFLElBQVo7QUFFQyxhQUFLLEtBQUw7QUFDRXBCLG1CQUFTLENBQUNxQixJQUFWLENBQWU7QUFDZE4sZUFBRyxFQUFHRyxHQUFHLENBQUNILEdBREk7QUFFZE8sbUJBQU8sRUFBR0osR0FBRyxDQUFDQyxJQUZBO0FBR2R1QixvQkFBUSxFQUFFeEIsR0FBRyxDQUFDRSxJQUhBO0FBSWRJLHFCQUFTLEVBQUUsSUFBSUMsSUFBSixDQUFTUCxHQUFHLENBQUNRLEtBQWIsRUFBb0JDLGNBQXBCLENBQW1DLEVBQW5DLEVBQXNDeEIsT0FBdEMsQ0FKRztBQUtkbUMsbUJBQU8sRUFBR0EsT0FMSTtBQU1kVixtQkFBTyxFQUFHbEIsVUFBVSxDQUFDUSxHQUFHLENBQUNXLEdBQUw7QUFOTixXQUFmO0FBUUQ7O0FBQ0QsYUFBSyxPQUFMO0FBQ0U3QixtQkFBUyxDQUFDcUIsSUFBVixDQUFlO0FBQ2ROLGVBQUcsRUFBR0csR0FBRyxDQUFDSCxHQURJO0FBRWRPLG1CQUFPLEVBQUdKLEdBQUcsQ0FBQ0MsSUFGQTtBQUdkdUIsb0JBQVEsRUFBRXhCLEdBQUcsQ0FBQ0UsSUFIQTtBQUlkSSxxQkFBUyxFQUFFLElBQUlDLElBQUosQ0FBU1AsR0FBRyxDQUFDUSxLQUFiLEVBQW9CQyxjQUFwQixDQUFtQyxFQUFuQyxFQUFzQ3hCLE9BQXRDLENBSkc7QUFLZG1DLG1CQUFPLEVBQUdBLE9BTEk7QUFNZFYsbUJBQU8sRUFBR2YsaUJBQWlCLENBQUNLLEdBQUcsQ0FBQ1csR0FBTDtBQU5iLFdBQWY7QUFRRDs7QUFDRCxhQUFLLE9BQUw7QUFDRTdCLG1CQUFTLENBQUNxQixJQUFWLENBQWU7QUFDZE4sZUFBRyxFQUFHRyxHQUFHLENBQUNILEdBREk7QUFFZE8sbUJBQU8sRUFBR0osR0FBRyxDQUFDQyxJQUZBO0FBR2R1QixvQkFBUSxFQUFFeEIsR0FBRyxDQUFDRSxJQUhBO0FBSWRJLHFCQUFTLEVBQUUsSUFBSUMsSUFBSixDQUFTUCxHQUFHLENBQUNRLEtBQWIsRUFBb0JDLGNBQXBCLENBQW1DLEVBQW5DLEVBQXNDeEIsT0FBdEMsQ0FKRztBQUtkbUMsbUJBQU8sRUFBR0EsT0FMSTtBQU1kVixtQkFBTyxFQUFHakIsWUFBWSxDQUFDTyxHQUFHLENBQUNXLEdBQUw7QUFOUixXQUFmO0FBUUQ7O0FBQ0QsYUFBSyxVQUFMO0FBQ0U3QixtQkFBUyxDQUFDcUIsSUFBVixDQUFlO0FBQ2ROLGVBQUcsRUFBR0csR0FBRyxDQUFDSCxHQURJO0FBRWRPLG1CQUFPLEVBQUdKLEdBQUcsQ0FBQ0MsSUFGQTtBQUdkdUIsb0JBQVEsRUFBRXhCLEdBQUcsQ0FBQ0UsSUFIQTtBQUlkSSxxQkFBUyxFQUFFLElBQUlDLElBQUosQ0FBU1AsR0FBRyxDQUFDUSxLQUFiLEVBQW9CQyxjQUFwQixDQUFtQyxFQUFuQyxFQUFzQ3hCLE9BQXRDLENBSkc7QUFLZG1DLG1CQUFPLEVBQUdBLE9BTEk7QUFNZFYsbUJBQU8sRUFBR2hCLFVBQVUsQ0FBQ00sR0FBRyxDQUFDVyxHQUFMO0FBTk4sV0FBZjtBQVFEOztBQUNELGFBQUssT0FBTDtBQUNDLGNBQUlDLEdBQUcsR0FBR1osR0FBRyxDQUFDQyxJQUFKLENBQVNZLEtBQVQsQ0FBZSxPQUFmLEVBQXdCLENBQXhCLENBQVY7O0FBQ0EsY0FBS0QsR0FBRyxJQUFJLE1BQVIsSUFBb0JBLEdBQUcsSUFBSSxNQUEzQixJQUF1Q0EsR0FBRyxJQUFJLE1BQTlDLElBQTBEQSxHQUFHLElBQUksTUFBakUsSUFBNkVBLEdBQUcsSUFBSSxNQUF4RixFQUNBO0FBQ0M5QixxQkFBUyxDQUFDcUIsSUFBVixDQUFlO0FBQ2ROLGlCQUFHLEVBQUdHLEdBQUcsQ0FBQ0gsR0FESTtBQUVkTyxxQkFBTyxFQUFHSixHQUFHLENBQUNDLElBRkE7QUFHZHVCLHNCQUFRLEVBQUV4QixHQUFHLENBQUNFLElBSEE7QUFJZEksdUJBQVMsRUFBRSxJQUFJQyxJQUFKLENBQVNQLEdBQUcsQ0FBQ1EsS0FBYixFQUFvQkMsY0FBcEIsQ0FBbUMsRUFBbkMsRUFBc0N4QixPQUF0QyxDQUpHO0FBS2RtQyxxQkFBTyxFQUFHQSxPQUxJO0FBTWRWLHFCQUFPLEVBQUdFLEdBQUcsQ0FBQ0UsTUFBSixDQUFXLCtCQUFYO0FBTkksYUFBZjtBQVFBLFdBVkQsTUFZQTtBQUNDaEMscUJBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkTixpQkFBRyxFQUFHRyxHQUFHLENBQUNILEdBREk7QUFFZE8scUJBQU8sRUFBR0osR0FBRyxDQUFDQyxJQUZBO0FBR2R1QixzQkFBUSxFQUFFeEIsR0FBRyxDQUFDRSxJQUhBO0FBSWRJLHVCQUFTLEVBQUUsSUFBSUMsSUFBSixDQUFTUCxHQUFHLENBQUNRLEtBQWIsRUFBb0JDLGNBQXBCLENBQW1DLEVBQW5DLEVBQXNDeEIsT0FBdEMsQ0FKRztBQUtkbUMscUJBQU8sRUFBR0EsT0FMSTtBQU1kVixxQkFBTyxFQUFHO0FBTkksYUFBZjtBQVFBOztBQUNEOztBQUNELGFBQUssWUFBTDtBQUNFNUIsbUJBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkTixlQUFHLEVBQUdHLEdBQUcsQ0FBQ0gsR0FESTtBQUVkNEIsZUFBRyxFQUFJekIsR0FBRyxDQUFDeUIsR0FGRztBQUdkQyxnQkFBSSxFQUFHMUIsR0FBRyxDQUFDMEIsSUFIRztBQUlkdEIsbUJBQU8sRUFBR0osR0FBRyxDQUFDQyxJQUpBO0FBS2R1QixvQkFBUSxFQUFFeEIsR0FBRyxDQUFDRSxJQUxBO0FBTWRJLHFCQUFTLEVBQUUsSUFBSUMsSUFBSixDQUFTUCxHQUFHLENBQUNRLEtBQWIsRUFBb0JDLGNBQXBCLENBQW1DLEVBQW5DLEVBQXNDeEIsT0FBdEMsQ0FORztBQU9kbUMsbUJBQU8sRUFBR0EsT0FQSTtBQVFkVixtQkFBTyxFQUFHVCxJQUFJLENBQUNhLE1BQUwsQ0FBWSxHQUFaLEVBQWlCLG1DQUFqQjtBQVJJLFdBQWY7QUFVRDtBQTlFRjtBQWdGQSxLQTVGRCxFQWJELENBMEdDOztBQUNBLFdBQU9oQyxTQUFQO0FBQ0E7O0FBdE1jLENBQWYsRTs7Ozs7Ozs7Ozs7QUNoQkRqQixNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDNkQsYUFBVyxFQUFDLE1BQUlBO0FBQWpCLENBQWQ7QUFBNkMsSUFBSTNELE1BQUo7QUFBV0gsTUFBTSxDQUFDSSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsS0FBSjtBQUFVTixNQUFNLENBQUNJLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNFLE9BQUssQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFNBQUssR0FBQ0QsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUdoSCxNQUFNeUQsV0FBVyxHQUFHLElBQUl4RCxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsYUFBckIsQ0FBcEI7O0FBRVAsSUFBSUosTUFBTSxDQUFDSyxRQUFYLEVBQXFCO0FBQ2pCTCxRQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNqQjtBQUNNLGtDQUFOLENBQXFDZ0QsU0FBckMsRUFBK0NSLE9BQS9DO0FBQUEsc0NBQXdEO0FBQ3ZELFlBQUl0QyxTQUFTLEdBQUksRUFBakI7QUFDQSxZQUFJK0MsU0FBUyxHQUFHLEVBQWhCLENBRnVELENBR3ZEOztBQUNBLGNBQU1DLE1BQU0saUJBQVNILFdBQVcsQ0FBQ0ksYUFBWixHQUE0QkMsU0FBNUIsQ0FBc0MsQ0FDOUM7QUFBQ0MsZ0JBQU0sRUFBRTtBQUFFekIsaUJBQUssRUFBRTtBQUFFYSxrQkFBSSxFQUFFTyxTQUFSO0FBQW1CTixrQkFBSSxFQUFFRjtBQUF6QjtBQUFUO0FBQVQsU0FEOEMsRUFFOUM7QUFBQ2MsY0FBSSxFQUFFO0FBQUVDLGtCQUFNLEVBQUU7QUFBRUMsMkJBQWEsRUFBRTtBQUFFQyxzQkFBTSxFQUFFLE9BQVY7QUFBbUJDLG9CQUFJLEVBQUU7QUFBQ0Msc0JBQUksRUFBRyxDQUFDLElBQUloQyxJQUFKLENBQVMsQ0FBVCxDQUFELEVBQWMsUUFBZDtBQUFSLGlCQUF6QjtBQUE0RGlDLHdCQUFRLEVBQUU7QUFBdEU7QUFBakI7QUFBVjtBQUFQLFNBRjhDLEVBRzlDO0FBQUNOLGNBQUksRUFBRTtBQUFFTyxrQkFBTSxFQUFFO0FBQUVMLDJCQUFhLEVBQUU7QUFBRUMsc0JBQU0sRUFBRSxhQUFWO0FBQXlCQyxvQkFBSSxFQUFFO0FBQUNDLHNCQUFJLEVBQUcsQ0FBQyxJQUFJaEMsSUFBSixDQUFTLENBQVQsQ0FBRCxFQUFjLFFBQWQ7QUFBUixpQkFBL0I7QUFBa0VpQyx3QkFBUSxFQUFFO0FBQTVFO0FBQWpCO0FBQVY7QUFBUCxTQUg4QyxFQUk5QztBQUFDUCxnQkFBTSxFQUFFO0FBQUVTLGtCQUFNLEVBQUU7QUFBRUMsaUJBQUcsRUFBRSxDQUFQO0FBQVVyQixrQkFBSSxFQUFFO0FBQWhCO0FBQVY7QUFBVCxTQUo4QyxFQUs5QztBQUFDVyxnQkFBTSxFQUFFO0FBQUVXLGtCQUFNLEVBQUU7QUFBRUQsaUJBQUcsRUFBRSxDQUFQO0FBQVVyQixrQkFBSSxFQUFFO0FBQWhCO0FBQVY7QUFBVCxTQUw4QyxFQU05QztBQUFDdUIsa0JBQVEsRUFDTDtBQUNJaEQsZUFBRyxFQUFDLE9BRFI7QUFFSWlELHVCQUFXLEVBQUU7QUFBRUMsdUJBQVMsRUFBRyxDQUFFLFNBQUYsRUFBYSxTQUFiO0FBQWQsYUFGakI7QUFHSVosa0JBQU0sRUFBQyxTQUhYO0FBSUlNLGtCQUFNLEVBQUMsU0FKWDtBQUtJTyxvQkFBUSxFQUFDLFdBTGI7QUFNSUMsa0JBQU0sRUFBQztBQU5YO0FBREosU0FOOEMsRUFnQjlDO0FBQUNoQixnQkFBTSxFQUFFO0FBQUVhLHVCQUFXLEVBQUU7QUFBRUgsaUJBQUcsRUFBRSxDQUFQO0FBQVVyQixrQkFBSSxFQUFFO0FBQWhCO0FBQWY7QUFBVCxTQWhCOEMsRUFpQjlDO0FBQUM0QixnQkFBTSxFQUNIO0FBQ0lyRCxlQUFHLEVBQUM7QUFBQzRDLG9CQUFNLEVBQUMsU0FBUjtBQUFtQnhDLGtCQUFJLEVBQUM7QUFBeEIsYUFEUjtBQUVJa0QscUJBQVMsRUFBQztBQUFDQyxrQkFBSSxFQUFDO0FBQU4sYUFGZDtBQUdJbEQsZ0JBQUksRUFBRTtBQUNGbUQsbUJBQUssRUFBRTtBQUFFLDRCQUFhLFdBQWY7QUFBNEIsMEJBQVc7QUFBdkM7QUFETDtBQUhWO0FBREosU0FqQjhDLEVBMEI5QztBQUFDQyxlQUFLLEVBQUc7QUFBRSwwQkFBYTtBQUFmO0FBQVQsU0ExQjhDLEVBMkI5QztBQUFDSixnQkFBTSxFQUNIO0FBQ0lyRCxlQUFHLEVBQUM7QUFBQzRDLG9CQUFNLEVBQUM7QUFBUixhQURSO0FBRUljLGdCQUFJLEVBQUM7QUFBQ0gsa0JBQUksRUFBQztBQUFOLGFBRlQ7QUFHSUksdUJBQVcsRUFBRTtBQUNUSCxtQkFBSyxFQUFFO0FBQUUsMkJBQVksV0FBZDtBQUEyQiwyQkFBWSxZQUF2QztBQUFzRCx3QkFBUztBQUEvRDtBQURFO0FBSGpCO0FBREosU0EzQjhDLEVBb0M5QztBQUFDQyxlQUFLLEVBQUc7QUFBRSwwQkFBYTtBQUFmO0FBQVQsU0FwQzhDLENBQXRDLEVBcUNsQnZELE9BckNrQixDQXFDVixVQUFTQyxHQUFULEVBQWM7QUFDeEI2QixtQkFBUyxDQUFDMUIsSUFBVixDQUFlSCxHQUFmO0FBQ0EsU0F2Q29CLENBQVQsQ0FBWjtBQXlDQSxZQUFJeUQsYUFBYSxHQUFHLENBQXBCO0FBQ0EsWUFBSUMsYUFBYSxHQUFHLENBQXBCO0FBQ0EsWUFBSUMsVUFBVSxHQUFJLENBQWxCO0FBQ0EsWUFBSVgsUUFBUSxHQUFVLENBQXRCO0FBQ0EsWUFBSUMsTUFBTSxHQUFZLENBQXRCO0FBQ0EsWUFBSVcsUUFBUSxHQUFVLENBQXRCO0FBQ0EsWUFBSUMsUUFBUSxHQUFHLEVBQWY7QUFDQSxZQUFJQyxRQUFRLEdBQUcsRUFBZjtBQUNBLFlBQUlDLFFBQVEsR0FBRyxFQUFmO0FBQ0EsWUFBSUMsVUFBVSxHQUFDLEVBQWY7QUFFQSxZQUFJQyxhQUFhLEdBQUksQ0FBckI7QUFDQSxZQUFJQyxhQUFhLEdBQUksQ0FBckI7QUFDQSxZQUFJQyxlQUFlLEdBQUcsQ0FBdEI7QUFDQSxZQUFJQyxlQUFlLEdBQUcsQ0FBdEI7QUFDQSxZQUFJQyxVQUFVLEdBQUcsQ0FBakI7QUFDQSxZQUFJQyxVQUFVLEdBQUcsQ0FBakI7QUFDQSxZQUFJQyxVQUFVLEdBQUcsQ0FBakI7QUFDQSxZQUFJQyxVQUFVLEdBQUcsQ0FBakI7QUFDQSxZQUFJQyxVQUFVLEdBQUcsQ0FBakI7QUFDQSxZQUFJQyxVQUFVLEdBQUcsQ0FBakI7QUFDQSxZQUFJQyxVQUFVLEdBQUcsQ0FBakI7QUFDQSxZQUFJQyxVQUFVLEdBQUcsQ0FBakI7O0FBR0EsYUFBSyxJQUFJQyxDQUFDLEdBQUMsQ0FBWCxFQUFjQSxDQUFDLEdBQUdoRCxTQUFTLENBQUNkLE1BQTVCLEVBQW9DOEQsQ0FBQyxFQUFyQyxFQUNBO0FBQ2MsY0FBSUMsT0FBTyxHQUFHakQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFoRixHQUFiLENBQWlCNEMsTUFBakIsQ0FBd0I1QixLQUF4QixDQUE4QixHQUE5QixDQUFkOztBQUNiLGNBQUs4QyxVQUFVLElBQUUsQ0FBYixJQUFvQm9CLFFBQVEsQ0FBQ0QsT0FBTyxDQUFDLENBQUQsQ0FBUixDQUFSLElBQXVCLENBQS9DLEVBQ0E7QUFDQ2xCLG9CQUFRLEdBQUlrQixPQUFPLENBQUMsQ0FBRCxDQUFuQjtBQUNBbkIsc0JBQVUsR0FBTyxDQUFqQjtBQUNBLFdBSkQsTUFLaUIsSUFBSUEsVUFBVSxJQUFFLENBQWhCLEVBQ2pCO0FBQ2dCLGdCQUFLQyxRQUFRLElBQUlrQixPQUFPLENBQUMsQ0FBRCxDQUFwQixJQUE2QkMsUUFBUSxDQUFDRCxPQUFPLENBQUMsQ0FBRCxDQUFSLENBQVIsSUFBdUIsQ0FBeEQsRUFDZjtBQUVtQixrQkFBSUUsUUFBUSxHQUFJdkIsYUFBYSxHQUFHQyxhQUFoQztBQUNBLG9CQUFNdUIsY0FBYyxpQkFBU2pILE1BQU0sQ0FBQ2tILElBQVAsQ0FBWSxzQkFBWixFQUFvQ0osT0FBTyxDQUFDLENBQUQsQ0FBM0MsQ0FBVCxDQUFwQjs7QUFFQSxrQkFBSUcsY0FBYyxJQUFJLEVBQXRCLEVBQTBCO0FBQzNDO0FBQ0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDRDtBQUVxQixvQkFBSUUsV0FBVyxHQUFDLEVBQWhCO0FBQ0Esb0JBQUlDLGNBQWMsR0FBSyxFQUF2QjtBQUNBRCwyQkFBVyxHQUFHLENBQ1Y7QUFBQywwQkFBUSxXQUFUO0FBQTJCLDJCQUFVdkI7QUFBckMsaUJBRFUsRUFFVjtBQUFDLDBCQUFRLFVBQVQ7QUFBMkIsMkJBQVVIO0FBQXJDLGlCQUZVLEVBR1Y7QUFBQywwQkFBUSxVQUFUO0FBQTJCLDJCQUFVQztBQUFyQyxpQkFIVSxFQUlWO0FBQUMsMEJBQVEsTUFBVDtBQUEyQiwyQkFBVXNCO0FBQXJDLGlCQUpVLEVBS1Y7QUFBQywwQkFBUSxXQUFUO0FBQTJCLDJCQUFVZixhQUFhLEdBQUdDO0FBQXJELGlCQUxVLEVBTVY7QUFBQywwQkFBUSxhQUFUO0FBQTJCLDJCQUFVQyxlQUFlLEdBQUdDO0FBQXZELGlCQU5VLEVBT1Y7QUFBQywwQkFBUSxlQUFUO0FBQTJCLDJCQUFVQyxVQUFVLEdBQUdDO0FBQWxELGlCQVBVLEVBUVY7QUFBQywwQkFBUSxlQUFUO0FBQTJCLDJCQUFVQyxVQUFVLEdBQUdDO0FBQWxELGlCQVJVLEVBU1Y7QUFBQywwQkFBUSxlQUFUO0FBQTJCLDJCQUFVQyxVQUFVLEdBQUdDO0FBQWxELGlCQVRVLEVBVVY7QUFBQywwQkFBUSxlQUFUO0FBQTJCLDJCQUFVQyxVQUFVLEdBQUdDO0FBQWxELGlCQVZVLENBQWQ7QUFhQUssOEJBQWMsQ0FBQyxDQUFELENBQWQsQ0FBa0JqQyxRQUFsQixDQUEyQmpELE9BQTNCLENBQW1DLENBQUNzRixPQUFELEVBQVVyRyxLQUFWLEtBQW9CO0FBQ25ELHNCQUFJc0csSUFBSSxHQUFHRCxPQUFPLENBQUNFLElBQW5CO0FBQ0FELHNCQUFJLEdBQUdBLElBQUksQ0FBQ3hFLE1BQUwsQ0FBWSxHQUFaLEVBQWdCdUUsT0FBTyxDQUFDRyxLQUF4QixFQUE4QixHQUE5QixDQUFQLENBRm1ELENBR25EOztBQUNBSixnQ0FBYyxDQUFDRSxJQUFELENBQWQsR0FBdUIsRUFBdkI7QUFDQUYsZ0NBQWMsQ0FBQ0UsSUFBRCxDQUFkLENBQXFCbkYsSUFBckIsQ0FBMEJzRixVQUFVLENBQUVULFFBQVEsR0FBR1MsVUFBVSxDQUFDSixPQUFPLENBQUNHLEtBQVQsQ0FBdEIsR0FBeUMsR0FBMUMsQ0FBVixDQUF5REUsT0FBekQsQ0FBaUUsQ0FBakUsQ0FBMUI7QUFFSCxpQkFQRDtBQVFBUCwyQkFBVyxDQUFDcEYsT0FBWixDQUFvQixDQUFDc0YsT0FBRCxFQUFVckcsS0FBVixLQUFvQjtBQUNwQ29HLGdDQUFjLENBQUNDLE9BQU8sQ0FBQ0UsSUFBVCxDQUFkLEdBQStCLEVBQS9CO0FBQ0FILGdDQUFjLENBQUNDLE9BQU8sQ0FBQ0UsSUFBVCxDQUFkLENBQTZCcEYsSUFBN0IsQ0FBa0NrRixPQUFPLENBQUNHLEtBQTFDO0FBRUgsaUJBSkQ7QUFLQXhCLDBCQUFVLENBQUM3RCxJQUFYLENBQWdCaUYsY0FBaEI7QUFDckIsZUFwRGlCLE1Bc0RsQjtBQUNDcEIsMEJBQVUsQ0FBQzdELElBQVgsQ0FBZ0I7QUFDZiwrQkFBYXlELFFBREU7QUFFZiw4QkFBWUgsYUFGRztBQUdmLDhCQUFZQyxhQUhHO0FBSWYsMEJBQVNzQixRQUpNO0FBS2YsK0JBQWFmLGFBQWEsR0FBR0MsYUFMZDtBQU1mLGlDQUFnQkMsZUFBZSxHQUFHQztBQU5uQixpQkFBaEI7QUFTQTs7QUFFRFAsc0JBQVEsQ0FBQzFELElBQVQsQ0FDQ3dGLE1BQU0sQ0FBQ2xDLGFBQUQsQ0FEUDtBQUdBSyxzQkFBUSxDQUFDM0QsSUFBVCxDQUNDd0YsTUFBTSxDQUFDakMsYUFBRCxDQURQO0FBR0FLLHNCQUFRLENBQUM1RCxJQUFULENBQ0N5RCxRQUFRLENBQUNnQyxTQUFULENBQW1CLENBQW5CLENBREQ7QUFHa0JoQyxzQkFBUSxHQUFJa0IsT0FBTyxDQUFDLENBQUQsQ0FBbkI7QUFDQXJCLDJCQUFhLEdBQUcsQ0FBaEI7QUFDQUMsMkJBQWEsR0FBRyxDQUFoQjtBQUNsQlMsNkJBQWUsR0FBSSxDQUFuQjtBQUNBQyw2QkFBZSxHQUFJLENBQW5CO0FBQ0FDLHdCQUFVLEdBQUcsQ0FBYjtBQUNBQyx3QkFBVSxHQUFHLENBQWI7QUFDQUMsd0JBQVUsR0FBRyxDQUFiO0FBQ0FDLHdCQUFVLEdBQUcsQ0FBYjtBQUNBQyx3QkFBVSxHQUFHLENBQWI7QUFDQUMsd0JBQVUsR0FBRyxDQUFiO0FBQ0FDLHdCQUFVLEdBQUcsQ0FBYjtBQUNBQyx3QkFBVSxHQUFHLENBQWI7QUFDQTtBQUNEOztBQUNXLGVBQUssSUFBSWlCLENBQUMsR0FBQyxDQUFYLEVBQWNBLENBQUMsR0FBRWhFLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhckIsV0FBYixDQUF5QnpDLE1BQTFDLEVBQWtEOEUsQ0FBQyxFQUFuRCxFQUNBO0FBQ0k3QyxvQkFBUSxHQUFHK0IsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFyQixXQUFiLENBQXlCcUMsQ0FBekIsRUFBNEIzRixJQUE1QixDQUFpQyxDQUFqQyxFQUFvQzhDLFFBQXJDLENBQW5CO0FBQ0FDLGtCQUFNLEdBQUc4QixRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXJCLFdBQWIsQ0FBeUJxQyxDQUF6QixFQUE0QjNGLElBQTVCLENBQWlDLENBQWpDLEVBQW9DK0MsTUFBckMsQ0FBakI7O0FBRUEsb0JBQU9wQixTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXJCLFdBQWIsQ0FBeUJxQyxDQUF6QixFQUE0QkMsT0FBbkM7QUFFSSxtQkFBSyxXQUFMO0FBQWlCO0FBQ2JyQyw2QkFBYSxHQUFHQSxhQUFhLEdBQUdzQixRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXJCLFdBQWIsQ0FBeUJxQyxDQUF6QixFQUE0QkUsT0FBN0IsQ0FBeEM7O0FBQ0Esd0JBQU8vQyxRQUFQO0FBRUksdUJBQUssQ0FBTDtBQUFPO0FBQ0htQixtQ0FBZSxHQUFHQSxlQUFlLEdBQUdZLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhckIsV0FBYixDQUF5QnFDLENBQXpCLEVBQTRCRSxPQUE3QixDQUE1QztBQUNBOztBQUNKLHVCQUFLLENBQUw7QUFBTztBQUNIOUIsaUNBQWEsR0FBR0MsYUFBYSxHQUFHYSxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXJCLFdBQWIsQ0FBeUJxQyxDQUF6QixFQUE0QkUsT0FBN0IsQ0FBeEM7QUFDQTs7QUFDSjtBQUNJO0FBVFI7O0FBV0Esd0JBQU85QyxNQUFQO0FBRUksdUJBQUssQ0FBTDtBQUFPO0FBQ0hvQiw4QkFBVSxHQUFHQSxVQUFVLEdBQUdVLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhckIsV0FBYixDQUF5QnFDLENBQXpCLEVBQTRCRSxPQUE3QixDQUFsQztBQUNBOztBQUNKLHVCQUFLLENBQUw7QUFBTztBQUNIeEIsOEJBQVUsR0FBR0EsVUFBVSxHQUFHUSxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXJCLFdBQWIsQ0FBeUJxQyxDQUF6QixFQUE0QkUsT0FBN0IsQ0FBbEM7QUFDQTs7QUFDSix1QkFBSyxDQUFMO0FBQU87QUFDSHRCLDhCQUFVLEdBQUd1QixVQUFVLEdBQUdqQixRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXJCLFdBQWIsQ0FBeUJxQyxDQUF6QixFQUE0QkUsT0FBN0IsQ0FBbEM7QUFDQTs7QUFDSix1QkFBSyxDQUFMO0FBQU87QUFDSHBCLDhCQUFVLEdBQUdBLFVBQVUsR0FBR0ksUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFyQixXQUFiLENBQXlCcUMsQ0FBekIsRUFBNEJFLE9BQTdCLENBQWxDO0FBQ0E7O0FBQ0o7QUFDSTtBQWZSOztBQWlCQTs7QUFDSixtQkFBSyxXQUFMO0FBQWlCO0FBQ2JyQyw2QkFBYSxHQUFHQSxhQUFhLEdBQUdxQixRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXJCLFdBQWIsQ0FBeUJxQyxDQUF6QixFQUE0QkUsT0FBN0IsQ0FBeEM7O0FBQ0Esd0JBQU8vQyxRQUFQO0FBRUksdUJBQUssQ0FBTDtBQUFPO0FBQ0hvQixtQ0FBZSxHQUFHQSxlQUFlLEdBQUdXLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhckIsV0FBYixDQUF5QnFDLENBQXpCLEVBQTRCRSxPQUE3QixDQUE1QztBQUNBOztBQUNKLHVCQUFLLENBQUw7QUFBTztBQUNIN0IsaUNBQWEsR0FBR0EsYUFBYSxHQUFHYSxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXJCLFdBQWIsQ0FBeUJxQyxDQUF6QixFQUE0QkUsT0FBN0IsQ0FBeEM7QUFDQTs7QUFDSjtBQUNJO0FBVFI7O0FBV0Esd0JBQU85QyxNQUFQO0FBRUksdUJBQUssQ0FBTDtBQUFPO0FBQ0hxQiw4QkFBVSxHQUFHQSxVQUFVLEdBQUdTLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhckIsV0FBYixDQUF5QnFDLENBQXpCLEVBQTRCRSxPQUE3QixDQUFsQztBQUNBOztBQUNKLHVCQUFLLENBQUw7QUFBTztBQUNIdkIsOEJBQVUsR0FBR0EsVUFBVSxHQUFHTyxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXJCLFdBQWIsQ0FBeUJxQyxDQUF6QixFQUE0QkUsT0FBN0IsQ0FBbEM7QUFDQTs7QUFDSix1QkFBSyxDQUFMO0FBQU87QUFDSHJCLDhCQUFVLEdBQUd1QixVQUFVLEdBQUdsQixRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXJCLFdBQWIsQ0FBeUJxQyxDQUF6QixFQUE0QkUsT0FBN0IsQ0FBbEM7QUFDQTs7QUFDSix1QkFBSyxDQUFMO0FBQU87QUFDSG5CLDhCQUFVLEdBQUdBLFVBQVUsR0FBR0csUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFyQixXQUFiLENBQXlCcUMsQ0FBekIsRUFBNEJFLE9BQTdCLENBQWxDO0FBQ0E7O0FBQ0o7QUFDSTtBQWZSOztBQWlCQTs7QUFDSjtBQUNJO0FBakVSO0FBcUVIO0FBRWI7O0FBRURqSCxpQkFBUyxDQUFDcUIsSUFBVixDQUFlO0FBQ2ROLGFBQUcsRUFBRSxVQURTO0FBRWRLLGNBQUksRUFBRSxLQUZRO0FBR2RnRyxlQUFLLEVBQUUsU0FITztBQUlkQyxjQUFJLEVBQUV0QyxRQUpRO0FBS2R1QyxjQUFJLEVBQUVyQztBQUxRLFNBQWY7QUFPQWpGLGlCQUFTLENBQUNxQixJQUFWLENBQWU7QUFDZE4sYUFBRyxFQUFFLFVBRFM7QUFFZEssY0FBSSxFQUFFLEtBRlE7QUFHZGdHLGVBQUssRUFBRSxTQUhPO0FBSWRDLGNBQUksRUFBRXJDLFFBSlE7QUFLZHNDLGNBQUksRUFBRXJDO0FBTFEsU0FBZjtBQU9BakYsaUJBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkTixhQUFHLEVBQUUsUUFEUztBQUVkc0csY0FBSSxFQUFFbkM7QUFGUSxTQUFmO0FBSUEsZUFBT2xGLFNBQVA7QUFDQSxPQWpSRDtBQUFBLEtBRmlCOztBQW9SWDtBQUNBLGlDQUFOLENBQW9DOEMsU0FBcEMsRUFBOENSLE9BQTlDO0FBQUEsc0NBQXVEO0FBQ3RELFlBQUl0QyxTQUFTLEdBQUksRUFBakI7QUFDQSxZQUFJK0MsU0FBUyxHQUFHLEVBQWhCLENBRnNELENBR3REOztBQUNBLGNBQU1DLE1BQU0saUJBQVNILFdBQVcsQ0FBQ0ksYUFBWixHQUE0QkMsU0FBNUIsQ0FBc0MsQ0FDOUM7QUFBQ0MsZ0JBQU0sRUFBRTtBQUFFekIsaUJBQUssRUFBRTtBQUFFYSxrQkFBSSxFQUFFTyxTQUFSO0FBQW1CTixrQkFBSSxFQUFFRjtBQUF6QjtBQUFUO0FBQVQsU0FEOEMsRUFFOUM7QUFBQ2MsY0FBSSxFQUFFO0FBQUVDLGtCQUFNLEVBQUU7QUFBRUMsMkJBQWEsRUFBRTtBQUFFQyxzQkFBTSxFQUFFLE9BQVY7QUFBbUJDLG9CQUFJLEVBQUU7QUFBQ0Msc0JBQUksRUFBRyxDQUFDLElBQUloQyxJQUFKLENBQVMsQ0FBVCxDQUFELEVBQWMsUUFBZDtBQUFSLGlCQUF6QjtBQUE0RGlDLHdCQUFRLEVBQUU7QUFBdEU7QUFBakI7QUFBVjtBQUFQLFNBRjhDLEVBRzlDO0FBQUNOLGNBQUksRUFBRTtBQUFFTyxrQkFBTSxFQUFFO0FBQUVMLDJCQUFhLEVBQUU7QUFBRUMsc0JBQU0sRUFBRSxnQkFBVjtBQUE0QkMsb0JBQUksRUFBRTtBQUFDQyxzQkFBSSxFQUFHLENBQUMsSUFBSWhDLElBQUosQ0FBUyxDQUFULENBQUQsRUFBYyxRQUFkO0FBQVIsaUJBQWxDO0FBQXFFaUMsd0JBQVEsRUFBRTtBQUEvRTtBQUFqQjtBQUFWO0FBQVAsU0FIOEMsRUFJOUM7QUFBQ1AsZ0JBQU0sRUFBRTtBQUFFUyxrQkFBTSxFQUFFO0FBQUVDLGlCQUFHLEVBQUUsQ0FBUDtBQUFVckIsa0JBQUksRUFBRTtBQUFoQjtBQUFWO0FBQVQsU0FKOEMsRUFLOUM7QUFBQ1csZ0JBQU0sRUFBRTtBQUFFVyxrQkFBTSxFQUFFO0FBQUVELGlCQUFHLEVBQUUsQ0FBUDtBQUFVckIsa0JBQUksRUFBRTtBQUFoQjtBQUFWO0FBQVQsU0FMOEMsRUFNOUM7QUFBQ3VCLGtCQUFRLEVBQ0w7QUFDSWhELGVBQUcsRUFBQyxPQURSO0FBRUltRCxvQkFBUSxFQUFFO0FBQUVELHVCQUFTLEVBQUcsQ0FBRSxTQUFGLEVBQWEsU0FBYjtBQUFkLGFBRmQ7QUFHSVosa0JBQU0sRUFBQyxTQUhYO0FBSUlNLGtCQUFNLEVBQUM7QUFKWDtBQURKLFNBTjhDLEVBYzlDO0FBQUNSLGdCQUFNLEVBQUU7QUFBRWUsb0JBQVEsRUFBRTtBQUFFTCxpQkFBRyxFQUFFLENBQVA7QUFBVXJCLGtCQUFJLEVBQUU7QUFBaEI7QUFBWjtBQUFULFNBZDhDLEVBZTlDO0FBQUM0QixnQkFBTSxFQUNIO0FBQ0lyRCxlQUFHLEVBQUM7QUFBQzRDLG9CQUFNLEVBQUMsU0FBUjtBQUFtQnhDLGtCQUFJLEVBQUM7QUFBeEIsYUFEUjtBQUVJa0QscUJBQVMsRUFBQztBQUFDQyxrQkFBSSxFQUFDO0FBQU47QUFGZDtBQURKLFNBZjhDLEVBcUI5QztBQUFDRSxlQUFLLEVBQUc7QUFBRSwwQkFBYTtBQUFmO0FBQVQsU0FyQjhDLEVBc0I5QztBQUFDSixnQkFBTSxFQUNIO0FBQ0lyRCxlQUFHLEVBQUM7QUFBQzRDLG9CQUFNLEVBQUM7QUFBUixhQURSO0FBRUljLGdCQUFJLEVBQUM7QUFBQ0gsa0JBQUksRUFBQztBQUFOLGFBRlQ7QUFHSUksdUJBQVcsRUFBRTtBQUNUSCxtQkFBSyxFQUFFO0FBQUUsMkJBQVksV0FBZDtBQUEyQiwyQkFBWTtBQUF2QztBQURFO0FBSGpCO0FBREosU0F0QjhDLEVBK0I5QztBQUFDQyxlQUFLLEVBQUc7QUFBRSwwQkFBYTtBQUFmO0FBQVQsU0EvQjhDLENBQXRDLEVBZ0NsQnZELE9BaENrQixDQWdDVixVQUFTQyxHQUFULEVBQWM7QUFDeEI2QixtQkFBUyxDQUFDMUIsSUFBVixDQUFlSCxHQUFmO0FBQ0EsU0FsQ29CLENBQVQsQ0FBWjtBQW9DQSxZQUFJeUQsYUFBYSxHQUFHLENBQXBCO0FBQ0EsWUFBSUMsYUFBYSxHQUFHLENBQXBCO0FBQ0EsWUFBSUMsVUFBVSxHQUFJLENBQWxCO0FBQ0EsWUFBSUMsUUFBUSxHQUFHLENBQWY7QUFDQSxZQUFJeUMsSUFBSSxHQUFHLENBQVg7QUFDQSxZQUFJekMsUUFBUSxHQUFHLENBQWY7QUFDQSxZQUFJQyxRQUFRLEdBQUcsRUFBZjtBQUNBLFlBQUlDLFFBQVEsR0FBRyxFQUFmO0FBQ0EsWUFBSUMsUUFBUSxHQUFHLEVBQWY7QUFDQSxZQUFJQyxVQUFVLEdBQUMsRUFBZjtBQUNTLFlBQUlnQixRQUFRLEdBQUcsQ0FBZjs7QUFHVCxhQUFLLElBQUlILENBQUMsR0FBQyxDQUFYLEVBQWNBLENBQUMsR0FBR2hELFNBQVMsQ0FBQ2QsTUFBNUIsRUFBb0M4RCxDQUFDLEVBQXJDLEVBQ0E7QUFDYyxjQUFJQyxPQUFPLEdBQUdqRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYWhGLEdBQWIsQ0FBaUI0QyxNQUFqQixDQUF3QjVCLEtBQXhCLENBQThCLEdBQTlCLENBQWQ7O0FBQ2IsY0FBSzhDLFVBQVUsSUFBRSxDQUFiLElBQW9Cb0IsUUFBUSxDQUFDRCxPQUFPLENBQUMsQ0FBRCxDQUFSLENBQVIsSUFBdUIsQ0FBL0MsRUFDQTtBQUNDbEIsb0JBQVEsR0FBSWtCLE9BQU8sQ0FBQyxDQUFELENBQW5CO0FBQ0FuQixzQkFBVSxHQUFPLENBQWpCO0FBQ0EsV0FKRCxNQUtpQixJQUFJQSxVQUFVLElBQUUsQ0FBaEIsRUFDakI7QUFDZ0IsZ0JBQUtDLFFBQVEsSUFBSWtCLE9BQU8sQ0FBQyxDQUFELENBQXBCLElBQTZCQyxRQUFRLENBQUNELE9BQU8sQ0FBQyxDQUFELENBQVIsQ0FBUixJQUF1QixDQUF4RCxFQUNmO0FBRW1CRSxzQkFBUSxHQUFJRCxRQUFRLENBQUMsQ0FBQ3RCLGFBQWEsR0FBR0MsYUFBakIsSUFBZ0MsSUFBakMsQ0FBcEI7QUFFbEJNLHdCQUFVLENBQUM3RCxJQUFYLENBQ0M2RSxRQUREO0FBSUFqQixzQkFBUSxDQUFDNUQsSUFBVCxDQUNDeUQsUUFBUSxDQUFDZ0MsU0FBVCxDQUFtQixDQUFuQixDQUREO0FBSWtCaEMsc0JBQVEsR0FBSWtCLE9BQU8sQ0FBQyxDQUFELENBQW5CO0FBQ0FyQiwyQkFBYSxHQUFHLENBQWhCO0FBQ0FDLDJCQUFhLEdBQUcsQ0FBaEI7QUFDbEI7QUFDRDs7QUFDVyxlQUFLLElBQUltQyxDQUFDLEdBQUMsQ0FBWCxFQUFjQSxDQUFDLEdBQUVoRSxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXJCLFdBQWIsQ0FBeUJ6QyxNQUExQyxFQUFrRDhFLENBQUMsRUFBbkQsRUFDQTtBQUNJLG9CQUFPaEUsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFyQixXQUFiLENBQXlCcUMsQ0FBekIsRUFBNEJDLE9BQW5DO0FBRUksbUJBQUssV0FBTDtBQUFpQjtBQUNickMsNkJBQWEsR0FBR0EsYUFBYSxHQUFHc0IsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFyQixXQUFiLENBQXlCcUMsQ0FBekIsRUFBNEJFLE9BQTdCLENBQXhDO0FBQ0E7O0FBQ0osbUJBQUssV0FBTDtBQUFpQjtBQUNickMsNkJBQWEsR0FBR0EsYUFBYSxHQUFHcUIsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFyQixXQUFiLENBQXlCcUMsQ0FBekIsRUFBNEJFLE9BQTdCLENBQXhDO0FBQ0E7O0FBQ0o7QUFDSTtBQVRSO0FBV0g7QUFDYjs7QUFDUWYsZ0JBQVEsR0FBSUQsUUFBUSxDQUFDLENBQUN0QixhQUFhLEdBQUdDLGFBQWpCLElBQWdDLElBQWpDLENBQXBCOztBQUNBLFlBQUs3QixTQUFTLENBQUNkLE1BQVYsR0FBbUIsQ0FBcEIsSUFBMkJpRSxRQUFRLEdBQUUsQ0FBekMsRUFDQTtBQUNJaEIsb0JBQVUsQ0FBQzdELElBQVgsQ0FDSTRFLFFBQVEsQ0FBQyxDQUFDdEIsYUFBYSxHQUFHQyxhQUFqQixJQUFnQyxJQUFqQyxDQURaO0FBSUFLLGtCQUFRLENBQUM1RCxJQUFULENBQ0l5RCxRQUFRLENBQUNnQyxTQUFULENBQW1CLENBQW5CLENBREo7QUFHSDs7QUFFVjlHLGlCQUFTLENBQUNxQixJQUFWLENBQWU7QUFDZE4sYUFBRyxFQUFFLGdCQURTO0FBRWRLLGNBQUksRUFBRSxLQUZRO0FBR2RpRyxjQUFJLEVBQUVuQyxVQUhRO0FBSWRvQyxjQUFJLEVBQUVyQztBQUpRLFNBQWY7QUFNQSxlQUFPakYsU0FBUDtBQUNBLE9BbkhEO0FBQUEsS0FyUmlCOztBQXlZakI7QUFDTSxzQ0FBTixDQUF5QzhDLFNBQXpDLEVBQW1EUixPQUFuRCxFQUEyRGtGLFlBQTNEO0FBQUEsc0NBQXlFO0FBQ3hFLFlBQUl4SCxTQUFTLEdBQUksRUFBakI7QUFDQSxZQUFJK0MsU0FBUyxHQUFHLEVBQWhCLENBRndFLENBR3hFOztBQUNBLGNBQU1DLE1BQU0saUJBQVNILFdBQVcsQ0FBQ0ksYUFBWixHQUE0QkMsU0FBNUIsQ0FBc0MsQ0FDOUM7QUFBQ0MsZ0JBQU0sRUFBRTtBQUFFekIsaUJBQUssRUFBRTtBQUFFYSxrQkFBSSxFQUFFTyxTQUFSO0FBQW1CTixrQkFBSSxFQUFFRjtBQUF6QjtBQUFUO0FBQVQsU0FEOEMsRUFFOUM7QUFBQ2MsY0FBSSxFQUFFO0FBQUVDLGtCQUFNLEVBQUU7QUFBRUMsMkJBQWEsRUFBRTtBQUFFQyxzQkFBTSxFQUFFLE9BQVY7QUFBbUJDLG9CQUFJLEVBQUU7QUFBQ0Msc0JBQUksRUFBRyxDQUFDLElBQUloQyxJQUFKLENBQVMsQ0FBVCxDQUFELEVBQWMsUUFBZDtBQUFSLGlCQUF6QjtBQUE0RGlDLHdCQUFRLEVBQUU7QUFBdEU7QUFBakI7QUFBVjtBQUFQLFNBRjhDLEVBRzlDO0FBQUNOLGNBQUksRUFBRTtBQUFFTyxrQkFBTSxFQUFFO0FBQUVMLDJCQUFhLEVBQUU7QUFBRUMsc0JBQU0sRUFBRSxVQUFWO0FBQXNCQyxvQkFBSSxFQUFFO0FBQUNDLHNCQUFJLEVBQUcsQ0FBQyxJQUFJaEMsSUFBSixDQUFTLENBQVQsQ0FBRCxFQUFjLFFBQWQ7QUFBUixpQkFBNUI7QUFBK0RpQyx3QkFBUSxFQUFFO0FBQXpFO0FBQWpCO0FBQVY7QUFBUCxTQUg4QyxFQUk5QztBQUFDUCxnQkFBTSxFQUFFO0FBQUVTLGtCQUFNLEVBQUU7QUFBRUMsaUJBQUcsRUFBRSxDQUFQO0FBQVVyQixrQkFBSSxFQUFFO0FBQWhCO0FBQVY7QUFBVCxTQUo4QyxFQUs5QztBQUFDVyxnQkFBTSxFQUFFO0FBQUVXLGtCQUFNLEVBQUU7QUFBRUQsaUJBQUcsRUFBRSxDQUFQO0FBQVVyQixrQkFBSSxFQUFFO0FBQWhCO0FBQVY7QUFBVCxTQUw4QyxFQU05QztBQUFDdUIsa0JBQVEsRUFDTDtBQUNJaEQsZUFBRyxFQUFDLE9BRFI7QUFFSW1ELG9CQUFRLEVBQUU7QUFBRUQsdUJBQVMsRUFBRyxDQUFFLFNBQUYsRUFBYSxTQUFiO0FBQWQsYUFGZDtBQUdJWixrQkFBTSxFQUFDLFNBSFg7QUFJSU0sa0JBQU0sRUFBQztBQUpYO0FBREosU0FOOEMsRUFjOUM7QUFBQ1IsZ0JBQU0sRUFBRTtBQUFFZSxvQkFBUSxFQUFFO0FBQUVMLGlCQUFHLEVBQUUsQ0FBUDtBQUFVckIsa0JBQUksRUFBRTtBQUFoQjtBQUFaO0FBQVQsU0FkOEMsRUFlOUM7QUFBQzRCLGdCQUFNLEVBQ0g7QUFDSXJELGVBQUcsRUFBQztBQUFDNEMsb0JBQU0sRUFBQyxTQUFSO0FBQW1CeEMsa0JBQUksRUFBQztBQUF4QixhQURSO0FBRUlrRCxxQkFBUyxFQUFDO0FBQUNDLGtCQUFJLEVBQUM7QUFBTjtBQUZkO0FBREosU0FmOEMsRUFxQjlDO0FBQUNFLGVBQUssRUFBRztBQUFFLDBCQUFhO0FBQWY7QUFBVCxTQXJCOEMsRUFzQjlDO0FBQUNKLGdCQUFNLEVBQ0g7QUFDSXJELGVBQUcsRUFBQztBQUFDNEMsb0JBQU0sRUFBQztBQUFSLGFBRFI7QUFFSWMsZ0JBQUksRUFBQztBQUFDSCxrQkFBSSxFQUFDO0FBQU4sYUFGVDtBQUdJSSx1QkFBVyxFQUFFO0FBQ1RILG1CQUFLLEVBQUU7QUFBRSwyQkFBWSxXQUFkO0FBQTJCLDJCQUFZO0FBQXZDO0FBREU7QUFIakI7QUFESixTQXRCOEMsRUErQjlDO0FBQUNDLGVBQUssRUFBRztBQUFFLDBCQUFhO0FBQWY7QUFBVCxTQS9COEMsQ0FBdEMsRUFnQ2xCdkQsT0FoQ2tCLENBZ0NWLFVBQVNDLEdBQVQsRUFBYztBQUN4QjZCLG1CQUFTLENBQUMxQixJQUFWLENBQWVILEdBQWY7QUFDQSxTQWxDb0IsQ0FBVCxDQUFaO0FBb0NBLFlBQUl5RCxhQUFhLEdBQUcsQ0FBcEI7QUFDQSxZQUFJQyxhQUFhLEdBQUcsQ0FBcEI7QUFDQSxZQUFJQyxVQUFVLEdBQUksQ0FBbEI7QUFDQSxZQUFJbEIsTUFBTSxHQUFHLENBQWI7QUFDQSxZQUFJTixNQUFNLEdBQUcsRUFBYjtBQUNBLFlBQUlvRSxRQUFRLEdBQUcsRUFBZjtBQUNBLFlBQUkxQyxRQUFRLEdBQUcsRUFBZjtBQUNBLFlBQUlDLFFBQVEsR0FBRyxFQUFmO0FBQ0EsWUFBSUMsUUFBUSxHQUFHLEVBQWY7QUFDQSxZQUFJQyxVQUFVLEdBQUMsRUFBZjtBQUNTLFlBQUl3QyxLQUFLLEdBQUcsQ0FBWjtBQUNBLFlBQUlDLFVBQVUsR0FBRyxDQUFqQjtBQUNBLFlBQUlDLFVBQVUsR0FBRyxDQUFqQjtBQUNBLFlBQUlDLE1BQU0sR0FBRyxNQUFiOztBQUNULGFBQUssSUFBSTlCLENBQUMsR0FBQyxDQUFYLEVBQWNBLENBQUMsR0FBR2hELFNBQVMsQ0FBQ2QsTUFBNUIsRUFBb0M4RCxDQUFDLEVBQXJDLEVBQ0E7QUFDYSxjQUFJQyxPQUFPLEdBQUdqRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYWhGLEdBQWIsQ0FBaUI0QyxNQUFqQixDQUF3QjVCLEtBQXhCLENBQThCLEdBQTlCLENBQWQ7O0FBQ0E0QixnQkFBTSxHQUFJcUMsT0FBTyxDQUFDLENBQUQsQ0FBakI7O0FBQ0EsY0FBS3JDLE1BQU0sSUFBRSxDQUFULElBQWdCQSxNQUFNLEdBQUMsRUFBM0IsRUFDQTtBQUNJa0Usa0JBQU0sR0FBRyxNQUFUO0FBQ0gsV0FIRCxNQUdRLElBQUtsRSxNQUFNLElBQUUsRUFBVCxJQUFpQkEsTUFBTSxHQUFDLEVBQTVCLEVBQ1I7QUFDSWtFLGtCQUFNLEdBQUcsTUFBVDtBQUNILFdBSE8sTUFJUjtBQUNLQSxrQkFBTSxHQUFHLE1BQVQ7QUFDSjs7QUFDREosa0JBQVEsR0FBTTFFLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhaEYsR0FBYixDQUFpQjRDLE1BQS9CO0FBQ0FnQix1QkFBYSxHQUFHLENBQWhCO0FBQ0FDLHVCQUFhLEdBQUcsQ0FBaEI7O0FBQ0EsZUFBSyxJQUFJbUMsQ0FBQyxHQUFDLENBQVgsRUFBY0EsQ0FBQyxHQUFFaEUsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFyQixXQUFiLENBQXlCekMsTUFBMUMsRUFBa0Q4RSxDQUFDLEVBQW5ELEVBQ0E7QUFDSSxvQkFBT2hFLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhckIsV0FBYixDQUF5QnFDLENBQXpCLEVBQTRCQyxPQUFuQztBQUVJLG1CQUFLLFdBQUw7QUFBaUI7QUFDYnJDLDZCQUFhLEdBQUdzQixRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXJCLFdBQWIsQ0FBeUJxQyxDQUF6QixFQUE0QkUsT0FBN0IsQ0FBeEI7QUFDQTs7QUFDSixtQkFBSyxXQUFMO0FBQWlCO0FBQ2JyQyw2QkFBYSxHQUFHcUIsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFyQixXQUFiLENBQXlCcUMsQ0FBekIsRUFBNEJFLE9BQTdCLENBQXhCO0FBQ0E7O0FBQ0o7QUFDSTtBQVRSO0FBV0g7O0FBQ0QvQixvQkFBVSxDQUFDN0QsSUFBWCxDQUFnQjtBQUNaaUcsZ0JBQUksRUFBRUcsUUFETTtBQUVaSyxpQkFBSyxFQUFFRCxNQUZLO0FBR1pFLG1CQUFPLEVBQUVwRCxhQUhHO0FBSVpxRCxtQkFBTyxFQUFFcEQsYUFKRztBQUtaOEMsaUJBQUssRUFBSTNFLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhdEI7QUFMVixXQUFoQjtBQU9BaUQsZUFBSyxHQUFHQSxLQUFLLEdBQUd6QixRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXRCLElBQWQsQ0FBeEI7QUFDQWtELG9CQUFVLEdBQUdBLFVBQVUsR0FBRzFCLFFBQVEsQ0FBQ3RCLGFBQUQsQ0FBbEM7QUFDQWlELG9CQUFVLEdBQUdBLFVBQVUsR0FBRzNCLFFBQVEsQ0FBQ3JCLGFBQUQsQ0FBbEM7QUFDQUcsa0JBQVEsQ0FBQzFELElBQVQsQ0FDSXdGLE1BQU0sQ0FBQ2xDLGFBQUQsQ0FEVjtBQUdBSyxrQkFBUSxDQUFDM0QsSUFBVCxDQUNJd0YsTUFBTSxDQUFDakMsYUFBRCxDQURWO0FBR0FLLGtCQUFRLENBQUM1RCxJQUFULENBQ0lvRyxRQURKO0FBR1o7O0FBRVF2QyxrQkFBVSxDQUFDN0QsSUFBWCxDQUFnQjtBQUNaaUcsY0FBSSxFQUFFLEVBRE07QUFFWlEsZUFBSyxFQUFFLE1BRks7QUFHWkMsaUJBQU8sRUFBRUosVUFIRztBQUlaSyxpQkFBTyxFQUFFSixVQUpHO0FBS1pGLGVBQUssRUFBSUE7QUFMRyxTQUFoQjtBQVFUMUgsaUJBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkTixhQUFHLEVBQUUsVUFEUztBQUVkSyxjQUFJLEVBQUUsS0FGUTtBQUdkZ0csZUFBSyxFQUFFLFNBSE87QUFJZEMsY0FBSSxFQUFFdEMsUUFKUTtBQUtkdUMsY0FBSSxFQUFFckM7QUFMUSxTQUFmO0FBT0FqRixpQkFBUyxDQUFDcUIsSUFBVixDQUFlO0FBQ2ROLGFBQUcsRUFBRSxVQURTO0FBRWRLLGNBQUksRUFBRSxLQUZRO0FBR2RnRyxlQUFLLEVBQUUsU0FITztBQUlkQyxjQUFJLEVBQUVyQyxRQUpRO0FBS2RzQyxjQUFJLEVBQUVyQztBQUxRLFNBQWY7QUFPQWpGLGlCQUFTLENBQUNxQixJQUFWLENBQWU7QUFDZE4sYUFBRyxFQUFFLFFBRFM7QUFFZHNHLGNBQUksRUFBRW5DO0FBRlEsU0FBZjtBQUlBLGVBQU9sRixTQUFQO0FBQ0EsT0FySUQ7QUFBQTs7QUExWWlCLEdBQWY7QUFpaEJGOztBQUVEZCxNQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUVoQjtBQUNDLDZCQUEyQnFDLElBQTNCLEVBQWdDQyxjQUFoQyxFQUErQ0MsWUFBL0MsRUFDQTtBQUNDLFFBQUlyQyxTQUFTLEdBQUksRUFBakI7QUFDQSxRQUFJRSxLQUFLLEdBQUssQ0FBZDtBQUNBLFFBQUlvQyxPQUFPLEdBQUksRUFBZjtBQUNBLFFBQUlkLFNBQVMsR0FBSSxFQUFqQjtBQUVBLFFBQUlyQixPQUFPLEdBQUc7QUFBQ0MsVUFBSSxFQUFFLFNBQVA7QUFBa0JDLFdBQUssRUFBRSxTQUF6QjtBQUFvQ0MsU0FBRyxFQUFFLFNBQXpDO0FBQW1EQyxVQUFJLEVBQUUsU0FBekQ7QUFBbUVDLFlBQU0sRUFBRSxTQUEzRTtBQUFxRkMsWUFBTSxFQUFFO0FBQTdGLEtBQWQ7QUFFQW9DLGVBQVcsQ0FBQ2pELElBQVosQ0FBaUI7QUFBQzhCLFdBQUssRUFBQztBQUFDYSxZQUFJLEVBQUVILGNBQVA7QUFBc0JJLFlBQUksRUFBQ0g7QUFBM0I7QUFBUCxLQUFqQixFQUFrRTtBQUFFdkIsVUFBSSxFQUFFO0FBQUVDLFdBQUcsRUFBRSxDQUFDO0FBQVI7QUFBUixLQUFsRSxFQUF3RkUsT0FBeEYsQ0FBZ0csVUFBU0MsR0FBVCxFQUFjO0FBQzdHLFVBQUlDLElBQUksR0FBR0QsR0FBRyxDQUFDQyxJQUFmOztBQUNBLFVBQUlELEdBQUcsQ0FBQ3VCLEtBQUosSUFBWSxDQUFoQixFQUNBO0FBQ0NILGVBQU8sR0FBRyxFQUFWO0FBQ0EsT0FIRCxNQUtBO0FBQ0NBLGVBQU8sR0FBRyxJQUFJYixJQUFKLENBQVNQLEdBQUcsQ0FBQ3VCLEtBQWIsRUFBb0JkLGNBQXBCLENBQW1DLEVBQW5DLEVBQXNDeEIsT0FBdEMsQ0FBVjtBQUNBOztBQUNEcUIsZUFBUyxHQUFHLElBQUlDLElBQUosQ0FBU1AsR0FBRyxDQUFDUSxLQUFiLEVBQW9CQyxjQUFwQixDQUFtQyxFQUFuQyxFQUFzQ3hCLE9BQXRDLENBQVo7O0FBRVMsVUFBSzhGLFFBQVEsQ0FBQy9FLEdBQUcsQ0FBQzBDLE1BQUwsQ0FBUixJQUF1QixDQUF4QixJQUFnQ3FDLFFBQVEsQ0FBQy9FLEdBQUcsQ0FBQzRDLE1BQUwsQ0FBUixJQUF1QixDQUEzRCxFQUNBLENBQ0k7QUFDSCxPQUhELE1BS0E7QUFDSTlELGlCQUFTLENBQUNxQixJQUFWLENBQWU7QUFDWE4sYUFBRyxFQUFHRyxHQUFHLENBQUNILEdBREM7QUFFWE8saUJBQU8sRUFBR0osR0FBRyxDQUFDQyxJQUZIO0FBR1hLLG1CQUFTLEVBQUUsSUFBSUMsSUFBSixDQUFTUCxHQUFHLENBQUNRLEtBQWIsRUFBb0JDLGNBQXBCLENBQW1DLEVBQW5DLEVBQXNDeEIsT0FBdEMsQ0FIQTtBQUlYbUMsaUJBQU8sRUFBR0EsT0FKQztBQUtYd0IsZ0JBQU0sRUFBRzVDLEdBQUcsQ0FBQzRDLE1BTEY7QUFNWEYsZ0JBQU0sRUFBRzFDLEdBQUcsQ0FBQzBDLE1BTkY7QUFPWDhELGVBQUssRUFBR3pCLFFBQVEsQ0FBQy9FLEdBQUcsQ0FBQzBDLE1BQUwsQ0FBUixHQUF1QnFDLFFBQVEsQ0FBQy9FLEdBQUcsQ0FBQzRDLE1BQUw7QUFQNUIsU0FBZjtBQVNIO0FBQ1YsS0E1QkQsRUFSRCxDQXFDQzs7QUFDQSxXQUFPOUQsU0FBUDtBQUNBOztBQTNDYyxDQUFmLEU7Ozs7Ozs7Ozs7O0FDemhCRGpCLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNpSixnQkFBYyxFQUFDLE1BQUlBO0FBQXBCLENBQWQ7QUFBbUQsSUFBSS9JLE1BQUo7QUFBV0gsTUFBTSxDQUFDSSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsS0FBSjtBQUFVTixNQUFNLENBQUNJLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNFLE9BQUssQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFNBQUssR0FBQ0QsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJOEksUUFBSjtBQUFhbkosTUFBTSxDQUFDSSxJQUFQLENBQVksWUFBWixFQUF5QjtBQUFDZ0osU0FBTyxDQUFDL0ksQ0FBRCxFQUFHO0FBQUM4SSxZQUFRLEdBQUM5SSxDQUFUO0FBQVc7O0FBQXZCLENBQXpCLEVBQWtELENBQWxEO0FBSXJMLE1BQU02SSxjQUFjLEdBQUcsSUFBSTVJLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixnQkFBckIsQ0FBdkI7O0FBRVAsSUFBSUosTUFBTSxDQUFDSyxRQUFYLEVBQXFCO0FBQ3BCTCxRQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNkO0FBQ00saUNBQU47QUFBQSxzQ0FDQTtBQUNDLFlBQUlFLFNBQVMsR0FBRyxFQUFoQjtBQUNBLHNCQUFPaUksY0FBYyxDQUFDckksSUFBZixDQUFvQixFQUFwQixFQUF3QjtBQUFDa0IsY0FBSSxFQUFFO0FBQUNnQyxxQkFBUyxFQUFFO0FBQVo7QUFBUCxTQUF4QixFQUFnRDdCLE9BQWhELENBQXdELFVBQVNDLEdBQVQsRUFBYztBQUM1RWxCLG1CQUFTLENBQUNxQixJQUFWLENBQWU7QUFDZE4sZUFBRyxFQUFFRyxHQUFHLENBQUNILEdBREs7QUFFZHFILHdCQUFZLEVBQUUsSUFBSTNHLElBQUosQ0FBU1AsR0FBRyxDQUFDNEIsU0FBYixFQUF3QnVGLGtCQUF4QixDQUEyQztBQUFFQyxzQkFBUSxFQUFFO0FBQVosYUFBM0MsQ0FGQTtBQUdkQyxzQkFBVSxFQUFFLElBQUk5RyxJQUFKLENBQVNQLEdBQUcsQ0FBQ29CLE9BQWIsRUFBc0IrRixrQkFBdEIsQ0FBeUM7QUFBRUMsc0JBQVEsRUFBRTtBQUFaLGFBQXpDLENBSEU7QUFJZHhGLHFCQUFTLEVBQUU1QixHQUFHLENBQUM0QixTQUpEO0FBS2RSLG1CQUFPLEVBQUVwQixHQUFHLENBQUNvQixPQUxDO0FBTWRrRyxrQkFBTSxFQUFHdEgsR0FBRyxDQUFDc0gsTUFOQztBQU9kQyxrQkFBTSxFQUFHdkgsR0FBRyxDQUFDdUgsTUFQQztBQVFkQyxtQkFBTyxFQUFHeEgsR0FBRyxDQUFDd0gsT0FSQTtBQVNkQyxrQkFBTSxFQUFHekgsR0FBRyxDQUFDeUgsTUFUQztBQVVkQyxxQkFBUyxFQUFFMUgsR0FBRyxDQUFDMEgsU0FWRDtBQVdkQyxtQkFBTyxFQUFHM0gsR0FBRyxDQUFDMkgsT0FYQTtBQVlkQyxrQkFBTSxFQUFHNUgsR0FBRyxDQUFDNEgsTUFaQztBQWFkQyxnQkFBSSxFQUFHN0gsR0FBRyxDQUFDNkgsSUFiRztBQWNkQyxrQkFBTSxFQUFHOUgsR0FBRyxDQUFDOEg7QUFkQyxXQUFmO0FBaUJBLFNBbEJNLENBQVA7QUFvQkEsZUFBT2hKLFNBQVA7QUFDQSxPQXhCRDtBQUFBLEtBRmM7O0FBMkJkO0FBQ00sZ0NBQU4sQ0FBbUNpSixPQUFuQztBQUFBLHNDQUE0QztBQUMzQyxZQUFJakosU0FBUyxHQUFJLEVBQWpCO0FBRVMsY0FBTXdELElBQUksR0FBRyxJQUFJL0IsSUFBSixDQUFTd0gsT0FBVCxDQUFiO0FBQ0FDLGVBQU8sQ0FBQ0MsR0FBUixDQUFZM0YsSUFBWixFQUprQyxDQUlmOztBQUVuQixjQUFNNEYsYUFBYSxHQUFHNUYsSUFBSSxDQUFDNkYsT0FBTCxFQUF0QjtBQUNULGNBQU1yRyxNQUFNLGlCQUFTaUYsY0FBYyxDQUFDaEYsYUFBZixHQUErQkMsU0FBL0IsQ0FBeUMsQ0FDN0Q7QUFBQ0MsZ0JBQU0sRUFBRTtBQUNObUcsaUJBQUssRUFBRTtBQUNQQyxrQkFBSSxFQUFFLENBQ047QUFBRS9HLG9CQUFJLEVBQUUsQ0FBRSxZQUFGLEVBQWU0RyxhQUFmO0FBQVIsZUFETSxFQUVOO0FBQUU3RyxvQkFBSSxFQUFFLENBQUUsVUFBRixFQUFjNkcsYUFBZDtBQUFSLGVBRk07QUFEQztBQUREO0FBQVQsU0FENkQsQ0FBekMsRUFTbEJuSSxPQVRrQixDQVNWLFVBQVNDLEdBQVQsRUFBYztBQUN4QmxCLG1CQUFTLENBQUNxQixJQUFWLENBQWVILEdBQWY7QUFDQSxTQVhvQixDQUFULENBQVo7QUFZQSxlQUFPbEIsU0FBUDtBQUNBLE9BcEJEO0FBQUEsS0E1QmM7O0FBaURkO0FBQ00sMkJBQU4sQ0FDQzhDLFNBREQsRUFFQ1IsT0FGRCxFQUdDa0csTUFIRCxFQUlDQyxNQUpELEVBS0NDLE9BTEQsRUFNQ0MsTUFORCxFQU9DQyxTQVBELEVBUUNDLE9BUkQsRUFTQ0MsTUFURCxFQVVDQyxJQVZELEVBV0NDLE1BWEQ7QUFBQSxzQ0FhQTtBQUNDLFlBQUksQ0FBQ2QsUUFBUSxDQUFDc0IsU0FBVCxDQUFtQixLQUFLQyxNQUF4QixFQUErQixPQUEvQixDQUFMLEVBQ0E7QUFDQyxnQkFBTSxJQUFJdkssTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixXQUFqQixFQUE2Qix3QkFBN0IsQ0FBTjtBQUNBLFNBSEQsTUFLQTtBQUNDLGdCQUFNQyxlQUFlLGlCQUFTekssTUFBTSxDQUFDa0gsSUFBUCxDQUFZLDRCQUFaLEVBQTBDdEQsU0FBMUMsQ0FBVCxDQUFyQjtBQUNBLGdCQUFNOEcsZUFBZSxpQkFBUzFLLE1BQU0sQ0FBQ2tILElBQVAsQ0FBWSw0QkFBWixFQUEwQzlELE9BQTFDLENBQVQsQ0FBckI7O0FBQ0EsY0FBS3FILGVBQWUsSUFBSSxFQUFwQixJQUE0QkMsZUFBZSxJQUFJLEVBQW5ELEVBQ0E7QUFDQyxrQkFBTSxJQUFJMUssTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixtQ0FBakIsQ0FBTjtBQUNBLFdBSEQsTUFLQTtBQUNDLDBCQUFNekIsY0FBYyxDQUFDNEIsTUFBZixDQUFzQjtBQUMzQi9HLHVCQUQyQjtBQUUzQlIscUJBRjJCO0FBRzNCa0csb0JBSDJCO0FBSTNCQyxvQkFKMkI7QUFLM0JDLHFCQUwyQjtBQU0zQkMsb0JBTjJCO0FBTzNCQyx1QkFQMkI7QUFRM0JDLHFCQVIyQjtBQVMzQkMsb0JBVDJCO0FBVTNCQyxrQkFWMkI7QUFXM0JDO0FBWDJCLGFBQXRCLENBQU47QUFjQTtBQUNEOztBQUNELGVBQU8sQ0FBUDtBQUNBLE9BN0NEO0FBQUE7O0FBbERjLEdBQWY7QUFpR0EsQyxDQUNEOzs7QUFDQTlKLE1BQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBRWQ7QUFDQSw0QkFBMEJxQixJQUExQixFQUNBO0FBQ0MsUUFBSTJJLFFBQVEsR0FBRzdCLGNBQWMsQ0FBQzhCLE9BQWYsQ0FBdUI7QUFBRTVJLFVBQUksRUFBQ0E7QUFBUCxLQUF2QixDQUFmOztBQUNBLFFBQUkySSxRQUFRLElBQUUsSUFBZCxFQUFvQjtBQUNuQixhQUFPLENBQVA7QUFDQSxLQUZELE1BSUE7QUFDQyxhQUFPLENBQVA7QUFDQTtBQUNELEdBYmE7O0FBZ0JkO0FBQ0EsMEJBQXdCRSxNQUF4QixFQUNBO0FBQ0MsUUFBSSxDQUFDOUIsUUFBUSxDQUFDc0IsU0FBVCxDQUFtQixLQUFLQyxNQUF4QixFQUErQixPQUEvQixDQUFMLEVBQ0E7QUFDQyxZQUFNLElBQUl2SyxNQUFNLENBQUN3SyxLQUFYLENBQWlCLFdBQWpCLEVBQTZCLHdCQUE3QixDQUFOO0FBQ0EsS0FIRCxNQUtBO0FBQ0N6QixvQkFBYyxDQUFDZ0MsTUFBZixDQUFzQkQsTUFBdEI7QUFDQTtBQUNELEdBM0JhOztBQTRCZDtBQUNBLDBCQUNDakosR0FERCxFQUVDeUgsTUFGRCxFQUdDQyxNQUhELEVBSUNDLE9BSkQsRUFLQ0MsTUFMRCxFQU1DQyxTQU5ELEVBT0NDLE9BUEQsRUFRQ0MsTUFSRCxFQVNDQyxJQVRELEVBVUNDLE1BVkQsRUFZQTtBQUNDLFFBQUksQ0FBQ2QsUUFBUSxDQUFDc0IsU0FBVCxDQUFtQixLQUFLQyxNQUF4QixFQUErQixPQUEvQixDQUFMLEVBQ0E7QUFDQyxZQUFNLElBQUl2SyxNQUFNLENBQUN3SyxLQUFYLENBQWlCLFdBQWpCLEVBQTZCLHdCQUE3QixDQUFOO0FBQ0EsS0FIRCxNQUtBO0FBQ0N6QixvQkFBYyxDQUFDaUMsTUFBZixDQUFzQm5KLEdBQXRCLEVBQ0M7QUFBRXFDLFlBQUksRUFBRTtBQUNQb0YsZ0JBRE87QUFFUEMsZ0JBRk87QUFHUEMsaUJBSE87QUFJUEMsZ0JBSk87QUFLUEMsbUJBTE87QUFNUEMsaUJBTk87QUFPUEMsZ0JBUE87QUFRUEMsY0FSTztBQVNQQztBQVRPO0FBQVIsT0FERDtBQWFBO0FBQ0Q7O0FBOURhLENBQWYsRTs7Ozs7Ozs7Ozs7QUMxR0FqSyxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDbUwsZUFBYSxFQUFDLE1BQUlBO0FBQW5CLENBQWQ7QUFBaUQsSUFBSWpMLE1BQUo7QUFBV0gsTUFBTSxDQUFDSSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsS0FBSjtBQUFVTixNQUFNLENBQUNJLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNFLE9BQUssQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFNBQUssR0FBQ0QsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUdwSCxNQUFNK0ssYUFBYSxHQUFHLElBQUk5SyxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsZUFBckIsQ0FBdEI7O0FBRVAsSUFBSUosTUFBTSxDQUFDSyxRQUFYLEVBQXFCO0FBQ25CTCxRQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUVmO0FBQ00sbUNBQU4sQ0FBc0NzQyxjQUF0QyxFQUFxREMsWUFBckQ7QUFBQSxzQ0FDQTtBQUVDLGNBQU1XLE1BQU0saUJBQVNtSCxhQUFhLENBQUNsSCxhQUFkLEdBQThCQyxTQUE5QixDQUF3QyxDQUM1RDtBQUFDQyxnQkFBTSxFQUFFO0FBQUVvRyxnQkFBSSxFQUFFLENBQUU7QUFBRWEsdUJBQVMsRUFBRTtBQUFFN0gsb0JBQUksRUFBRUgsY0FBUjtBQUF3Qkksb0JBQUksRUFBQ0g7QUFBN0I7QUFBYixhQUFGO0FBQVI7QUFBVCxTQUQ0RCxFQUU1RDtBQUFDbUMsZUFBSyxFQUFHO0FBQUU0RixxQkFBUyxFQUFHLENBQUM7QUFBZjtBQUFULFNBRjRELEVBRzVEO0FBQ0NyRyxrQkFBUSxFQUFFO0FBQ1QsbUJBQU8sTUFERTtBQUVULG1CQUFPLFVBRkU7QUFHVCx5QkFBYTtBQUFFVCwyQkFBYSxFQUFFO0FBQUVDLHNCQUFNLEVBQUUsbUJBQVY7QUFBK0JDLG9CQUFJLEVBQUU7QUFBQ0Msc0JBQUksRUFBRyxDQUFDLElBQUloQyxJQUFKLENBQVMsQ0FBVCxDQUFELEVBQWMsWUFBZDtBQUFSLGlCQUFyQztBQUE0RWlDLHdCQUFRLEVBQUU7QUFBdEY7QUFBakIsYUFISjtBQUlULG1CQUFPLE9BSkU7QUFLVCxtQkFBTSxRQUxHO0FBTVQsd0JBQVk7QUFOSDtBQURYLFNBSDRELENBQXhDLENBQVQsQ0FBWjtBQWNBLGVBQU9WLE1BQU0sQ0FBQ3FILE9BQVAsRUFBUDtBQUNBLE9BbEJEO0FBQUE7O0FBSGUsR0FBZjtBQXVCRDs7QUFHRG5MLE1BQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBQ2Q7QUFDQSx5QkFDRXFCLElBREYsRUFFRUcsT0FGRixFQUdFcUIsR0FIRixFQUlFMkgsUUFKRixFQUtFQyxPQUxGLEVBTUVDLE9BTkYsRUFPRTlELEtBUEYsRUFRRXpFLE1BUkYsRUFTRXdJLFFBVEYsRUFVRUMsUUFWRixFQVlBO0FBQ0M7QUFDQUYsV0FBTyxHQUFHdkUsUUFBUSxDQUFDdUUsT0FBRCxDQUFsQjtBQUNBOUQsU0FBSyxHQUFHRyxNQUFNLENBQUNILEtBQUQsQ0FBZDtBQUVBeUQsaUJBQWEsQ0FBQ04sTUFBZCxDQUFxQjtBQUNwQjFJLFVBRG9CO0FBRXBCRyxhQUZvQjtBQUdwQnFCLFNBSG9CO0FBSXBCNEgsYUFKb0I7QUFLcEJDLGFBTG9CO0FBTXBCOUQsV0FOb0I7QUFPcEJ6RSxZQVBvQjtBQVFwQndJLGNBUm9CO0FBU3BCSCxjQVRvQixDQVVwQjs7QUFWb0IsS0FBckI7QUFZQSxHQS9CYTs7QUFnQ2Q7QUFDQSw4QkFDRW5KLElBREYsRUFFRUcsT0FGRixFQUdFcUIsR0FIRixFQUlFMkgsUUFKRixFQUtFQyxPQUxGLEVBTUVDLE9BTkYsRUFPRTlELEtBUEYsRUFRRXpFLE1BUkYsRUFTRXdJLFFBVEYsRUFVRUMsUUFWRixFQVlBO0FBQ0NGLFdBQU8sR0FBR3ZFLFFBQVEsQ0FBQ3VFLE9BQUQsQ0FBbEI7QUFDQTlELFNBQUssR0FBR0csTUFBTSxDQUFDSCxLQUFELENBQWQ7O0FBQ0EsWUFBT1QsUUFBUSxDQUFDcUUsUUFBRCxDQUFmO0FBRUMsV0FBSyxDQUFMO0FBQU87QUFDTjVELGFBQUssR0FBR1QsUUFBUSxDQUFDUyxLQUFELENBQWhCO0FBQ0F5RCxxQkFBYSxDQUFDTixNQUFkLENBQXFCO0FBQ3BCMUksY0FEb0I7QUFFcEJHLGlCQUZvQjtBQUdwQnFCLGFBSG9CO0FBSXBCNEgsaUJBSm9CO0FBS3BCQyxpQkFMb0I7QUFNcEI5RCxlQU5vQjtBQU9wQnpFLGdCQVBvQjtBQVFwQndJLGtCQVJvQixDQVNwQjs7QUFUb0IsU0FBckI7QUFXRDs7QUFDQSxXQUFLLENBQUw7QUFBTztBQUNOL0QsYUFBSyxHQUFHVCxRQUFRLENBQUNTLEtBQUQsQ0FBaEI7QUFDQXlELHFCQUFhLENBQUNOLE1BQWQsQ0FBcUI7QUFDcEIxSSxjQURvQjtBQUVwQkcsaUJBRm9CO0FBR3BCcUIsYUFIb0I7QUFJcEI0SCxpQkFKb0I7QUFLcEJDLGlCQUxvQjtBQU1wQjlELGVBTm9CO0FBT3BCekUsZ0JBUG9CO0FBUXBCd0ksa0JBUm9CLENBU3BCOztBQVRvQixTQUFyQjtBQVdEOztBQUNBLFdBQUssQ0FBTDtBQUFPO0FBQ04sWUFBSUUsR0FBRyxHQUFFMUUsUUFBUSxDQUFDUyxLQUFELENBQVIsR0FBaUIsTUFBMUI7QUFDQSxZQUFJa0UsSUFBSSxHQUFFM0UsUUFBUSxDQUFDUyxLQUFELENBQVIsSUFBbUIsRUFBN0I7QUFDQUEsYUFBSyxHQUFHaUUsR0FBUjtBQUNBakUsYUFBSyxHQUFHVCxRQUFRLENBQUNTLEtBQUQsQ0FBaEI7QUFDQXlELHFCQUFhLENBQUNOLE1BQWQsQ0FBcUI7QUFDcEIxSSxjQURvQjtBQUVwQkcsaUJBRm9CO0FBR3BCcUIsYUFIb0I7QUFJcEI0SCxpQkFKb0I7QUFLcEJDLGlCQUxvQjtBQU1wQjlELGVBTm9CO0FBT3BCekUsZ0JBUG9CO0FBUXBCd0ksa0JBUm9CLENBU3BCOztBQVRvQixTQUFyQixFQUxELENBZ0JDOztBQUNBL0QsYUFBSyxHQUFHa0UsSUFBUjtBQUNBbEUsYUFBSyxHQUFHVCxRQUFRLENBQUNTLEtBQUQsQ0FBaEI7QUFDQThELGVBQU8sR0FBR0EsT0FBTyxHQUFHLENBQXBCO0FBQ0FMLHFCQUFhLENBQUNOLE1BQWQsQ0FBcUI7QUFDcEIxSSxjQURvQjtBQUVwQkcsaUJBRm9CO0FBR3BCcUIsYUFIb0I7QUFJcEI0SCxpQkFKb0I7QUFLcEJDLGlCQUxvQjtBQU1wQjlELGVBTm9CO0FBT3BCekUsZ0JBUG9CO0FBUXBCd0ksa0JBUm9CLENBU3BCOztBQVRvQixTQUFyQjtBQVdEOztBQUNBLFdBQUssQ0FBTDtBQUFPO0FBQ04sWUFBSUcsSUFBSSxHQUFFM0UsUUFBUSxDQUFDUyxLQUFELENBQVIsR0FBaUIsTUFBM0I7QUFDQSxZQUFJaUUsR0FBRyxHQUFFMUUsUUFBUSxDQUFDUyxLQUFELENBQVIsSUFBbUIsRUFBNUI7QUFDQUEsYUFBSyxHQUFHaUUsR0FBUjtBQUNBakUsYUFBSyxHQUFHVCxRQUFRLENBQUNTLEtBQUQsQ0FBaEI7QUFDQXlELHFCQUFhLENBQUNOLE1BQWQsQ0FBcUI7QUFDcEIxSSxjQURvQjtBQUVwQkcsaUJBRm9CO0FBR3BCcUIsYUFIb0I7QUFJcEI0SCxpQkFKb0I7QUFLcEJDLGlCQUxvQjtBQU1wQjlELGVBTm9CO0FBT3BCekUsZ0JBUG9CO0FBUXBCd0ksa0JBUm9CLENBU3BCOztBQVRvQixTQUFyQixFQUxELENBZ0JDOztBQUNBL0QsYUFBSyxHQUFHa0UsSUFBUjtBQUNBbEUsYUFBSyxHQUFHVCxRQUFRLENBQUNTLEtBQUQsQ0FBaEI7QUFDQThELGVBQU8sR0FBR0EsT0FBTyxHQUFHLENBQXBCO0FBQ0FMLHFCQUFhLENBQUNOLE1BQWQsQ0FBcUI7QUFDcEIxSSxjQURvQjtBQUVwQkcsaUJBRm9CO0FBR3BCcUIsYUFIb0I7QUFJcEI0SCxpQkFKb0I7QUFLcEJDLGlCQUxvQjtBQU1wQjlELGVBTm9CO0FBT3BCekUsZ0JBUG9CO0FBUXBCd0ksa0JBUm9CLENBU3BCOztBQVRvQixTQUFyQjtBQVdEOztBQUNBLFdBQUssQ0FBTDtBQUFPO0FBQ04sWUFBSUksR0FBRyxHQUFHLElBQUlDLFlBQUosQ0FBaUIsQ0FBakIsQ0FBVjtBQUNBRCxXQUFHLENBQUMsQ0FBRCxDQUFILEdBQVNuRSxLQUFUO0FBQ0EsWUFBSXFFLElBQUksR0FBRyxJQUFJQyxXQUFKLENBQWdCSCxHQUFHLENBQUNJLE1BQXBCLENBQVg7QUFDQXZFLGFBQUssR0FBSXFFLElBQUksQ0FBQyxDQUFELENBQWI7QUFDQXJFLGFBQUssR0FBR1QsUUFBUSxDQUFDUyxLQUFELENBQWhCO0FBQ0F5RCxxQkFBYSxDQUFDTixNQUFkLENBQXFCO0FBQ3BCMUksY0FEb0I7QUFFcEJHLGlCQUZvQjtBQUdwQnFCLGFBSG9CO0FBSXBCNEgsaUJBSm9CO0FBS3BCQyxpQkFMb0I7QUFNcEI5RCxlQU5vQjtBQU9wQnpFLGdCQVBvQjtBQVFwQndJLGtCQVJvQixDQVNwQjs7QUFUb0IsU0FBckI7QUFXQS9ELGFBQUssR0FBSXFFLElBQUksQ0FBQyxDQUFELENBQWI7QUFDQXJFLGFBQUssR0FBR1QsUUFBUSxDQUFDUyxLQUFELENBQWhCO0FBQ0E4RCxlQUFPLEdBQUdBLE9BQU8sR0FBRyxDQUFwQjtBQUNBTCxxQkFBYSxDQUFDTixNQUFkLENBQXFCO0FBQ3BCMUksY0FEb0I7QUFFcEJHLGlCQUZvQjtBQUdwQnFCLGFBSG9CO0FBSXBCNEgsaUJBSm9CO0FBS3BCQyxpQkFMb0I7QUFNcEI5RCxlQU5vQjtBQU9wQnpFLGdCQVBvQjtBQVFwQndJLGtCQVJvQixDQVNwQjs7QUFUb0IsU0FBckI7QUFXRDs7QUFDQTtBQUFTO0FBOUhWO0FBZ0lBLEdBaExhOztBQWlMZDtBQUNBLDRCQUNFdEosSUFERixFQUVFRyxPQUZGLEVBR0VxQixHQUhGLEVBSUUySCxRQUpGLEVBS0VDLE9BTEYsRUFNRUMsT0FORixFQU9FOUQsS0FQRixFQVFFekUsTUFSRixFQVNFd0ksUUFURixFQVVFQyxRQVZGLEVBWUE7QUFDQ0YsV0FBTyxHQUFHdkUsUUFBUSxDQUFDdUUsT0FBRCxDQUFsQjtBQUNBOUQsU0FBSyxHQUFHRyxNQUFNLENBQUNILEtBQUQsQ0FBZDs7QUFDQSxZQUFPVCxRQUFRLENBQUNxRSxRQUFELENBQWY7QUFFQyxXQUFLLENBQUw7QUFBTztBQUNONUQsYUFBSyxHQUFHVCxRQUFRLENBQUNTLEtBQUQsQ0FBaEI7QUFDQXlELHFCQUFhLENBQUNOLE1BQWQsQ0FBcUI7QUFDcEIxSSxjQURvQjtBQUVwQkcsaUJBRm9CO0FBR3BCcUIsYUFIb0I7QUFJcEI0SCxpQkFKb0I7QUFLcEJDLGlCQUxvQjtBQU1wQjlELGVBTm9CO0FBT3BCekUsZ0JBUG9CO0FBUXBCd0ksa0JBUm9CLENBU3BCOztBQVRvQixTQUFyQjtBQVdEOztBQUNBLFdBQUssQ0FBTDtBQUFPO0FBQ04vRCxhQUFLLEdBQUdULFFBQVEsQ0FBQ1MsS0FBRCxDQUFoQjtBQUNBeUQscUJBQWEsQ0FBQ04sTUFBZCxDQUFxQjtBQUNwQjFJLGNBRG9CO0FBRXBCRyxpQkFGb0I7QUFHcEJxQixhQUhvQjtBQUlwQjRILGlCQUpvQjtBQUtwQkMsaUJBTG9CO0FBTXBCOUQsZUFOb0I7QUFPcEJ6RSxnQkFQb0I7QUFRcEJ3SSxrQkFSb0IsQ0FTcEI7O0FBVG9CLFNBQXJCO0FBV0Q7O0FBQ0EsV0FBSyxDQUFMO0FBQU87QUFDTixZQUFJRSxHQUFHLEdBQUUxRSxRQUFRLENBQUNTLEtBQUQsQ0FBUixHQUFpQixNQUExQjtBQUNBLFlBQUlrRSxJQUFJLEdBQUUzRSxRQUFRLENBQUNTLEtBQUQsQ0FBUixJQUFtQixFQUE3QjtBQUNBQSxhQUFLLEdBQUdpRSxHQUFSO0FBQ0FqRSxhQUFLLEdBQUdULFFBQVEsQ0FBQ1MsS0FBRCxDQUFoQjtBQUNBeUQscUJBQWEsQ0FBQ04sTUFBZCxDQUFxQjtBQUNwQjFJLGNBRG9CO0FBRXBCRyxpQkFGb0I7QUFHcEJxQixhQUhvQjtBQUlwQjRILGlCQUpvQjtBQUtwQkMsaUJBTG9CO0FBTXBCOUQsZUFOb0I7QUFPcEJ6RSxnQkFQb0I7QUFRcEJ3SSxrQkFSb0IsQ0FTcEI7O0FBVG9CLFNBQXJCLEVBTEQsQ0FnQkM7O0FBQ0EvRCxhQUFLLEdBQUdrRSxJQUFSO0FBQ0FsRSxhQUFLLEdBQUdULFFBQVEsQ0FBQ1MsS0FBRCxDQUFoQjtBQUNBOEQsZUFBTyxHQUFHQSxPQUFPLEdBQUcsQ0FBcEI7QUFDQUwscUJBQWEsQ0FBQ04sTUFBZCxDQUFxQjtBQUNwQjFJLGNBRG9CO0FBRXBCRyxpQkFGb0I7QUFHcEJxQixhQUhvQjtBQUlwQjRILGlCQUpvQjtBQUtwQkMsaUJBTG9CO0FBTXBCOUQsZUFOb0I7QUFPcEJ6RSxnQkFQb0I7QUFRcEJ3SSxrQkFSb0IsQ0FTcEI7O0FBVG9CLFNBQXJCO0FBV0Q7O0FBQ0EsV0FBSyxDQUFMO0FBQU87QUFDTixZQUFJRyxJQUFJLEdBQUUzRSxRQUFRLENBQUNTLEtBQUQsQ0FBUixHQUFpQixNQUEzQjtBQUNBLFlBQUlpRSxHQUFHLEdBQUUxRSxRQUFRLENBQUNTLEtBQUQsQ0FBUixJQUFtQixFQUE1QjtBQUNBQSxhQUFLLEdBQUdpRSxHQUFSO0FBQ0FqRSxhQUFLLEdBQUdULFFBQVEsQ0FBQ1MsS0FBRCxDQUFoQjtBQUNBeUQscUJBQWEsQ0FBQ04sTUFBZCxDQUFxQjtBQUNwQjFJLGNBRG9CO0FBRXBCRyxpQkFGb0I7QUFHcEJxQixhQUhvQjtBQUlwQjRILGlCQUpvQjtBQUtwQkMsaUJBTG9CO0FBTXBCOUQsZUFOb0I7QUFPcEJ6RSxnQkFQb0I7QUFRcEJ3SSxrQkFSb0IsQ0FTcEI7O0FBVG9CLFNBQXJCLEVBTEQsQ0FnQkM7O0FBQ0EvRCxhQUFLLEdBQUdrRSxJQUFSO0FBQ0FsRSxhQUFLLEdBQUdULFFBQVEsQ0FBQ1MsS0FBRCxDQUFoQjtBQUNBOEQsZUFBTyxHQUFHQSxPQUFPLEdBQUcsQ0FBcEI7QUFDQUwscUJBQWEsQ0FBQ04sTUFBZCxDQUFxQjtBQUNwQjFJLGNBRG9CO0FBRXBCRyxpQkFGb0I7QUFHcEJxQixhQUhvQjtBQUlwQjRILGlCQUpvQjtBQUtwQkMsaUJBTG9CO0FBTXBCOUQsZUFOb0I7QUFPcEJ6RSxnQkFQb0I7QUFRcEJ3SSxrQkFSb0IsQ0FTcEI7O0FBVG9CLFNBQXJCO0FBV0Q7O0FBQ0EsV0FBSyxDQUFMO0FBQU87QUFDTixZQUFJSSxHQUFHLEdBQUcsSUFBSUMsWUFBSixDQUFpQixDQUFqQixDQUFWO0FBQ0FELFdBQUcsQ0FBQyxDQUFELENBQUgsR0FBU25FLEtBQVQ7QUFDQSxZQUFJcUUsSUFBSSxHQUFHLElBQUlDLFdBQUosQ0FBZ0JILEdBQUcsQ0FBQ0ksTUFBcEIsQ0FBWDtBQUNBdkUsYUFBSyxHQUFJcUUsSUFBSSxDQUFDLENBQUQsQ0FBYjtBQUNBckUsYUFBSyxHQUFHVCxRQUFRLENBQUNTLEtBQUQsQ0FBaEI7QUFDQXlELHFCQUFhLENBQUNOLE1BQWQsQ0FBcUI7QUFDcEIxSSxjQURvQjtBQUVwQkcsaUJBRm9CO0FBR3BCcUIsYUFIb0I7QUFJcEI0SCxpQkFKb0I7QUFLcEJDLGlCQUxvQjtBQU1wQjlELGVBTm9CO0FBT3BCekUsZ0JBUG9CO0FBUXBCd0ksa0JBUm9CLENBU3BCOztBQVRvQixTQUFyQjtBQVdBL0QsYUFBSyxHQUFJcUUsSUFBSSxDQUFDLENBQUQsQ0FBYjtBQUNBckUsYUFBSyxHQUFHVCxRQUFRLENBQUNTLEtBQUQsQ0FBaEI7QUFDQThELGVBQU8sR0FBR0EsT0FBTyxHQUFHLENBQXBCO0FBQ0FMLHFCQUFhLENBQUNOLE1BQWQsQ0FBcUI7QUFDcEIxSSxjQURvQjtBQUVwQkcsaUJBRm9CO0FBR3BCcUIsYUFIb0I7QUFJcEI0SCxpQkFKb0I7QUFLcEJDLGlCQUxvQjtBQU1wQjlELGVBTm9CO0FBT3BCekUsZ0JBUG9CO0FBUXBCd0ksa0JBUm9CLENBU3BCOztBQVRvQixTQUFyQjtBQVdEOztBQUNBO0FBQVM7QUE5SFY7QUFnSUEsR0FqVWE7O0FBa1VkO0FBQ0EsbUNBQWlDckksY0FBakMsRUFDQTtBQUNDLFFBQUlwQyxTQUFTLEdBQUcsRUFBaEI7QUFDQSxRQUFJRSxLQUFLLEdBQUcsQ0FBWjtBQUVBaUssaUJBQWEsQ0FBQ3ZLLElBQWQsQ0FBbUI7QUFBQ3dLLGVBQVMsRUFBQztBQUFDN0gsWUFBSSxFQUFFSDtBQUFQO0FBQVgsS0FBbkIsRUFBc0Q7QUFBRXRCLFVBQUksRUFBRTtBQUFFc0osaUJBQVMsRUFBRSxDQUFDO0FBQWQ7QUFBUixLQUF0RCxFQUFrRm5KLE9BQWxGLENBQTBGLFVBQVNDLEdBQVQsRUFBYztBQUN2R2xCLGVBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkTixXQUFHLEVBQUVHLEdBQUcsQ0FBQ0gsR0FESztBQUVkYixhQUFLLEVBQUNBLEtBRlE7QUFHZGdMLFdBQUcsRUFBRWhLLEdBQUcsQ0FBQ0ksT0FISztBQUlkOEksaUJBQVMsRUFBRSxJQUFJM0ksSUFBSixDQUFTUCxHQUFHLENBQUNrSixTQUFiLEVBQXdCekksY0FBeEIsRUFKRztBQUtkd0osZUFBTyxFQUFFakssR0FBRyxDQUFDQyxJQUxDO0FBTWR1RixhQUFLLEVBQUN4RixHQUFHLENBQUN3RixLQU5JO0FBT2QrRCxnQkFBUSxFQUFFdkosR0FBRyxDQUFDdUo7QUFQQSxPQUFmO0FBU0F2SyxXQUFLLEdBQUNBLEtBQUssR0FBQyxDQUFaO0FBQ0EsS0FYRDtBQVlBLFdBQU9GLFNBQVA7QUFDQSxHQXJWYTs7QUFzVmQ7QUFDQSx1Q0FBcUNvQyxjQUFyQyxFQUFvREMsWUFBcEQsRUFDQTtBQUNDLFFBQUlyQyxTQUFTLEdBQUcsRUFBaEI7QUFDQSxRQUFJRSxLQUFLLEdBQUcsQ0FBWjtBQUVBaUssaUJBQWEsQ0FBQ3ZLLElBQWQsQ0FBbUI7QUFBQ3dLLGVBQVMsRUFBQztBQUFDN0gsWUFBSSxFQUFFSCxjQUFQO0FBQXNCSSxZQUFJLEVBQUNIO0FBQTNCO0FBQVgsS0FBbkIsRUFBd0U7QUFBRXZCLFVBQUksRUFBRTtBQUFFc0osaUJBQVMsRUFBRSxDQUFDO0FBQWQ7QUFBUixLQUF4RSxFQUFvR25KLE9BQXBHLENBQTRHLFVBQVNDLEdBQVQsRUFBYztBQUN6SGxCLGVBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkTixXQUFHLEVBQUVHLEdBQUcsQ0FBQ0gsR0FESztBQUVkYixhQUFLLEVBQUNBLEtBRlE7QUFHZGdMLFdBQUcsRUFBRWhLLEdBQUcsQ0FBQ0ksT0FISztBQUlkOEksaUJBQVMsRUFBRSxJQUFJM0ksSUFBSixDQUFTUCxHQUFHLENBQUNrSixTQUFiLEVBQXdCekksY0FBeEIsRUFKRztBQUtkd0osZUFBTyxFQUFFakssR0FBRyxDQUFDQyxJQUxDO0FBTWR1RixhQUFLLEVBQUN4RixHQUFHLENBQUN3RixLQU5JO0FBT2QrRCxnQkFBUSxFQUFFdkosR0FBRyxDQUFDdUo7QUFQQSxPQUFmO0FBU0F2SyxXQUFLLEdBQUNBLEtBQUssR0FBQyxDQUFaO0FBQ0EsS0FYRDtBQVlBLFdBQU9GLFNBQVA7QUFDQTs7QUF6V2EsQ0FBZixFOzs7Ozs7Ozs7OztBQ2hDQWpCLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNvTSxVQUFRLEVBQUMsTUFBSUE7QUFBZCxDQUFkO0FBQXVDLElBQUlsTSxNQUFKO0FBQVdILE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLEtBQUo7QUFBVU4sTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRSxPQUFLLENBQUNELENBQUQsRUFBRztBQUFDQyxTQUFLLEdBQUNELENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSThJLFFBQUo7QUFBYW5KLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQ2dKLFNBQU8sQ0FBQy9JLENBQUQsRUFBRztBQUFDOEksWUFBUSxHQUFDOUksQ0FBVDtBQUFXOztBQUF2QixDQUF6QixFQUFrRCxDQUFsRDtBQUl6SyxNQUFNZ00sUUFBUSxHQUFHLElBQUkvTCxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsVUFBckIsQ0FBakI7O0FBRVAsSUFBSUosTUFBTSxDQUFDSyxRQUFYLEVBQXFCO0FBQ3BCTCxRQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNkO0FBQ00sMkJBQU47QUFBQSxzQ0FDQTtBQUNDLFlBQUlFLFNBQVMsR0FBRyxFQUFoQjtBQUNBLHNCQUFPb0wsUUFBUSxDQUFDeEwsSUFBVCxDQUFjLEVBQWQsRUFBa0I7QUFBQ2tCLGNBQUksRUFBRTtBQUFDZ0MscUJBQVMsRUFBRTtBQUFaO0FBQVAsU0FBbEIsRUFBMEM3QixPQUExQyxDQUFrRCxVQUFTQyxHQUFULEVBQWM7QUFDdEVsQixtQkFBUyxDQUFDcUIsSUFBVixDQUFlO0FBQ2ROLGVBQUcsRUFBRUcsR0FBRyxDQUFDSCxHQURLO0FBRWRxSCx3QkFBWSxFQUFFLElBQUkzRyxJQUFKLENBQVNQLEdBQUcsQ0FBQzRCLFNBQWIsRUFBd0J1RixrQkFBeEIsQ0FBMkM7QUFBRUMsc0JBQVEsRUFBRTtBQUFaLGFBQTNDLENBRkE7QUFHZEMsc0JBQVUsRUFBRSxJQUFJOUcsSUFBSixDQUFTUCxHQUFHLENBQUNvQixPQUFiLEVBQXNCK0Ysa0JBQXRCLENBQXlDO0FBQUVDLHNCQUFRLEVBQUU7QUFBWixhQUF6QyxDQUhFO0FBSWR4RixxQkFBUyxFQUFFNUIsR0FBRyxDQUFDNEIsU0FKRDtBQUtkUixtQkFBTyxFQUFFcEIsR0FBRyxDQUFDb0IsT0FMQztBQU1DNEIsb0JBQVEsRUFBRWhELEdBQUcsQ0FBQ2dEO0FBTmYsV0FBZjtBQVNBLFNBVk0sQ0FBUDtBQVlBLGVBQU9sRSxTQUFQO0FBQ0EsT0FoQkQ7QUFBQSxLQUZjOztBQW1CZDtBQUNNLDBCQUFOLENBQTZCaUosT0FBN0I7QUFBQSxzQ0FBc0M7QUFDckMsWUFBSWpKLFNBQVMsR0FBSSxFQUFqQjtBQUNTLGNBQU13RCxJQUFJLEdBQUcsSUFBSS9CLElBQUosQ0FBU3dILE9BQVQsQ0FBYixDQUY0QixDQUc1Qjs7QUFFQSxjQUFNRyxhQUFhLEdBQUc1RixJQUFJLENBQUM2RixPQUFMLEVBQXRCO0FBRVQsY0FBTXJHLE1BQU0saUJBQVNvSSxRQUFRLENBQUNuSSxhQUFULEdBQXlCQyxTQUF6QixDQUFtQyxDQUN2RDtBQUFDQyxnQkFBTSxFQUFFO0FBQ05tRyxpQkFBSyxFQUFFO0FBQ1BDLGtCQUFJLEVBQUUsQ0FDTjtBQUFFL0csb0JBQUksRUFBRSxDQUFFLFlBQUYsRUFBZTRHLGFBQWY7QUFBUixlQURNLEVBRU47QUFBRTdHLG9CQUFJLEVBQUUsQ0FBRSxVQUFGLEVBQWM2RyxhQUFkO0FBQVIsZUFGTTtBQURDO0FBREQ7QUFBVCxTQUR1RCxDQUFuQyxFQVNsQm5JLE9BVGtCLENBU1YsVUFBU0MsR0FBVCxFQUFjO0FBQ3hCO0FBQ0FsQixtQkFBUyxDQUFDcUIsSUFBVixDQUFlSCxHQUFmO0FBQ0EsU0Fab0IsQ0FBVCxDQUFaO0FBYUEsZUFBT2xCLFNBQVA7QUFDQSxPQXJCRDtBQUFBLEtBcEJjOztBQXlDVjtBQUNFLCtCQUFOLENBQWtDb0osYUFBbEM7QUFBQSxzQ0FBaUQ7QUFDdkMsWUFBSXBKLFNBQVMsR0FBSSxFQUFqQjtBQUNULGNBQU1nRCxNQUFNLGlCQUFTb0ksUUFBUSxDQUFDbkksYUFBVCxHQUF5QkMsU0FBekIsQ0FBbUMsQ0FDdkQ7QUFBQ0MsZ0JBQU0sRUFBRTtBQUNObUcsaUJBQUssRUFBRTtBQUNQQyxrQkFBSSxFQUFFLENBQ047QUFBRS9HLG9CQUFJLEVBQUUsQ0FBRSxZQUFGLEVBQWU0RyxhQUFmO0FBQVIsZUFETSxFQUVOO0FBQUU3RyxvQkFBSSxFQUFFLENBQUUsVUFBRixFQUFjNkcsYUFBZDtBQUFSLGVBRk07QUFEQztBQUREO0FBQVQsU0FEdUQsQ0FBbkMsRUFTbEJuSSxPQVRrQixDQVNWLFVBQVNDLEdBQVQsRUFBYztBQUN4QjtBQUNBbEIsbUJBQVMsQ0FBQ3FCLElBQVYsQ0FBZUgsR0FBZjtBQUNBLFNBWm9CLENBQVQsQ0FBWjtBQWFBLGVBQU9sQixTQUFQO0FBQ0EsT0FoQkQ7QUFBQSxLQTFDYzs7QUEyRGQ7QUFDTSxxQkFBTixDQUNDOEMsU0FERCxFQUVDUixPQUZELEVBR1U0QixRQUhWO0FBQUEsc0NBS0E7QUFDQyxZQUFJLENBQUNnRSxRQUFRLENBQUNzQixTQUFULENBQW1CLEtBQUtDLE1BQXhCLEVBQStCLE9BQS9CLENBQUwsRUFDQTtBQUNDLGdCQUFNLElBQUl2SyxNQUFNLENBQUN3SyxLQUFYLENBQWlCLFdBQWpCLEVBQTZCLHdCQUE3QixDQUFOO0FBQ0EsU0FIRCxNQUtBO0FBQ0MsZ0JBQU1DLGVBQWUsaUJBQVN6SyxNQUFNLENBQUNrSCxJQUFQLENBQVksc0JBQVosRUFBb0N0RCxTQUFwQyxDQUFULENBQXJCO0FBQ0EsZ0JBQU04RyxlQUFlLGlCQUFTMUssTUFBTSxDQUFDa0gsSUFBUCxDQUFZLHNCQUFaLEVBQW9DOUQsT0FBcEMsQ0FBVCxDQUFyQjs7QUFDQSxjQUFLcUgsZUFBZSxJQUFJLEVBQXBCLElBQTRCQyxlQUFlLElBQUksRUFBbkQsRUFDQTtBQUNDLGtCQUFNLElBQUkxSyxNQUFNLENBQUN3SyxLQUFYLENBQWlCLG1DQUFqQixDQUFOO0FBQ0EsV0FIRCxNQUtBO0FBQ0MsMEJBQU0wQixRQUFRLENBQUN2QixNQUFULENBQWdCO0FBQ3JCL0csdUJBRHFCO0FBRXJCUixxQkFGcUI7QUFHSDRCO0FBSEcsYUFBaEIsQ0FBTjtBQU1BO0FBQ0Q7O0FBQ0QsZUFBTyxDQUFQO0FBQ0EsT0E3QkQ7QUFBQTs7QUE1RGMsR0FBZjtBQTJGQSxDLENBQ0Q7OztBQUNBaEYsTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFFZDtBQUNBLHNCQUFvQnFCLElBQXBCLEVBQ0E7QUFDQyxRQUFJMkksUUFBUSxHQUFHc0IsUUFBUSxDQUFDckIsT0FBVCxDQUFpQjtBQUFFNUksVUFBSSxFQUFDQTtBQUFQLEtBQWpCLENBQWY7O0FBQ0EsUUFBSTJJLFFBQVEsSUFBRSxJQUFkLEVBQW9CO0FBQ25CLGFBQU8sQ0FBUDtBQUNBLEtBRkQsTUFJQTtBQUNDLGFBQU8sQ0FBUDtBQUNBO0FBQ0QsR0FiYTs7QUFnQmQ7QUFDQSxvQkFBa0JFLE1BQWxCLEVBQ0E7QUFDQyxRQUFJLENBQUM5QixRQUFRLENBQUNzQixTQUFULENBQW1CLEtBQUtDLE1BQXhCLEVBQStCLE9BQS9CLENBQUwsRUFDQTtBQUNDLFlBQU0sSUFBSXZLLE1BQU0sQ0FBQ3dLLEtBQVgsQ0FBaUIsV0FBakIsRUFBNkIsd0JBQTdCLENBQU47QUFDQSxLQUhELE1BS0E7QUFDQzBCLGNBQVEsQ0FBQ25CLE1BQVQsQ0FBZ0JELE1BQWhCO0FBQ0E7QUFDRCxHQTNCYTs7QUE0QmQ7QUFDQSxvQkFDQ2pKLEdBREQsRUFFT21ELFFBRlAsRUFJQTtBQUNDLFFBQUksQ0FBQ2dFLFFBQVEsQ0FBQ3NCLFNBQVQsQ0FBbUIsS0FBS0MsTUFBeEIsRUFBK0IsT0FBL0IsQ0FBTCxFQUNBO0FBQ0MsWUFBTSxJQUFJdkssTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixXQUFqQixFQUE2Qix3QkFBN0IsQ0FBTjtBQUNBLEtBSEQsTUFLQTtBQUNDMEIsY0FBUSxDQUFDbEIsTUFBVCxDQUFnQm5KLEdBQWhCLEVBQ0M7QUFBRXFDLFlBQUksRUFBRTtBQUNRYztBQURSO0FBQVIsT0FERDtBQUtBO0FBQ0QsR0E5Q2E7O0FBK0NkO0FBQ0Esd0JBQ0NuRCxHQURELEVBRU8rQixTQUZQLEVBR09SLE9BSFAsRUFLQTtBQUNDLFFBQUksQ0FBQzRGLFFBQVEsQ0FBQ3NCLFNBQVQsQ0FBbUIsS0FBS0MsTUFBeEIsRUFBK0IsT0FBL0IsQ0FBTCxFQUNBO0FBQ0MsWUFBTSxJQUFJdkssTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixXQUFqQixFQUE2Qix3QkFBN0IsQ0FBTjtBQUNBLEtBSEQsTUFLQTtBQUNDMEIsY0FBUSxDQUFDbEIsTUFBVCxDQUFnQm5KLEdBQWhCLEVBQ0M7QUFBRXFDLFlBQUksRUFBRTtBQUNRTixtQkFEUjtBQUVRUjtBQUZSO0FBQVIsT0FERDtBQU1BO0FBQ0Q7O0FBbkVhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNwR0F2RCxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDcU0sa0JBQWdCLEVBQUMsTUFBSUE7QUFBdEIsQ0FBZDtBQUF1RCxJQUFJbk0sTUFBSjtBQUFXSCxNQUFNLENBQUNJLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxLQUFKO0FBQVVOLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0UsT0FBSyxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsU0FBSyxHQUFDRCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUk4SSxRQUFKO0FBQWFuSixNQUFNLENBQUNJLElBQVAsQ0FBWSxZQUFaLEVBQXlCO0FBQUNnSixTQUFPLENBQUMvSSxDQUFELEVBQUc7QUFBQzhJLFlBQVEsR0FBQzlJLENBQVQ7QUFBVzs7QUFBdkIsQ0FBekIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSWtNLGFBQUo7QUFBa0J2TSxNQUFNLENBQUNJLElBQVAsQ0FBWSxvQkFBWixFQUFpQztBQUFDZ0osU0FBTyxDQUFDL0ksQ0FBRCxFQUFHO0FBQUNrTSxpQkFBYSxHQUFDbE0sQ0FBZDtBQUFnQjs7QUFBNUIsQ0FBakMsRUFBK0QsQ0FBL0Q7QUFLaFEsTUFBTWlNLGdCQUFnQixHQUFHLElBQUloTSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsa0JBQXJCLENBQXpCOztBQUVQLElBQUlKLE1BQU0sQ0FBQ0ssUUFBWCxFQUFxQjtBQUNwQkwsUUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDUix3Q0FBTjtBQUFBLHNDQUE2QztBQUM1QyxZQUFJRSxTQUFTLEdBQUcsRUFBaEI7QUFDQSw2QkFBYXFMLGdCQUFnQixDQUFDcEksYUFBakIsR0FBaUNDLFNBQWpDLENBQTJDLENBQ3ZEO0FBQ0NxSSxpQkFBTyxFQUNQO0FBQ0NDLGdCQUFJLEVBQUUsZUFEUDtBQUVDQyxzQkFBVSxFQUFFLFdBRmI7QUFHQ0Msd0JBQVksRUFBRSxLQUhmO0FBSUNDLGNBQUUsRUFBRTtBQUpMO0FBRkQsU0FEdUQsRUFVdkQ7QUFBRUMsaUJBQU8sRUFBRTtBQUFYLFNBVnVELEVBV3ZEO0FBQ0NMLGlCQUFPLEVBQ1A7QUFDQ0MsZ0JBQUksRUFBRSxnQkFEUDtBQUVDQyxzQkFBVSxFQUFFLFVBRmI7QUFHQ0Msd0JBQVksRUFBRSxLQUhmO0FBSUNDLGNBQUUsRUFBRTtBQUpMO0FBRkQsU0FYdUQsRUFvQnZEO0FBQUVDLGlCQUFPLEVBQUU7QUFBWCxTQXBCdUQsRUFxQnZEO0FBQUM3SCxrQkFBUSxFQUFFO0FBQ1YsbUJBQU8sTUFERztBQUVWLHFCQUFTLFlBRkM7QUFHVixzQkFBVSxXQUhBO0FBSVYscUJBQVMsVUFKQztBQUtWLHlCQUFhLFdBTEg7QUFNVix5QkFBYSxZQU5IO0FBT1YsNEJBQWdCLGVBUE47QUFRVix3QkFBWSxXQVJGO0FBU1Ysc0JBQVU7QUFUQTtBQUFYLFNBckJ1RCxDQUEzQyxFQWlDVnNHLE9BakNVLEVBQWI7QUFrQ0EsT0FwQ0Q7QUFBQTs7QUFEYyxHQUFmO0FBdUNBLEMsQ0FDQTs7O0FBQ0RuTCxNQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNkO0FBQ0Esb0NBQ0E7QUFDQyxRQUFJRSxTQUFTLEdBQUcsRUFBaEI7QUFDQXFMLG9CQUFnQixDQUFDekwsSUFBakIsQ0FBc0IsRUFBdEIsRUFBMEI7QUFBQ2tCLFVBQUksRUFBRTtBQUFDK0ssa0JBQVUsRUFBRSxDQUFDO0FBQWQ7QUFBUCxLQUExQixFQUFvRDVLLE9BQXBELENBQTRELFVBQVNDLEdBQVQsRUFBYztBQUN6RSxVQUFJeUIsR0FBRyxHQUFHekQsTUFBTSxDQUFDa0gsSUFBUCxDQUFZLHVCQUFaLEVBQW9DbEYsR0FBRyxDQUFDNEssU0FBeEMsQ0FBVjtBQUNBLFVBQUlDLEtBQUssR0FBRzdNLE1BQU0sQ0FBQ2tILElBQVAsQ0FBWSx3QkFBWixFQUFxQ3pELEdBQUcsQ0FBQ1IsSUFBekMsQ0FBWjtBQUNBbkMsZUFBUyxDQUFDcUIsSUFBVixDQUFlO0FBQ2ROLFdBQUcsRUFBRUcsR0FBRyxDQUFDSCxHQURLO0FBRWRnTCxhQUFLLEVBQUVBLEtBRk87QUFHZEMsY0FBTSxFQUFFckosR0FBRyxDQUFDUixJQUhFO0FBSWQySixpQkFBUyxFQUFFbkosR0FBRyxDQUFDeEIsSUFKRDtBQUtkOEssYUFBSyxFQUFFL0ssR0FBRyxDQUFDNEssU0FMRztBQU1kSSxpQkFBUyxFQUFFaEwsR0FBRyxDQUFDZ0wsU0FORDtBQU9kQyxvQkFBWSxFQUFFakwsR0FBRyxDQUFDaUwsWUFQSjtBQVFkQyxnQkFBUSxFQUFFbEwsR0FBRyxDQUFDa0w7QUFSQSxPQUFmO0FBVUEsS0FiRDtBQWNBLFdBQU9wTSxTQUFQO0FBQ0EsR0FwQmE7O0FBc0JkO0FBQ0Esd0NBQXNDcU0sTUFBdEMsRUFBNkNDLFVBQTdDLEVBQXdENUosUUFBeEQsRUFDQTtBQUNDLFFBQUk4SCxPQUFPLEdBQUcsQ0FBZDtBQUNBLFFBQUkrQixjQUFjLEdBQUcsQ0FBckI7QUFDQWxCLG9CQUFnQixDQUFDekwsSUFBakIsQ0FBc0I7QUFBRWtNLGVBQVMsRUFBQ087QUFBWixLQUF0QixFQUEyQ3BMLE9BQTNDLENBQW1ELFVBQVNDLEdBQVQsRUFBYztBQUNoRSxVQUFJd0IsUUFBUSxJQUFFLE1BQWQsRUFDQTtBQUNDLFlBQUk4SixLQUFLLEdBQUcsQ0FBWjtBQUNBQSxhQUFLLEdBQUdGLFVBQVUsQ0FBQ3ZLLEtBQVgsQ0FBaUIsR0FBakIsQ0FBUjtBQUNBeUksZUFBTyxHQUFHdkUsUUFBUSxDQUFDdUcsS0FBSyxDQUFDLENBQUQsQ0FBTixDQUFsQjtBQUNBLE9BTEQsTUFPQTtBQUNDaEMsZUFBTyxHQUFHdkUsUUFBUSxDQUFDcUcsVUFBRCxDQUFsQjtBQUNBOztBQUNELFVBQUlHLFFBQVEsR0FBR3hHLFFBQVEsQ0FBQy9FLEdBQUcsQ0FBQ2lMLFlBQUwsQ0FBUixHQUE2QmxHLFFBQVEsQ0FBQy9FLEdBQUcsQ0FBQ2tMLFFBQUwsQ0FBcEQ7O0FBQ0EsVUFBSzVCLE9BQU8sSUFBSXZFLFFBQVEsQ0FBQy9FLEdBQUcsQ0FBQ2lMLFlBQUwsQ0FBcEIsSUFBMkMzQixPQUFPLElBQUVpQyxRQUF4RCxFQUNBO0FBQ0NGLHNCQUFjLEdBQUdyTCxHQUFHLENBQUNnTCxTQUFyQjtBQUNBO0FBRUQsS0FqQkQ7O0FBa0JBLFFBQUlLLGNBQWMsSUFBRSxDQUFwQixFQUNBO0FBQ0MsYUFBTyxJQUFQO0FBQ0E7O0FBQ0QsV0FBT0EsY0FBUDtBQUNBLEdBbERhOztBQW9EZDtBQUNBLDRCQUNDVCxTQURELEVBRUNZLFVBRkQsRUFHQ1AsWUFIRCxFQUlDQyxRQUpELEVBS0NPLFVBTEQsRUFNQ2QsVUFORCxFQVFBO0FBQ0MsUUFBSUssU0FBUyxHQUFHLENBQWhCOztBQUNBLFFBQUksQ0FBQ2hFLFFBQVEsQ0FBQ3NCLFNBQVQsQ0FBbUIsS0FBS0MsTUFBeEIsRUFBK0IsT0FBL0IsQ0FBTCxFQUNBO0FBQ0MsWUFBTSxJQUFJdkssTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixXQUFqQixFQUE2Qix3QkFBN0IsQ0FBTjtBQUNBLEtBSEQsTUFLQTtBQUVDLFVBQUlyQyxJQUFJLEdBQUdnRSxnQkFBZ0IsQ0FBQ3RCLE9BQWpCLENBQXlCO0FBQUUrQixpQkFBUyxFQUFDQTtBQUFaLE9BQXpCLEVBQWdEO0FBQUNoTCxZQUFJLEVBQUM7QUFBRW9MLG1CQUFTLEVBQUcsQ0FBQztBQUFmLFNBQU47QUFBMEJsTCxhQUFLLEVBQUM7QUFBaEMsT0FBaEQsQ0FBWDs7QUFDQSxVQUFJcUcsSUFBSSxJQUFJLElBQVosRUFDQSxDQUNDO0FBQ0EsT0FIRCxNQUtBO0FBRUM2RSxpQkFBUyxHQUFJakcsUUFBUSxDQUFDb0IsSUFBSSxDQUFDNkUsU0FBTixDQUFSLEdBQTRCLENBQXpDLENBRkQsQ0FHQztBQUNBOztBQUNEYixzQkFBZ0IsQ0FBQ3hCLE1BQWpCLENBQXdCO0FBQ3ZCaUMsaUJBRHVCO0FBRXZCSSxpQkFGdUI7QUFHdkJDLG9CQUh1QjtBQUl2QkMsZ0JBSnVCO0FBS3ZCTyxrQkFMdUI7QUFNdkJkO0FBTnVCLE9BQXhCO0FBUUE7O0FBQ0QsV0FBTyxDQUFQO0FBQ0EsR0EzRmE7O0FBNEZkO0FBQ0EsNEJBQTBCN0IsTUFBMUIsRUFBa0M7QUFDakMsUUFBSSxDQUFDOUIsUUFBUSxDQUFDc0IsU0FBVCxDQUFtQixLQUFLQyxNQUF4QixFQUErQixPQUEvQixDQUFMLEVBQ0E7QUFDQyxZQUFNLElBQUl2SyxNQUFNLENBQUN3SyxLQUFYLENBQWlCLFdBQWpCLEVBQTZCLHdCQUE3QixDQUFOO0FBQ0EsS0FIRCxNQUtBO0FBQ0MyQixzQkFBZ0IsQ0FBQ3BCLE1BQWpCLENBQXdCRCxNQUF4QjtBQUNBO0FBQ0QsR0F0R2E7O0FBdUdkO0FBQ0EsNEJBQ0NqSixHQURELEVBRUNvTCxZQUZELEVBR0NDLFFBSEQsRUFJQ08sVUFKRCxFQUtDZCxVQUxELEVBT0E7QUFDQyxRQUFJLENBQUMzRCxRQUFRLENBQUNzQixTQUFULENBQW1CLEtBQUtDLE1BQXhCLEVBQStCLE9BQS9CLENBQUwsRUFDQTtBQUNDLFlBQU0sSUFBSXZLLE1BQU0sQ0FBQ3dLLEtBQVgsQ0FBaUIsV0FBakIsRUFBNkIsd0JBQTdCLENBQU47QUFDQSxLQUhELE1BS0E7QUFDQzJCLHNCQUFnQixDQUFDbkIsTUFBakIsQ0FBd0JuSixHQUF4QixFQUNDO0FBQUVxQyxZQUFJLEVBQUU7QUFDUCtJLHNCQURPO0FBRVBDLGtCQUZPO0FBR1BPLG9CQUhPO0FBSVBkO0FBSk87QUFBUixPQUREO0FBUUE7QUFDRDs7QUEvSGEsQ0FBZixFOzs7Ozs7Ozs7OztBQ2pEQTlNLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUM0TixtQkFBaUIsRUFBQyxNQUFJQTtBQUF2QixDQUFkO0FBQXlELElBQUkxTixNQUFKO0FBQVdILE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLEtBQUo7QUFBVU4sTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRSxPQUFLLENBQUNELENBQUQsRUFBRztBQUFDQyxTQUFLLEdBQUNELENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSXlOLGFBQUo7QUFBa0I5TixNQUFNLENBQUNJLElBQVAsQ0FBWSxvQkFBWixFQUFpQztBQUFDZ0osU0FBTyxDQUFDL0ksQ0FBRCxFQUFHO0FBQUN5TixpQkFBYSxHQUFDek4sQ0FBZDtBQUFnQjs7QUFBNUIsQ0FBakMsRUFBK0QsQ0FBL0Q7QUFBa0UsSUFBSTBOLGdCQUFKO0FBQXFCL04sTUFBTSxDQUFDSSxJQUFQLENBQVksdUJBQVosRUFBb0M7QUFBQzJOLGtCQUFnQixDQUFDMU4sQ0FBRCxFQUFHO0FBQUMwTixvQkFBZ0IsR0FBQzFOLENBQWpCO0FBQW1COztBQUF4QyxDQUFwQyxFQUE4RSxDQUE5RTtBQUFpRixJQUFJOEksUUFBSjtBQUFhbkosTUFBTSxDQUFDSSxJQUFQLENBQVksWUFBWixFQUF5QjtBQUFDZ0osU0FBTyxDQUFDL0ksQ0FBRCxFQUFHO0FBQUM4SSxZQUFRLEdBQUM5SSxDQUFUO0FBQVc7O0FBQXZCLENBQXpCLEVBQWtELENBQWxEO0FBTXJYLE1BQU13TixpQkFBaUIsR0FBRyxJQUFJdk4sS0FBSyxDQUFDQyxVQUFWLENBQXFCLG1CQUFyQixDQUExQjs7QUFHUCxJQUFJSixNQUFNLENBQUNLLFFBQVgsRUFBcUI7QUFDbEI7QUFDRkwsUUFBTSxDQUFDTSxPQUFQLENBQWUsa0JBQWYsRUFBbUMsU0FBU3VOLGdCQUFULENBQTBCck4sYUFBMUIsRUFBeUM7QUFDM0V3SixXQUFPLENBQUNDLEdBQVIsQ0FBWSxtQkFBWjtBQUNBLFdBQU95RCxpQkFBaUIsQ0FBQ2hOLElBQWxCLENBQXVCRixhQUF2QixDQUFQO0FBQ0EsR0FIRDtBQUtBUixRQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNkO0FBQ00sbUNBQU4sQ0FDQ3dCLE9BREQsRUFFQzBMLGFBRkQsRUFHQ0MsTUFIRCxFQUlDQyxRQUpELEVBS0NDLFFBTEQsRUFNQ0MsTUFORCxFQU9DQyxNQVBELEVBUUN4QixVQVJEO0FBQUEsc0NBVUE7QUFFQyxZQUFJLENBQUMzRCxRQUFRLENBQUNzQixTQUFULENBQW1CLEtBQUtDLE1BQXhCLEVBQStCLE9BQS9CLENBQUwsRUFDQTtBQUNDLGdCQUFNLElBQUl2SyxNQUFNLENBQUN3SyxLQUFYLENBQWlCLFdBQWpCLEVBQTZCLHdCQUE3QixDQUFOO0FBQ0EsU0FIRCxNQUtBO0FBQ0MsY0FBSSxjQUFNa0QsaUJBQWlCLENBQUM3QyxPQUFsQixDQUEwQjtBQUFFUixnQkFBSSxFQUFFLENBQUU7QUFBRTBELG9CQUFNLEVBQUU7QUFBRUssbUJBQUcsRUFBRUw7QUFBUDtBQUFWLGFBQUYsRUFBK0I7QUFBRTNMLHFCQUFPLEVBQUU7QUFBRWdNLG1CQUFHLEVBQUVoTTtBQUFQO0FBQVgsYUFBL0I7QUFBUixXQUExQixDQUFOLEtBQXlHLElBQTdHLEVBQ0E7QUFDQyxrQkFBTSxJQUFJcEMsTUFBTSxDQUFDd0ssS0FBWCxDQUFpQiwrQ0FBakIsQ0FBTjtBQUNBLFdBSEQsTUFLQTtBQUNDLDBCQUFNa0QsaUJBQWlCLENBQUMvQyxNQUFsQixDQUF5QjtBQUMvQnZJLHFCQUQrQjtBQUUvQjBMLDJCQUYrQjtBQUcvQkMsb0JBSCtCO0FBSS9CQyxzQkFKK0I7QUFLL0JDLHNCQUwrQjtBQU0vQkMsb0JBTitCO0FBTy9CQyxvQkFQK0I7QUFRL0J4QjtBQVIrQixhQUF6QixDQUFOO0FBVUE7O0FBQ0QsaUJBQU8sQ0FBUDtBQUNBO0FBQ0QsT0FyQ0Q7QUFBQSxLQUZjOztBQXdDZDtBQUNNLHlDQUFOO0FBQUEsc0NBQThDO0FBQzdDLDZCQUFhZSxpQkFBaUIsQ0FBQzNKLGFBQWxCLEdBQWtDQyxTQUFsQyxDQUE0QyxDQUN4RDtBQUNDcUksaUJBQU8sRUFDUDtBQUNDQyxnQkFBSSxFQUFFLGVBRFA7QUFFQ0Msc0JBQVUsRUFBRSxlQUZiO0FBR0NDLHdCQUFZLEVBQUUsS0FIZjtBQUlDQyxjQUFFLEVBQUU7QUFKTDtBQUZELFNBRHdELEVBVXhEO0FBQUVDLGlCQUFPLEVBQUU7QUFBWCxTQVZ3RCxFQVd4RDtBQUNDTCxpQkFBTyxFQUNQO0FBQ0NDLGdCQUFJLEVBQUUsa0JBRFA7QUFFQ0Msc0JBQVUsRUFBRSxRQUZiO0FBR0NDLHdCQUFZLEVBQUUsS0FIZjtBQUlDQyxjQUFFLEVBQUU7QUFKTDtBQUZELFNBWHdELEVBb0J4RDtBQUFFQyxpQkFBTyxFQUFFO0FBQVgsU0FwQndELEVBcUJ4RDtBQUNDTCxpQkFBTyxFQUNQO0FBQ0NDLGdCQUFJLEVBQUUsZ0JBRFA7QUFFQ0Msc0JBQVUsRUFBRSxhQUZiO0FBR0NDLHdCQUFZLEVBQUUsS0FIZjtBQUlDQyxjQUFFLEVBQUU7QUFKTDtBQUZELFNBckJ3RCxFQThCeEQ7QUFBRUMsaUJBQU8sRUFBRTtBQUFYLFNBOUJ3RCxFQStCeEQ7QUFBQ3BILGVBQUssRUFBRztBQUFFLDJCQUFjO0FBQWhCO0FBQVQsU0EvQndELEVBZ0N4RDtBQUFDVCxrQkFBUSxFQUFFO0FBQ1YsbUJBQU8sTUFERztBQUVWLHFCQUFTLFlBRkM7QUFHVixzQkFBVSxXQUhBO0FBSVYsdUJBQWEsVUFKSDtBQUtWLHNCQUFXLFVBTEQ7QUFNViw2QkFBa0IsY0FOUjtBQU9WLHlCQUFjLGFBUEo7QUFRVixzQkFBVyxjQVJEO0FBU1Ysd0JBQWMsV0FUSjtBQVVWLHdCQUFjLFdBVko7QUFXVixzQkFBWSxTQVhGO0FBWVYsc0JBQVksU0FaRjtBQWFWLHNCQUFZO0FBYkY7QUFBWCxTQWhDd0QsQ0FBNUMsRUErQ1ZzRyxPQS9DVSxFQUFiO0FBZ0RBLE9BakREO0FBQUEsS0F6Q2M7O0FBMkZkO0FBQ00sNkNBQU4sQ0FBZ0RrRCxVQUFoRDtBQUFBLHNDQUNBO0FBQ0MsNkJBQWFYLGlCQUFpQixDQUFDM0osYUFBbEIsR0FBa0NDLFNBQWxDLENBQTRDLENBQ3pEO0FBQUNDLGdCQUFNLEVBQUU7QUFBRW9HLGdCQUFJLEVBQUUsQ0FBRTtBQUFFMEQsb0JBQU0sRUFBRTtBQUFFSyxtQkFBRyxFQUFFQztBQUFQO0FBQVYsYUFBRixFQUFtQztBQUFFQyx1QkFBUyxFQUFFO0FBQUVGLG1CQUFHLEVBQUU7QUFBUDtBQUFiLGFBQW5DO0FBQVI7QUFBVCxTQUR5RCxFQUV6RDtBQUFDOUksZUFBSyxFQUFHO0FBQUVxSCxzQkFBVSxFQUFHLENBQUM7QUFBaEI7QUFBVCxTQUZ5RCxFQUd6RDtBQUNDTixpQkFBTyxFQUNMO0FBQ0RDLGdCQUFJLEVBQUUsZUFETDtBQUVEQyxzQkFBVSxFQUFFLGVBRlg7QUFHREMsd0JBQVksRUFBRSxLQUhiO0FBSURDLGNBQUUsRUFBRTtBQUpIO0FBRkgsU0FIeUQsRUFZekQ7QUFBRUMsaUJBQU8sRUFBRTtBQUFYLFNBWnlELENBQTVDLEVBYVZ2QixPQWJVLEVBQWI7QUFjQSxPQWhCRDtBQUFBLEtBNUZjOztBQTZHZDtBQUNNLHVDQUFOLENBQTBDa0QsVUFBMUM7QUFBQSxzQ0FDQTtBQUNDLDZCQUFhWCxpQkFBaUIsQ0FBQzNKLGFBQWxCLEdBQWtDQyxTQUFsQyxDQUE0QyxDQUN6RDtBQUFDQyxnQkFBTSxFQUFFO0FBQUVvRyxnQkFBSSxFQUFFLENBQUU7QUFBRTBELG9CQUFNLEVBQUU7QUFBRUssbUJBQUcsRUFBRUM7QUFBUDtBQUFWLGFBQUYsRUFBbUM7QUFBRUMsdUJBQVMsRUFBRTtBQUFFRixtQkFBRyxFQUFFO0FBQVA7QUFBYixhQUFuQztBQUFSO0FBQVQsU0FEeUQsRUFFekQ7QUFDQy9CLGlCQUFPLEVBQ0w7QUFDREMsZ0JBQUksRUFBRSxlQURMO0FBRURDLHNCQUFVLEVBQUUsZUFGWDtBQUdEQyx3QkFBWSxFQUFFLEtBSGI7QUFJREMsY0FBRSxFQUFFO0FBSkg7QUFGSCxTQUZ5RCxFQVd6RDtBQUFFQyxpQkFBTyxFQUFFO0FBQVgsU0FYeUQsRUFZekQ7QUFBQ3BILGVBQUssRUFBRztBQUFFLDRCQUFlO0FBQWpCO0FBQVQsU0FaeUQsQ0FBNUMsRUFhVjZGLE9BYlUsRUFBYjtBQWNBLE9BaEJEO0FBQUEsS0E5R2M7O0FBK0hiO0FBQ0ssb0NBQU4sQ0FDQzRDLE1BREQsRUFFQ1EsV0FGRDtBQUFBLHNDQUlBO0FBRUMsNkJBQWFiLGlCQUFpQixDQUFDaE4sSUFBbEIsQ0FBdUI7QUFBRTJKLGNBQUksRUFBRSxDQUFFO0FBQUUwRCxrQkFBTSxFQUFFO0FBQUVLLGlCQUFHLEVBQUVMO0FBQVA7QUFBVixXQUFGLEVBQStCO0FBQUVRLHVCQUFXLEVBQUU7QUFBRUgsaUJBQUcsRUFBRUc7QUFBUDtBQUFmLFdBQS9CO0FBQVIsU0FBdkIsRUFBc0dDLEtBQXRHLEVBQWI7QUFDQSxPQVBEO0FBQUE7O0FBaEljLEdBQWY7QUF5SUE7O0FBRUR4TyxNQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNkO0FBQ0EscUNBQ0E7QUFDQyxRQUFJRSxTQUFTLEdBQUcsRUFBaEI7QUFDQTRNLHFCQUFpQixDQUFDaE4sSUFBbEIsQ0FBdUIsRUFBdkIsRUFBMEI7QUFBQ2tCLFVBQUksRUFBQztBQUFFK0ssa0JBQVUsRUFBRyxDQUFDO0FBQWhCO0FBQU4sS0FBMUIsRUFBc0Q1SyxPQUF0RCxDQUE4RCxVQUFTQyxHQUFULEVBQWM7QUFDM0UsVUFBSXlNLE9BQU8sR0FBR3pPLE1BQU0sQ0FBQ2tILElBQVAsQ0FBWSx1QkFBWixFQUFvQ2xGLEdBQUcsQ0FBQzhMLGFBQXhDLENBQWQ7QUFDQSxVQUFJQyxNQUFNLEdBQUcvTixNQUFNLENBQUNrSCxJQUFQLENBQVksNEJBQVosRUFBeUNsRixHQUFHLENBQUMrTCxNQUE3QyxDQUFiO0FBQ0EsVUFBSWxCLEtBQUssR0FBRzdNLE1BQU0sQ0FBQ2tILElBQVAsQ0FBWSx3QkFBWixFQUFxQzZHLE1BQU0sQ0FBQzlLLElBQTVDLENBQVo7QUFFQW5DLGVBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkTixXQUFHLEVBQUVHLEdBQUcsQ0FBQ0gsR0FESztBQUVkZ0wsYUFBSyxFQUFFQSxLQUZPO0FBR2RDLGNBQU0sRUFBRWlCLE1BQU0sQ0FBQzlLLElBSEQ7QUFJZGIsZUFBTyxFQUFHSixHQUFHLENBQUNJLE9BSkE7QUFLZHNNLGNBQU0sRUFBRTFNLEdBQUcsQ0FBQzhMLGFBTEU7QUFNZEEscUJBQWEsRUFBR1csT0FORjtBQU9kRSxpQkFBUyxFQUFFM00sR0FBRyxDQUFDK0wsTUFQRDtBQVFkQSxjQUFNLEVBQUVBLE1BQU0sQ0FBQzlMLElBUkQ7QUFTZCtMLGdCQUFRLEVBQUdoTSxHQUFHLENBQUNnTSxRQVREO0FBVWRDLGdCQUFRLEVBQUdqTSxHQUFHLENBQUNpTSxRQVZEO0FBV2RXLGNBQU0sRUFBRzVNLEdBQUcsQ0FBQzRNLE1BWEM7QUFZZFYsY0FBTSxFQUFHbE0sR0FBRyxDQUFDa00sTUFaQztBQWFkQyxjQUFNLEVBQUduTSxHQUFHLENBQUNtTSxNQWJDO0FBY2RTLGNBQU0sRUFBRzVNLEdBQUcsQ0FBQzRNO0FBZEMsT0FBZjtBQWlCQSxLQXRCRDtBQXdCQSxXQUFPOU4sU0FBUDtBQUNBLEdBOUJhOztBQWlDZDtBQUNBLGlDQUErQnVOLFVBQS9CLEVBQ0E7QUFDQyxRQUFJdk4sU0FBUyxHQUFHLEVBQWhCO0FBQ0EsUUFBSTZOLFNBQVMsR0FBRzNPLE1BQU0sQ0FBQ2tILElBQVAsQ0FBWSx3QkFBWixFQUFxQ21ILFVBQXJDLENBQWhCO0FBQ0FYLHFCQUFpQixDQUFDaE4sSUFBbEIsQ0FBdUI7QUFBQ3FOLFlBQU0sRUFBQ1k7QUFBUixLQUF2QixFQUEwQztBQUFDWixZQUFNLEVBQUMsQ0FBUjtBQUFVcEIsZ0JBQVUsRUFBQztBQUFyQixLQUExQyxFQUFtRTVLLE9BQW5FLENBQTJFLFVBQVNDLEdBQVQsRUFBYztBQUN4RixVQUFJWSxHQUFHLEdBQUc1QyxNQUFNLENBQUNrSCxJQUFQLENBQVksc0JBQVosRUFBbUNsRixHQUFHLENBQUM4TCxhQUF2QyxDQUFWOztBQUNBLFVBQUlsTCxHQUFHLElBQUUsSUFBVCxFQUNBO0FBQ0M5QixpQkFBUyxDQUFDcUIsSUFBVixDQUFlO0FBQ2ROLGFBQUcsRUFBRUcsR0FBRyxDQUFDSCxHQURLO0FBRWRPLGlCQUFPLEVBQUdKLEdBQUcsQ0FBQ0ksT0FGQTtBQUdkMEwsdUJBQWEsRUFBRzlMLEdBQUcsQ0FBQzhMLGFBSE47QUFJZEMsZ0JBQU0sRUFBQy9MLEdBQUcsQ0FBQytMLE1BSkc7QUFLZGMsY0FBSSxFQUFHak0sR0FMTztBQU1kb0wsa0JBQVEsRUFBR2hNLEdBQUcsQ0FBQ2dNLFFBTkQ7QUFPZEMsa0JBQVEsRUFBR2pNLEdBQUcsQ0FBQ2lNLFFBUEQ7QUFRZEMsZ0JBQU0sRUFBR2xNLEdBQUcsQ0FBQ2tNLE1BUkM7QUFTZEMsZ0JBQU0sRUFBR25NLEdBQUcsQ0FBQ21NLE1BVEM7QUFVZFMsZ0JBQU0sRUFBRzVNLEdBQUcsQ0FBQzRNO0FBVkMsU0FBZjtBQVlBO0FBQ0QsS0FqQkQ7QUFrQkEsV0FBTzlOLFNBQVA7QUFDQSxHQXpEYTs7QUEyRGQ7QUFDQSxtQ0FDQ21CLElBREQsRUFFQzZMLGFBRkQsRUFHQ0MsTUFIRCxFQUlDQyxRQUpELEVBS0NDLFFBTEQsRUFNQ0MsTUFORCxFQU9DQyxNQVBELEVBUUNHLFNBUkQsRUFTQ0MsV0FURCxFQVVDNUIsVUFWRCxFQVlBO0FBQ0UsUUFBSSxDQUFDM0QsUUFBUSxDQUFDc0IsU0FBVCxDQUFtQixLQUFLQyxNQUF4QixFQUErQixPQUEvQixDQUFMLEVBQ0E7QUFDQyxZQUFNLElBQUl2SyxNQUFNLENBQUN3SyxLQUFYLENBQWlCLFdBQWpCLEVBQTZCLHdCQUE3QixDQUFOO0FBQ0EsS0FIRCxNQUtBO0FBRUMsVUFBSXBJLE9BQU8sR0FBRyxFQUFkO0FBQ0EsVUFBSTBNLE1BQU0sR0FBSyxDQUFmO0FBRUEsVUFBSUEsTUFBTSxHQUFHcEIsaUJBQWlCLENBQUNoTixJQUFsQixDQUF1QjtBQUFFMkosWUFBSSxFQUFFLENBQUU7QUFBRTBELGdCQUFNLEVBQUU7QUFBRUssZUFBRyxFQUFFTDtBQUFQO0FBQVYsU0FBRixFQUErQjtBQUFFUSxxQkFBVyxFQUFFO0FBQUVILGVBQUcsRUFBRUc7QUFBUDtBQUFmLFNBQS9CO0FBQVIsT0FBdkIsRUFBc0dDLEtBQXRHLEVBQWI7QUFDQU0sWUFBTSxHQUFHQSxNQUFNLEdBQUcsQ0FBbEI7O0FBRUEsY0FBT1AsV0FBUDtBQUVDLGFBQUssU0FBTDtBQUNDLGNBQUlPLE1BQU0sR0FBQyxFQUFYLEVBQ0E7QUFDQzFNLG1CQUFPLEdBQUdBLE9BQU8sQ0FBQ1UsTUFBUixDQUFlYixJQUFmLEVBQW9CLEtBQXBCLEVBQTBCNk0sTUFBMUIsQ0FBVjtBQUNBLFdBSEQsTUFHTyxJQUFJQSxNQUFNLEdBQUMsR0FBWCxFQUNQO0FBQ0MxTSxtQkFBTyxHQUFHQSxPQUFPLENBQUNVLE1BQVIsQ0FBZWIsSUFBZixFQUFvQixJQUFwQixFQUF5QjZNLE1BQXpCLENBQVY7QUFDQSxXQUhNLE1BSVA7QUFDQzFNLG1CQUFPLEdBQUdBLE9BQU8sQ0FBQ1UsTUFBUixDQUFlYixJQUFmLEVBQW9CLEdBQXBCLEVBQXdCNk0sTUFBeEIsQ0FBVjtBQUNBOztBQUNEOztBQUNELGFBQUssU0FBTDtBQUNDLGNBQUlBLE1BQU0sR0FBQyxFQUFYLEVBQ0E7QUFDQzFNLG1CQUFPLEdBQUdBLE9BQU8sQ0FBQ1UsTUFBUixDQUFlYixJQUFmLEVBQW9CLElBQXBCLEVBQXlCNk0sTUFBekIsQ0FBVjtBQUNBLFdBSEQsTUFJQTtBQUNDMU0sbUJBQU8sR0FBR0EsT0FBTyxDQUFDVSxNQUFSLENBQWViLElBQWYsRUFBb0IsR0FBcEIsRUFBd0I2TSxNQUF4QixDQUFWO0FBQ0E7O0FBQ0Q7O0FBQ0Q7QUFDQzFNLGlCQUFPLEdBQUdBLE9BQU8sQ0FBQ1UsTUFBUixDQUFlYixJQUFmLEVBQW9CLEdBQXBCLEVBQXdCNk0sTUFBeEIsQ0FBVjtBQUNBO0FBekJGOztBQTRCQSxVQUFJcEIsaUJBQWlCLENBQUM3QyxPQUFsQixDQUEwQjtBQUFFUixZQUFJLEVBQUUsQ0FBRTtBQUFFMEQsZ0JBQU0sRUFBRTtBQUFFSyxlQUFHLEVBQUVMO0FBQVA7QUFBVixTQUFGLEVBQStCO0FBQUUzTCxpQkFBTyxFQUFFO0FBQUVnTSxlQUFHLEVBQUVoTTtBQUFQO0FBQVgsU0FBL0I7QUFBUixPQUExQixLQUFtRyxJQUF2RyxFQUNBO0FBQ0MsY0FBTSxJQUFJcEMsTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixxREFBakIsQ0FBTjtBQUNBLE9BSEQsTUFLQTtBQUVDa0QseUJBQWlCLENBQUMvQyxNQUFsQixDQUF5QjtBQUN4QnZJLGlCQUR3QjtBQUV4QjBMLHVCQUZ3QjtBQUd4QkMsZ0JBSHdCO0FBSXhCQyxrQkFKd0I7QUFLeEJDLGtCQUx3QjtBQU14QkMsZ0JBTndCO0FBT3hCQyxnQkFQd0I7QUFReEJHLG1CQVJ3QjtBQVN4QkMscUJBVHdCO0FBVXhCNUI7QUFWd0IsU0FBekI7QUFZQTs7QUFDRCxhQUFPLENBQVA7QUFDQTtBQUNGLEdBeElhOztBQXlJZDtBQUNBLDZCQUNDdkssT0FERCxFQUVDMEwsYUFGRCxFQUdDQyxNQUhELEVBSUNDLFFBSkQsRUFLQ0MsUUFMRCxFQU1DQyxNQU5ELEVBT0NDLE1BUEQsRUFRQ1MsTUFSRCxFQVNDbkIsVUFURCxFQVVDYSxTQVZELEVBV0MzQixVQVhELEVBYUE7QUFDRSxRQUFJLENBQUMzRCxRQUFRLENBQUNzQixTQUFULENBQW1CLEtBQUtDLE1BQXhCLEVBQStCLE9BQS9CLENBQUwsRUFDQTtBQUNDLFlBQU0sSUFBSXZLLE1BQU0sQ0FBQ3dLLEtBQVgsQ0FBaUIsV0FBakIsRUFBNkIsd0JBQTdCLENBQU47QUFDQSxLQUhELE1BS0E7QUFDQyxVQUFJa0QsaUJBQWlCLENBQUM3QyxPQUFsQixDQUEwQjtBQUFFUixZQUFJLEVBQUUsQ0FBRTtBQUFFMEQsZ0JBQU0sRUFBRTtBQUFFSyxlQUFHLEVBQUVMO0FBQVA7QUFBVixTQUFGLEVBQStCO0FBQUUzTCxpQkFBTyxFQUFFO0FBQUVnTSxlQUFHLEVBQUVoTTtBQUFQO0FBQVgsU0FBL0I7QUFBUixPQUExQixLQUFtRyxJQUF2RyxFQUNBO0FBQ0MsY0FBTSxJQUFJcEMsTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixxREFBakIsQ0FBTjtBQUNBLE9BSEQsTUFLQTtBQUNDa0QseUJBQWlCLENBQUMvQyxNQUFsQixDQUF5QjtBQUN4QnZJLGlCQUR3QjtBQUV4QjBMLHVCQUZ3QjtBQUd4QkMsZ0JBSHdCO0FBSXhCQyxrQkFKd0I7QUFLeEJDLGtCQUx3QjtBQU14QkMsZ0JBTndCO0FBT3hCQyxnQkFQd0I7QUFReEJTLGdCQVJ3QjtBQVN4Qm5CLG9CQVR3QjtBQVV4QmEsbUJBVndCO0FBV3hCM0I7QUFYd0IsU0FBekI7QUFhQTs7QUFDRCxhQUFPLENBQVA7QUFDQTtBQUNGLEdBcExhOztBQXFMZDtBQUNBLDZCQUNDOUssR0FERCxFQUVDTyxPQUZELEVBR0MwTCxhQUhELEVBSUNDLE1BSkQsRUFLQ0MsUUFMRCxFQU1DQyxRQU5ELEVBT0NDLE1BUEQsRUFRQ0MsTUFSRCxFQVNDUyxNQVRELEVBVUNuQixVQVZELEVBV0NkLFVBWEQsRUFhQTtBQUNDLFFBQUksQ0FBQzNELFFBQVEsQ0FBQ3NCLFNBQVQsQ0FBbUIsS0FBS0MsTUFBeEIsRUFBK0IsT0FBL0IsQ0FBTCxFQUNBO0FBQ0MsWUFBTSxJQUFJdkssTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixXQUFqQixFQUE2Qix3QkFBN0IsQ0FBTjtBQUNBLEtBSEQsTUFLQTtBQUNFO0FBQ0E7QUFDQztBQUNEO0FBQ0E7QUFDQTtBQUNDLFVBQUlvRSxNQUFNLEdBQUc3SCxRQUFRLENBQUM2SCxNQUFELENBQXJCO0FBRUFsQix1QkFBaUIsQ0FBQzFDLE1BQWxCLENBQXlCbkosR0FBekIsRUFDQTtBQUFFcUMsWUFBSSxFQUFFO0FBQ045QixpQkFETTtBQUVOMEwsdUJBRk07QUFHTkMsZ0JBSE07QUFJTkMsa0JBSk07QUFLTkMsa0JBTE07QUFNTkMsZ0JBTk07QUFPTkMsZ0JBUE07QUFRTlMsZ0JBUk07QUFTTm5CLG9CQVRNO0FBVU5kO0FBVk07QUFBUixPQURBLEVBVEgsQ0F1QkU7QUFDRDtBQUNELEdBbE9hOztBQW1PZDtBQUNDLDZCQUEyQjdCLE1BQTNCLEVBQW1DO0FBQ25DLFFBQUksQ0FBQzlCLFFBQVEsQ0FBQ3NCLFNBQVQsQ0FBbUIsS0FBS0MsTUFBeEIsRUFBK0IsT0FBL0IsQ0FBTCxFQUNBO0FBQ0MsWUFBTSxJQUFJdkssTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixXQUFqQixFQUE2Qix3QkFBN0IsQ0FBTjtBQUNBLEtBSEQsTUFLQTtBQUNDa0QsdUJBQWlCLENBQUMzQyxNQUFsQixDQUF5QkQsTUFBekI7QUFDQTtBQUNBOztBQTdPWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDM0pBakwsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ3NNLGVBQWEsRUFBQyxNQUFJQTtBQUFuQixDQUFkO0FBQWlELElBQUlwTSxNQUFKO0FBQVdILE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLEtBQUo7QUFBVU4sTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRSxPQUFLLENBQUNELENBQUQsRUFBRztBQUFDQyxTQUFLLEdBQUNELENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSThJLFFBQUo7QUFBYW5KLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQ2dKLFNBQU8sQ0FBQy9JLENBQUQsRUFBRztBQUFDOEksWUFBUSxHQUFDOUksQ0FBVDtBQUFXOztBQUF2QixDQUF6QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJNk8sY0FBSjtBQUFtQmxQLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLHFCQUFaLEVBQWtDO0FBQUNnSixTQUFPLENBQUMvSSxDQUFELEVBQUc7QUFBQzZPLGtCQUFjLEdBQUM3TyxDQUFmO0FBQWlCOztBQUE3QixDQUFsQyxFQUFpRSxDQUFqRTtBQUszUCxNQUFNa00sYUFBYSxHQUFHLElBQUlqTSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsZUFBckIsQ0FBdEI7O0FBRVAsSUFBSUosTUFBTSxDQUFDSyxRQUFYLEVBQXFCO0FBQ3BCTCxRQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNmO0FBQ08scUNBQU47QUFBQSxzQ0FDQTtBQUNDLFlBQUlFLFNBQVMsR0FBRyxFQUFoQjtBQUNBLHNCQUFNc0wsYUFBYSxDQUFDckksYUFBZCxHQUE4QkMsU0FBOUIsQ0FBd0MsQ0FDM0M7QUFDRHFJLGlCQUFPLEVBQ0w7QUFDREMsZ0JBQUksRUFBRSxnQkFETDtBQUVEQyxzQkFBVSxFQUFFLE1BRlg7QUFHREMsd0JBQVksRUFBRSxLQUhiO0FBSURDLGNBQUUsRUFBRTtBQUpIO0FBRkQsU0FEMkMsRUFVM0M7QUFBRUMsaUJBQU8sRUFBRTtBQUFYLFNBVjJDLEVBVzNDO0FBQUVzQyxzQkFBWSxFQUFFO0FBQUVDLG1CQUFPLEVBQUU7QUFBRUMsMkJBQWEsRUFBRSxDQUM3QztBQUFFQyxvQkFBSSxFQUFFO0FBQVIsZUFENkMsRUFFN0M7QUFBRWhDLHNCQUFNLEVBQUU7QUFBVixlQUY2QyxFQUc3QztBQUFFaUMsd0JBQVEsRUFBRTtBQUFaLGVBSDZDLEVBSTdDO0FBQUVDLHlCQUFTLEVBQUU7QUFBYixlQUo2QyxFQUs3QyxXQUw2QztBQUFqQjtBQUFYO0FBQWhCLFNBWDJDLENBQXhDLEVBbUJIdE4sT0FuQkcsQ0FtQkssVUFBU0MsR0FBVCxFQUFjO0FBQ3hCbEIsbUJBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkTixlQUFHLEVBQUVHLEdBQUcsQ0FBQ21MLE1BREs7QUFFZE4saUJBQUssRUFBRTdLLEdBQUcsQ0FBQ0MsSUFGRztBQUdkNkssa0JBQU0sRUFBRTlLLEdBQUcsQ0FBQ0gsR0FIRTtBQUlkSSxnQkFBSSxFQUFFRCxHQUFHLENBQUNtTixJQUpJO0FBS2RDLG9CQUFRLEVBQUVwTixHQUFHLENBQUNvTixRQUxBO0FBTWRDLHFCQUFTLEVBQUVyTixHQUFHLENBQUNxTjtBQU5ELFdBQWY7QUFTQSxTQTdCSyxDQUFOO0FBK0JBLGVBQU92TyxTQUFQO0FBQ0EsT0FuQ0Q7QUFBQTs7QUFGYyxHQUFmO0FBdUNBLEMsQ0FDRDs7O0FBQ0FkLE1BQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBRWQ7QUFDQSxpQ0FDQTtBQUNDLFFBQUlFLFNBQVMsR0FBRyxFQUFoQjtBQUNBc0wsaUJBQWEsQ0FBQzFMLElBQWQsQ0FBbUIsRUFBbkIsRUFBdUI7QUFBQ2tCLFVBQUksRUFBRTtBQUFDSyxZQUFJLEVBQUU7QUFBUDtBQUFQLEtBQXZCLEVBQTBDRixPQUExQyxDQUFrRCxVQUFTQyxHQUFULEVBQWM7QUFDL0QsVUFBSTZLLEtBQUssR0FBRzdNLE1BQU0sQ0FBQ2tILElBQVAsQ0FBWSx3QkFBWixFQUFxQ2xGLEdBQUcsQ0FBQ2lCLElBQXpDLENBQVo7QUFDQW5DLGVBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkTixXQUFHLEVBQUVHLEdBQUcsQ0FBQ0gsR0FESztBQUVkZ0wsYUFBSyxFQUFFQSxLQUZPO0FBR2RDLGNBQU0sRUFBRTlLLEdBQUcsQ0FBQ2lCLElBSEU7QUFJZGhCLFlBQUksRUFBRUQsR0FBRyxDQUFDQyxJQUpJO0FBS2RtTixnQkFBUSxFQUFFcE4sR0FBRyxDQUFDb04sUUFMQTtBQU1kQyxpQkFBUyxFQUFFck4sR0FBRyxDQUFDcU47QUFORCxPQUFmO0FBU0EsS0FYRDtBQWFBLFdBQU92TyxTQUFQO0FBQ0EsR0FwQmE7O0FBcUJkLDBCQUF3QmlNLEtBQXhCLEVBQ0E7QUFDQyxXQUFPWCxhQUFhLENBQUN2QixPQUFkLENBQXNCO0FBQUVoSixTQUFHLEVBQUNrTDtBQUFOLEtBQXRCLENBQVA7QUFDQSxHQXhCYTs7QUF5QmQ7QUFDQSwwQkFBd0JBLEtBQXhCLEVBQ0E7QUFDQyxRQUFJdUMsT0FBTyxHQUFHbEQsYUFBYSxDQUFDdkIsT0FBZCxDQUFzQjtBQUFFaEosU0FBRyxFQUFDa0w7QUFBTixLQUF0QixDQUFkOztBQUNBLFFBQUl1QyxPQUFPLElBQUUsSUFBYixFQUFtQjtBQUNsQixhQUFPLElBQVA7QUFDQSxLQUZELE1BSUE7QUFDQyxhQUFPQSxPQUFPLENBQUNyTixJQUFmO0FBQ0E7QUFDRCxHQXBDYTs7QUFxQ2Q7QUFDQSwwQkFBd0I4SyxLQUF4QixFQUNBO0FBQ0MsUUFBSXRKLEdBQUcsR0FBRzJJLGFBQWEsQ0FBQ3ZCLE9BQWQsQ0FBc0I7QUFBRWhKLFNBQUcsRUFBQ2tMO0FBQU4sS0FBdEIsQ0FBVjs7QUFDQSxRQUFJdEosR0FBRyxJQUFFLElBQVQsRUFBZTtBQUNkLGFBQU8sSUFBUDtBQUNBLEtBRkQsTUFJQTtBQUNDLGFBQU9BLEdBQUcsQ0FBQ1IsSUFBWDtBQUNBO0FBQ0QsR0FoRGE7O0FBaURkO0FBQ0EseUJBQ0NBLElBREQsRUFFQ2hCLElBRkQsRUFHQ21OLFFBSEQsRUFJQ0MsU0FKRCxFQUtDNUIsVUFMRCxFQU1DZCxVQU5ELEVBUUE7QUFDQyxRQUFJLENBQUMzRCxRQUFRLENBQUNzQixTQUFULENBQW1CLEtBQUtDLE1BQXhCLEVBQStCLE9BQS9CLENBQUwsRUFDQTtBQUNDLFlBQU0sSUFBSXZLLE1BQU0sQ0FBQ3dLLEtBQVgsQ0FBaUIsV0FBakIsRUFBNkIsd0JBQTdCLENBQU47QUFDQSxLQUhELE1BS0E7QUFDQyxVQUFJNEIsYUFBYSxDQUFDdkIsT0FBZCxDQUFzQjtBQUFFUixZQUFJLEVBQUUsQ0FBRTtBQUFFcEgsY0FBSSxFQUFFO0FBQUVtTCxlQUFHLEVBQUVuTDtBQUFQO0FBQVIsU0FBRixFQUEyQjtBQUFFaEIsY0FBSSxFQUFFO0FBQUVtTSxlQUFHLEVBQUVuTTtBQUFQO0FBQVIsU0FBM0I7QUFBUixPQUF0QixLQUFxRixJQUF6RixFQUNBO0FBQ0MsY0FBTSxJQUFJakMsTUFBTSxDQUFDd0ssS0FBWCxDQUFpQiwwREFBakIsQ0FBTjtBQUNBLE9BSEQsTUFLQTtBQUNDNEIscUJBQWEsQ0FBQ3pCLE1BQWQsQ0FBcUI7QUFDcEIxSCxjQURvQjtBQUVwQmhCLGNBRm9CO0FBR3BCbU4sa0JBSG9CO0FBSXBCQyxtQkFKb0I7QUFLcEI1QixvQkFMb0I7QUFNcEJkO0FBTm9CLFNBQXJCO0FBUUE7QUFDRDtBQUNELEdBakZhOztBQWtGZDtBQUNBLHlCQUF1QjdCLE1BQXZCLEVBQStCO0FBQzlCLFFBQUksQ0FBQzlCLFFBQVEsQ0FBQ3NCLFNBQVQsQ0FBbUIsS0FBS0MsTUFBeEIsRUFBK0IsT0FBL0IsQ0FBTCxFQUNBO0FBQ0MsWUFBTSxJQUFJdkssTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixXQUFqQixFQUE2Qix3QkFBN0IsQ0FBTjtBQUNBLEtBSEQsTUFLQTtBQUNDNEIsbUJBQWEsQ0FBQ3JCLE1BQWQsQ0FBcUJELE1BQXJCO0FBQ0E7QUFDRCxHQTVGYTs7QUE2RmQ7QUFDQSx5QkFDQ2pKLEdBREQsRUFFQ3VOLFFBRkQsRUFHQ0MsU0FIRCxFQUlDNUIsVUFKRCxFQUtDZCxVQUxELEVBT0E7QUFDQyxRQUFJLENBQUMzRCxRQUFRLENBQUNzQixTQUFULENBQW1CLEtBQUtDLE1BQXhCLEVBQStCLE9BQS9CLENBQUwsRUFDQTtBQUNDLFlBQU0sSUFBSXZLLE1BQU0sQ0FBQ3dLLEtBQVgsQ0FBaUIsV0FBakIsRUFBNkIsd0JBQTdCLENBQU47QUFDQSxLQUhELE1BS0E7QUFDQzRCLG1CQUFhLENBQUNwQixNQUFkLENBQXFCbkosR0FBckIsRUFDQztBQUFFcUMsWUFBSSxFQUFFO0FBQ1BrTCxrQkFETztBQUVQQyxtQkFGTztBQUdQNUIsb0JBSE87QUFJUGQ7QUFKTztBQUFSLE9BREQ7QUFRQTtBQUNEOztBQXJIYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDaERBLE1BQU00QyxLQUFLLEdBQUc7QUFDWkMsT0FBSyxFQUFFLE9BREs7QUFFWkMsZUFBYSxFQUFFLGVBRkg7QUFHWkMsVUFBUSxFQUFFLFVBSEU7QUFJWkMsTUFBSSxFQUFFLE1BSk07QUFLWkMsUUFBTSxFQUFFO0FBTEksQ0FBZDtBQURBL1AsTUFBTSxDQUFDZ1EsYUFBUCxDQVNlTixLQVRmLEU7Ozs7Ozs7Ozs7O0FDQUExUCxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDZ1EsZ0JBQWMsRUFBQyxNQUFJQTtBQUFwQixDQUFkO0FBQW1ELElBQUk5UCxNQUFKO0FBQVdILE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLEtBQUo7QUFBVU4sTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRSxPQUFLLENBQUNELENBQUQsRUFBRztBQUFDQyxTQUFLLEdBQUNELENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSThJLFFBQUo7QUFBYW5KLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQ2dKLFNBQU8sQ0FBQy9JLENBQUQsRUFBRztBQUFDOEksWUFBUSxHQUFDOUksQ0FBVDtBQUFXOztBQUF2QixDQUF6QixFQUFrRCxDQUFsRDtBQUlyTCxNQUFNNFAsY0FBYyxHQUFHLElBQUkzUCxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsZ0JBQXJCLENBQXZCO0FBRVA7QUFDQUosTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDZDtBQUNBLGtDQUNBO0FBQ0MsUUFBSUUsU0FBUyxHQUFHLEVBQWhCO0FBQ0FnUCxrQkFBYyxDQUFDcFAsSUFBZixDQUFvQixFQUFwQixFQUF3QjtBQUFDa0IsVUFBSSxFQUFFO0FBQUNtTyxhQUFLLEVBQUU7QUFBUjtBQUFQLEtBQXhCLEVBQTRDaE8sT0FBNUMsQ0FBb0QsVUFBU0MsR0FBVCxFQUFjO0FBQ2pFbEIsZUFBUyxDQUFDcUIsSUFBVixDQUFlO0FBQ2ROLFdBQUcsRUFBRUcsR0FBRyxDQUFDSCxHQURLO0FBRWRtTyxZQUFJLEVBQUVoTyxHQUFHLENBQUNnTyxJQUZJO0FBR2QvTixZQUFJLEVBQUVELEdBQUcsQ0FBQ0MsSUFISTtBQUlkZ08saUJBQVMsRUFBRWpPLEdBQUcsQ0FBQ2lPLFNBSkQ7QUFLZEYsYUFBSyxFQUFFL04sR0FBRyxDQUFDK04sS0FMRztBQU1kRyxjQUFNLEVBQUVsTyxHQUFHLENBQUNrTztBQU5FLE9BQWY7QUFTQSxLQVZEO0FBWUEsV0FBT3BQLFNBQVA7QUFDQSxHQWxCYTs7QUFtQmQ7QUFDQSwwQkFDQ2tQLElBREQsRUFFQ0MsU0FGRCxFQUdDRixLQUhELEVBSUNHLE1BSkQsRUFNQTtBQUNDLFFBQUksQ0FBQ2xILFFBQVEsQ0FBQ3NCLFNBQVQsQ0FBbUIsS0FBS0MsTUFBeEIsRUFBK0IsT0FBL0IsQ0FBTCxFQUNBO0FBQ0MsWUFBTSxJQUFJdkssTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixXQUFqQixFQUE2Qix3QkFBN0IsQ0FBTjtBQUNBLEtBSEQsTUFLQTtBQUNDLFVBQUlzRixjQUFjLENBQUNqRixPQUFmLENBQXVCO0FBQUU1SSxZQUFJLEVBQUNBO0FBQVAsT0FBdkIsS0FBc0MsSUFBMUMsRUFDQTtBQUNDLGNBQU0sSUFBSWpDLE1BQU0sQ0FBQ3dLLEtBQVgsQ0FBaUIsaURBQWpCLENBQU47QUFDQSxPQUhELE1BS0E7QUFDQ3NGLHNCQUFjLENBQUNuRixNQUFmLENBQXNCO0FBQ3JCcUYsY0FEcUI7QUFFckJDLG1CQUZxQjtBQUdyQkYsZUFIcUI7QUFJckJHO0FBSnFCLFNBQXRCO0FBT0E7QUFDRDtBQUNELEdBaERhOztBQWlEZDtBQUNBLDBCQUF3QnBGLE1BQXhCLEVBQ0E7QUFDQyxRQUFJLENBQUM5QixRQUFRLENBQUNzQixTQUFULENBQW1CLEtBQUtDLE1BQXhCLEVBQStCLE9BQS9CLENBQUwsRUFDQTtBQUNDLFlBQU0sSUFBSXZLLE1BQU0sQ0FBQ3dLLEtBQVgsQ0FBaUIsV0FBakIsRUFBNkIsd0JBQTdCLENBQU47QUFDQSxLQUhELE1BS0E7QUFDQ3NGLG9CQUFjLENBQUMvRSxNQUFmLENBQXNCRCxNQUF0QjtBQUNBO0FBQ0QsR0E1RGE7O0FBNkRkO0FBQ0EsNkJBQ0NqSixHQURELEVBRUNxTyxNQUZELEVBSUE7QUFDQ2xHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHdCQUF3QmlHLE1BQXBDOztBQUNBLFFBQUksQ0FBQ2xILFFBQVEsQ0FBQ3NCLFNBQVQsQ0FBbUIsS0FBS0MsTUFBeEIsRUFBK0IsT0FBL0IsQ0FBTCxFQUNBO0FBQ0MsWUFBTSxJQUFJdkssTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixXQUFqQixFQUE2Qix3QkFBN0IsQ0FBTjtBQUNBLEtBSEQsTUFLQTtBQUNDc0Ysb0JBQWMsQ0FBQzlFLE1BQWYsQ0FBc0JuSixHQUF0QixFQUNDO0FBQUVxQyxZQUFJLEVBQUU7QUFDUGdNO0FBRE87QUFBUixPQUREO0FBS0E7QUFDRDs7QUFoRmEsQ0FBZixFOzs7Ozs7Ozs7OztBQ1BBclEsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQzhOLGtCQUFnQixFQUFDLE1BQUlBO0FBQXRCLENBQWQ7QUFBdUQsSUFBSTVOLE1BQUo7QUFBV0gsTUFBTSxDQUFDSSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsS0FBSjtBQUFVTixNQUFNLENBQUNJLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNFLE9BQUssQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFNBQUssR0FBQ0QsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJNk8sY0FBSjtBQUFtQmxQLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLHFCQUFaLEVBQWtDO0FBQUNnSixTQUFPLENBQUMvSSxDQUFELEVBQUc7QUFBQzZPLGtCQUFjLEdBQUM3TyxDQUFmO0FBQWlCOztBQUE3QixDQUFsQyxFQUFpRSxDQUFqRTtBQUFvRSxJQUFJOEksUUFBSjtBQUFhbkosTUFBTSxDQUFDSSxJQUFQLENBQVksWUFBWixFQUF5QjtBQUFDZ0osU0FBTyxDQUFDL0ksQ0FBRCxFQUFHO0FBQUM4SSxZQUFRLEdBQUM5SSxDQUFUO0FBQVc7O0FBQXZCLENBQXpCLEVBQWtELENBQWxEO0FBSWhSLE1BQU0wTixnQkFBZ0IsR0FBRyxJQUFJek4sS0FBSyxDQUFDQyxVQUFWLENBQXFCLGtCQUFyQixDQUF6Qjs7QUFJUCxJQUFJSixNQUFNLENBQUNLLFFBQVgsRUFBcUI7QUFFcEI7QUFDQUwsUUFBTSxDQUFDTSxPQUFQLENBQWUsa0JBQWYsRUFBbUMsU0FBUzZQLGdCQUFULENBQTBCM1AsYUFBMUIsRUFBd0NDLGdCQUF4QyxFQUEwRDtBQUM1RixXQUFPbU4sZ0JBQWdCLENBQUNsTixJQUFqQixDQUFzQkYsYUFBdEIsRUFBb0NDLGdCQUFwQyxDQUFQO0FBQ0EsR0FGRDtBQUlBVCxRQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNkO0FBQ00sa0NBQU4sQ0FBcUNxQyxJQUFyQyxFQUEyQ2hCLElBQTNDLEVBQWdEMEssVUFBaEQ7QUFBQSxzQ0FDQTtBQUNDLFlBQUksQ0FBQzNELFFBQVEsQ0FBQ3NCLFNBQVQsQ0FBbUIsS0FBS0MsTUFBeEIsRUFBK0IsT0FBL0IsQ0FBTCxFQUNBO0FBQ0MsZ0JBQU0sSUFBSXZLLE1BQU0sQ0FBQ3dLLEtBQVgsQ0FBaUIsV0FBakIsRUFBNkIsd0JBQTdCLENBQU47QUFDQSxTQUhELE1BS0E7QUFDQyxjQUFJLGNBQU1vRCxnQkFBZ0IsQ0FBQy9DLE9BQWpCLENBQXlCO0FBQUVSLGdCQUFJLEVBQUUsQ0FBRTtBQUFFcEgsa0JBQUksRUFBRTtBQUFFbUwsbUJBQUcsRUFBRW5MO0FBQVA7QUFBUixhQUFGLEVBQTJCO0FBQUVoQixrQkFBSSxFQUFFO0FBQUVtTSxtQkFBRyxFQUFFbk07QUFBUDtBQUFSLGFBQTNCO0FBQVIsV0FBekIsQ0FBTixLQUE4RixJQUFsRyxFQUNBO0FBQ0Msa0JBQU0sSUFBSWpDLE1BQU0sQ0FBQ3dLLEtBQVgsQ0FBaUIscURBQWpCLENBQU47QUFDQSxXQUhELE1BS0E7QUFDQywwQkFBTW9ELGdCQUFnQixDQUFDakQsTUFBakIsQ0FBd0I7QUFDN0IxSCxrQkFENkI7QUFFN0JoQixrQkFGNkI7QUFHN0IwSztBQUg2QixhQUF4QixDQUFOO0FBS0E7O0FBQ0QsaUJBQU8sQ0FBUDtBQUNBO0FBQ0QsT0F0QkQ7QUFBQTs7QUFGYyxHQUFmO0FBMEJBOztBQUVEM00sTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQztBQUNBO0FBQ0M7QUFDRDtBQUNBO0FBQ0E7QUFDQztBQUNDO0FBQ0E7QUFDQTtBQUNEO0FBQ0Q7QUFDRDtBQUNBLDRCQUEwQnFDLElBQTFCLEVBQWdDaEIsSUFBaEMsRUFBcUMwSyxVQUFyQyxFQUNBO0FBQ0UsUUFBSSxDQUFDM0QsUUFBUSxDQUFDc0IsU0FBVCxDQUFtQixLQUFLQyxNQUF4QixFQUErQixPQUEvQixDQUFMLEVBQ0E7QUFDQyxZQUFNLElBQUl2SyxNQUFNLENBQUN3SyxLQUFYLENBQWlCLFdBQWpCLEVBQTZCLHdCQUE3QixDQUFOO0FBQ0EsS0FIRCxNQUtBO0FBQ0MsVUFBSW9ELGdCQUFnQixDQUFDL0MsT0FBakIsQ0FBeUI7QUFBRVIsWUFBSSxFQUFFLENBQUU7QUFBRXBILGNBQUksRUFBRTtBQUFFbUwsZUFBRyxFQUFFbkw7QUFBUDtBQUFSLFNBQUYsRUFBMkI7QUFBRWhCLGNBQUksRUFBRTtBQUFFbU0sZUFBRyxFQUFFbk07QUFBUDtBQUFSLFNBQTNCO0FBQVIsT0FBekIsS0FBd0YsSUFBNUYsRUFDQTtBQUNDLGNBQU0sSUFBSWpDLE1BQU0sQ0FBQ3dLLEtBQVgsQ0FBaUIscURBQWpCLENBQU47QUFDQSxPQUhELE1BS0E7QUFDQ29ELHdCQUFnQixDQUFDakQsTUFBakIsQ0FBd0I7QUFDdkIxSCxjQUR1QjtBQUV2QmhCLGNBRnVCO0FBR3ZCMEs7QUFIdUIsU0FBeEI7QUFLQTs7QUFDRCxhQUFPLENBQVA7QUFDQTtBQUNGLEdBMUNhOztBQTJDZDtBQUNBLDRCQUNDOUssR0FERCxFQUVDSSxJQUZELEVBR0N3TCxVQUhELEVBSUNkLFVBSkQsRUFNQTtBQUNDLFFBQUksQ0FBQzNELFFBQVEsQ0FBQ3NCLFNBQVQsQ0FBbUIsS0FBS0MsTUFBeEIsRUFBK0IsT0FBL0IsQ0FBTCxFQUNBO0FBQ0MsWUFBTSxJQUFJdkssTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixXQUFqQixFQUE2Qix3QkFBN0IsQ0FBTjtBQUNBLEtBSEQsTUFLQTtBQUNDb0Qsc0JBQWdCLENBQUM1QyxNQUFqQixDQUF3Qm5KLEdBQXhCLEVBQ0M7QUFBRXFDLFlBQUksRUFBRTtBQUNQakMsY0FETztBQUVQd0wsb0JBRk87QUFHUGQ7QUFITztBQUFSLE9BREQ7QUFPQTtBQUNELEdBakVhOztBQWtFZDtBQUNBLDRCQUEwQjdCLE1BQTFCLEVBQWtDO0FBQ2pDLFFBQUksQ0FBQzlCLFFBQVEsQ0FBQ3NCLFNBQVQsQ0FBbUIsS0FBS0MsTUFBeEIsRUFBK0IsT0FBL0IsQ0FBTCxFQUNBO0FBQ0MsWUFBTSxJQUFJdkssTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixXQUFqQixFQUE2Qix3QkFBN0IsQ0FBTjtBQUNBLEtBSEQsTUFLQTtBQUNDb0Qsc0JBQWdCLENBQUM3QyxNQUFqQixDQUF3QkQsTUFBeEI7QUFDQTtBQUNELEdBNUVhOztBQTZFZDtBQUNBLDJCQUNBO0FBQ0MsUUFBSWhLLFNBQVMsR0FBRyxFQUFoQjtBQUNBOE0sb0JBQWdCLENBQUNsTixJQUFqQixDQUFzQixFQUF0QixFQUF5QjtBQUFDa0IsVUFBSSxFQUFDO0FBQUVxQixZQUFJLEVBQUcsQ0FBQztBQUFWO0FBQU4sS0FBekIsRUFBK0NsQixPQUEvQyxDQUF1RCxVQUFTQyxHQUFULEVBQWM7QUFDcEUsVUFBSTZLLEtBQUssR0FBRzdNLE1BQU0sQ0FBQ2tILElBQVAsQ0FBWSx3QkFBWixFQUFxQ2xGLEdBQUcsQ0FBQ2lCLElBQXpDLENBQVo7QUFDQSxVQUFJbU4sS0FBSyxHQUFHdkQsS0FBSyxDQUFDL0osTUFBTixDQUFhLEdBQWIsRUFBaUJkLEdBQUcsQ0FBQ0MsSUFBckIsQ0FBWjtBQUNBbkIsZUFBUyxDQUFDcUIsSUFBVixDQUFlO0FBQ2ROLFdBQUcsRUFBRUcsR0FBRyxDQUFDSCxHQURLO0FBRWRnTCxhQUFLLEVBQUVBLEtBRk87QUFHZEMsY0FBTSxFQUFFOUssR0FBRyxDQUFDaUIsSUFIRTtBQUlkbU4sYUFBSyxFQUFFQSxLQUpPO0FBS2RuTyxZQUFJLEVBQUdELEdBQUcsQ0FBQ0MsSUFMRztBQU1kMEssa0JBQVUsRUFBRTNLLEdBQUcsQ0FBQzJLO0FBTkYsT0FBZjtBQVFBLEtBWEQ7QUFZQSxXQUFPN0wsU0FBUDtBQUNBLEdBOUZhOztBQStGZDtBQUNBLCtCQUE2QjZOLFNBQTdCLEVBQ0E7QUFDQyxXQUFPZixnQkFBZ0IsQ0FBQy9DLE9BQWpCLENBQXlCO0FBQUNoSixTQUFHLEVBQUM4TTtBQUFMLEtBQXpCLENBQVA7QUFDQSxHQW5HYTs7QUFvR2Q7QUFDQSw2QkFBMkJBLFNBQTNCLEVBQ0E7QUFDQyxRQUFJMEIsVUFBVSxHQUFHekMsZ0JBQWdCLENBQUMvQyxPQUFqQixDQUF5QjtBQUFDaEosU0FBRyxFQUFDOE07QUFBTCxLQUF6QixDQUFqQjs7QUFDQSxRQUFJMEIsVUFBVSxJQUFFLElBQWhCLEVBQXNCO0FBQ3JCLGFBQU8sSUFBUDtBQUNBLEtBRkQsTUFJQTtBQUNDLGFBQU9BLFVBQVUsQ0FBQ3BPLElBQWxCO0FBQ0E7QUFDRCxHQS9HYTs7QUFnSGQ7QUFDQSwyQkFBeUI4TCxNQUF6QixFQUNBO0FBQ0MsUUFBSVksU0FBUyxHQUFHZixnQkFBZ0IsQ0FBQy9DLE9BQWpCLENBQXlCO0FBQUM1SSxVQUFJLEVBQUM4TDtBQUFOLEtBQXpCLENBQWhCOztBQUNBLFFBQUlZLFNBQVMsSUFBRSxJQUFmLEVBQXFCO0FBQ3BCLGFBQU8sSUFBUDtBQUNBLEtBRkQsTUFJQTtBQUNDLGFBQU9BLFNBQVMsQ0FBQzlNLEdBQWpCO0FBQ0E7QUFDRDs7QUEzSGEsQ0FBZixFOzs7Ozs7Ozs7OztBQzNDQWhDLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUN3USxVQUFRLEVBQUMsTUFBSUE7QUFBZCxDQUFkO0FBQXVDLElBQUl0USxNQUFKO0FBQVdILE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLEtBQUo7QUFBVU4sTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRSxPQUFLLENBQUNELENBQUQsRUFBRztBQUFDQyxTQUFLLEdBQUNELENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFHMUcsTUFBTW9RLFFBQVEsR0FBRyxJQUFJblEsS0FBSyxDQUFDQyxVQUFWLENBQXFCLFVBQXJCLENBQWpCOztBQUNQLElBQUlKLE1BQU0sQ0FBQ0ssUUFBWCxFQUFxQjtBQUNwQkwsUUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDZDtBQUNNLDJCQUFOLENBQThCc0MsY0FBOUIsRUFBNkNDLFlBQTdDO0FBQUEsc0NBQ0E7QUFDQyxjQUFNVyxNQUFNLGlCQUFTd00sUUFBUSxDQUFDdk0sYUFBVCxHQUF5QkMsU0FBekIsQ0FBbUMsQ0FDdkQ7QUFBQ0MsZ0JBQU0sRUFBRTtBQUFFb0csZ0JBQUksRUFBRSxDQUFFO0FBQUUvSCx1QkFBUyxFQUFFO0FBQUVlLG9CQUFJLEVBQUVILGNBQVI7QUFBd0JJLG9CQUFJLEVBQUNIO0FBQTdCO0FBQWIsYUFBRjtBQUFSO0FBQVQsU0FEdUQsRUFFdkQ7QUFBQ21DLGVBQUssRUFBRztBQUFFaEQscUJBQVMsRUFBRyxDQUFDO0FBQWY7QUFBVCxTQUZ1RCxFQUd2RDtBQUNDdUMsa0JBQVEsRUFBRTtBQUNULG1CQUFPLE1BREU7QUFFVCxtQkFBTyxNQUZFO0FBR1QseUJBQWE7QUFBRVQsMkJBQWEsRUFBRTtBQUFFQyxzQkFBTSxFQUFFLGdCQUFWO0FBQTRCQyxvQkFBSSxFQUFFO0FBQUNDLHNCQUFJLEVBQUcsQ0FBQyxJQUFJaEMsSUFBSixDQUFTLENBQVQsQ0FBRCxFQUFjLFlBQWQ7QUFBUixpQkFBbEM7QUFBeUVpQyx3QkFBUSxFQUFFO0FBQW5GO0FBQWpCLGFBSEo7QUFJVCxtQkFBTyxNQUpFO0FBS1QsbUJBQU07QUFMRztBQURYLFNBSHVELENBQW5DLENBQVQsQ0FBWjtBQWFBLGVBQU9WLE1BQU0sQ0FBQ3FILE9BQVAsRUFBUDtBQUNBLE9BaEJEO0FBQUE7O0FBRmMsR0FBZjtBQXFCQyxDOzs7Ozs7Ozs7OztBQzFCRnRMLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNtSixTQUFPLEVBQUMsTUFBSUQ7QUFBYixDQUFkO0FBQXNDLElBQUl1SCxLQUFKO0FBQVUxUSxNQUFNLENBQUNJLElBQVAsQ0FBWSx1QkFBWixFQUFvQztBQUFDc1EsT0FBSyxDQUFDclEsQ0FBRCxFQUFHO0FBQUNxUSxTQUFLLEdBQUNyUSxDQUFOO0FBQVE7O0FBQWxCLENBQXBDLEVBQXdELENBQXhEOztBQUVqQyxNQUFNOEksUUFBTixDQUFlO0FBQzFCLFNBQU9zQixTQUFQLENBQWlCQyxNQUFqQixFQUF5QmlHLElBQXpCLEVBQStCO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQztBQUNBO0FBQ0Q7QUFDQTtBQUNDO0FBQ0E7QUFDRDtBQUVBLFdBQU8sQ0FBUDtBQUVHOztBQUVELFNBQU9DLE9BQVAsQ0FBZWxHLE1BQWYsRUFBdUJpRyxJQUF2QixFQUE2QjtBQUN6QixXQUFPRCxLQUFLLENBQUNHLFlBQU4sQ0FBbUIxUSxNQUFNLENBQUN1SyxNQUFQLEVBQW5CLEVBQW9DaUcsSUFBcEMsQ0FBUDtBQUNIOztBQUVELFNBQU9HLGFBQVAsQ0FBcUJwRyxNQUFyQixFQUE2QjtBQUN6QixRQUFJLENBQUNBLE1BQUwsRUFBYTtBQUNULFlBQU0sSUFBSXZLLE1BQU0sQ0FBQ3dLLEtBQVgsQ0FBaUIsZ0JBQWpCLEVBQW1DLHdCQUFuQyxDQUFOO0FBQ0g7O0FBQUE7QUFDSixHQTNCeUIsQ0E2QjFCO0FBQ0E7QUFDQTs7O0FBL0IwQjs7QUFrQzlCLElBQUl4SyxNQUFNLENBQUNLLFFBQVgsRUFBcUI7QUFDcEJMLFFBQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBRVAsb0JBQU47QUFBQSxzQ0FBeUI7QUFDMUIsWUFBSWdRLFlBQVksR0FBRzVRLE1BQU0sQ0FBQzZRLElBQVAsRUFBbkI7O0FBQ0EsWUFBR0QsWUFBSCxFQUNBO0FBQ0MsaUJBQU9BLFlBQVA7QUFDQSxTQUhELE1BS0E7QUFDQyxpQkFBTyxFQUFQO0FBQ0E7QUFDQyxPQVZEO0FBQUEsS0FGYTs7QUFjZjtBQUNRLGlCQUFOO0FBQUEsc0NBQXNCO0FBQ3RCLFlBQUlBLFlBQVksR0FBRzVRLE1BQU0sQ0FBQzZRLElBQVAsRUFBbkI7QUFDQTdHLGVBQU8sQ0FBQ0MsR0FBUixDQUFZLGdCQUFaLEVBQTZCMkcsWUFBN0I7O0FBRUEsWUFBSUwsS0FBSyxDQUFDRyxZQUFOLENBQW1CRSxZQUFuQixFQUFpQyxDQUFDLE9BQUQsRUFBVSxlQUFWLENBQWpDLENBQUosRUFBa0U7QUFDakUsaUJBQU8sSUFBUDtBQUNBOztBQUVELGNBQU0sSUFBSTVRLE1BQU0sQ0FBQ3dLLEtBQVgsQ0FBaUIsY0FBakIsRUFBaUMsb0NBQWpDLENBQU47QUFDQVIsZUFBTyxDQUFDQyxHQUFSLENBQVksVUFBWjtBQUVDLE9BWEQ7QUFBQTs7QUFmYSxHQUFmO0FBNkJBLEM7Ozs7Ozs7Ozs7O0FDbEVEcEssTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ2dSLHFCQUFtQixFQUFDLE1BQUlBO0FBQXpCLENBQWQ7QUFBNkQsSUFBSTlRLE1BQUo7QUFBV0gsTUFBTSxDQUFDSSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsS0FBSjtBQUFVTixNQUFNLENBQUNJLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNFLE9BQUssQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFNBQUssR0FBQ0QsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJOEksUUFBSjtBQUFhbkosTUFBTSxDQUFDSSxJQUFQLENBQVksWUFBWixFQUF5QjtBQUFDZ0osU0FBTyxDQUFDL0ksQ0FBRCxFQUFHO0FBQUM4SSxZQUFRLEdBQUM5SSxDQUFUO0FBQVc7O0FBQXZCLENBQXpCLEVBQWtELENBQWxEO0FBSS9MLE1BQU00USxtQkFBbUIsR0FBRyxJQUFJM1EsS0FBSyxDQUFDQyxVQUFWLENBQXFCLHFCQUFyQixDQUE1Qjs7QUFFUCxJQUFJSixNQUFNLENBQUNLLFFBQVgsRUFBcUI7QUFDcEJMLFFBQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBQ2Q7QUFDTSx5Q0FBTjtBQUFBLHNDQUE4QztBQUM3QyxZQUFJRSxTQUFTLEdBQUcsRUFBaEI7QUFDQSxZQUFJRSxLQUFLLEdBQUcsQ0FBWjtBQUNBLHNCQUFNOFAsbUJBQW1CLENBQUMvTSxhQUFwQixHQUFvQ0MsU0FBcEMsQ0FBOEMsQ0FDbkQ7QUFDQ2tCLGdCQUFNLEVBQUU7QUFDUCxtQkFBTztBQUNOLHNCQUFRLE9BREY7QUFFTixzQkFBUTtBQUZGO0FBREE7QUFEVCxTQURtRCxFQVNuRDtBQUNDbUgsaUJBQU8sRUFDUDtBQUNDQyxnQkFBSSxFQUFFLGdCQURQO0FBRUNDLHNCQUFVLEVBQUUsVUFGYjtBQUdDQyx3QkFBWSxFQUFFLEtBSGY7QUFJQ0MsY0FBRSxFQUFFO0FBSkw7QUFGRCxTQVRtRCxFQWtCbkQ7QUFBQ0MsaUJBQU8sRUFBRTtBQUFWLFNBbEJtRCxFQW1CbkQ7QUFBQzdILGtCQUFRLEVBQ1I7QUFDQ2hELGVBQUcsRUFBRyxlQURQO0FBRUNnTCxpQkFBSyxFQUFFLGdCQUZSO0FBR0MzTCxnQkFBSSxFQUFFO0FBSFA7QUFERCxTQW5CbUQsQ0FBOUMsRUEwQkhhLE9BMUJHLENBMEJLLFVBQVNDLEdBQVQsRUFBYztBQUN4QmxCLG1CQUFTLENBQUNxQixJQUFWLENBQWU7QUFDZE4sZUFBRyxFQUFFYixLQURTO0FBRWRpQyxnQkFBSSxFQUFFakIsR0FBRyxDQUFDSCxHQUZJO0FBR2RnTCxpQkFBSyxFQUFFN0ssR0FBRyxDQUFDNkssS0FIRztBQUlkM0wsZ0JBQUksRUFBRWMsR0FBRyxDQUFDZDtBQUpJLFdBQWY7QUFNQUYsZUFBSyxHQUFHQSxLQUFLLEdBQUksQ0FBakI7QUFDQSxTQWxDSyxDQUFOO0FBbUNBLGVBQU9GLFNBQVA7QUFDQSxPQXZDRDtBQUFBOztBQUZjLEdBQWY7QUEyQ0EsQyxDQUNBOzs7QUFDRGQsTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDZDtBQUNBLHFDQUFtQ3FDLElBQW5DLEVBQXdDL0IsSUFBeEMsRUFDQTtBQUNDLFFBQUlKLFNBQVMsR0FBRyxFQUFoQjtBQUNBLFFBQUlpUSxHQUFHLEdBQUssS0FBWjtBQUNBLFFBQUlDLFNBQVMsR0FBSSxLQUFqQjtBQUNBRix1QkFBbUIsQ0FBQ3BRLElBQXBCLENBQXlCO0FBQUMsY0FBT3VDLElBQVI7QUFBYSxjQUFPL0I7QUFBcEIsS0FBekIsRUFBb0Q7QUFBQ1UsVUFBSSxFQUFFO0FBQUNxUCxlQUFPLEVBQUU7QUFBVjtBQUFQLEtBQXBELEVBQTBFbFAsT0FBMUUsQ0FBa0YsVUFBU0MsR0FBVCxFQUFjO0FBQy9GK08sU0FBRyxHQUFHLEtBQU47O0FBQ0EsY0FBTy9PLEdBQUcsQ0FBQ2tQLFdBQVg7QUFFQyxhQUFLLEdBQUw7QUFDQ0gsYUFBRyxHQUFHLGlCQUFOO0FBQ0E7O0FBQ0QsYUFBSyxHQUFMO0FBQ0NBLGFBQUcsR0FBRyxjQUFOO0FBQ0E7O0FBQ0QsYUFBSyxHQUFMO0FBQ0NBLGFBQUcsR0FBRyxlQUFOO0FBQ0E7O0FBQ0Q7QUFBUztBQVhWOztBQWNBLFVBQUlsRSxLQUFLLEdBQUc3TSxNQUFNLENBQUNrSCxJQUFQLENBQVksd0JBQVosRUFBcUNsRixHQUFHLENBQUNpQixJQUF6QyxDQUFaO0FBQ0FuQyxlQUFTLENBQUNxQixJQUFWLENBQWU7QUFDZE4sV0FBRyxFQUFLRyxHQUFHLENBQUNILEdBREU7QUFFZG9CLFlBQUksRUFBSWpCLEdBQUcsQ0FBQ2lCLElBRkU7QUFHZDRKLGFBQUssRUFBSUEsS0FISztBQUlkM0wsWUFBSSxFQUFJYyxHQUFHLENBQUNkLElBSkU7QUFLZGdRLG1CQUFXLEVBQUdsUCxHQUFHLENBQUNrUCxXQUxKO0FBTWRELGVBQU8sRUFBSWpQLEdBQUcsQ0FBQ2lQLE9BTkQ7QUFPZEUsZUFBTyxFQUFJblAsR0FBRyxDQUFDbVA7QUFQRCxPQUFmO0FBU0EsS0ExQkQ7QUEyQkEsV0FBT3JRLFNBQVA7QUFDQSxHQW5DYTs7QUFzQ2Q7QUFDQSwrQkFDQ21DLElBREQsRUFFQy9CLElBRkQsRUFHQ2dRLFdBSEQsRUFJQ0QsT0FKRCxFQUtDRSxPQUxELEVBTUN4RSxVQU5ELEVBT0E7QUFDQyxRQUFJLENBQUMzRCxRQUFRLENBQUNzQixTQUFULENBQW1CLEtBQUtDLE1BQXhCLEVBQStCLE9BQS9CLENBQUwsRUFDQTtBQUNDLFlBQU0sSUFBSXZLLE1BQU0sQ0FBQ3dLLEtBQVgsQ0FBaUIsV0FBakIsRUFBNkIsd0JBQTdCLENBQU47QUFDQSxLQUhELE1BS0E7QUFDQ3NHLHlCQUFtQixDQUFDbkcsTUFBcEIsQ0FBMkI7QUFDMUIxSCxZQUQwQjtBQUUxQi9CLFlBRjBCO0FBRzFCZ1EsbUJBSDBCO0FBSTFCRCxlQUowQjtBQUsxQkUsZUFMMEI7QUFNMUJ4RTtBQU4wQixPQUEzQjtBQVFBOztBQUNELFdBQU8sQ0FBUDtBQUNBLEdBL0RhOztBQWdFZDtBQUNBLCtCQUE2QjdCLE1BQTdCLEVBQXFDO0FBQ3BDLFFBQUksQ0FBQzlCLFFBQVEsQ0FBQ3NCLFNBQVQsQ0FBbUIsS0FBS0MsTUFBeEIsRUFBK0IsT0FBL0IsQ0FBTCxFQUNBO0FBQ0MsWUFBTSxJQUFJdkssTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixXQUFqQixFQUE2Qix3QkFBN0IsQ0FBTjtBQUNBLEtBSEQsTUFLQTtBQUNDc0cseUJBQW1CLENBQUMvRixNQUFwQixDQUEyQkQsTUFBM0I7QUFDQTtBQUNELEdBMUVhOztBQTJFZDtBQUNBLCtCQUNDakosR0FERCxFQUVDb0IsSUFGRCxFQUdDL0IsSUFIRCxFQUlDZ1EsV0FKRCxFQUtDRCxPQUxELEVBTUNFLE9BTkQsRUFPQ3hFLFVBUEQsRUFRQTtBQUNDLFFBQUksQ0FBQzNELFFBQVEsQ0FBQ3NCLFNBQVQsQ0FBbUIsS0FBS0MsTUFBeEIsRUFBK0IsT0FBL0IsQ0FBTCxFQUNBO0FBQ0MsWUFBTSxJQUFJdkssTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixXQUFqQixFQUE2Qix3QkFBN0IsQ0FBTjtBQUNBLEtBSEQsTUFLQTtBQUNDc0cseUJBQW1CLENBQUM5RixNQUFwQixDQUEyQm5KLEdBQTNCLEVBQ0M7QUFBRXFDLFlBQUksRUFBRTtBQUNQakIsY0FETztBQUVQL0IsY0FGTztBQUdQZ1EscUJBSE87QUFJUEQsaUJBSk87QUFLUEUsaUJBTE87QUFNUHhFO0FBTk87QUFBUixPQUREO0FBVUE7QUFDRDs7QUF0R2EsQ0FBZixFOzs7Ozs7Ozs7OztBQ3BEQTlNLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNpUCxnQkFBYyxFQUFDLE1BQUlBO0FBQXBCLENBQWQ7QUFBbUQsSUFBSS9PLE1BQUo7QUFBV0gsTUFBTSxDQUFDSSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsS0FBSjtBQUFVTixNQUFNLENBQUNJLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNFLE9BQUssQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFNBQUssR0FBQ0QsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJOEksUUFBSjtBQUFhbkosTUFBTSxDQUFDSSxJQUFQLENBQVksWUFBWixFQUF5QjtBQUFDZ0osU0FBTyxDQUFDL0ksQ0FBRCxFQUFHO0FBQUM4SSxZQUFRLEdBQUM5SSxDQUFUO0FBQVc7O0FBQXZCLENBQXpCLEVBQWtELENBQWxEO0FBSXJMLE1BQU02TyxjQUFjLEdBQUcsSUFBSTVPLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixnQkFBckIsQ0FBdkI7O0FBRVAsSUFBSUosTUFBTSxDQUFDSyxRQUFYLEVBQXFCO0FBQ3BCO0FBQ0FMLFFBQU0sQ0FBQ00sT0FBUCxDQUFlLGdCQUFmLEVBQWlDLFNBQVM4USxjQUFULENBQXdCNVEsYUFBeEIsRUFBdUM7QUFDdkV3SixXQUFPLENBQUNDLEdBQVIsQ0FBWSwwQ0FBMEN6SixhQUF0RDtBQUNBLFdBQU91TyxjQUFjLENBQUNyTyxJQUFmLENBQW9CRixhQUFwQixDQUFQO0FBQ0EsR0FIRDtBQUlBLEMsQ0FDRDs7O0FBQ0FSLE1BQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBQ2Q7QUFDQSxrQ0FDQTtBQUNDLFFBQUlFLFNBQVMsR0FBRyxFQUFoQjtBQUNBaU8sa0JBQWMsQ0FBQ3JPLElBQWYsQ0FBb0IsRUFBcEIsRUFBd0I7QUFBQ2tCLFVBQUksRUFBRTtBQUFDMkYsWUFBSSxFQUFFO0FBQVA7QUFBUCxLQUF4QixFQUEyQ3hGLE9BQTNDLENBQW1ELFVBQVNDLEdBQVQsRUFBYztBQUNoRWxCLGVBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkTixXQUFHLEVBQUVHLEdBQUcsQ0FBQ0gsR0FESztBQUVkSSxZQUFJLEVBQUVELEdBQUcsQ0FBQ0MsSUFGSTtBQUdkc0YsWUFBSSxFQUFFdkYsR0FBRyxDQUFDdUYsSUFISTtBQUlka0csa0JBQVUsRUFBRXpMLEdBQUcsQ0FBQ3lMO0FBSkYsT0FBZjtBQU9BLEtBUkQ7QUFVQSxXQUFPM00sU0FBUDtBQUNBLEdBaEJhOztBQWlCZDtBQUNBLHVDQUNBO0FBQ0MsUUFBSUEsU0FBUyxHQUFHLEVBQWhCO0FBQ0FpTyxrQkFBYyxDQUFDck8sSUFBZixDQUFvQixFQUFwQixFQUF3QjtBQUFDa0IsVUFBSSxFQUFFO0FBQUMyRixZQUFJLEVBQUU7QUFBUDtBQUFQLEtBQXhCLEVBQTJDeEYsT0FBM0MsQ0FBbUQsVUFBU0MsR0FBVCxFQUFjO0FBQ2hFLFVBQUlBLEdBQUcsQ0FBQ0MsSUFBSixJQUFVLFFBQWQsRUFBd0I7QUFDdkJuQixpQkFBUyxDQUFDcUIsSUFBVixDQUFlO0FBQ2ROLGFBQUcsRUFBRUcsR0FBRyxDQUFDSCxHQURLO0FBRWRJLGNBQUksRUFBRUQsR0FBRyxDQUFDQyxJQUZJO0FBR2RzRixjQUFJLEVBQUV2RixHQUFHLENBQUN1RixJQUhJO0FBSWRrRyxvQkFBVSxFQUFFekwsR0FBRyxDQUFDeUw7QUFKRixTQUFmO0FBTUE7QUFDRCxLQVREO0FBV0EsV0FBTzNNLFNBQVA7QUFDQSxHQWpDYTs7QUFrQ2Q7QUFDQSw0QkFBMEJtQixJQUExQixFQUNBO0FBQ0MsUUFBSTJJLFFBQVEsR0FBR21FLGNBQWMsQ0FBQ2xFLE9BQWYsQ0FBdUI7QUFBRTVJLFVBQUksRUFBQ0E7QUFBUCxLQUF2QixDQUFmOztBQUNBLFFBQUkySSxRQUFRLElBQUUsSUFBZCxFQUFvQjtBQUNuQixhQUFPLENBQVA7QUFDQSxLQUZELE1BSUE7QUFDQyxhQUFPLENBQVA7QUFDQTtBQUNELEdBN0NhOztBQThDZDtBQUNBLDJCQUF5QmtDLE1BQXpCLEVBQ0E7QUFDQyxRQUFJbEMsUUFBUSxHQUFHbUUsY0FBYyxDQUFDbEUsT0FBZixDQUF1QjtBQUFFaEosU0FBRyxFQUFDaUw7QUFBTixLQUF2QixDQUFmOztBQUNBLFFBQUlsQyxRQUFRLElBQUUsSUFBZCxFQUFvQjtBQUNuQixhQUFPLElBQVA7QUFDQSxLQUZELE1BSUE7QUFDQyxhQUFPQSxRQUFRLENBQUMzSSxJQUFoQjtBQUNBO0FBQ0QsR0F6RGE7O0FBMERkO0FBQ0EsMEJBQ0NBLElBREQsRUFFQ3dMLFVBRkQsRUFHQ2xHLElBSEQsRUFLQTtBQUNDLFFBQUksQ0FBQ3lCLFFBQVEsQ0FBQ3NCLFNBQVQsQ0FBbUIsS0FBS0MsTUFBeEIsRUFBK0IsT0FBL0IsQ0FBTCxFQUNBO0FBQ0MsWUFBTSxJQUFJdkssTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixXQUFqQixFQUE2Qix3QkFBN0IsQ0FBTjtBQUNBLEtBSEQsTUFLQTtBQUNDLFVBQUl1RSxjQUFjLENBQUNsRSxPQUFmLENBQXVCO0FBQUU1SSxZQUFJLEVBQUNBO0FBQVAsT0FBdkIsS0FBc0MsSUFBMUMsRUFDQTtBQUNDLGNBQU0sSUFBSWpDLE1BQU0sQ0FBQ3dLLEtBQVgsQ0FBaUIsaURBQWpCLENBQU47QUFDQSxPQUhELE1BS0E7QUFDQ3VFLHNCQUFjLENBQUNwRSxNQUFmLENBQXNCO0FBQ3JCMUksY0FEcUI7QUFFckJ3TCxvQkFGcUI7QUFHckJsRztBQUhxQixTQUF0QjtBQU1BO0FBQ0Q7QUFDRCxHQXJGYTs7QUFzRmQ7QUFDQSwwQkFBd0J1RCxNQUF4QixFQUNBO0FBQ0MsUUFBSSxDQUFDOUIsUUFBUSxDQUFDc0IsU0FBVCxDQUFtQixLQUFLQyxNQUF4QixFQUErQixPQUEvQixDQUFMLEVBQ0E7QUFDQyxZQUFNLElBQUl2SyxNQUFNLENBQUN3SyxLQUFYLENBQWlCLFdBQWpCLEVBQTZCLHdCQUE3QixDQUFOO0FBQ0EsS0FIRCxNQUtBO0FBQ0N1RSxvQkFBYyxDQUFDaEUsTUFBZixDQUFzQkQsTUFBdEI7QUFDQTtBQUNELEdBakdhOztBQWtHZDtBQUNBLDBCQUNDakosR0FERCxFQUVDNEwsVUFGRCxFQUdDbEcsSUFIRCxFQUtBO0FBQ0MsUUFBSSxDQUFDeUIsUUFBUSxDQUFDc0IsU0FBVCxDQUFtQixLQUFLQyxNQUF4QixFQUErQixPQUEvQixDQUFMLEVBQ0E7QUFDQyxZQUFNLElBQUl2SyxNQUFNLENBQUN3SyxLQUFYLENBQWlCLFdBQWpCLEVBQTZCLHdCQUE3QixDQUFOO0FBQ0EsS0FIRCxNQUtBO0FBQ0N1RSxvQkFBYyxDQUFDL0QsTUFBZixDQUFzQm5KLEdBQXRCLEVBQ0M7QUFBRXFDLFlBQUksRUFBRTtBQUNQdUosb0JBRE87QUFFUGxHO0FBRk87QUFBUixPQUREO0FBTUE7QUFDRCxHQXRIYTs7QUF3SGQ7QUFDQSxpQ0FDQzFGLEdBREQsRUFFQ3dQLElBRkQsRUFHQ0MsV0FIRCxFQUtBO0FBQ0MsUUFBSSxDQUFDdEksUUFBUSxDQUFDc0IsU0FBVCxDQUFtQixLQUFLQyxNQUF4QixFQUErQixPQUEvQixDQUFMLEVBQ0E7QUFDQyxZQUFNLElBQUl2SyxNQUFNLENBQUN3SyxLQUFYLENBQWlCLFdBQWpCLEVBQTZCLHdCQUE3QixDQUFOO0FBQ0EsS0FIRCxNQUtBO0FBQ0N1RSxvQkFBYyxDQUFDL0QsTUFBZixDQUFzQm5KLEdBQXRCLEVBQ0M7QUFBRXFDLFlBQUksRUFBRTtBQUNQbU4sY0FETztBQUVQQztBQUZPO0FBQVIsT0FERDtBQU1BO0FBQ0QsR0E1SWE7O0FBOElkO0FBQ0EsOEJBQ0N6UCxHQURELEVBRUNtSixNQUZELEVBSUE7QUFDQyxRQUFJLENBQUNoQyxRQUFRLENBQUNzQixTQUFULENBQW1CLEtBQUtDLE1BQXhCLEVBQStCLE9BQS9CLENBQUwsRUFDQTtBQUNDLFlBQU0sSUFBSXZLLE1BQU0sQ0FBQ3dLLEtBQVgsQ0FBaUIsV0FBakIsRUFBNkIsd0JBQTdCLENBQU47QUFDQSxLQUhELE1BS0E7QUFDQ3VFLG9CQUFjLENBQUMvRCxNQUFmLENBQXNCbkosR0FBdEIsRUFDQztBQUFFcUMsWUFBSSxFQUFFO0FBQ1A4RztBQURPO0FBQVIsT0FERDtBQUtBO0FBQ0Q7O0FBaEthLENBQWYsRTs7Ozs7Ozs7Ozs7QUNkQW5MLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUN5UixrQkFBZ0IsRUFBQyxNQUFJQTtBQUF0QixDQUFkO0FBQXVELElBQUl2UixNQUFKO0FBQVdILE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLEtBQUo7QUFBVU4sTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRSxPQUFLLENBQUNELENBQUQsRUFBRztBQUFDQyxTQUFLLEdBQUNELENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSTZJLGNBQUo7QUFBbUJsSixNQUFNLENBQUNJLElBQVAsQ0FBWSxxQkFBWixFQUFrQztBQUFDZ0osU0FBTyxDQUFDL0ksQ0FBRCxFQUFHO0FBQUM2SSxrQkFBYyxHQUFDN0ksQ0FBZjtBQUFpQjs7QUFBN0IsQ0FBbEMsRUFBaUUsQ0FBakU7QUFJL0wsTUFBTXFSLGdCQUFnQixHQUFHLElBQUlwUixLQUFLLENBQUNDLFVBQVYsQ0FBcUIsa0JBQXJCLENBQXpCOztBQUVQLElBQUlKLE1BQU0sQ0FBQ0ssUUFBWCxFQUFxQjtBQUNwQkwsUUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDZDtBQUNNLHNDQUFOLENBQXlDZ0QsU0FBekMsRUFBbURSLE9BQW5EO0FBQUEsc0NBQTREO0FBQzNELFlBQUl0QyxTQUFTLEdBQUksRUFBakI7QUFDQSxZQUFJK0MsU0FBUyxHQUFHLEVBQWhCO0FBRUEsY0FBTUMsTUFBTSxpQkFBU3lOLGdCQUFnQixDQUFDeE4sYUFBakIsR0FBaUNDLFNBQWpDLENBQTJDLENBQy9EO0FBQUNDLGdCQUFNLEVBQUU7QUFBRTNCLHFCQUFTLEVBQUU7QUFBRWUsa0JBQUksRUFBRU8sU0FBUjtBQUFtQk4sa0JBQUksRUFBRUY7QUFBekI7QUFBYjtBQUFULFNBRCtELEVBRS9EO0FBQUNjLGNBQUksRUFBRTtBQUFFQyxrQkFBTSxFQUFFO0FBQUVDLDJCQUFhLEVBQUU7QUFBRUMsc0JBQU0sRUFBRSxhQUFWO0FBQXlCQyxvQkFBSSxFQUFFO0FBQUNDLHNCQUFJLEVBQUcsQ0FBQyxJQUFJaEMsSUFBSixDQUFTLENBQVQsQ0FBRCxFQUFjLFlBQWQ7QUFBUixpQkFBL0I7QUFBc0VpQyx3QkFBUSxFQUFFO0FBQWhGO0FBQWpCO0FBQVY7QUFBUCxTQUYrRCxFQUcvRDtBQUFDTixjQUFJLEVBQUU7QUFBRXNOLG9CQUFRLEVBQUU7QUFBRXBOLDJCQUFhLEVBQUU7QUFBRUMsc0JBQU0sRUFBRSxPQUFWO0FBQW1CQyxvQkFBSSxFQUFFO0FBQUNDLHNCQUFJLEVBQUcsQ0FBQyxJQUFJaEMsSUFBSixDQUFTLENBQVQsQ0FBRCxFQUFjLFlBQWQ7QUFBUixpQkFBekI7QUFBZ0VpQyx3QkFBUSxFQUFFO0FBQTFFO0FBQWpCO0FBQVo7QUFBUCxTQUgrRCxFQUkvRDtBQUFDSyxrQkFBUSxFQUNSO0FBQ0NoRCxlQUFHLEVBQUMsU0FETDtBQUVDNEcsc0JBQVUsRUFBRTtBQUNYZ0oscUJBQU8sRUFBRTtBQUNOQyxxQkFBSyxFQUFFLE9BREQ7QUFFTmpGLGtCQUFFLEVBQUUsTUFGRTtBQUdOa0Ysb0JBQUksRUFBRTtBQUFFQyxxQkFBRyxFQUFFLENBQUUsVUFBRixFQUFjLENBQUMsQ0FBRCxDQUFkO0FBQVA7QUFIQTtBQURFLGFBRmI7QUFTQ2xKLHNCQUFVLEVBQUU7QUFDWCtJLHFCQUFPLEVBQUU7QUFDTkMscUJBQUssRUFBRSxPQUREO0FBRU5qRixrQkFBRSxFQUFFLE1BRkU7QUFHTmtGLG9CQUFJLEVBQUU7QUFBRUMscUJBQUcsRUFBRSxDQUFFLFVBQUYsRUFBYyxDQUFDLENBQUQsQ0FBZDtBQUFQO0FBSEE7QUFERSxhQVRiO0FBZ0JDNU0sb0JBQVEsRUFBRTtBQUNUeU0scUJBQU8sRUFBRTtBQUNOQyxxQkFBSyxFQUFFLE9BREQ7QUFFTmpGLGtCQUFFLEVBQUUsTUFGRTtBQUdOa0Ysb0JBQUksRUFBRTtBQUFFQyxxQkFBRyxFQUFFLENBQUUsVUFBRixFQUFjLENBQUMsQ0FBRCxDQUFkO0FBQVA7QUFIQTtBQURBLGFBaEJYO0FBdUJDQyxjQUFFLEVBQUU7QUFDSEoscUJBQU8sRUFBRTtBQUNOQyxxQkFBSyxFQUFFLE9BREQ7QUFFTmpGLGtCQUFFLEVBQUUsTUFGRTtBQUdOa0Ysb0JBQUksRUFBRTtBQUFFQyxxQkFBRyxFQUFFLENBQUUsVUFBRixFQUFjLENBQUMsQ0FBRCxDQUFkO0FBQVA7QUFIQTtBQUROLGFBdkJMO0FBOEJDeEosZ0JBQUksRUFBQyxZQTlCTjtBQStCQ29KLG9CQUFRLEVBQUM7QUEvQlY7QUFERCxTQUorRCxFQXVDL0Q7QUFBQ2xNLGVBQUssRUFBRztBQUFFLG9CQUFPO0FBQVQ7QUFBVCxTQXZDK0QsRUF3Qy9EO0FBQUNULGtCQUFRLEVBQ1I7QUFDQ2hELGVBQUcsRUFBRyxNQURQO0FBRUM0RyxzQkFBVSxFQUFHO0FBQUVyRCxrQkFBSSxFQUFFO0FBQVIsYUFGZDtBQUdDc0Qsc0JBQVUsRUFBRztBQUFFdEQsa0JBQUksRUFBRTtBQUFSLGFBSGQ7QUFJQ0osb0JBQVEsRUFBRztBQUFFSSxrQkFBSSxFQUFFO0FBQVIsYUFKWjtBQUtDeU0sY0FBRSxFQUFLO0FBQUV6TSxrQkFBSSxFQUFFO0FBQVIsYUFMUjtBQU1DZ0QsZ0JBQUksRUFBSSxPQU5UO0FBT0NvSixvQkFBUSxFQUFLLFdBUGQ7QUFRQy9NLGtCQUFNLEVBQUk7QUFBRXFOLG1CQUFLLEVBQUU7QUFBQ3hOLG9CQUFJLEVBQUU7QUFBQ0Msc0JBQUksRUFBRyxDQUFDLElBQUloQyxJQUFKLENBQVMsQ0FBVCxDQUFELEVBQWMsT0FBZDtBQUFSLGlCQUFQO0FBQXlDaUMsd0JBQVEsRUFBRTtBQUFuRDtBQUFULGFBUlg7QUFTQ3VOLG9CQUFRLEVBQUc7QUFBRUMscUJBQU8sRUFBRTtBQUFFMU4sb0JBQUksRUFBRTtBQUFDQyxzQkFBSSxFQUFHLENBQUMsSUFBSWhDLElBQUosQ0FBUyxDQUFULENBQUQsRUFBYyxPQUFkO0FBQVIsaUJBQVI7QUFBMENpQyx3QkFBUSxFQUFFO0FBQXBEO0FBQVg7QUFUWjtBQURELFNBeEMrRCxDQUEzQyxFQXFEbEJ6QyxPQXJEa0IsQ0FxRFYsVUFBU0MsR0FBVCxFQUFjO0FBQ3hCNkIsbUJBQVMsQ0FBQzFCLElBQVYsQ0FBZUgsR0FBZjtBQUNBLFNBdkRvQixDQUFULENBQVo7QUF5REEsWUFBSXlELGFBQWEsR0FBRyxDQUFwQjtBQUNBLFlBQUlDLGFBQWEsR0FBRyxDQUFwQjtBQUNBLFlBQUl1TSxPQUFPLEdBQUssQ0FBaEI7QUFDQSxZQUFJdE0sVUFBVSxHQUFJLENBQWxCO0FBQ0EsWUFBSXVNLGFBQWEsR0FBRyxDQUFwQjtBQUNBLFlBQUlDLGFBQWEsR0FBRyxDQUFwQjtBQUNBLFlBQUkvSixJQUFJLEdBQUcsRUFBWDtBQUVBLFlBQUlyQyxRQUFRLEdBQUcsRUFBZjtBQUNBLFlBQUlDLFVBQVUsR0FBQyxFQUFmOztBQUVBLGFBQUssSUFBSWEsQ0FBQyxHQUFDLENBQVgsRUFBY0EsQ0FBQyxHQUFHaEQsU0FBUyxDQUFDZCxNQUE1QixFQUFvQzhELENBQUMsRUFBckMsRUFDQTtBQUNDLGNBQUtsQixVQUFVLElBQUUsQ0FBYixJQUFvQjlCLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFha0wsUUFBYixJQUF5QixFQUE3QyxJQUFxRGxPLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhcEMsTUFBYixJQUF1QixDQUFoRixFQUNBO0FBQ0N3TixtQkFBTyxHQUFLcE8sU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFwQyxNQUF6QjtBQUNBMkQsZ0JBQUksR0FBS3ZFLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhMkssUUFBdEI7QUFDQS9MLHlCQUFhLEdBQUdzQixRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTRCLFVBQWQsQ0FBeEI7QUFDQS9DLHlCQUFhLEdBQUdxQixRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTZCLFVBQWQsQ0FBeEI7QUFDQS9DLHNCQUFVLEdBQUcsQ0FBYjtBQUNBLFdBUEQsTUFPTyxJQUFJQSxVQUFVLElBQUUsQ0FBaEIsRUFDUDtBQUNDLGdCQUFJeU0sSUFBSSxDQUFDQyxHQUFMLENBQVN0TCxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTRCLFVBQWQsQ0FBUixHQUFvQ2hELGFBQTdDLElBQTRELEtBQWhFLEVBQ0EsQ0FDQztBQUNBLGFBSEQsTUFLZTtBQUNJeU0sMkJBQWEsR0FBR0EsYUFBYSxHQUFHRSxJQUFJLENBQUNDLEdBQUwsQ0FBU3RMLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhNEIsVUFBZCxDQUFSLEdBQW9DaEQsYUFBN0MsQ0FBaEM7QUFDSDs7QUFDaEIsZ0JBQUkyTSxJQUFJLENBQUNDLEdBQUwsQ0FBU3RMLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhNkIsVUFBZCxDQUFSLEdBQW9DaEQsYUFBN0MsSUFBNEQsS0FBaEUsRUFDQSxDQUNDO0FBQ0EsYUFIRCxNQUtlO0FBQ0l5TSwyQkFBYSxHQUFHQSxhQUFhLEdBQUdDLElBQUksQ0FBQ0MsR0FBTCxDQUFTdEwsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE2QixVQUFkLENBQVIsR0FBb0NoRCxhQUE3QyxDQUFoQztBQUNIOztBQUVoQixnQkFBTTdCLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFha0wsUUFBYixJQUF5QixFQUExQixJQUFrQ2xPLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhcEMsTUFBYixJQUF1QixDQUExRCxJQUFpRW9DLENBQUMsSUFBSWhELFNBQVMsQ0FBQ2QsTUFBVixHQUFpQixDQUEzRixFQUNBO0FBQ0N5RixtQkFBSyxHQUFJMEosYUFBYSxHQUFHQyxhQUF6QjtBQUVBbk0sd0JBQVUsQ0FBQzdELElBQVgsQ0FDQ3NGLFVBQVUsQ0FBQ0UsTUFBTSxDQUFDYSxLQUFELENBQU4sR0FBYyxJQUFmLENBQVYsQ0FBK0JkLE9BQS9CLENBQXVDLENBQXZDLENBREQ7QUFHQTNCLHNCQUFRLENBQUM1RCxJQUFULENBQ0NpRyxJQUREO0FBR0E4SiwyQkFBYSxHQUFJLENBQWpCO0FBQ0FDLDJCQUFhLEdBQUksQ0FBakI7QUFDQUYscUJBQU8sR0FBS3BPLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhcEMsTUFBekI7QUFDQTJELGtCQUFJLEdBQUt2RSxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTJLLFFBQXRCO0FBQ0E7O0FBQ2MvTCx5QkFBYSxHQUFHc0IsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE0QixVQUFkLENBQXhCO0FBQ0EvQyx5QkFBYSxHQUFHcUIsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE2QixVQUFkLENBQXhCO0FBQ2Y7QUFDRDs7QUFFRDVILGlCQUFTLENBQUNxQixJQUFWLENBQWU7QUFDZE4sYUFBRyxFQUFFLGdCQURTO0FBRWRLLGNBQUksRUFBRSxLQUZRO0FBR2RpRyxjQUFJLEVBQUVuQyxVQUhRO0FBSWRvQyxjQUFJLEVBQUVyQztBQUpRLFNBQWY7QUFNQSxlQUFPakYsU0FBUDtBQUNBLE9BL0hEO0FBQUEsS0FGYzs7QUFrSWQ7QUFDTSwwQ0FBTixDQUE2QzhDLFNBQTdDLEVBQXVEUixPQUF2RCxFQUErRGtGLFlBQS9EO0FBQUEsc0NBQTZFO0FBQzVFLFlBQUl4SCxTQUFTLEdBQUksRUFBakI7QUFDQSxZQUFJK0MsU0FBUyxHQUFHLEVBQWhCLENBRjRFLENBRzVFOztBQUNBLGNBQU1DLE1BQU0saUJBQVN5TixnQkFBZ0IsQ0FBQ3hOLGFBQWpCLEdBQWlDQyxTQUFqQyxDQUEyQyxDQUMvRDtBQUFDQyxnQkFBTSxFQUFFO0FBQUUzQixxQkFBUyxFQUFFO0FBQUVlLGtCQUFJLEVBQUVPLFNBQVI7QUFBbUJOLGtCQUFJLEVBQUVGO0FBQXpCO0FBQWI7QUFBVCxTQUQrRCxFQUUvRDtBQUFDYyxjQUFJLEVBQUU7QUFBRUMsa0JBQU0sRUFBRTtBQUFFQywyQkFBYSxFQUFFO0FBQUVDLHNCQUFNLEVBQUUsYUFBVjtBQUF5QkMsb0JBQUksRUFBRTtBQUFDQyxzQkFBSSxFQUFHLENBQUMsSUFBSWhDLElBQUosQ0FBUyxDQUFULENBQUQsRUFBYyxZQUFkO0FBQVIsaUJBQS9CO0FBQXNFaUMsd0JBQVEsRUFBRTtBQUFoRjtBQUFqQjtBQUFWO0FBQVAsU0FGK0QsRUFHL0Q7QUFBQ0ssa0JBQVEsRUFDUjtBQUNDaEQsZUFBRyxFQUFDLFNBREw7QUFFQzRHLHNCQUFVLEVBQUU7QUFDWGdKLHFCQUFPLEVBQUU7QUFDTkMscUJBQUssRUFBRSxPQUREO0FBRU5qRixrQkFBRSxFQUFFLE1BRkU7QUFHTmtGLG9CQUFJLEVBQUU7QUFBRUMscUJBQUcsRUFBRSxDQUFFLFVBQUYsRUFBYyxDQUFDLENBQUQsQ0FBZDtBQUFQO0FBSEE7QUFERSxhQUZiO0FBU0NsSixzQkFBVSxFQUFFO0FBQ1grSSxxQkFBTyxFQUFFO0FBQ05DLHFCQUFLLEVBQUUsT0FERDtBQUVOakYsa0JBQUUsRUFBRSxNQUZFO0FBR05rRixvQkFBSSxFQUFFO0FBQUVDLHFCQUFHLEVBQUUsQ0FBRSxVQUFGLEVBQWMsQ0FBQyxDQUFELENBQWQ7QUFBUDtBQUhBO0FBREUsYUFUYjtBQWdCQzVNLG9CQUFRLEVBQUU7QUFDVHlNLHFCQUFPLEVBQUU7QUFDTkMscUJBQUssRUFBRSxPQUREO0FBRU5qRixrQkFBRSxFQUFFLE1BRkU7QUFHTmtGLG9CQUFJLEVBQUU7QUFBRUMscUJBQUcsRUFBRSxDQUFFLFVBQUYsRUFBYyxDQUFDLENBQUQsQ0FBZDtBQUFQO0FBSEE7QUFEQSxhQWhCWDtBQXVCQ0MsY0FBRSxFQUFFO0FBQ0hKLHFCQUFPLEVBQUU7QUFDTkMscUJBQUssRUFBRSxPQUREO0FBRU5qRixrQkFBRSxFQUFFLE1BRkU7QUFHTmtGLG9CQUFJLEVBQUU7QUFBRUMscUJBQUcsRUFBRSxDQUFFLFVBQUYsRUFBYyxDQUFDLENBQUQsQ0FBZDtBQUFQO0FBSEE7QUFETixhQXZCTDtBQThCQ3hKLGdCQUFJLEVBQUM7QUE5Qk47QUFERCxTQUgrRCxFQXFDL0Q7QUFBQzlDLGVBQUssRUFBRztBQUFFLG9CQUFPO0FBQVQ7QUFBVCxTQXJDK0QsRUFzQy9EO0FBQUNULGtCQUFRLEVBQ1I7QUFDQ2hELGVBQUcsRUFBRyxNQURQO0FBRUM0RyxzQkFBVSxFQUFHO0FBQUVyRCxrQkFBSSxFQUFFO0FBQVIsYUFGZDtBQUdDc0Qsc0JBQVUsRUFBRztBQUFFdEQsa0JBQUksRUFBRTtBQUFSLGFBSGQ7QUFJQ0osb0JBQVEsRUFBRztBQUFFSSxrQkFBSSxFQUFFO0FBQVIsYUFKWjtBQUtDaUQsZ0JBQUksRUFBSTtBQUFFakQsa0JBQUksRUFBRTtBQUFSLGFBTFQ7QUFNQ2dELGdCQUFJLEVBQUksT0FOVDtBQU9DM0Qsa0JBQU0sRUFBSTtBQUFFcU4sbUJBQUssRUFBRTtBQUFDeE4sb0JBQUksRUFBRTtBQUFDQyxzQkFBSSxFQUFHLENBQUMsSUFBSWhDLElBQUosQ0FBUyxDQUFULENBQUQsRUFBYyxPQUFkO0FBQVIsaUJBQVA7QUFBeUNpQyx3QkFBUSxFQUFFO0FBQW5EO0FBQVQsYUFQWDtBQVFDdU4sb0JBQVEsRUFBRztBQUFFQyxxQkFBTyxFQUFFO0FBQUUxTixvQkFBSSxFQUFFO0FBQUNDLHNCQUFJLEVBQUcsQ0FBQyxJQUFJaEMsSUFBSixDQUFTLENBQVQsQ0FBRCxFQUFjLE9BQWQ7QUFBUixpQkFBUjtBQUEwQ2lDLHdCQUFRLEVBQUU7QUFBcEQ7QUFBWDtBQVJaO0FBREQsU0F0QytELENBQTNDLEVBa0RsQnpDLE9BbERrQixDQWtEVixVQUFTQyxHQUFULEVBQWM7QUFDeEI2QixtQkFBUyxDQUFDMUIsSUFBVixDQUFlSCxHQUFmO0FBQ0EsU0FwRG9CLENBQVQsQ0FBWjtBQXNEQSxZQUFJeUQsYUFBYSxHQUFHLENBQXBCO0FBQ0EsWUFBSUMsYUFBYSxHQUFHLENBQXBCO0FBQ0EsWUFBSXVNLE9BQU8sR0FBSyxDQUFoQjtBQUNBLFlBQUl0TSxVQUFVLEdBQUksQ0FBbEI7QUFDQSxZQUFJdU0sYUFBYSxHQUFHLENBQXBCO0FBQ0EsWUFBSUMsYUFBYSxHQUFHLENBQXBCO0FBQ0EsWUFBSWxNLGFBQWEsR0FBSSxDQUFyQjtBQUNBLFlBQUlDLGFBQWEsR0FBSSxDQUFyQjtBQUNBLFlBQUlDLGVBQWUsR0FBRyxDQUF0QjtBQUNBLFlBQUlDLGVBQWUsR0FBRyxDQUF0QjtBQUNBLFlBQUlnQyxJQUFJLEdBQUcsRUFBWDtBQUNBLFlBQUl4QyxRQUFRLEdBQUcsQ0FBZjtBQUNBLFlBQUl5QyxJQUFJLEdBQUcsQ0FBWDtBQUNBLFlBQUl6QyxRQUFRLEdBQUcsQ0FBZjtBQUNBLFlBQUlDLFFBQVEsR0FBRyxFQUFmO0FBQ0EsWUFBSUMsUUFBUSxHQUFHLEVBQWY7QUFDQSxZQUFJQyxRQUFRLEdBQUcsRUFBZjtBQUNBLFlBQUlDLFVBQVUsR0FBQyxFQUFmO0FBQ0EsWUFBSUssVUFBVSxHQUFHLENBQWpCO0FBQ0EsWUFBSUMsVUFBVSxHQUFHLENBQWpCO0FBQ0EsWUFBSUMsVUFBVSxHQUFHLENBQWpCO0FBQ0EsWUFBSUMsVUFBVSxHQUFHLENBQWpCO0FBQ0EsWUFBSUMsVUFBVSxHQUFHLENBQWpCO0FBQ0EsWUFBSUMsVUFBVSxHQUFHLENBQWpCO0FBQ0EsWUFBSUMsVUFBVSxHQUFHLENBQWpCO0FBQ0EsWUFBSUMsVUFBVSxHQUFHLENBQWpCOztBQUVBLGFBQUssSUFBSUMsQ0FBQyxHQUFDLENBQVgsRUFBY0EsQ0FBQyxHQUFHaEQsU0FBUyxDQUFDZCxNQUE1QixFQUFvQzhELENBQUMsRUFBckMsRUFDQTtBQUNDLGNBQUtsQixVQUFVLElBQUUsQ0FBYixJQUFvQjlCLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFha0wsUUFBYixJQUF5QixDQUE3QyxJQUFvRGxPLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhcEMsTUFBYixJQUF1QixFQUEvRSxFQUNBO0FBQ0N3TixtQkFBTyxHQUFLcE8sU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFwQyxNQUF6QjtBQUNBMkQsZ0JBQUksR0FBS3ZFLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhaEYsR0FBdEI7QUFDQStELG9CQUFRLEdBQUkvQixTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXVCLElBQXpCO0FBQ0FwRCxvQkFBUSxHQUFJK0IsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE3QixRQUFkLENBQXBCO0FBQ0FxRCxnQkFBSSxHQUFLdEIsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWF3QixJQUFkLENBQWpCO0FBQ0E1Qyx5QkFBYSxHQUFHc0IsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE0QixVQUFkLENBQXhCO0FBQ0EvQyx5QkFBYSxHQUFHcUIsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE2QixVQUFkLENBQXhCO0FBQ0EvQyxzQkFBVSxHQUFHLENBQWI7QUFDQSxXQVZELE1BVU8sSUFBSUEsVUFBVSxJQUFFLENBQWhCLEVBQ1A7QUFDQ3VNLHlCQUFhLEdBQUdBLGFBQWEsR0FBR0UsSUFBSSxDQUFDQyxHQUFMLENBQVN0TCxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTRCLFVBQWQsQ0FBUixHQUFvQ2hELGFBQTdDLENBQWhDO0FBQ0EwTSx5QkFBYSxHQUFHQSxhQUFhLEdBQUdDLElBQUksQ0FBQ0MsR0FBTCxDQUFTdEwsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE2QixVQUFkLENBQVIsR0FBb0NoRCxhQUE3QyxDQUFoQzs7QUFFQSxvQkFBT1YsUUFBUDtBQUVDLG1CQUFLLENBQUw7QUFBTztBQUNObUIsK0JBQWUsR0FBR0EsZUFBZSxHQUFHaU0sSUFBSSxDQUFDQyxHQUFMLENBQVN0TCxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTRCLFVBQWQsQ0FBUixHQUFvQ2hELGFBQTdDLENBQXBDO0FBQ0FXLCtCQUFlLEdBQUdBLGVBQWUsR0FBR2dNLElBQUksQ0FBQ0MsR0FBTCxDQUFTdEwsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE2QixVQUFkLENBQVIsR0FBb0NoRCxhQUE3QyxDQUFwQztBQUNBOztBQUNELG1CQUFLLENBQUw7QUFBTztBQUNOTyw2QkFBYSxHQUFHQyxhQUFhLEdBQUdrTSxJQUFJLENBQUNDLEdBQUwsQ0FBU3RMLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhNEIsVUFBZCxDQUFSLEdBQW9DaEQsYUFBN0MsQ0FBaEM7QUFDQVMsNkJBQWEsR0FBR0EsYUFBYSxHQUFHa00sSUFBSSxDQUFDQyxHQUFMLENBQVN0TCxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTZCLFVBQWQsQ0FBUixHQUFvQ2hELGFBQTdDLENBQWhDO0FBQ0E7O0FBQ0Q7QUFDQztBQVhGOztBQWFBLG9CQUFPMkMsSUFBUDtBQUVDLG1CQUFLLENBQUw7QUFBTztBQUNOaEMsMEJBQVUsR0FBR0EsVUFBVSxHQUFHK0wsSUFBSSxDQUFDQyxHQUFMLENBQVN0TCxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTRCLFVBQWQsQ0FBUixHQUFvQ2hELGFBQTdDLENBQTFCO0FBQ0FhLDBCQUFVLEdBQUdBLFVBQVUsR0FBRzhMLElBQUksQ0FBQ0MsR0FBTCxDQUFTdEwsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE2QixVQUFkLENBQVIsR0FBb0NoRCxhQUE3QyxDQUExQjtBQUNBOztBQUNELG1CQUFLLENBQUw7QUFBTztBQUNOYSwwQkFBVSxHQUFHQSxVQUFVLEdBQUc2TCxJQUFJLENBQUNDLEdBQUwsQ0FBU3RMLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhNEIsVUFBZCxDQUFSLEdBQW9DaEQsYUFBN0MsQ0FBMUI7QUFDQWUsMEJBQVUsR0FBR0EsVUFBVSxHQUFHNEwsSUFBSSxDQUFDQyxHQUFMLENBQVN0TCxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTZCLFVBQWQsQ0FBUixHQUFvQ2hELGFBQTdDLENBQTFCO0FBQ0E7O0FBQ0QsbUJBQUssQ0FBTDtBQUFPO0FBQ05lLDBCQUFVLEdBQUd1QixVQUFVLEdBQUdvSyxJQUFJLENBQUNDLEdBQUwsQ0FBU3RMLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhNEIsVUFBZCxDQUFSLEdBQW9DaEQsYUFBN0MsQ0FBMUI7QUFDQWlCLDBCQUFVLEdBQUd1QixVQUFVLEdBQUdtSyxJQUFJLENBQUNDLEdBQUwsQ0FBU3RMLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhNkIsVUFBZCxDQUFSLEdBQW9DaEQsYUFBN0MsQ0FBMUI7QUFDQTs7QUFDRCxtQkFBSyxDQUFMO0FBQU87QUFDTmlCLDBCQUFVLEdBQUdBLFVBQVUsR0FBR3lMLElBQUksQ0FBQ0MsR0FBTCxDQUFTdEwsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE0QixVQUFkLENBQVIsR0FBb0NoRCxhQUE3QyxDQUExQjtBQUNBbUIsMEJBQVUsR0FBR0EsVUFBVSxHQUFHd0wsSUFBSSxDQUFDQyxHQUFMLENBQVN0TCxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTZCLFVBQWQsQ0FBUixHQUFvQ2hELGFBQTdDLENBQTFCO0FBQ0E7O0FBQ0Q7QUFDQztBQW5CRjs7QUFzQkEsZ0JBQUs3QixTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYWtMLFFBQWIsSUFBeUIsQ0FBMUIsSUFBaUNsTyxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXBDLE1BQWIsSUFBdUIsRUFBNUQsRUFDQTtBQUNDLG9CQUFNd0MsY0FBYyxpQkFBU2pILE1BQU0sQ0FBQ2tILElBQVAsQ0FBWSw0QkFBWixFQUEwQ3JELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhdUIsSUFBdkQsQ0FBVCxDQUFwQjs7QUFDQSxrQkFBSW5CLGNBQWMsSUFBSSxFQUF0QixFQUEwQjtBQUV4QjtBQUNBO0FBQ0E7QUFDQTtBQUNELG9CQUFJRCxRQUFRLEdBQUlrTCxhQUFhLEdBQUdDLGFBQWhDO0FBQ0Esb0JBQUkzSixLQUFLLEdBQUcsQ0FBWjs7QUFDQSx3QkFBT3pCLFFBQVEsQ0FBQ3VCLFlBQUQsQ0FBZjtBQUVDLHVCQUFLLENBQUw7QUFDQ0UseUJBQUssR0FBSTBKLGFBQWEsR0FBR0MsYUFBekI7QUFDQTs7QUFDRCx1QkFBSyxDQUFMO0FBQ0MzSix5QkFBSyxHQUFJbkMsVUFBVSxHQUFHQyxVQUF0QjtBQUNBOztBQUNELHVCQUFLLENBQUw7QUFDQ2tDLHlCQUFLLEdBQUlqQyxVQUFVLEdBQUdDLFVBQXRCO0FBQ0E7O0FBQ0QsdUJBQUssQ0FBTDtBQUNDZ0MseUJBQUssR0FBSS9CLFVBQVUsR0FBR0MsVUFBdEI7QUFDQTs7QUFDRCx1QkFBSyxDQUFMO0FBQ0M4Qix5QkFBSyxHQUFJN0IsVUFBVSxHQUFHQyxVQUF0QjtBQUNBO0FBaEJGLGlCQVJ5QixDQTBCekI7QUFDQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNEOzs7QUFFQVosMEJBQVUsQ0FBQzdELElBQVgsQ0FBZ0I7QUFDZiwrQkFBYWlHLElBQUksQ0FBQ3RGLE1BQUwsQ0FBWSxPQUFaLEVBQW9CZSxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYWhGLEdBQWpDLENBREU7QUFFZiw4QkFBWXFRLGFBRkc7QUFHZiw4QkFBWUMsYUFIRztBQUlmLDBCQUFTbkwsUUFKTTtBQUtmLCtCQUFhZixhQUFhLEdBQUdDLGFBTGQ7QUFNZixpQ0FBZ0JDLGVBQWUsR0FBR0MsZUFObkI7QUFPZixtQ0FBa0JDLFVBQVUsR0FBR0MsVUFQaEI7QUFRZixtQ0FBa0JDLFVBQVUsR0FBR0MsVUFSaEI7QUFTZixtQ0FBa0JDLFVBQVUsR0FBR0MsVUFUaEI7QUFVZixtQ0FBa0JDLFVBQVUsR0FBR0MsVUFWaEI7QUFXZiw2QkFBWWEsVUFBVSxDQUFFZSxLQUFLLEdBQUdmLFVBQVUsQ0FBQ1IsY0FBYyxDQUFDLENBQUQsQ0FBZCxDQUFrQnFDLE1BQW5CLENBQW5CLEdBQWlELEdBQWxELENBQVYsQ0FBaUU1QixPQUFqRSxDQUF5RSxDQUF6RSxDQVhHO0FBWWYsNkJBQVlELFVBQVUsQ0FBRWUsS0FBSyxHQUFHZixVQUFVLENBQUNSLGNBQWMsQ0FBQyxDQUFELENBQWQsQ0FBa0JzQyxNQUFuQixDQUFuQixHQUFpRCxHQUFsRCxDQUFWLENBQWlFN0IsT0FBakUsQ0FBeUUsQ0FBekUsQ0FaRztBQWFmLDhCQUFZRCxVQUFVLENBQUVlLEtBQUssR0FBR2YsVUFBVSxDQUFDUixjQUFjLENBQUMsQ0FBRCxDQUFkLENBQWtCdUMsT0FBbkIsQ0FBbkIsR0FBa0QsR0FBbkQsQ0FBVixDQUFrRTlCLE9BQWxFLENBQTBFLENBQTFFLENBYkc7QUFjZiw2QkFBWUQsVUFBVSxDQUFFZSxLQUFLLEdBQUdmLFVBQVUsQ0FBQ1IsY0FBYyxDQUFDLENBQUQsQ0FBZCxDQUFrQndDLE1BQW5CLENBQW5CLEdBQWlELEdBQWxELENBQVYsQ0FBaUUvQixPQUFqRSxDQUF5RSxDQUF6RSxDQWRHO0FBZWYsbUNBQWdCRCxVQUFVLENBQUVlLEtBQUssR0FBR2YsVUFBVSxDQUFDUixjQUFjLENBQUMsQ0FBRCxDQUFkLENBQWtCeUMsU0FBbkIsQ0FBbkIsR0FBb0QsR0FBckQsQ0FBVixDQUFvRWhDLE9BQXBFLENBQTRFLENBQTVFLENBZkQ7QUFnQmYsOEJBQWFELFVBQVUsQ0FBRWUsS0FBSyxHQUFHZixVQUFVLENBQUNSLGNBQWMsQ0FBQyxDQUFELENBQWQsQ0FBa0IwQyxPQUFuQixDQUFuQixHQUFrRCxHQUFuRCxDQUFWLENBQWtFakMsT0FBbEUsQ0FBMEUsQ0FBMUUsQ0FoQkU7QUFpQmYsNkJBQVlELFVBQVUsQ0FBRWUsS0FBSyxHQUFHZixVQUFVLENBQUNSLGNBQWMsQ0FBQyxDQUFELENBQWQsQ0FBa0IyQyxNQUFuQixDQUFuQixHQUFpRCxHQUFsRCxDQUFWLENBQWlFbEMsT0FBakUsQ0FBeUUsQ0FBekUsQ0FqQkc7QUFrQmYsMEJBQVFELFVBQVUsQ0FBRWUsS0FBSyxHQUFHZixVQUFVLENBQUNSLGNBQWMsQ0FBQyxDQUFELENBQWQsQ0FBa0I0QyxJQUFuQixDQUFuQixHQUErQyxHQUFoRCxDQUFWLENBQStEbkMsT0FBL0QsQ0FBdUUsQ0FBdkUsQ0FsQk87QUFtQmYsNkJBQVlELFVBQVUsQ0FBRWUsS0FBSyxHQUFHZixVQUFVLENBQUNSLGNBQWMsQ0FBQyxDQUFELENBQWQsQ0FBa0I2QyxNQUFuQixDQUFuQixHQUFpRCxHQUFsRCxDQUFWLENBQWlFcEMsT0FBakUsQ0FBeUUsQ0FBekU7QUFuQkcsaUJBQWhCO0FBcUJBLGVBOUVELE1BZ0ZBO0FBQ0MxQiwwQkFBVSxDQUFDN0QsSUFBWCxDQUFnQjtBQUNmLCtCQUFhaUcsSUFBSSxDQUFDdEYsTUFBTCxDQUFZLE9BQVosRUFBb0JlLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhaEYsR0FBakMsQ0FERTtBQUVmLDhCQUFZcVEsYUFGRztBQUdmLDhCQUFZQyxhQUhHO0FBSWYsMEJBQVNuTCxRQUpNO0FBS2YsK0JBQWFmLGFBQWEsR0FBR0MsYUFMZDtBQU1mLGlDQUFnQkMsZUFBZSxHQUFHQyxlQU5uQjtBQU9mLG1DQUFrQkMsVUFBVSxHQUFHQyxVQVBoQjtBQVFmLG1DQUFrQkMsVUFBVSxHQUFHQyxVQVJoQjtBQVNmLG1DQUFrQkMsVUFBVSxHQUFHQyxVQVRoQjtBQVVmLG1DQUFrQkMsVUFBVSxHQUFHQztBQVZoQixpQkFBaEI7QUFhQTs7QUFFRGYsc0JBQVEsQ0FBQzFELElBQVQsQ0FDQ3dGLE1BQU0sQ0FBQ3VLLGFBQUQsQ0FEUDtBQUdBcE0sc0JBQVEsQ0FBQzNELElBQVQsQ0FDQ3dGLE1BQU0sQ0FBQ3dLLGFBQUQsQ0FEUDtBQUdBcE0sc0JBQVEsQ0FBQzVELElBQVQsQ0FDQ2lHLElBREQ7QUFHQThKLDJCQUFhLEdBQUksQ0FBakI7QUFDQUMsMkJBQWEsR0FBSSxDQUFqQjtBQUNBbE0sMkJBQWEsR0FBSSxDQUFqQjtBQUNBQywyQkFBYSxHQUFJLENBQWpCO0FBQ0FDLDZCQUFlLEdBQUksQ0FBbkI7QUFDQUMsNkJBQWUsR0FBSSxDQUFuQjtBQUNBQyx3QkFBVSxHQUFHLENBQWI7QUFDQUMsd0JBQVUsR0FBRyxDQUFiO0FBQ0FDLHdCQUFVLEdBQUcsQ0FBYjtBQUNBQyx3QkFBVSxHQUFHLENBQWI7QUFDQUMsd0JBQVUsR0FBRyxDQUFiO0FBQ0FDLHdCQUFVLEdBQUcsQ0FBYjtBQUNBQyx3QkFBVSxHQUFHLENBQWI7QUFDQUMsd0JBQVUsR0FBRyxDQUFiO0FBQ0FxTCxxQkFBTyxHQUFLcE8sU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFwQyxNQUF6QjtBQUNBMkQsa0JBQUksR0FBS3ZFLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhaEYsR0FBdEI7QUFDQStELHNCQUFRLEdBQUkvQixTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXVCLElBQXpCO0FBQ0FwRCxzQkFBUSxHQUFJK0IsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE3QixRQUFkLENBQXBCO0FBQ0FxRCxrQkFBSSxHQUFLdEIsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWF3QixJQUFkLENBQWpCO0FBQ0E1QywyQkFBYSxHQUFHc0IsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE0QixVQUFkLENBQXhCO0FBQ0EvQywyQkFBYSxHQUFHcUIsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE2QixVQUFkLENBQXhCO0FBQ0E7QUFDRDtBQUNEOztBQUVENUgsaUJBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkTixhQUFHLEVBQUUsVUFEUztBQUVkSyxjQUFJLEVBQUUsS0FGUTtBQUdkZ0csZUFBSyxFQUFFLFNBSE87QUFJZEMsY0FBSSxFQUFFdEMsUUFKUTtBQUtkdUMsY0FBSSxFQUFFckM7QUFMUSxTQUFmO0FBT0FqRixpQkFBUyxDQUFDcUIsSUFBVixDQUFlO0FBQ2ROLGFBQUcsRUFBRSxVQURTO0FBRWRLLGNBQUksRUFBRSxLQUZRO0FBR2RnRyxlQUFLLEVBQUUsU0FITztBQUlkQyxjQUFJLEVBQUVyQyxRQUpRO0FBS2RzQyxjQUFJLEVBQUVyQztBQUxRLFNBQWY7QUFPQWpGLGlCQUFTLENBQUNxQixJQUFWLENBQWU7QUFDZE4sYUFBRyxFQUFFLFFBRFM7QUFFZHNHLGNBQUksRUFBRW5DO0FBRlEsU0FBZjtBQUlBLGVBQU9sRixTQUFQO0FBQ0EsT0FqU0Q7QUFBQSxLQW5JYzs7QUFxYWQ7QUFDTSx1Q0FBTixDQUEwQzhDLFNBQTFDLEVBQW9EUixPQUFwRCxFQUE0RGtGLFlBQTVEO0FBQUEsc0NBQTBFO0FBQ3pFLFlBQUl4SCxTQUFTLEdBQUksRUFBakI7QUFDQSxZQUFJK0MsU0FBUyxHQUFHLEVBQWhCLENBRnlFLENBR3pFOztBQUNBLGNBQU1DLE1BQU0saUJBQVN5TixnQkFBZ0IsQ0FBQ3hOLGFBQWpCLEdBQWlDQyxTQUFqQyxDQUEyQyxDQUMvRDtBQUFDQyxnQkFBTSxFQUFFO0FBQUUzQixxQkFBUyxFQUFFO0FBQUVlLGtCQUFJLEVBQUVPLFNBQVI7QUFBbUJOLGtCQUFJLEVBQUVGO0FBQXpCO0FBQWI7QUFBVCxTQUQrRCxFQUUvRDtBQUFDYyxjQUFJLEVBQUU7QUFBRUMsa0JBQU0sRUFBRTtBQUFFQywyQkFBYSxFQUFFO0FBQUVDLHNCQUFNLEVBQUUsYUFBVjtBQUF5QkMsb0JBQUksRUFBRTtBQUFDQyxzQkFBSSxFQUFHLENBQUMsSUFBSWhDLElBQUosQ0FBUyxDQUFULENBQUQsRUFBYyxZQUFkO0FBQVIsaUJBQS9CO0FBQXNFaUMsd0JBQVEsRUFBRTtBQUFoRjtBQUFqQjtBQUFWO0FBQVAsU0FGK0QsRUFHL0Q7QUFBQ04sY0FBSSxFQUFFO0FBQUVzTixvQkFBUSxFQUFFO0FBQUVwTiwyQkFBYSxFQUFFO0FBQUVDLHNCQUFNLEVBQUUsT0FBVjtBQUFtQkMsb0JBQUksRUFBRTtBQUFDQyxzQkFBSSxFQUFHLENBQUMsSUFBSWhDLElBQUosQ0FBUyxDQUFULENBQUQsRUFBYyxZQUFkO0FBQVIsaUJBQXpCO0FBQWdFaUMsd0JBQVEsRUFBRTtBQUExRTtBQUFqQjtBQUFaO0FBQVAsU0FIK0QsRUFJL0Q7QUFBQ0ssa0JBQVEsRUFDUjtBQUNDaEQsZUFBRyxFQUFDLFNBREw7QUFFQzRHLHNCQUFVLEVBQUU7QUFDWGdKLHFCQUFPLEVBQUU7QUFDTkMscUJBQUssRUFBRSxPQUREO0FBRU5qRixrQkFBRSxFQUFFLE1BRkU7QUFHTmtGLG9CQUFJLEVBQUU7QUFBRUMscUJBQUcsRUFBRSxDQUFFLFVBQUYsRUFBYyxDQUFDLENBQUQsQ0FBZDtBQUFQO0FBSEE7QUFERSxhQUZiO0FBU0NsSixzQkFBVSxFQUFFO0FBQ1grSSxxQkFBTyxFQUFFO0FBQ05DLHFCQUFLLEVBQUUsT0FERDtBQUVOakYsa0JBQUUsRUFBRSxNQUZFO0FBR05rRixvQkFBSSxFQUFFO0FBQUVDLHFCQUFHLEVBQUUsQ0FBRSxVQUFGLEVBQWMsQ0FBQyxDQUFELENBQWQ7QUFBUDtBQUhBO0FBREUsYUFUYjtBQWdCQzVNLG9CQUFRLEVBQUU7QUFDVHlNLHFCQUFPLEVBQUU7QUFDTkMscUJBQUssRUFBRSxPQUREO0FBRU5qRixrQkFBRSxFQUFFLE1BRkU7QUFHTmtGLG9CQUFJLEVBQUU7QUFBRUMscUJBQUcsRUFBRSxDQUFFLFVBQUYsRUFBYyxDQUFDLENBQUQsQ0FBZDtBQUFQO0FBSEE7QUFEQSxhQWhCWDtBQXVCQ0MsY0FBRSxFQUFFO0FBQ0hKLHFCQUFPLEVBQUU7QUFDTkMscUJBQUssRUFBRSxPQUREO0FBRU5qRixrQkFBRSxFQUFFLE1BRkU7QUFHTmtGLG9CQUFJLEVBQUU7QUFBRUMscUJBQUcsRUFBRSxDQUFFLFVBQUYsRUFBYyxDQUFDLENBQUQsQ0FBZDtBQUFQO0FBSEE7QUFETixhQXZCTDtBQThCQ3hKLGdCQUFJLEVBQUMsWUE5Qk47QUErQkNvSixvQkFBUSxFQUFDO0FBL0JWO0FBREQsU0FKK0QsRUF1Qy9EO0FBQUNsTSxlQUFLLEVBQUc7QUFBRSxvQkFBTztBQUFUO0FBQVQsU0F2QytELEVBd0MvRDtBQUFDVCxrQkFBUSxFQUNSO0FBQ0NoRCxlQUFHLEVBQUcsTUFEUDtBQUVDNEcsc0JBQVUsRUFBRztBQUFFckQsa0JBQUksRUFBRTtBQUFSLGFBRmQ7QUFHQ3NELHNCQUFVLEVBQUc7QUFBRXRELGtCQUFJLEVBQUU7QUFBUixhQUhkO0FBSUNKLG9CQUFRLEVBQUc7QUFBRUksa0JBQUksRUFBRTtBQUFSLGFBSlo7QUFLQ2lELGdCQUFJLEVBQUk7QUFBRWpELGtCQUFJLEVBQUU7QUFBUixhQUxUO0FBTUNnRCxnQkFBSSxFQUFJLE9BTlQ7QUFPQ29KLG9CQUFRLEVBQUMsV0FQVjtBQVFDL00sa0JBQU0sRUFBSTtBQUFFcU4sbUJBQUssRUFBRTtBQUFDeE4sb0JBQUksRUFBRTtBQUFDQyxzQkFBSSxFQUFHLENBQUMsSUFBSWhDLElBQUosQ0FBUyxDQUFULENBQUQsRUFBYyxPQUFkO0FBQVIsaUJBQVA7QUFBeUNpQyx3QkFBUSxFQUFFO0FBQW5EO0FBQVQsYUFSWDtBQVNDdU4sb0JBQVEsRUFBRztBQUFFQyxxQkFBTyxFQUFFO0FBQUUxTixvQkFBSSxFQUFFO0FBQUNDLHNCQUFJLEVBQUcsQ0FBQyxJQUFJaEMsSUFBSixDQUFTLENBQVQsQ0FBRCxFQUFjLE9BQWQ7QUFBUixpQkFBUjtBQUEwQ2lDLHdCQUFRLEVBQUU7QUFBcEQ7QUFBWDtBQVRaO0FBREQsU0F4QytELENBQTNDLEVBcURsQnpDLE9BckRrQixDQXFEVixVQUFTQyxHQUFULEVBQWM7QUFDeEI2QixtQkFBUyxDQUFDMUIsSUFBVixDQUFlSCxHQUFmO0FBQ0EsU0F2RG9CLENBQVQsQ0FBWjtBQXlEQSxZQUFJeUQsYUFBYSxHQUFHLENBQXBCO0FBQ0EsWUFBSUMsYUFBYSxHQUFHLENBQXBCO0FBQ0EsWUFBSXVNLE9BQU8sR0FBSyxDQUFoQjtBQUNBLFlBQUl0TSxVQUFVLEdBQUksQ0FBbEI7QUFDQSxZQUFJdU0sYUFBYSxHQUFHLENBQXBCO0FBQ0EsWUFBSUMsYUFBYSxHQUFHLENBQXBCO0FBQ0EsWUFBSWxNLGFBQWEsR0FBSSxDQUFyQjtBQUNBLFlBQUlDLGFBQWEsR0FBSSxDQUFyQjtBQUNBLFlBQUlDLGVBQWUsR0FBRyxDQUF0QjtBQUNBLFlBQUlDLGVBQWUsR0FBRyxDQUF0QjtBQUNBLFlBQUlnQyxJQUFJLEdBQUcsRUFBWDtBQUNBLFlBQUl4QyxRQUFRLEdBQUcsQ0FBZjtBQUNBLFlBQUl5QyxJQUFJLEdBQUcsQ0FBWDtBQUNBLFlBQUl6QyxRQUFRLEdBQUcsQ0FBZjtBQUNBLFlBQUlDLFFBQVEsR0FBRyxFQUFmO0FBQ0EsWUFBSUMsUUFBUSxHQUFHLEVBQWY7QUFDQSxZQUFJQyxRQUFRLEdBQUcsRUFBZjtBQUNBLFlBQUlDLFVBQVUsR0FBQyxFQUFmO0FBQ0EsWUFBSUssVUFBVSxHQUFHLENBQWpCO0FBQ0EsWUFBSUMsVUFBVSxHQUFHLENBQWpCO0FBQ0EsWUFBSUMsVUFBVSxHQUFHLENBQWpCO0FBQ0EsWUFBSUMsVUFBVSxHQUFHLENBQWpCO0FBQ0EsWUFBSUMsVUFBVSxHQUFHLENBQWpCO0FBQ0EsWUFBSUMsVUFBVSxHQUFHLENBQWpCO0FBQ0EsWUFBSUMsVUFBVSxHQUFHLENBQWpCO0FBQ0EsWUFBSUMsVUFBVSxHQUFHLENBQWpCO0FBQ1MsWUFBSTRLLFFBQVEsR0FBRyxFQUFmOztBQUVULGFBQUssSUFBSTNLLENBQUMsR0FBQyxDQUFYLEVBQWNBLENBQUMsR0FBR2hELFNBQVMsQ0FBQ2QsTUFBNUIsRUFBb0M4RCxDQUFDLEVBQXJDLEVBQ0E7QUFDQyxjQUFLbEIsVUFBVSxJQUFFLENBQWIsSUFBb0I5QixTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYWtMLFFBQWIsSUFBeUIsRUFBN0MsSUFBcURsTyxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXBDLE1BQWIsSUFBdUIsQ0FBaEYsRUFDQTtBQUNDd04sbUJBQU8sR0FBS3BPLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhcEMsTUFBekI7QUFDQTJELGdCQUFJLEdBQUt2RSxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYWhGLEdBQXRCO0FBQ0ErRCxvQkFBUSxHQUFJL0IsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWF1QixJQUF6QjtBQUNBb0osb0JBQVEsR0FBSTNOLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhMkssUUFBekI7QUFDQXhNLG9CQUFRLEdBQUkrQixRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTdCLFFBQWQsQ0FBcEI7QUFDQXFELGdCQUFJLEdBQUt0QixRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXdCLElBQWQsQ0FBakI7QUFDQTVDLHlCQUFhLEdBQUdzQixRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTRCLFVBQWQsQ0FBeEI7QUFDQS9DLHlCQUFhLEdBQUdxQixRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTZCLFVBQWQsQ0FBeEI7QUFDQS9DLHNCQUFVLEdBQUcsQ0FBYjtBQUNBLFdBWEQsTUFXTyxJQUFJQSxVQUFVLElBQUUsQ0FBaEIsRUFDUDtBQUVDLGdCQUFJeU0sSUFBSSxDQUFDQyxHQUFMLENBQVN0TCxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTRCLFVBQWQsQ0FBUixHQUFvQ2hELGFBQTdDLElBQTRELEtBQWhFLEVBQ0EsQ0FDQztBQUNBLGFBSEQsTUFLZTtBQUNJeU0sMkJBQWEsR0FBR0EsYUFBYSxHQUFHRSxJQUFJLENBQUNDLEdBQUwsQ0FBU3RMLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhNEIsVUFBZCxDQUFSLEdBQW9DaEQsYUFBN0MsQ0FBaEM7O0FBQ0Esc0JBQU9ULFFBQVA7QUFFSSxxQkFBSyxDQUFMO0FBQU87QUFDSG1CLGlDQUFlLEdBQUdBLGVBQWUsR0FBR2lNLElBQUksQ0FBQ0MsR0FBTCxDQUFTdEwsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE0QixVQUFkLENBQVIsR0FBb0NoRCxhQUE3QyxDQUFwQztBQUNBOztBQUNKLHFCQUFLLENBQUw7QUFBTztBQUNIUSwrQkFBYSxHQUFHQyxhQUFhLEdBQUdrTSxJQUFJLENBQUNDLEdBQUwsQ0FBU3RMLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhNEIsVUFBZCxDQUFSLEdBQW9DaEQsYUFBN0MsQ0FBaEM7QUFDQTs7QUFDSjtBQUNJO0FBVFI7O0FBV0Esc0JBQU80QyxJQUFQO0FBRUkscUJBQUssQ0FBTDtBQUFPO0FBQ0hoQyw0QkFBVSxHQUFHQSxVQUFVLEdBQUcrTCxJQUFJLENBQUNDLEdBQUwsQ0FBU3RMLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhNEIsVUFBZCxDQUFSLEdBQW9DaEQsYUFBN0MsQ0FBMUI7QUFDQTs7QUFDSixxQkFBSyxDQUFMO0FBQU87QUFDSGMsNEJBQVUsR0FBR0EsVUFBVSxHQUFHNkwsSUFBSSxDQUFDQyxHQUFMLENBQVN0TCxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTRCLFVBQWQsQ0FBUixHQUFvQ2hELGFBQTdDLENBQTFCO0FBQ0E7O0FBQ0oscUJBQUssQ0FBTDtBQUFPO0FBQ0hnQiw0QkFBVSxHQUFHdUIsVUFBVSxHQUFHb0ssSUFBSSxDQUFDQyxHQUFMLENBQVN0TCxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTRCLFVBQWQsQ0FBUixHQUFvQ2hELGFBQTdDLENBQTFCO0FBQ0E7O0FBQ0oscUJBQUssQ0FBTDtBQUFPO0FBQ0hrQiw0QkFBVSxHQUFHQSxVQUFVLEdBQUd5TCxJQUFJLENBQUNDLEdBQUwsQ0FBU3RMLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhNEIsVUFBZCxDQUFSLEdBQW9DaEQsYUFBN0MsQ0FBMUI7QUFDQTs7QUFDSjtBQUNJO0FBZlI7QUFpQkg7O0FBQ2hCLGdCQUFJMk0sSUFBSSxDQUFDQyxHQUFMLENBQVN0TCxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTZCLFVBQWQsQ0FBUixHQUFvQ2hELGFBQTdDLElBQTRELEtBQWhFLEVBQ0EsQ0FDQztBQUNBLGFBSEQsTUFLZTtBQUNJeU0sMkJBQWEsR0FBR0EsYUFBYSxHQUFHQyxJQUFJLENBQUNDLEdBQUwsQ0FBU3RMLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhNkIsVUFBZCxDQUFSLEdBQW9DaEQsYUFBN0MsQ0FBaEM7O0FBQ0Esc0JBQU9WLFFBQVA7QUFFSSxxQkFBSyxDQUFMO0FBQU87QUFDSG9CLGlDQUFlLEdBQUdBLGVBQWUsR0FBR2dNLElBQUksQ0FBQ0MsR0FBTCxDQUFTdEwsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE2QixVQUFkLENBQVIsR0FBb0NoRCxhQUE3QyxDQUFwQztBQUNBOztBQUNKLHFCQUFLLENBQUw7QUFBTztBQUNIUSwrQkFBYSxHQUFHQSxhQUFhLEdBQUdrTSxJQUFJLENBQUNDLEdBQUwsQ0FBU3RMLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhNkIsVUFBZCxDQUFSLEdBQW9DaEQsYUFBN0MsQ0FBaEM7QUFDQTs7QUFDSjtBQUNJO0FBVFI7O0FBV0Esc0JBQU8yQyxJQUFQO0FBRUkscUJBQUssQ0FBTDtBQUFPO0FBQ0gvQiw0QkFBVSxHQUFHQSxVQUFVLEdBQUc4TCxJQUFJLENBQUNDLEdBQUwsQ0FBU3RMLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhNkIsVUFBZCxDQUFSLEdBQW9DaEQsYUFBN0MsQ0FBMUI7QUFDQTs7QUFDSixxQkFBSyxDQUFMO0FBQU87QUFDSGMsNEJBQVUsR0FBR0EsVUFBVSxHQUFHNEwsSUFBSSxDQUFDQyxHQUFMLENBQVN0TCxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTZCLFVBQWQsQ0FBUixHQUFvQ2hELGFBQTdDLENBQTFCO0FBQ0E7O0FBQ0oscUJBQUssQ0FBTDtBQUFPO0FBQ0hnQiw0QkFBVSxHQUFHdUIsVUFBVSxHQUFHbUssSUFBSSxDQUFDQyxHQUFMLENBQVN0TCxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTZCLFVBQWQsQ0FBUixHQUFvQ2hELGFBQTdDLENBQTFCO0FBQ0E7O0FBQ0oscUJBQUssQ0FBTDtBQUFPO0FBQ0hrQiw0QkFBVSxHQUFHQSxVQUFVLEdBQUd3TCxJQUFJLENBQUNDLEdBQUwsQ0FBU3RMLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhNkIsVUFBZCxDQUFSLEdBQW9DaEQsYUFBN0MsQ0FBMUI7QUFDQTs7QUFDSjtBQUNJO0FBZlI7QUFpQkg7O0FBR2hCLGdCQUFLN0IsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFrTCxRQUFiLElBQXlCLEVBQTFCLElBQWtDbE8sU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFwQyxNQUFiLElBQXVCLENBQTdELEVBQ0E7QUFDQyxvQkFBTXdDLGNBQWMsaUJBQVNqSCxNQUFNLENBQUNrSCxJQUFQLENBQVksNEJBQVosRUFBMENyRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXVCLElBQXZELENBQVQsQ0FBcEI7QUFDa0Isa0JBQUlwQixRQUFRLEdBQVdrTCxhQUFhLEdBQUdDLGFBQXZDOztBQUNsQixrQkFBSWxMLGNBQWMsSUFBSSxFQUF0QixFQUEwQjtBQUV4QjtBQUNBO0FBQ0E7QUFDQTtBQUNELG9CQUFJRCxRQUFRLEdBQUlrTCxhQUFhLEdBQUdDLGFBQWhDO0FBQ0Esb0JBQUkzSixLQUFLLEdBQUcsQ0FBWjs7QUFDQSx3QkFBT3pCLFFBQVEsQ0FBQ3VCLFlBQUQsQ0FBZjtBQUVDLHVCQUFLLENBQUw7QUFDQ0UseUJBQUssR0FBSTBKLGFBQWEsR0FBR0MsYUFBekI7QUFDQTs7QUFDRCx1QkFBSyxDQUFMO0FBQ0MzSix5QkFBSyxHQUFJbkMsVUFBVSxHQUFHQyxVQUF0QjtBQUNBOztBQUNELHVCQUFLLENBQUw7QUFDQ2tDLHlCQUFLLEdBQUlqQyxVQUFVLEdBQUdDLFVBQXRCO0FBQ0E7O0FBQ0QsdUJBQUssQ0FBTDtBQUNDZ0MseUJBQUssR0FBSS9CLFVBQVUsR0FBR0MsVUFBdEI7QUFDQTs7QUFDRCx1QkFBSyxDQUFMO0FBQ0M4Qix5QkFBSyxHQUFJN0IsVUFBVSxHQUFHQyxVQUF0QjtBQUNBO0FBaEJGOztBQWtCQVosMEJBQVUsQ0FBQzdELElBQVgsQ0FBZ0I7QUFDZiwrQkFBYWlHLElBQUksQ0FBQ3RGLE1BQUwsQ0FBWSxPQUFaLEVBQW9CZSxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYWhGLEdBQWpDLENBREU7QUFFZiw4QkFBWXFRLGFBRkc7QUFHZiw4QkFBWUMsYUFIRztBQUlmLDBCQUFTbkwsUUFKTTtBQUtmLCtCQUFhZixhQUFhLEdBQUdDLGFBTGQ7QUFNZixpQ0FBZ0JDLGVBQWUsR0FBR0MsZUFObkI7QUFPZixtQ0FBa0JDLFVBQVUsR0FBR0MsVUFQaEI7QUFRZixtQ0FBa0JDLFVBQVUsR0FBR0MsVUFSaEI7QUFTZixtQ0FBa0JDLFVBQVUsR0FBR0MsVUFUaEI7QUFVZixtQ0FBa0JDLFVBQVUsR0FBR0MsVUFWaEI7QUFXZiw2QkFBWWEsVUFBVSxDQUFFZSxLQUFLLEdBQUdmLFVBQVUsQ0FBQ1IsY0FBYyxDQUFDLENBQUQsQ0FBZCxDQUFrQnFDLE1BQW5CLENBQW5CLEdBQWlELEdBQWxELENBQVYsQ0FBaUU1QixPQUFqRSxDQUF5RSxDQUF6RSxDQVhHO0FBWWYsNkJBQVlELFVBQVUsQ0FBRWUsS0FBSyxHQUFHZixVQUFVLENBQUNSLGNBQWMsQ0FBQyxDQUFELENBQWQsQ0FBa0JzQyxNQUFuQixDQUFuQixHQUFpRCxHQUFsRCxDQUFWLENBQWlFN0IsT0FBakUsQ0FBeUUsQ0FBekUsQ0FaRztBQWFmLDhCQUFZRCxVQUFVLENBQUVlLEtBQUssR0FBR2YsVUFBVSxDQUFDUixjQUFjLENBQUMsQ0FBRCxDQUFkLENBQWtCdUMsT0FBbkIsQ0FBbkIsR0FBa0QsR0FBbkQsQ0FBVixDQUFrRTlCLE9BQWxFLENBQTBFLENBQTFFLENBYkc7QUFjZiw2QkFBWUQsVUFBVSxDQUFFZSxLQUFLLEdBQUdmLFVBQVUsQ0FBQ1IsY0FBYyxDQUFDLENBQUQsQ0FBZCxDQUFrQndDLE1BQW5CLENBQW5CLEdBQWlELEdBQWxELENBQVYsQ0FBaUUvQixPQUFqRSxDQUF5RSxDQUF6RSxDQWRHO0FBZWYsbUNBQWdCRCxVQUFVLENBQUVlLEtBQUssR0FBR2YsVUFBVSxDQUFDUixjQUFjLENBQUMsQ0FBRCxDQUFkLENBQWtCeUMsU0FBbkIsQ0FBbkIsR0FBb0QsR0FBckQsQ0FBVixDQUFvRWhDLE9BQXBFLENBQTRFLENBQTVFLENBZkQ7QUFnQmYsOEJBQWFELFVBQVUsQ0FBRWUsS0FBSyxHQUFHZixVQUFVLENBQUNSLGNBQWMsQ0FBQyxDQUFELENBQWQsQ0FBa0IwQyxPQUFuQixDQUFuQixHQUFrRCxHQUFuRCxDQUFWLENBQWtFakMsT0FBbEUsQ0FBMEUsQ0FBMUUsQ0FoQkU7QUFpQmYsNkJBQVlELFVBQVUsQ0FBRWUsS0FBSyxHQUFHZixVQUFVLENBQUNSLGNBQWMsQ0FBQyxDQUFELENBQWQsQ0FBa0IyQyxNQUFuQixDQUFuQixHQUFpRCxHQUFsRCxDQUFWLENBQWlFbEMsT0FBakUsQ0FBeUUsQ0FBekUsQ0FqQkc7QUFrQmYsMEJBQVFELFVBQVUsQ0FBRWUsS0FBSyxHQUFHZixVQUFVLENBQUNSLGNBQWMsQ0FBQyxDQUFELENBQWQsQ0FBa0I0QyxJQUFuQixDQUFuQixHQUErQyxHQUFoRCxDQUFWLENBQStEbkMsT0FBL0QsQ0FBdUUsQ0FBdkUsQ0FsQk87QUFtQmYsNkJBQVlELFVBQVUsQ0FBRWUsS0FBSyxHQUFHZixVQUFVLENBQUNSLGNBQWMsQ0FBQyxDQUFELENBQWQsQ0FBa0I2QyxNQUFuQixDQUFuQixHQUFpRCxHQUFsRCxDQUFWLENBQWlFcEMsT0FBakUsQ0FBeUUsQ0FBekU7QUFuQkcsaUJBQWhCO0FBcUJBLGVBL0NELE1BaURBO0FBQ0MxQiwwQkFBVSxDQUFDN0QsSUFBWCxDQUFnQjtBQUNmLCtCQUFhaUcsSUFBSSxDQUFDdEYsTUFBTCxDQUFZLE9BQVosRUFBb0JlLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhaEYsR0FBakMsQ0FERTtBQUVmLDhCQUFZcVEsYUFGRztBQUdmLDhCQUFZQyxhQUhHO0FBSWYsMEJBQVNuTCxRQUpNO0FBS2YsK0JBQWFmLGFBQWEsR0FBR0MsYUFMZDtBQU1mLGlDQUFnQkMsZUFBZSxHQUFHQyxlQU5uQjtBQU9mLG1DQUFrQkMsVUFBVSxHQUFHQyxVQVBoQjtBQVFmLG1DQUFrQkMsVUFBVSxHQUFHQyxVQVJoQjtBQVNmLG1DQUFrQkMsVUFBVSxHQUFHQyxVQVRoQjtBQVVmLG1DQUFrQkMsVUFBVSxHQUFHQztBQVZoQixpQkFBaEI7QUFhQTs7QUFFRGYsc0JBQVEsQ0FBQzFELElBQVQsQ0FDQ3dGLE1BQU0sQ0FBQ3VLLGFBQUQsQ0FEUDtBQUdBcE0sc0JBQVEsQ0FBQzNELElBQVQsQ0FDQ3dGLE1BQU0sQ0FBQ3dLLGFBQUQsQ0FEUDtBQUdBcE0sc0JBQVEsQ0FBQzVELElBQVQsQ0FDQ3FQLFFBREQ7QUFHQVUsMkJBQWEsR0FBSSxDQUFqQjtBQUNBQywyQkFBYSxHQUFJLENBQWpCO0FBQ0FsTSwyQkFBYSxHQUFJLENBQWpCO0FBQ0FDLDJCQUFhLEdBQUksQ0FBakI7QUFDQUMsNkJBQWUsR0FBSSxDQUFuQjtBQUNBQyw2QkFBZSxHQUFJLENBQW5CO0FBQ0FDLHdCQUFVLEdBQUcsQ0FBYjtBQUNBQyx3QkFBVSxHQUFHLENBQWI7QUFDQUMsd0JBQVUsR0FBRyxDQUFiO0FBQ0FDLHdCQUFVLEdBQUcsQ0FBYjtBQUNBQyx3QkFBVSxHQUFHLENBQWI7QUFDQUMsd0JBQVUsR0FBRyxDQUFiO0FBQ0FDLHdCQUFVLEdBQUcsQ0FBYjtBQUNBQyx3QkFBVSxHQUFHLENBQWI7QUFDQXFMLHFCQUFPLEdBQUtwTyxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXBDLE1BQXpCO0FBQ0EyRCxrQkFBSSxHQUFLdkUsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFoRixHQUF0QjtBQUNBK0Qsc0JBQVEsR0FBSS9CLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhdUIsSUFBekI7QUFDQW9KLHNCQUFRLEdBQUkzTixTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTJLLFFBQXpCO0FBQ0F4TSxzQkFBUSxHQUFJK0IsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE3QixRQUFkLENBQXBCO0FBQ0FxRCxrQkFBSSxHQUFLdEIsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWF3QixJQUFkLENBQWpCO0FBQ0E1QywyQkFBYSxHQUFHc0IsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE0QixVQUFkLENBQXhCO0FBQ0EvQywyQkFBYSxHQUFHcUIsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE2QixVQUFkLENBQXhCO0FBQ0E7O0FBRUR1SixtQkFBTyxHQUFLbEwsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFwQyxNQUFkLENBQXBCO0FBQ0FnQix5QkFBYSxHQUFHc0IsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE0QixVQUFkLENBQXhCO0FBQ0EvQyx5QkFBYSxHQUFHcUIsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE2QixVQUFkLENBQXhCO0FBQ0E7QUFDRDs7QUFFRDVILGlCQUFTLENBQUNxQixJQUFWLENBQWU7QUFDZE4sYUFBRyxFQUFFLFVBRFM7QUFFZEssY0FBSSxFQUFFLEtBRlE7QUFHZGdHLGVBQUssRUFBRSxTQUhPO0FBSWRDLGNBQUksRUFBRXRDLFFBSlE7QUFLZHVDLGNBQUksRUFBRXJDO0FBTFEsU0FBZjtBQU9BakYsaUJBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkTixhQUFHLEVBQUUsVUFEUztBQUVkSyxjQUFJLEVBQUUsS0FGUTtBQUdkZ0csZUFBSyxFQUFFLFNBSE87QUFJZEMsY0FBSSxFQUFFckMsUUFKUTtBQUtkc0MsY0FBSSxFQUFFckM7QUFMUSxTQUFmO0FBT0FqRixpQkFBUyxDQUFDcUIsSUFBVixDQUFlO0FBQ2ROLGFBQUcsRUFBRSxRQURTO0FBRWRzRyxjQUFJLEVBQUVuQztBQUZRLFNBQWY7QUFJQSxlQUFPbEYsU0FBUDtBQUNBLE9BbFREO0FBQUEsS0F0YWM7O0FBeXRCZDtBQUNNLDhDQUFOLENBQWlEOEMsU0FBakQsRUFBMkRSLE9BQTNEO0FBQUEsc0NBQW9FO0FBQ25FLFlBQUl0QyxTQUFTLEdBQUksRUFBakI7QUFDQSxZQUFJK0MsU0FBUyxHQUFHLEVBQWhCLENBRm1FLENBR25FOztBQUNBLGNBQU1DLE1BQU0saUJBQVN5TixnQkFBZ0IsQ0FBQ3hOLGFBQWpCLEdBQWlDQyxTQUFqQyxDQUEyQyxDQUMvRDtBQUFDQyxnQkFBTSxFQUFFO0FBQUUzQixxQkFBUyxFQUFFO0FBQUVlLGtCQUFJLEVBQUVPLFNBQVI7QUFBbUJOLGtCQUFJLEVBQUVGO0FBQXpCO0FBQWI7QUFBVCxTQUQrRCxFQUUvRDtBQUFDYyxjQUFJLEVBQUU7QUFBRUMsa0JBQU0sRUFBRTtBQUFFQywyQkFBYSxFQUFFO0FBQUVDLHNCQUFNLEVBQUUsYUFBVjtBQUF5QkMsb0JBQUksRUFBRTtBQUFDQyxzQkFBSSxFQUFHLENBQUMsSUFBSWhDLElBQUosQ0FBUyxDQUFULENBQUQsRUFBYyxZQUFkO0FBQVIsaUJBQS9CO0FBQXNFaUMsd0JBQVEsRUFBRTtBQUFoRjtBQUFqQjtBQUFWO0FBQVAsU0FGK0QsRUFHL0Q7QUFBQ0ssa0JBQVEsRUFDUjtBQUNDaEQsZUFBRyxFQUFDLFNBREw7QUFFQzRHLHNCQUFVLEVBQUU7QUFDWGdKLHFCQUFPLEVBQUU7QUFDTkMscUJBQUssRUFBRSxPQUREO0FBRU5qRixrQkFBRSxFQUFFLE1BRkU7QUFHTmtGLG9CQUFJLEVBQUU7QUFBRUMscUJBQUcsRUFBRSxDQUFFLFVBQUYsRUFBYyxDQUFDLENBQUQsQ0FBZDtBQUFQO0FBSEE7QUFERSxhQUZiO0FBU0NsSixzQkFBVSxFQUFFO0FBQ1grSSxxQkFBTyxFQUFFO0FBQ05DLHFCQUFLLEVBQUUsT0FERDtBQUVOakYsa0JBQUUsRUFBRSxNQUZFO0FBR05rRixvQkFBSSxFQUFFO0FBQUVDLHFCQUFHLEVBQUUsQ0FBRSxVQUFGLEVBQWMsQ0FBQyxDQUFELENBQWQ7QUFBUDtBQUhBO0FBREUsYUFUYjtBQWdCQ3hKLGdCQUFJLEVBQUM7QUFoQk47QUFERCxTQUgrRCxFQXVCL0Q7QUFBQzlDLGVBQUssRUFBRztBQUFFLG9CQUFPO0FBQVQ7QUFBVCxTQXZCK0QsRUF3Qi9EO0FBQUNULGtCQUFRLEVBQ1I7QUFDQ2hELGVBQUcsRUFBRyxNQURQO0FBRUM0RyxzQkFBVSxFQUFHO0FBQUVyRCxrQkFBSSxFQUFFO0FBQVIsYUFGZDtBQUdDc0Qsc0JBQVUsRUFBRztBQUFFdEQsa0JBQUksRUFBRTtBQUFSLGFBSGQ7QUFJQ2dELGdCQUFJLEVBQUksT0FKVDtBQUtDM0Qsa0JBQU0sRUFBSTtBQUFFcU4sbUJBQUssRUFBRTtBQUFDeE4sb0JBQUksRUFBRTtBQUFDQyxzQkFBSSxFQUFHLENBQUMsSUFBSWhDLElBQUosQ0FBUyxDQUFULENBQUQsRUFBYyxPQUFkO0FBQVIsaUJBQVA7QUFBeUNpQyx3QkFBUSxFQUFFO0FBQW5EO0FBQVQsYUFMWDtBQU1DdU4sb0JBQVEsRUFBRztBQUFFQyxxQkFBTyxFQUFFO0FBQUUxTixvQkFBSSxFQUFFO0FBQUNDLHNCQUFJLEVBQUcsQ0FBQyxJQUFJaEMsSUFBSixDQUFTLENBQVQsQ0FBRCxFQUFjLE9BQWQ7QUFBUixpQkFBUjtBQUEwQ2lDLHdCQUFRLEVBQUU7QUFBcEQ7QUFBWDtBQU5aO0FBREQsU0F4QitELENBQTNDLEVBa0NsQnpDLE9BbENrQixDQWtDVixVQUFTQyxHQUFULEVBQWM7QUFDeEI2QixtQkFBUyxDQUFDMUIsSUFBVixDQUFlSCxHQUFmO0FBQ0EsU0FwQ29CLENBQVQsQ0FBWjtBQXNDQSxZQUFJeUQsYUFBYSxHQUFHLENBQXBCO0FBQ0EsWUFBSUMsYUFBYSxHQUFHLENBQXBCO0FBQ0EsWUFBSXVNLE9BQU8sR0FBSyxDQUFoQjtBQUNBLFlBQUl0TSxVQUFVLEdBQUksQ0FBbEI7QUFDQSxZQUFJMk0sU0FBUyxHQUFJLENBQWpCO0FBQ0EsWUFBSUMsU0FBUyxHQUFJLENBQWpCO0FBQ0EsWUFBSUwsYUFBYSxHQUFHLENBQXBCO0FBQ0EsWUFBSUMsYUFBYSxHQUFHLENBQXBCO0FBQ0EsWUFBSTNKLEtBQUssR0FBRyxDQUFaO0FBQ0EsWUFBSUosSUFBSSxHQUFHLEVBQVg7QUFDQSxZQUFJdkMsUUFBUSxHQUFHLEVBQWY7QUFDQSxZQUFJQyxRQUFRLEdBQUcsRUFBZjtBQUNBLFlBQUlDLFFBQVEsR0FBRyxFQUFmO0FBQ0EsWUFBSUMsVUFBVSxHQUFDLEVBQWY7O0FBRUEsYUFBSyxJQUFJYSxDQUFDLEdBQUMsQ0FBWCxFQUFjQSxDQUFDLEdBQUdoRCxTQUFTLENBQUNkLE1BQTVCLEVBQW9DOEQsQ0FBQyxFQUFyQyxFQUNBO0FBQ0MsY0FBS2xCLFVBQVUsSUFBRSxDQUFiLElBQW9COUIsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFwQyxNQUFiLElBQXVCLEVBQS9DLEVBQ0E7QUFDQ3dOLG1CQUFPLEdBQUtwTyxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXBDLE1BQXpCO0FBQ0EyRCxnQkFBSSxHQUFLdkUsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFoRixHQUF0QjtBQUNBNEQseUJBQWEsR0FBR3NCLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhNEIsVUFBZCxDQUF4QjtBQUNBL0MseUJBQWEsR0FBR3FCLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhNkIsVUFBZCxDQUF4QjtBQUNBL0Msc0JBQVUsR0FBRyxDQUFiO0FBQ0EsV0FQRCxNQU9PLElBQUlBLFVBQVUsSUFBRSxDQUFoQixFQUNQO0FBQ0M7QUFDQTtBQUNDdU0seUJBQWEsR0FBR0EsYUFBYSxHQUFHRSxJQUFJLENBQUNDLEdBQUwsQ0FBU3RMLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhNEIsVUFBZCxDQUFSLEdBQW9DaEQsYUFBN0MsQ0FBaEMsQ0FIRixDQUlDO0FBQ0E7QUFDQTs7QUFDQzBNLHlCQUFhLEdBQUdBLGFBQWEsR0FBR0MsSUFBSSxDQUFDQyxHQUFMLENBQVN0TCxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTZCLFVBQWQsQ0FBUixHQUFvQ2hELGFBQTdDLENBQWhDLENBUEYsQ0FRQztBQUNBOztBQUNBLGdCQUFJN0IsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFrTCxRQUFiLElBQXlCLENBQTdCLEVBQ0E7QUFDQy9MLHdCQUFVLENBQUM3RCxJQUFYLENBQWdCO0FBQ2ZpRyxvQkFBSSxFQUFFQSxJQUFJLENBQUN0RixNQUFMLENBQVksT0FBWixFQUFvQmUsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFoRixHQUFqQyxDQURTO0FBRWYrRyxxQkFBSyxFQUFFLEVBRlE7QUFHZkMsdUJBQU8sRUFBRXFKLGFBSE07QUFJZnBKLHVCQUFPLEVBQUVxSixhQUpNO0FBS2YzSixxQkFBSyxFQUFJO0FBTE0sZUFBaEI7QUFPQThKLHVCQUFTLEdBQUdBLFNBQVMsR0FBR0osYUFBeEI7QUFDQUssdUJBQVMsR0FBR0EsU0FBUyxHQUFHSixhQUF4QjtBQUVBM0osbUJBQUssR0FBRzhKLFNBQVMsR0FBR0MsU0FBcEI7QUFFQTFNLHNCQUFRLENBQUMxRCxJQUFULENBQ0N3RixNQUFNLENBQUN1SyxhQUFELENBRFA7QUFHQXBNLHNCQUFRLENBQUMzRCxJQUFULENBQ0N3RixNQUFNLENBQUN3SyxhQUFELENBRFA7QUFHQXBNLHNCQUFRLENBQUM1RCxJQUFULENBQ0M4UCxPQURELEVBbkJELENBc0JDOztBQUNBLGtCQUFJcE8sU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFwQyxNQUFiLElBQXFCLEVBQXpCLEVBQ0E7QUFDQ3VCLDBCQUFVLENBQUM3RCxJQUFYLENBQWdCO0FBQ2ZpRyxzQkFBSSxFQUFFLHNCQURTO0FBRWZRLHVCQUFLLEVBQUMsTUFGUztBQUdmQyx5QkFBTyxFQUFHeUosU0FISztBQUlmeEoseUJBQU8sRUFBR3lKLFNBSks7QUFLZi9KLHVCQUFLLEVBQUdBO0FBTE8saUJBQWhCO0FBT0E4Six5QkFBUyxHQUFLLENBQWQ7QUFDQUMseUJBQVMsR0FBSyxDQUFkO0FBQ0EsZUFYRCxNQVdPLElBQUkxTyxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXBDLE1BQWIsSUFBcUIsQ0FBekIsRUFDUDtBQUNDdUIsMEJBQVUsQ0FBQzdELElBQVgsQ0FBZ0I7QUFDZmlHLHNCQUFJLEVBQUUsbUJBRFM7QUFFZlEsdUJBQUssRUFBQyxNQUZTO0FBR2ZDLHlCQUFPLEVBQUd5SixTQUhLO0FBSWZ4Six5QkFBTyxFQUFHeUosU0FKSztBQUtmL0osdUJBQUssRUFBR0E7QUFMTyxpQkFBaEI7QUFPQThKLHlCQUFTLEdBQUssQ0FBZDtBQUNBQyx5QkFBUyxHQUFLLENBQWQ7QUFDQTs7QUFBQyxrQkFBSTFPLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhcEMsTUFBYixJQUFxQixFQUF6QixFQUNGO0FBQ0N1QiwwQkFBVSxDQUFDN0QsSUFBWCxDQUFnQjtBQUNmaUcsc0JBQUksRUFBRSxvQkFEUztBQUVmUSx1QkFBSyxFQUFDLE1BRlM7QUFHZkMseUJBQU8sRUFBR3lKLFNBSEs7QUFJZnhKLHlCQUFPLEVBQUd5SixTQUpLO0FBS2YvSix1QkFBSyxFQUFHQTtBQUxPLGlCQUFoQjtBQU9BOEoseUJBQVMsR0FBSyxDQUFkO0FBQ0FDLHlCQUFTLEdBQUssQ0FBZDtBQUVBOztBQUNETCwyQkFBYSxHQUFJLENBQWpCO0FBQ0FDLDJCQUFhLEdBQUksQ0FBakI7QUFDQS9KLGtCQUFJLEdBQUt2RSxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYWhGLEdBQXRCO0FBQ0E7O0FBRURvUSxtQkFBTyxHQUFLbEwsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFwQyxNQUFkLENBQXBCO0FBQ0FnQix5QkFBYSxHQUFHc0IsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE0QixVQUFkLENBQXhCO0FBQ0EvQyx5QkFBYSxHQUFHcUIsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE2QixVQUFkLENBQXhCO0FBQ0E7QUFDRDs7QUFFRDVILGlCQUFTLENBQUNxQixJQUFWLENBQWU7QUFDZE4sYUFBRyxFQUFFLFVBRFM7QUFFZEssY0FBSSxFQUFFLEtBRlE7QUFHZGdHLGVBQUssRUFBRSxTQUhPO0FBSWRDLGNBQUksRUFBRXRDLFFBSlE7QUFLZHVDLGNBQUksRUFBRXJDO0FBTFEsU0FBZjtBQU9BakYsaUJBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkTixhQUFHLEVBQUUsVUFEUztBQUVkSyxjQUFJLEVBQUUsS0FGUTtBQUdkZ0csZUFBSyxFQUFFLFNBSE87QUFJZEMsY0FBSSxFQUFFckMsUUFKUTtBQUtkc0MsY0FBSSxFQUFFckM7QUFMUSxTQUFmO0FBT0FqRixpQkFBUyxDQUFDcUIsSUFBVixDQUFlO0FBQ2ROLGFBQUcsRUFBRSxRQURTO0FBRWRzRyxjQUFJLEVBQUVuQztBQUZRLFNBQWY7QUFJQSxlQUFPbEYsU0FBUDtBQUNBLE9BdEtEO0FBQUEsS0ExdEJjOztBQWk0QmQ7QUFDTSw2Q0FBTixDQUFnRDhDLFNBQWhELEVBQTBEUixPQUExRDtBQUFBLHNDQUFtRTtBQUNsRSxZQUFJdEMsU0FBUyxHQUFJLEVBQWpCO0FBQ0EsWUFBSStDLFNBQVMsR0FBRyxFQUFoQixDQUZrRSxDQUdsRTs7QUFDQSxjQUFNQyxNQUFNLGlCQUFTeU4sZ0JBQWdCLENBQUN4TixhQUFqQixHQUFpQ0MsU0FBakMsQ0FBMkMsQ0FDL0Q7QUFBQ0MsZ0JBQU0sRUFBRTtBQUFFM0IscUJBQVMsRUFBRTtBQUFFZSxrQkFBSSxFQUFFTyxTQUFSO0FBQW1CTixrQkFBSSxFQUFFRjtBQUF6QjtBQUFiO0FBQVQsU0FEK0QsRUFFL0Q7QUFBQ2MsY0FBSSxFQUFFO0FBQUVDLGtCQUFNLEVBQUU7QUFBRUMsMkJBQWEsRUFBRTtBQUFFQyxzQkFBTSxFQUFFLGFBQVY7QUFBeUJDLG9CQUFJLEVBQUU7QUFBQ0Msc0JBQUksRUFBRyxDQUFDLElBQUloQyxJQUFKLENBQVMsQ0FBVCxDQUFELEVBQWMsWUFBZDtBQUFSLGlCQUEvQjtBQUFzRWlDLHdCQUFRLEVBQUU7QUFBaEY7QUFBakI7QUFBVjtBQUFQLFNBRitELEVBRy9EO0FBQUNLLGtCQUFRLEVBQ1I7QUFDQ2hELGVBQUcsRUFBQyxTQURMO0FBRUM0RyxzQkFBVSxFQUFFO0FBQ1hnSixxQkFBTyxFQUFFO0FBQ05DLHFCQUFLLEVBQUUsT0FERDtBQUVOakYsa0JBQUUsRUFBRSxNQUZFO0FBR05rRixvQkFBSSxFQUFFO0FBQUVDLHFCQUFHLEVBQUUsQ0FBRSxVQUFGLEVBQWMsQ0FBQyxDQUFELENBQWQ7QUFBUDtBQUhBO0FBREUsYUFGYjtBQVNDbEosc0JBQVUsRUFBRTtBQUNYK0kscUJBQU8sRUFBRTtBQUNOQyxxQkFBSyxFQUFFLE9BREQ7QUFFTmpGLGtCQUFFLEVBQUUsTUFGRTtBQUdOa0Ysb0JBQUksRUFBRTtBQUFFQyxxQkFBRyxFQUFFLENBQUUsVUFBRixFQUFjLENBQUMsQ0FBRCxDQUFkO0FBQVA7QUFIQTtBQURFLGFBVGI7QUFnQkN4SixnQkFBSSxFQUFDO0FBaEJOO0FBREQsU0FIK0QsRUF1Qi9EO0FBQUM5QyxlQUFLLEVBQUc7QUFBRSxvQkFBTztBQUFUO0FBQVQsU0F2QitELEVBd0IvRDtBQUFDVCxrQkFBUSxFQUNSO0FBQ0NoRCxlQUFHLEVBQUcsTUFEUDtBQUVDNEcsc0JBQVUsRUFBRztBQUFFckQsa0JBQUksRUFBRTtBQUFSLGFBRmQ7QUFHQ3NELHNCQUFVLEVBQUc7QUFBRXRELGtCQUFJLEVBQUU7QUFBUixhQUhkO0FBSUNnRCxnQkFBSSxFQUFJLE9BSlQ7QUFLQzNELGtCQUFNLEVBQUk7QUFBRXFOLG1CQUFLLEVBQUU7QUFBQ3hOLG9CQUFJLEVBQUU7QUFBQ0Msc0JBQUksRUFBRyxDQUFDLElBQUloQyxJQUFKLENBQVMsQ0FBVCxDQUFELEVBQWMsT0FBZDtBQUFSLGlCQUFQO0FBQXlDaUMsd0JBQVEsRUFBRTtBQUFuRDtBQUFULGFBTFg7QUFNQ3VOLG9CQUFRLEVBQUc7QUFBRUMscUJBQU8sRUFBRTtBQUFFMU4sb0JBQUksRUFBRTtBQUFDQyxzQkFBSSxFQUFHLENBQUMsSUFBSWhDLElBQUosQ0FBUyxDQUFULENBQUQsRUFBYyxPQUFkO0FBQVIsaUJBQVI7QUFBMENpQyx3QkFBUSxFQUFFO0FBQXBEO0FBQVg7QUFOWjtBQURELFNBeEIrRCxDQUEzQyxFQWtDbEJ6QyxPQWxDa0IsQ0FrQ1YsVUFBU0MsR0FBVCxFQUFjO0FBQ3hCNkIsbUJBQVMsQ0FBQzFCLElBQVYsQ0FBZUgsR0FBZjtBQUNBLFNBcENvQixDQUFULENBQVo7QUFzQ0EsWUFBSXlELGFBQWEsR0FBRyxDQUFwQjtBQUNBLFlBQUlDLGFBQWEsR0FBRyxDQUFwQjtBQUNBLFlBQUl1TSxPQUFPLEdBQUssQ0FBaEI7QUFDQSxZQUFJdE0sVUFBVSxHQUFJLENBQWxCO0FBQ0EsWUFBSTJNLFNBQVMsR0FBSSxDQUFqQjtBQUNBLFlBQUlDLFNBQVMsR0FBSSxDQUFqQjtBQUNBLFlBQUlMLGFBQWEsR0FBRyxDQUFwQjtBQUNBLFlBQUlDLGFBQWEsR0FBRyxDQUFwQjtBQUNBLFlBQUkzSixLQUFLLEdBQUcsQ0FBWjtBQUNBLFlBQUlKLElBQUksR0FBRyxFQUFYO0FBQ0EsWUFBSXZDLFFBQVEsR0FBRyxFQUFmO0FBQ0EsWUFBSUMsUUFBUSxHQUFHLEVBQWY7QUFDQSxZQUFJQyxRQUFRLEdBQUcsRUFBZjtBQUNBLFlBQUlDLFVBQVUsR0FBQyxFQUFmOztBQUVBLGFBQUssSUFBSWEsQ0FBQyxHQUFDLENBQVgsRUFBY0EsQ0FBQyxHQUFHaEQsU0FBUyxDQUFDZCxNQUE1QixFQUFvQzhELENBQUMsRUFBckMsRUFDQTtBQUNDLGNBQUtsQixVQUFVLElBQUUsQ0FBYixJQUFvQjlCLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhcEMsTUFBYixJQUF1QixDQUEzQyxJQUFpRFosU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFrTCxRQUFiLElBQXlCLEVBQTlFLEVBQ0E7QUFDQ0UsbUJBQU8sR0FBS3BPLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhcEMsTUFBekI7QUFDQTJELGdCQUFJLEdBQUt2RSxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYWhGLEdBQXRCO0FBQ0E0RCx5QkFBYSxHQUFHc0IsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE0QixVQUFkLENBQXhCO0FBQ0EvQyx5QkFBYSxHQUFHcUIsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE2QixVQUFkLENBQXhCO0FBQ0EvQyxzQkFBVSxHQUFHLENBQWI7QUFDQSxXQVBELE1BT08sSUFBSUEsVUFBVSxJQUFFLENBQWhCLEVBQ1A7QUFDQyxnQkFBSXlNLElBQUksQ0FBQ0MsR0FBTCxDQUFTdEwsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE0QixVQUFkLENBQVIsR0FBb0NoRCxhQUE3QyxJQUE0RCxLQUFoRSxFQUNBLENBQ0M7QUFDQSxhQUhELE1BS2U7QUFDSXlNLDJCQUFhLEdBQUdBLGFBQWEsR0FBR0UsSUFBSSxDQUFDQyxHQUFMLENBQVN0TCxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTRCLFVBQWQsQ0FBUixHQUFvQ2hELGFBQTdDLENBQWhDO0FBQ0g7O0FBQ2hCLGdCQUFJMk0sSUFBSSxDQUFDQyxHQUFMLENBQVN0TCxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTZCLFVBQWQsQ0FBUixHQUFvQ2hELGFBQTdDLElBQTRELEtBQWhFLEVBQ0EsQ0FDQztBQUNBLGFBSEQsTUFLZTtBQUNJeU0sMkJBQWEsR0FBR0EsYUFBYSxHQUFHQyxJQUFJLENBQUNDLEdBQUwsQ0FBU3RMLFFBQVEsQ0FBQ2xELFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhNkIsVUFBZCxDQUFSLEdBQW9DaEQsYUFBN0MsQ0FBaEM7QUFDSDs7QUFFaEIsZ0JBQUk3QixTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYWtMLFFBQWIsSUFBeUIsRUFBN0IsRUFDQTtBQUNDL0wsd0JBQVUsQ0FBQzdELElBQVgsQ0FBZ0I7QUFDZmlHLG9CQUFJLEVBQUVBLElBQUksQ0FBQ3RGLE1BQUwsQ0FBWSxPQUFaLEVBQW9CZSxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYWhGLEdBQWpDLENBRFM7QUFFZitHLHFCQUFLLEVBQUUsRUFGUTtBQUdmQyx1QkFBTyxFQUFFcUosYUFITTtBQUlmcEosdUJBQU8sRUFBRXFKLGFBSk07QUFLZjNKLHFCQUFLLEVBQUk7QUFMTSxlQUFoQjtBQU9BOEosdUJBQVMsR0FBR0EsU0FBUyxHQUFHSixhQUF4QjtBQUNBSyx1QkFBUyxHQUFHQSxTQUFTLEdBQUdKLGFBQXhCO0FBRUEzSixtQkFBSyxHQUFHOEosU0FBUyxHQUFHQyxTQUFwQjtBQUVBMU0sc0JBQVEsQ0FBQzFELElBQVQsQ0FDQ3dGLE1BQU0sQ0FBQ3VLLGFBQUQsQ0FEUDtBQUdBcE0sc0JBQVEsQ0FBQzNELElBQVQsQ0FDQ3dGLE1BQU0sQ0FBQ3dLLGFBQUQsQ0FEUDtBQUdBcE0sc0JBQVEsQ0FBQzVELElBQVQsQ0FDQzhQLE9BREQsRUFuQkQsQ0FzQkM7O0FBQ0Esa0JBQUlwTyxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXBDLE1BQWIsSUFBcUIsRUFBekIsRUFDQTtBQUNDdUIsMEJBQVUsQ0FBQzdELElBQVgsQ0FBZ0I7QUFDZmlHLHNCQUFJLEVBQUUsTUFEUztBQUVmUSx1QkFBSyxFQUFDLE1BRlM7QUFHZkMseUJBQU8sRUFBR3lKLFNBSEs7QUFJZnhKLHlCQUFPLEVBQUd5SixTQUpLO0FBS2YvSix1QkFBSyxFQUFHQTtBQUxPLGlCQUFoQjtBQU9BOEoseUJBQVMsR0FBSyxDQUFkO0FBQ0FDLHlCQUFTLEdBQUssQ0FBZDtBQUNBLGVBWEQsTUFXTyxJQUFJMU8sU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFwQyxNQUFiLElBQXFCLEVBQXpCLEVBQ1A7QUFDQ3VCLDBCQUFVLENBQUM3RCxJQUFYLENBQWdCO0FBQ2ZpRyxzQkFBSSxFQUFFLE1BRFM7QUFFZlEsdUJBQUssRUFBQyxNQUZTO0FBR2ZDLHlCQUFPLEVBQUd5SixTQUhLO0FBSWZ4Six5QkFBTyxFQUFHeUosU0FKSztBQUtmL0osdUJBQUssRUFBR0E7QUFMTyxpQkFBaEI7QUFPQThKLHlCQUFTLEdBQUssQ0FBZDtBQUNBQyx5QkFBUyxHQUFLLENBQWQ7QUFDQTs7QUFBQyxrQkFBSTFPLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhcEMsTUFBYixJQUFxQixDQUF6QixFQUNGO0FBQ0N1QiwwQkFBVSxDQUFDN0QsSUFBWCxDQUFnQjtBQUNmaUcsc0JBQUksRUFBRSxNQURTO0FBRWZRLHVCQUFLLEVBQUMsTUFGUztBQUdmQyx5QkFBTyxFQUFHeUosU0FISztBQUlmeEoseUJBQU8sRUFBR3lKLFNBSks7QUFLZi9KLHVCQUFLLEVBQUdBO0FBTE8saUJBQWhCO0FBT0E4Six5QkFBUyxHQUFLLENBQWQ7QUFDQUMseUJBQVMsR0FBSyxDQUFkO0FBRUE7O0FBQ0RMLDJCQUFhLEdBQUksQ0FBakI7QUFDQUMsMkJBQWEsR0FBSSxDQUFqQjtBQUNBL0osa0JBQUksR0FBS3ZFLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhaEYsR0FBdEI7QUFDQTs7QUFFRG9RLG1CQUFPLEdBQUtsTCxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXBDLE1BQWQsQ0FBcEI7QUFDQWdCLHlCQUFhLEdBQUdzQixRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTRCLFVBQWQsQ0FBeEI7QUFDQS9DLHlCQUFhLEdBQUdxQixRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTZCLFVBQWQsQ0FBeEI7QUFDQTtBQUNEOztBQUVENUgsaUJBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkTixhQUFHLEVBQUUsVUFEUztBQUVkSyxjQUFJLEVBQUUsS0FGUTtBQUdkZ0csZUFBSyxFQUFFLFNBSE87QUFJZEMsY0FBSSxFQUFFdEMsUUFKUTtBQUtkdUMsY0FBSSxFQUFFckM7QUFMUSxTQUFmO0FBT0FqRixpQkFBUyxDQUFDcUIsSUFBVixDQUFlO0FBQ2ROLGFBQUcsRUFBRSxVQURTO0FBRWRLLGNBQUksRUFBRSxLQUZRO0FBR2RnRyxlQUFLLEVBQUUsU0FITztBQUlkQyxjQUFJLEVBQUVyQyxRQUpRO0FBS2RzQyxjQUFJLEVBQUVyQztBQUxRLFNBQWY7QUFPQWpGLGlCQUFTLENBQUNxQixJQUFWLENBQWU7QUFDZE4sYUFBRyxFQUFFLFFBRFM7QUFFZHNHLGNBQUksRUFBRW5DO0FBRlEsU0FBZjtBQUlBLGVBQU9sRixTQUFQO0FBQ0EsT0E5S0Q7QUFBQSxLQWw0QmM7O0FBaWpDZDtBQUNNLDJDQUFOLENBQThDOEMsU0FBOUMsRUFBd0RSLE9BQXhEO0FBQUEsc0NBQWlFO0FBQ2hFLFlBQUl0QyxTQUFTLEdBQUksRUFBakI7QUFDQSxZQUFJK0MsU0FBUyxHQUFHLEVBQWhCLENBRmdFLENBR2hFOztBQUNBLGNBQU1DLE1BQU0saUJBQVN5TixnQkFBZ0IsQ0FBQ3hOLGFBQWpCLEdBQWlDQyxTQUFqQyxDQUEyQyxDQUMvRDtBQUFDQyxnQkFBTSxFQUFFO0FBQUUzQixxQkFBUyxFQUFFO0FBQUVlLGtCQUFJLEVBQUVPLFNBQVI7QUFBbUJOLGtCQUFJLEVBQUVGO0FBQXpCO0FBQWI7QUFBVCxTQUQrRCxFQUUvRDtBQUFDYyxjQUFJLEVBQUU7QUFBRUMsa0JBQU0sRUFBRTtBQUFFQywyQkFBYSxFQUFFO0FBQUVDLHNCQUFNLEVBQUUsYUFBVjtBQUF5QkMsb0JBQUksRUFBRTtBQUFDQyxzQkFBSSxFQUFHLENBQUMsSUFBSWhDLElBQUosQ0FBUyxDQUFULENBQUQsRUFBYyxZQUFkO0FBQVIsaUJBQS9CO0FBQXNFaUMsd0JBQVEsRUFBRTtBQUFoRjtBQUFqQjtBQUFWO0FBQVAsU0FGK0QsRUFHL0Q7QUFBQ0ssa0JBQVEsRUFDUjtBQUNDaEQsZUFBRyxFQUFDLFNBREw7QUFFQzRHLHNCQUFVLEVBQUU7QUFDWGdKLHFCQUFPLEVBQUU7QUFDTkMscUJBQUssRUFBRSxPQUREO0FBRU5qRixrQkFBRSxFQUFFLE1BRkU7QUFHTmtGLG9CQUFJLEVBQUU7QUFBRUMscUJBQUcsRUFBRSxDQUFFLFVBQUYsRUFBYyxDQUFDLENBQUQsQ0FBZDtBQUFQO0FBSEE7QUFERSxhQUZiO0FBU0NsSixzQkFBVSxFQUFFO0FBQ1grSSxxQkFBTyxFQUFFO0FBQ05DLHFCQUFLLEVBQUUsT0FERDtBQUVOakYsa0JBQUUsRUFBRSxNQUZFO0FBR05rRixvQkFBSSxFQUFFO0FBQUVDLHFCQUFHLEVBQUUsQ0FBRSxVQUFGLEVBQWMsQ0FBQyxDQUFELENBQWQ7QUFBUDtBQUhBO0FBREUsYUFUYjtBQWdCQ3hKLGdCQUFJLEVBQUM7QUFoQk47QUFERCxTQUgrRCxFQXVCL0Q7QUFBQzlDLGVBQUssRUFBRztBQUFFLG9CQUFPO0FBQVQ7QUFBVCxTQXZCK0QsRUF3Qi9EO0FBQUNULGtCQUFRLEVBQ1I7QUFDQ2hELGVBQUcsRUFBRyxNQURQO0FBRUM0RyxzQkFBVSxFQUFHO0FBQUVyRCxrQkFBSSxFQUFFO0FBQVIsYUFGZDtBQUdDc0Qsc0JBQVUsRUFBRztBQUFFdEQsa0JBQUksRUFBRTtBQUFSLGFBSGQ7QUFJQ2dELGdCQUFJLEVBQUksT0FKVDtBQUtDM0Qsa0JBQU0sRUFBSTtBQUFFcU4sbUJBQUssRUFBRTtBQUFDeE4sb0JBQUksRUFBRTtBQUFDQyxzQkFBSSxFQUFHLENBQUMsSUFBSWhDLElBQUosQ0FBUyxDQUFULENBQUQsRUFBYyxPQUFkO0FBQVIsaUJBQVA7QUFBeUNpQyx3QkFBUSxFQUFFO0FBQW5EO0FBQVQsYUFMWDtBQU1DdU4sb0JBQVEsRUFBRztBQUFFQyxxQkFBTyxFQUFFO0FBQUUxTixvQkFBSSxFQUFFO0FBQUNDLHNCQUFJLEVBQUcsQ0FBQyxJQUFJaEMsSUFBSixDQUFTLENBQVQsQ0FBRCxFQUFjLE9BQWQ7QUFBUixpQkFBUjtBQUEwQ2lDLHdCQUFRLEVBQUU7QUFBcEQ7QUFBWDtBQU5aO0FBREQsU0F4QitELENBQTNDLEVBa0NsQnpDLE9BbENrQixDQWtDVixVQUFTQyxHQUFULEVBQWM7QUFDeEI2QixtQkFBUyxDQUFDMUIsSUFBVixDQUFlSCxHQUFmO0FBQ0EsU0FwQ29CLENBQVQsQ0FBWjtBQXNDQSxZQUFJeUQsYUFBYSxHQUFHLENBQXBCO0FBQ0EsWUFBSUMsYUFBYSxHQUFHLENBQXBCO0FBQ0EsWUFBSXVNLE9BQU8sR0FBSyxDQUFoQjtBQUNBLFlBQUl0TSxVQUFVLEdBQUksQ0FBbEI7QUFDQSxZQUFJMk0sU0FBUyxHQUFJLENBQWpCO0FBQ0EsWUFBSUMsU0FBUyxHQUFJLENBQWpCO0FBQ0EsWUFBSUwsYUFBYSxHQUFHLENBQXBCO0FBQ0EsWUFBSUMsYUFBYSxHQUFHLENBQXBCO0FBQ0EsWUFBSTNKLEtBQUssR0FBRyxDQUFaO0FBQ0EsWUFBSUosSUFBSSxHQUFHLEVBQVg7QUFDQSxZQUFJdkMsUUFBUSxHQUFHLEVBQWY7QUFDQSxZQUFJQyxRQUFRLEdBQUcsRUFBZjtBQUNBLFlBQUlDLFFBQVEsR0FBRyxFQUFmO0FBQ0EsWUFBSUMsVUFBVSxHQUFDLEVBQWY7O0FBRUEsYUFBSyxJQUFJYSxDQUFDLEdBQUMsQ0FBWCxFQUFjQSxDQUFDLEdBQUdoRCxTQUFTLENBQUNkLE1BQTVCLEVBQW9DOEQsQ0FBQyxFQUFyQyxFQUNBO0FBQ0MsY0FBS2xCLFVBQVUsSUFBRSxDQUFiLElBQW9COUIsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFwQyxNQUFiLElBQXVCLEVBQTNDLElBQWtEWixTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYWtMLFFBQWIsSUFBeUIsRUFBL0UsRUFDQTtBQUNDRSxtQkFBTyxHQUFLcE8sU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWFwQyxNQUF6QjtBQUNBMkQsZ0JBQUksR0FBS3ZFLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhaEYsR0FBdEI7QUFDQTRELHlCQUFhLEdBQUdzQixRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTRCLFVBQWQsQ0FBeEI7QUFDQS9DLHlCQUFhLEdBQUdxQixRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTZCLFVBQWQsQ0FBeEI7QUFDQS9DLHNCQUFVLEdBQUcsQ0FBYjtBQUNBLFdBUEQsTUFPTyxJQUFJQSxVQUFVLElBQUUsQ0FBaEIsRUFDUDtBQUNDO0FBQ0E7QUFDQ3VNLHlCQUFhLEdBQUdBLGFBQWEsR0FBR0UsSUFBSSxDQUFDQyxHQUFMLENBQVN0TCxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTRCLFVBQWQsQ0FBUixHQUFvQ2hELGFBQTdDLENBQWhDLENBSEYsQ0FJQztBQUNBO0FBQ0E7O0FBQ0MwTSx5QkFBYSxHQUFHQSxhQUFhLEdBQUdDLElBQUksQ0FBQ0MsR0FBTCxDQUFTdEwsUUFBUSxDQUFDbEQsU0FBUyxDQUFDZ0QsQ0FBRCxDQUFULENBQWE2QixVQUFkLENBQVIsR0FBb0NoRCxhQUE3QyxDQUFoQyxDQVBGLENBUUM7QUFDQTs7QUFFQSxnQkFBSTdCLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFha0wsUUFBYixJQUF5QixFQUE3QixFQUNBO0FBQ0MvTCx3QkFBVSxDQUFDN0QsSUFBWCxDQUFnQjtBQUNmaUcsb0JBQUksRUFBRUEsSUFBSSxDQUFDdEYsTUFBTCxDQUFZLE9BQVosRUFBb0JlLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhaEYsR0FBakMsQ0FEUztBQUVmK0cscUJBQUssRUFBRSxFQUZRO0FBR2ZDLHVCQUFPLEVBQUVxSixhQUhNO0FBSWZwSix1QkFBTyxFQUFFcUosYUFKTTtBQUtmM0oscUJBQUssRUFBSTtBQUxNLGVBQWhCO0FBT0E4Six1QkFBUyxHQUFHQSxTQUFTLEdBQUdKLGFBQXhCO0FBQ0FLLHVCQUFTLEdBQUdBLFNBQVMsR0FBR0osYUFBeEI7QUFFQTNKLG1CQUFLLEdBQUc4SixTQUFTLEdBQUdDLFNBQXBCO0FBRUExTSxzQkFBUSxDQUFDMUQsSUFBVCxDQUNDd0YsTUFBTSxDQUFDdUssYUFBRCxDQURQO0FBR0FwTSxzQkFBUSxDQUFDM0QsSUFBVCxDQUNDd0YsTUFBTSxDQUFDd0ssYUFBRCxDQURQO0FBR0FwTSxzQkFBUSxDQUFDNUQsSUFBVCxDQUNDOFAsT0FERDs7QUFHa0Isa0JBQUlwTyxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXBDLE1BQWIsSUFBdUIsRUFBM0IsRUFDbEI7QUFDQ3VCLDBCQUFVLENBQUM3RCxJQUFYLENBQWdCO0FBQ2ZpRyxzQkFBSSxFQUFFLHFDQURTO0FBRWZRLHVCQUFLLEVBQUMsTUFGUztBQUdmQyx5QkFBTyxFQUFHeUosU0FISztBQUlmeEoseUJBQU8sRUFBR3lKLFNBSks7QUFLZi9KLHVCQUFLLEVBQUdBO0FBTE8saUJBQWhCO0FBT0E4Six5QkFBUyxHQUFLLENBQWQ7QUFDQUMseUJBQVMsR0FBSyxDQUFkO0FBRUE7O0FBQ0RMLDJCQUFhLEdBQUksQ0FBakI7QUFDQUMsMkJBQWEsR0FBSSxDQUFqQjtBQUNBL0osa0JBQUksR0FBS3ZFLFNBQVMsQ0FBQ2dELENBQUQsQ0FBVCxDQUFhaEYsR0FBdEI7QUFDQTs7QUFFRG9RLG1CQUFPLEdBQUtsTCxRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYXBDLE1BQWQsQ0FBcEI7QUFDQWdCLHlCQUFhLEdBQUdzQixRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTRCLFVBQWQsQ0FBeEI7QUFDQS9DLHlCQUFhLEdBQUdxQixRQUFRLENBQUNsRCxTQUFTLENBQUNnRCxDQUFELENBQVQsQ0FBYTZCLFVBQWQsQ0FBeEI7QUFDQTtBQUNEOztBQUVENUgsaUJBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkTixhQUFHLEVBQUUsVUFEUztBQUVkSyxjQUFJLEVBQUUsS0FGUTtBQUdkZ0csZUFBSyxFQUFFLFNBSE87QUFJZEMsY0FBSSxFQUFFdEMsUUFKUTtBQUtkdUMsY0FBSSxFQUFFckM7QUFMUSxTQUFmO0FBT0FqRixpQkFBUyxDQUFDcUIsSUFBVixDQUFlO0FBQ2ROLGFBQUcsRUFBRSxVQURTO0FBRWRLLGNBQUksRUFBRSxLQUZRO0FBR2RnRyxlQUFLLEVBQUUsU0FITztBQUlkQyxjQUFJLEVBQUVyQyxRQUpRO0FBS2RzQyxjQUFJLEVBQUVyQztBQUxRLFNBQWY7QUFPQWpGLGlCQUFTLENBQUNxQixJQUFWLENBQWU7QUFDZE4sYUFBRyxFQUFFLFFBRFM7QUFFZHNHLGNBQUksRUFBRW5DO0FBRlEsU0FBZjtBQUlBLGVBQU9sRixTQUFQO0FBQ0EsT0FoSkQ7QUFBQTs7QUFsakNjLEdBQWY7QUFvc0NBLEM7Ozs7Ozs7Ozs7O0FDM3NDRGpCLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUMwUyxjQUFZLEVBQUMsTUFBSUE7QUFBbEIsQ0FBZDtBQUErQyxJQUFJeFMsTUFBSjtBQUFXSCxNQUFNLENBQUNJLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxLQUFKO0FBQVVOLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0UsT0FBSyxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsU0FBSyxHQUFDRCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUk4SSxRQUFKO0FBQWFuSixNQUFNLENBQUNJLElBQVAsQ0FBWSxZQUFaLEVBQXlCO0FBQUNnSixTQUFPLENBQUMvSSxDQUFELEVBQUc7QUFBQzhJLFlBQVEsR0FBQzlJLENBQVQ7QUFBVzs7QUFBdkIsQ0FBekIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXlOLGFBQUo7QUFBa0I5TixNQUFNLENBQUNJLElBQVAsQ0FBWSxvQkFBWixFQUFpQztBQUFDZ0osU0FBTyxDQUFDL0ksQ0FBRCxFQUFHO0FBQUN5TixpQkFBYSxHQUFDek4sQ0FBZDtBQUFnQjs7QUFBNUIsQ0FBakMsRUFBK0QsQ0FBL0Q7QUFNeFAsTUFBTXNTLFlBQVksR0FBRyxJQUFJclMsS0FBSyxDQUFDQyxVQUFWLENBQXFCLGNBQXJCLENBQXJCOztBQUVQLElBQUlKLE1BQU0sQ0FBQ0ssUUFBWCxFQUFxQjtBQUNwQjtBQUNBTCxRQUFNLENBQUNNLE9BQVAsQ0FBZSxtQkFBZixFQUFvQyxTQUFTbVMsaUJBQVQsQ0FBMkIvUixJQUEzQixFQUFnQ08sT0FBaEMsRUFBeUM7QUFDNUUsV0FBT3VSLFlBQVksQ0FBQzlSLElBQWIsQ0FBa0JBLElBQWxCLEVBQXVCTyxPQUF2QixDQUFQO0FBQ0EsR0FGRDtBQUlBakIsUUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDUixvQ0FBTjtBQUFBLHNDQUNBO0FBQ0MsZUFBTzRSLFlBQVksQ0FBQ3hPLFNBQWIsQ0FBdUIsQ0FDN0I7QUFBQ0MsZ0JBQU0sRUFBRTtBQUFFeU8sc0JBQVUsRUFBRTtBQUFFdEUsaUJBQUcsRUFBRTtBQUFQO0FBQWQ7QUFBVCxTQUQ2QixFQUU3QjtBQUFDdkosa0JBQVEsRUFDUjtBQUFFaEQsZUFBRyxFQUFFLENBQVA7QUFDQ2lNLHlCQUFhLEVBQUMsQ0FEZjtBQUVDcEssZ0JBQUksRUFBRTtBQUZQO0FBREQsU0FGNkIsQ0FBdkIsRUFTTHlILE9BVEssRUFBUDtBQVVBLE9BWkQ7QUFBQSxLQURjOztBQWNkO0FBQ00sd0NBQU4sQ0FBMkN3SCxNQUEzQztBQUFBLHNDQUNBO0FBQ0MsNkJBQWFILFlBQVksQ0FBQ3pPLGFBQWIsR0FBNkJDLFNBQTdCLENBQXVDLENBQ2xEO0FBQ0NxSSxpQkFBTyxFQUNQO0FBQ0NDLGdCQUFJLEVBQUUsZ0JBRFA7QUFFQ0Msc0JBQVUsRUFBRSxNQUZiO0FBR0NDLHdCQUFZLEVBQUUsS0FIZjtBQUlDQyxjQUFFLEVBQUU7QUFKTDtBQUZELFNBRGtELEVBVWxEO0FBQUVDLGlCQUFPLEVBQUU7QUFBWCxTQVZrRCxFQVdsRDtBQUFDekksZ0JBQU0sRUFBRTtBQUFFME8sa0JBQU0sRUFBRTtBQUFFZixpQkFBRyxFQUFFZTtBQUFQO0FBQVY7QUFBVCxTQVhrRCxFQVlsRDtBQUFDck4sZUFBSyxFQUFHO0FBQUUsd0JBQVc7QUFBYjtBQUFULFNBWmtELEVBYWxEO0FBQ0NULGtCQUFRLEVBQ1I7QUFDQyxtQkFBTyxNQURSO0FBRUMscUJBQVMsWUFGVjtBQUdDLHNCQUFVLFdBSFg7QUFJQyw2QkFBaUIsZ0JBSmxCO0FBS0MsMEJBQWUsYUFMaEI7QUFNQyxzQkFBVSxTQU5YO0FBT0Msb0JBQVEsT0FQVDtBQVFDLHdCQUFZLFdBUmI7QUFTQyxxQkFBUyxRQVRWO0FBVUMsd0JBQVk7QUFWYjtBQUZELFNBYmtELENBQXZDLEVBNEJUc0csT0E1QlMsRUFBYjtBQTZCQSxPQS9CRDtBQUFBLEtBZmM7O0FBK0NkO0FBQ00sd0NBQU4sQ0FBMkM1RCxJQUEzQztBQUFBLHNDQUNBO0FBQ0MsNkJBQWFpTCxZQUFZLENBQUN6TyxhQUFiLEdBQTZCQyxTQUE3QixDQUF1QyxDQUNsRDtBQUNDcUksaUJBQU8sRUFDUDtBQUNDQyxnQkFBSSxFQUFFLGdCQURQO0FBRUNDLHNCQUFVLEVBQUUsTUFGYjtBQUdDQyx3QkFBWSxFQUFFLEtBSGY7QUFJQ0MsY0FBRSxFQUFFO0FBSkw7QUFGRCxTQURrRCxFQVVsRDtBQUFFQyxpQkFBTyxFQUFFO0FBQVgsU0FWa0QsRUFXbEQ7QUFBQ3pJLGdCQUFNLEVBQUU7QUFBRXNELGdCQUFJLEVBQUU7QUFBRXFLLGlCQUFHLEVBQUVySztBQUFQO0FBQVI7QUFBVCxTQVhrRCxFQVlsRDtBQUFDakMsZUFBSyxFQUFHO0FBQUUsd0JBQVc7QUFBYjtBQUFULFNBWmtELEVBYWxEO0FBQ0NULGtCQUFRLEVBQ1I7QUFDQyxtQkFBTyxNQURSO0FBRUMscUJBQVMsWUFGVjtBQUdDLHNCQUFVLFdBSFg7QUFJQyw2QkFBaUIsZ0JBSmxCO0FBS0MsMEJBQWUsYUFMaEI7QUFNQyxzQkFBVSxTQU5YO0FBT0Msb0JBQVEsT0FQVDtBQVFDLHdCQUFZLFdBUmI7QUFTQyxxQkFBUyxRQVRWO0FBVUMsd0JBQVk7QUFWYjtBQUZELFNBYmtELENBQXZDLEVBNEJUc0csT0E1QlMsRUFBYjtBQTZCQSxPQS9CRDtBQUFBLEtBaERjOztBQWdGZDtBQUNNLG9DQUFOO0FBQUEsc0NBQ0E7QUFDQyw2QkFBYXFILFlBQVksQ0FBQ3pPLGFBQWIsR0FBNkJDLFNBQTdCLENBQXVDLENBQ2xEO0FBQ0NxSSxpQkFBTyxFQUNQO0FBQ0NDLGdCQUFJLEVBQUUsZ0JBRFA7QUFFQ0Msc0JBQVUsRUFBRSxNQUZiO0FBR0NDLHdCQUFZLEVBQUUsS0FIZjtBQUlDQyxjQUFFLEVBQUU7QUFKTDtBQUZELFNBRGtELEVBVWxEO0FBQUVDLGlCQUFPLEVBQUU7QUFBWCxTQVZrRCxFQVdsRDtBQUFDcEgsZUFBSyxFQUFHO0FBQUUsd0JBQVc7QUFBYjtBQUFULFNBWGtELEVBWWxEO0FBQ0NULGtCQUFRLEVBQ1I7QUFDQyxtQkFBTyxNQURSO0FBRUMscUJBQVMsWUFGVjtBQUdDLHNCQUFVLFdBSFg7QUFJQyw2QkFBaUIsZ0JBSmxCO0FBS0MsMEJBQWUsYUFMaEI7QUFNQyxzQkFBVSxTQU5YO0FBT0Msb0JBQVEsT0FQVDtBQVFDLHdCQUFZLFdBUmI7QUFTQyxxQkFBUyxRQVRWO0FBVUMsd0JBQVk7QUFWYjtBQUZELFNBWmtELENBQXZDLEVBMkJUc0csT0EzQlMsRUFBYjtBQTRCQSxPQTlCRDtBQUFBOztBQWpGYyxHQUFmO0FBaUhBOztBQUVBbkwsTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDaEI7QUFDQztBQUNBLHdCQUNDcUMsSUFERCxFQUVDNkssYUFGRCxFQUdDNEUsVUFIRCxFQUlDbkwsSUFKRCxFQUtDb0wsTUFMRCxFQU1DQyxLQU5ELEVBT0NDLFFBUEQsRUFRQ3BGLFVBUkQsRUFVQTtBQUNDLFFBQUksQ0FBQ3pFLFFBQVEsQ0FBQ3NCLFNBQVQsQ0FBbUIsS0FBS0MsTUFBeEIsRUFBK0IsT0FBL0IsQ0FBTCxFQUNBO0FBQ0MsWUFBTSxJQUFJdkssTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixXQUFqQixFQUE2Qix3QkFBN0IsQ0FBTjtBQUNBLEtBSEQsTUFLQTtBQUNDLFVBQUlnSSxZQUFZLENBQUMzSCxPQUFiLENBQXFCO0FBQUVSLFlBQUksRUFBRSxDQUFFO0FBQUVwSCxjQUFJLEVBQUU7QUFBRW1MLGVBQUcsRUFBRW5MO0FBQVA7QUFBUixTQUFGLEVBQTJCO0FBQUU0UCxrQkFBUSxFQUFFO0FBQUV6RSxlQUFHLEVBQUV5RTtBQUFQO0FBQVosU0FBM0IsRUFBNEQ7QUFBRS9FLHVCQUFhLEVBQUU7QUFBRU0sZUFBRyxFQUFFTjtBQUFQO0FBQWpCLFNBQTVEO0FBQVIsT0FBckIsS0FBdUksSUFBM0ksRUFDQTtBQUNDLGNBQU0sSUFBSTlOLE1BQU0sQ0FBQ3dLLEtBQVgsQ0FBaUIseUJBQWpCLENBQU47QUFDQSxPQUhELE1BS0E7QUFDQyxZQUFJc0ksUUFBUSxHQUFHLENBQWY7QUFDQSxZQUFJM0ssSUFBSSxHQUFHcUssWUFBWSxDQUFDM0gsT0FBYixDQUFxQjtBQUFFNUgsY0FBSSxFQUFDQTtBQUFQLFNBQXJCLEVBQWtDO0FBQUNyQixjQUFJLEVBQUM7QUFBRWtSLG9CQUFRLEVBQUcsQ0FBQztBQUFkLFdBQU47QUFBeUJoUixlQUFLLEVBQUM7QUFBL0IsU0FBbEMsQ0FBWDs7QUFDQSxZQUFJcUcsSUFBSSxJQUFJLElBQVosRUFDQSxDQUNDO0FBQ0EsU0FIRCxNQUtBO0FBQ0MySyxrQkFBUSxHQUFJL0wsUUFBUSxDQUFDb0IsSUFBSSxDQUFDMkssUUFBTixDQUFSLEdBQTJCLENBQXZDO0FBQ0E7O0FBRUROLG9CQUFZLENBQUM3SCxNQUFiLENBQW9CO0FBQ25CMUgsY0FEbUI7QUFFbkI2Syx1QkFGbUI7QUFHbkI0RSxvQkFIbUI7QUFJbkJuTCxjQUptQjtBQUtuQm9MLGdCQUxtQjtBQU1uQkMsZUFObUI7QUFPbkJDLGtCQVBtQjtBQVFuQnBGLG9CQVJtQjtBQVNuQnFGO0FBVG1CLFNBQXBCO0FBV0E7QUFDRDtBQUNELEdBbERjOztBQW1EZjtBQUNBLHdCQUNDalIsR0FERCxFQUVDb0IsSUFGRCxFQUdDNkssYUFIRCxFQUlDNEUsVUFKRCxFQUtDbkwsSUFMRCxFQU1Db0wsTUFORCxFQU9DQyxLQVBELEVBUUNDLFFBUkQsRUFTQ3BGLFVBVEQsRUFXQTtBQUNDLFFBQUksQ0FBQ3pFLFFBQVEsQ0FBQ3NCLFNBQVQsQ0FBbUIsS0FBS0MsTUFBeEIsRUFBK0IsT0FBL0IsQ0FBTCxFQUNBO0FBQ0MsWUFBTSxJQUFJdkssTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixXQUFqQixFQUE2Qix3QkFBN0IsQ0FBTjtBQUNBLEtBSEQsTUFLQTtBQUNDO0FBQ0E7QUFDQztBQUNEO0FBQ0E7QUFDQTtBQUNDZ0ksa0JBQVksQ0FBQ3hILE1BQWIsQ0FBb0JuSixHQUFwQixFQUNBO0FBQUVxQyxZQUFJLEVBQUU7QUFDTjRKLHVCQURNO0FBRU52RyxjQUZNO0FBR05tTCxvQkFITTtBQUlOQyxnQkFKTTtBQUtOQyxlQUxNO0FBTU5DLGtCQU5NO0FBT05wRjtBQVBNO0FBQVIsT0FEQSxFQVBGLENBa0JDO0FBQ0E7QUFDRCxHQXpGYzs7QUEwRmY7QUFDQSx3QkFBc0IzQyxNQUF0QixFQUE4QjtBQUM3QixRQUFJLENBQUM5QixRQUFRLENBQUNzQixTQUFULENBQW1CLEtBQUtDLE1BQXhCLEVBQStCLE9BQS9CLENBQUwsRUFDQTtBQUNDLFlBQU0sSUFBSXZLLE1BQU0sQ0FBQ3dLLEtBQVgsQ0FBaUIsV0FBakIsRUFBNkIsd0JBQTdCLENBQU47QUFDQSxLQUhELE1BS0E7QUFDQ2dJLGtCQUFZLENBQUN6SCxNQUFiLENBQW9CRCxNQUFwQjtBQUNBO0FBQ0QsR0FwR2M7O0FBcUdmO0FBQ0EsZ0NBQ0E7QUFDQyxRQUFJaEssU0FBUyxHQUFHLEVBQWhCO0FBQ0EsUUFBSUUsS0FBSyxHQUFJLENBQWI7QUFDQXdSLGdCQUFZLENBQUM5UixJQUFiLEdBQW9CcUIsT0FBcEIsQ0FBNEIsVUFBU0MsR0FBVCxFQUFjO0FBQ3pDbEIsZUFBUyxDQUFDcUIsSUFBVixDQUFlO0FBQ2ROLFdBQUcsRUFBRUcsR0FBRyxDQUFDSCxHQURLO0FBRWRiLGFBQUssRUFBRUEsS0FGTztBQUdkOE0scUJBQWEsRUFBRzlMLEdBQUcsQ0FBQzhMLGFBSE47QUFJZHZHLFlBQUksRUFBRXZGLEdBQUcsQ0FBQ3VGLElBSkk7QUFLZG1MLGtCQUFVLEVBQUcxUSxHQUFHLENBQUMwUTtBQUxILE9BQWY7QUFPQTFSLFdBQUssR0FBR0EsS0FBSyxHQUFHLENBQWhCO0FBRUEsS0FWRDtBQVdBLFdBQU9GLFNBQVA7QUFDQSxHQXRIYzs7QUF1SGY7QUFDQSxvQ0FDQTtBQUNDLFFBQUlBLFNBQVMsR0FBRyxFQUFoQjtBQUNBMFIsZ0JBQVksQ0FBQzlSLElBQWIsQ0FBa0I7QUFBQ2dTLGdCQUFVLEVBQUM7QUFBWixLQUFsQixFQUFpRDNRLE9BQWpELENBQXlELFVBQVNDLEdBQVQsRUFBYztBQUN0RWxCLGVBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkMkwscUJBQWEsRUFBRzlMLEdBQUcsQ0FBQzhMLGFBQUosQ0FBa0JqTCxLQUFsQixDQUF3QixHQUF4QixFQUE2QixDQUE3QixFQUFnQyxDQUFoQyxDQURGO0FBRWQwRSxZQUFJLEVBQUV2RixHQUFHLENBQUN1RjtBQUZJLE9BQWY7QUFJQSxLQUxEO0FBT0EsV0FBT3pHLFNBQVA7QUFDQSxHQW5JYzs7QUFvSWY7QUFDQSxrQ0FDQTtBQUNDLFFBQUlBLFNBQVMsR0FBRyxFQUFoQjtBQUNBMFIsZ0JBQVksQ0FBQzlSLElBQWIsQ0FBa0I7QUFBQ2dTLGdCQUFVLEVBQUM7QUFBWixLQUFsQixFQUE4QzNRLE9BQTlDLENBQXNELFVBQVNDLEdBQVQsRUFBYztBQUNuRSxVQUFJK1EsT0FBTyxHQUFHL1EsR0FBRyxDQUFDOEwsYUFBSixDQUFrQmpMLEtBQWxCLENBQXdCLEdBQXhCLEVBQTZCLENBQTdCLEVBQWdDLENBQWhDLENBQWQ7QUFDQSxVQUFJbVEsSUFBSSxHQUFHaFQsTUFBTSxDQUFDa0gsSUFBUCxDQUFZLHVCQUFaLEVBQW9DNkwsT0FBcEMsQ0FBWDtBQUNBalMsZUFBUyxDQUFDcUIsSUFBVixDQUFlO0FBQ2QyTCxxQkFBYSxFQUFHaUYsT0FERjtBQUVkeEwsWUFBSSxFQUFFdkYsR0FBRyxDQUFDdUYsSUFGSTtBQUdkeUwsWUFBSSxFQUFFQTtBQUhRLE9BQWY7QUFLQSxLQVJEO0FBVUEsV0FBT2xTLFNBQVA7QUFDQSxHQW5KYzs7QUFvSmY7QUFDQSx1Q0FDQTtBQUNDLFFBQUlBLFNBQVMsR0FBRyxFQUFoQjtBQUNBMFIsZ0JBQVksQ0FBQzlSLElBQWIsQ0FBa0I7QUFBQ2dTLGdCQUFVLEVBQUM7QUFBWixLQUFsQixFQUFtRDNRLE9BQW5ELENBQTJELFVBQVNDLEdBQVQsRUFBYztBQUN4RSxVQUFJK1EsT0FBTyxHQUFHL1EsR0FBRyxDQUFDOEwsYUFBSixDQUFrQmpMLEtBQWxCLENBQXdCLEdBQXhCLEVBQTZCLENBQTdCLEVBQWdDLENBQWhDLENBQWQ7QUFDQSxVQUFJbVEsSUFBSSxHQUFHaFQsTUFBTSxDQUFDa0gsSUFBUCxDQUFZLHVCQUFaLEVBQW9DNkwsT0FBcEMsQ0FBWDtBQUNBalMsZUFBUyxDQUFDcUIsSUFBVixDQUFlO0FBQ2QyTCxxQkFBYSxFQUFHaUYsT0FERjtBQUVkeEwsWUFBSSxFQUFFdkYsR0FBRyxDQUFDdUYsSUFGSTtBQUdkeUwsWUFBSSxFQUFFQTtBQUhRLE9BQWY7QUFLQSxLQVJEO0FBVUEsV0FBT2xTLFNBQVA7QUFDQSxHQW5LYzs7QUFvS2Y7QUFDQSw0QkFDQTtBQUNDLFFBQUltUyxTQUFTLEdBQUMsQ0FBQyx1QkFBRCxDQUFkO0FBQ0EsUUFBSW5TLFNBQVMsR0FBRyxFQUFoQjtBQUNBMFIsZ0JBQVksQ0FBQzlSLElBQWIsQ0FBa0I7QUFBQ29OLG1CQUFhLEVBQUU7QUFBQzhELFdBQUcsRUFBQ3FCO0FBQUw7QUFBaEIsS0FBbEIsRUFBb0RsUixPQUFwRCxDQUE0RCxVQUFTQyxHQUFULEVBQWM7QUFDekUsVUFBSStRLE9BQU8sR0FBRy9RLEdBQUcsQ0FBQzhMLGFBQUosQ0FBa0JqTCxLQUFsQixDQUF3QixHQUF4QixFQUE2QixDQUE3QixFQUFnQyxDQUFoQyxDQUFkO0FBQ0EsVUFBSW1RLElBQUksR0FBR2hULE1BQU0sQ0FBQ2tILElBQVAsQ0FBWSx1QkFBWixFQUFvQzZMLE9BQXBDLENBQVg7QUFDQWpTLGVBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkMkwscUJBQWEsRUFBR2lGLE9BREY7QUFFZHhMLFlBQUksRUFBRXZGLEdBQUcsQ0FBQ3VGO0FBRkksT0FBZjtBQUlBLEtBUEQ7QUFTQSxXQUFPekcsU0FBUDtBQUNBLEdBbkxjOztBQW9MZjtBQUNBLHdCQUFzQm9TLE9BQXRCLEVBQThCalEsSUFBOUIsRUFDQTtBQUNDLFFBQUluQyxTQUFTLEdBQUcsRUFBaEI7QUFDQSxRQUFJcVMsUUFBUSxHQUFJLE1BQWhCO0FBQ0EsUUFBSUMsTUFBTSxHQUFNLE9BQWhCO0FBQ0EsUUFBSUMsU0FBUyxHQUFHLElBQWhCO0FBQ0FiLGdCQUFZLENBQUM5UixJQUFiLENBQWtCO0FBQUNvUyxjQUFRLEVBQUM7QUFBQ2xCLFdBQUcsRUFBQ3NCO0FBQUwsT0FBVjtBQUF3QmpRLFVBQUksRUFBQ0E7QUFBN0IsS0FBbEIsRUFBcUQ7QUFBQ3JCLFVBQUksRUFBQztBQUFFK1EsY0FBTSxFQUFHLENBQUM7QUFBWjtBQUFOLEtBQXJELEVBQTZFNVEsT0FBN0UsQ0FBcUYsVUFBU0MsR0FBVCxFQUFjO0FBQ2xHLFVBQUlvUixNQUFNLElBQUlwUixHQUFHLENBQUMyUSxNQUFsQixFQUNBLENBQ0M7QUFDQSxPQUhELE1BR08sSUFBSVMsTUFBTSxJQUFJLEVBQWQsRUFBa0I7QUFDeEJ0UyxpQkFBUyxDQUFDcUIsSUFBVixDQUFlO0FBQ2QyUSxrQkFBUSxFQUFFOVEsR0FBRyxDQUFDOFEsUUFEQTtBQUVkSCxnQkFBTSxFQUFHM1EsR0FBRyxDQUFDMlEsTUFGQztBQUdkcEwsY0FBSSxFQUFHdkYsR0FBRyxDQUFDdUYsSUFIRztBQUlkOEwsbUJBQVMsRUFBRUEsU0FKRztBQUtkRixrQkFBUSxFQUFFQTtBQUxJLFNBQWY7O0FBT0EsWUFBSUEsUUFBUSxJQUFJLE1BQWhCLEVBQ0E7QUFDQ0Esa0JBQVEsR0FBSSxPQUFaO0FBQ0EsU0FIRCxNQUlBO0FBQ0NBLGtCQUFRLEdBQUksTUFBWjtBQUNBOztBQUNERSxpQkFBUyxHQUFJLEtBQWI7QUFDQTs7QUFDREQsWUFBTSxHQUFHcFIsR0FBRyxDQUFDMlEsTUFBYjtBQUNBLEtBdEJEO0FBdUJBLFdBQU83UixTQUFQO0FBQ0E7O0FBbk5jLENBQWYsRTs7Ozs7Ozs7Ozs7QUNqSURqQixNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDNk4sZUFBYSxFQUFDLE1BQUlBO0FBQW5CLENBQWQ7QUFBaUQsSUFBSTNOLE1BQUo7QUFBV0gsTUFBTSxDQUFDSSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsS0FBSjtBQUFVTixNQUFNLENBQUNJLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNFLE9BQUssQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFNBQUssR0FBQ0QsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJa00sYUFBSjtBQUFrQnZNLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLG9CQUFaLEVBQWlDO0FBQUNnSixTQUFPLENBQUMvSSxDQUFELEVBQUc7QUFBQ2tNLGlCQUFhLEdBQUNsTSxDQUFkO0FBQWdCOztBQUE1QixDQUFqQyxFQUErRCxDQUEvRDtBQUt4TCxNQUFNeU4sYUFBYSxHQUFHLElBQUl4TixLQUFLLENBQUNDLFVBQVYsQ0FBcUIsZUFBckIsQ0FBdEI7O0FBQ1A7QUFDQTtBQUNBLElBQUlKLE1BQU0sQ0FBQ0ssUUFBWCxFQUFxQjtBQUVwQkwsUUFBTSxDQUFDTSxPQUFQLENBQWUsd0JBQWYsRUFBeUMsU0FBU2dULHNCQUFULENBQWdDOVMsYUFBaEMsRUFBOENDLGdCQUE5QyxFQUFnRTtBQUN4RyxXQUFPa04sYUFBYSxDQUFDak4sSUFBZCxDQUFtQkYsYUFBbkIsRUFBaUNDLGdCQUFqQyxDQUFQO0FBQ0EsR0FGRCxFQUZvQixDQU1sQjs7QUFDRlQsUUFBTSxDQUFDTSxPQUFQLENBQWUsZUFBZixFQUFnQyxTQUFTaVQsYUFBVCxDQUF1Qi9TLGFBQXZCLEVBQXFDQyxnQkFBckMsRUFBdUQ7QUFDdEYsV0FBT2tOLGFBQWEsQ0FBQ2pOLElBQWQsQ0FBbUJGLGFBQW5CLEVBQWlDQyxnQkFBakMsQ0FBUDtBQUNBLEdBRkQsRUFQb0IsQ0FVcEI7QUFFQTs7QUFDQVQsUUFBTSxDQUFDTSxPQUFQLENBQWUsd0JBQWYsRUFBeUMsU0FBU2tULHNCQUFULENBQWdDaFQsYUFBaEMsRUFBOENDLGdCQUE5QyxFQUFnRTtBQUN4RyxXQUFPa04sYUFBYSxDQUFDak4sSUFBZCxDQUFtQkYsYUFBbkIsRUFBaUNDLGdCQUFqQyxDQUFQO0FBQ0EsR0FGRCxFQWJvQixDQWlCcEI7O0FBQ0FULFFBQU0sQ0FBQ00sT0FBUCxDQUFlLG9CQUFmLEVBQXFDLFNBQVNtVCxrQkFBVCxDQUE0QmpULGFBQTVCLEVBQTBDQyxnQkFBMUMsRUFBNEQ7QUFDaEcsV0FBT2tOLGFBQWEsQ0FBQ2pOLElBQWQsQ0FBbUJGLGFBQW5CLEVBQWlDQyxnQkFBakMsQ0FBUDtBQUNBLEdBRkQ7QUFJQVQsUUFBTSxDQUFDTSxPQUFQLENBQWUsb0JBQWYsRUFBcUMsU0FBU29ULGtCQUFULENBQTRCbFQsYUFBNUIsRUFBMENDLGdCQUExQyxFQUE0RDtBQUNoRyxXQUFPa04sYUFBYSxDQUFDak4sSUFBZCxDQUFtQkYsYUFBbkIsRUFBaUNDLGdCQUFqQyxDQUFQO0FBQ0EsR0FGRDtBQUtBVCxRQUFNLENBQUNNLE9BQVAsQ0FBZSxzQkFBZixFQUF1QyxTQUFTcVQsb0JBQVQsQ0FBOEJuVCxhQUE5QixFQUE0Q0MsZ0JBQTVDLEVBQThEO0FBQ3BHLFdBQU9rTixhQUFhLENBQUNqTixJQUFkLENBQW1CRixhQUFuQixFQUFpQ0MsZ0JBQWpDLENBQVA7QUFDQSxHQUZEO0FBSUFULFFBQU0sQ0FBQ00sT0FBUCxDQUFlLG9CQUFmLEVBQXFDLFNBQVNzVCxrQkFBVCxDQUE0QnBULGFBQTVCLEVBQTBDQyxnQkFBMUMsRUFBNEQ7QUFDaEcsV0FBT2tOLGFBQWEsQ0FBQ2pOLElBQWQsQ0FBbUJGLGFBQW5CLEVBQWlDQyxnQkFBakMsQ0FBUDtBQUNBLEdBRkQ7QUFJQVQsUUFBTSxDQUFDTSxPQUFQLENBQWUsMkJBQWYsRUFBNEMsU0FBU3VULHlCQUFULENBQW1DclQsYUFBbkMsRUFBaURDLGdCQUFqRCxFQUFtRTtBQUM5RyxXQUFPa04sYUFBYSxDQUFDak4sSUFBZCxDQUFtQkYsYUFBbkIsRUFBaUNDLGdCQUFqQyxDQUFQO0FBQ0EsR0FGRDtBQUlBVCxRQUFNLENBQUNNLE9BQVAsQ0FBZSxzQkFBZixFQUF1QyxTQUFTd1Qsb0JBQVQsQ0FBOEJ0VCxhQUE5QixFQUE0Q0MsZ0JBQTVDLEVBQThEO0FBQ3BHLFdBQU9rTixhQUFhLENBQUNqTixJQUFkLENBQW1CRixhQUFuQixFQUFpQ0MsZ0JBQWpDLENBQVA7QUFDQSxHQUZEO0FBSUFULFFBQU0sQ0FBQ00sT0FBUCxDQUFlLG9CQUFmLEVBQXFDLFNBQVN5VCxrQkFBVCxDQUE0QnZULGFBQTVCLEVBQTBDQyxnQkFBMUMsRUFBNEQ7QUFDaEcsV0FBT2tOLGFBQWEsQ0FBQ2pOLElBQWQsQ0FBbUJGLGFBQW5CLEVBQWlDQyxnQkFBakMsQ0FBUDtBQUNBLEdBRkQ7QUFJRVQsUUFBTSxDQUFDTSxPQUFQLENBQWUscUJBQWYsRUFBc0MsU0FBUzBULG1CQUFULENBQTZCeFQsYUFBN0IsRUFBMkNDLGdCQUEzQyxFQUE2RDtBQUNwRyxXQUFPa04sYUFBYSxDQUFDak4sSUFBZCxDQUFtQkYsYUFBbkIsRUFBaUNDLGdCQUFqQyxDQUFQO0FBQ0EsR0FGQztBQUlGVCxRQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNkO0FBQ00sMEJBQU47QUFBQSxzQ0FBK0I7QUFDN0IsNkJBQWErTSxhQUFhLENBQUM1SixhQUFkLEdBQThCQyxTQUE5QixDQUF3QyxDQUNyRDtBQUNDcUksaUJBQU8sRUFDUDtBQUNDQyxnQkFBSSxFQUFFLGVBRFA7QUFFQ0Msc0JBQVUsRUFBRSxXQUZiO0FBR0NDLHdCQUFZLEVBQUUsS0FIZjtBQUlDQyxjQUFFLEVBQUU7QUFKTDtBQUZELFNBRHFELEVBVXJEO0FBQUVDLGlCQUFPLEVBQUU7QUFBWCxTQVZxRCxFQVdyRDtBQUNDTCxpQkFBTyxFQUNQO0FBQ0NDLGdCQUFJLEVBQUUsZ0JBRFA7QUFFQ0Msc0JBQVUsRUFBRSxVQUZiO0FBR0NDLHdCQUFZLEVBQUUsS0FIZjtBQUlDQyxjQUFFLEVBQUU7QUFKTDtBQUZELFNBWHFELEVBb0JyRDtBQUFFQyxpQkFBTyxFQUFFO0FBQVgsU0FwQnFELEVBcUJyRDtBQUFDcEgsZUFBSyxFQUFHO0FBQUVzSCxxQkFBUyxFQUFDO0FBQVo7QUFBVCxTQXJCcUQsRUFzQnJEO0FBQUMvSCxrQkFBUSxFQUFFO0FBQ1YsbUJBQU8sTUFERztBQUVWLHFCQUFTLFlBRkM7QUFHVixzQkFBVSxXQUhBO0FBSVYscUJBQVMsTUFKQztBQUtWLHlCQUFhLFdBTEg7QUFNVixxQkFBUztBQU5DO0FBQVgsU0F0QnFELENBQXhDLEVBK0JYc0csT0EvQlcsRUFBYjtBQWdDRCxPQWpDRDtBQUFBOztBQUZjLEdBQWY7QUFzQ0FuTCxRQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUVSLHdDQUFOO0FBQUEsc0NBQTZDO0FBQzVDLDZCQUFhK00sYUFBYSxDQUFDNUosYUFBZCxHQUE4QkMsU0FBOUIsQ0FBd0MsQ0FDcEQ7QUFDQ3FJLGlCQUFPLEVBQ1A7QUFDQ0MsZ0JBQUksRUFBRSxlQURQO0FBRUNDLHNCQUFVLEVBQUUsV0FGYjtBQUdDQyx3QkFBWSxFQUFFLEtBSGY7QUFJQ0MsY0FBRSxFQUFFO0FBSkw7QUFGRCxTQURvRCxFQVVwRDtBQUFFQyxpQkFBTyxFQUFFO0FBQVgsU0FWb0QsRUFXcEQ7QUFDQ0wsaUJBQU8sRUFDUDtBQUNDQyxnQkFBSSxFQUFFLGdCQURQO0FBRUNDLHNCQUFVLEVBQUUsVUFGYjtBQUdDQyx3QkFBWSxFQUFFLEtBSGY7QUFJQ0MsY0FBRSxFQUFFO0FBSkw7QUFGRCxTQVhvRCxFQW9CcEQ7QUFBRUMsaUJBQU8sRUFBRTtBQUFYLFNBcEJvRCxFQXFCcEQ7QUFBQ3BILGVBQUssRUFBRztBQUFFc0gscUJBQVMsRUFBQztBQUFaO0FBQVQsU0FyQm9ELEVBc0JwRDtBQUFDL0gsa0JBQVEsRUFBRTtBQUNWLG1CQUFPLE1BREc7QUFFVixxQkFBUyxZQUZDO0FBR1Ysc0JBQVUsV0FIQTtBQUlWLHFCQUFTLE1BSkM7QUFLVix5QkFBYSxXQUxIO0FBTVYscUJBQVM7QUFOQztBQUFYLFNBdEJvRCxDQUF4QyxFQStCVnNHLE9BL0JVLEVBQWI7QUFnQ0EsT0FqQ0Q7QUFBQSxLQUZjOztBQW9DZDtBQUNNLHFDQUFOO0FBQUEsc0NBQTBDO0FBQ3pDLDZCQUFhd0MsYUFBYSxDQUFDNUosYUFBZCxHQUE4QkMsU0FBOUIsQ0FBd0MsQ0FDcEQ7QUFDQ3FJLGlCQUFPLEVBQ1A7QUFDQ0MsZ0JBQUksRUFBRSxlQURQO0FBRUNDLHNCQUFVLEVBQUUsV0FGYjtBQUdDQyx3QkFBWSxFQUFFLEtBSGY7QUFJQ0MsY0FBRSxFQUFFO0FBSkw7QUFGRCxTQURvRCxFQVVwRDtBQUFFQyxpQkFBTyxFQUFFO0FBQVgsU0FWb0QsRUFXcEQ7QUFDQ0wsaUJBQU8sRUFDUDtBQUNDQyxnQkFBSSxFQUFFLGdCQURQO0FBRUNDLHNCQUFVLEVBQUUsVUFGYjtBQUdDQyx3QkFBWSxFQUFFLEtBSGY7QUFJQ0MsY0FBRSxFQUFFO0FBSkw7QUFGRCxTQVhvRCxFQW9CcEQ7QUFBRUMsaUJBQU8sRUFBRTtBQUFYLFNBcEJvRCxFQXFCcEQ7QUFBQ3BILGVBQUssRUFBRztBQUFFc0gscUJBQVMsRUFBQztBQUFaO0FBQVQsU0FyQm9ELEVBc0JwRDtBQUFDL0gsa0JBQVEsRUFBRTtBQUNWLG1CQUFPLE1BREc7QUFFVixxQkFBUyxZQUZDO0FBR1Ysc0JBQVUsV0FIQTtBQUlWLHFCQUFTLFVBSkM7QUFLVix5QkFBYSxXQUxIO0FBTVYsdUJBQVcsVUFORDtBQU9WLDJCQUFlLGNBUEw7QUFRVix5QkFBYSxZQVJIO0FBU1Ysd0JBQVksV0FURjtBQVVWLDBCQUFjLGFBVko7QUFXViw2QkFBaUIsZ0JBWFA7QUFZViwyQkFBZSxjQVpMO0FBYVYsc0JBQVUsU0FiQTtBQWNWLHdCQUFZLFdBZEY7QUFlVix5QkFBYSxZQWZIO0FBZ0JWLHFCQUFTLE1BaEJDO0FBaUJWLHFCQUFTO0FBakJDO0FBQVgsU0F0Qm9ELENBQXhDLEVBMENWc0csT0ExQ1UsRUFBYjtBQTJDQSxPQTVDRDtBQUFBLEtBckNjOztBQWtGZDtBQUNPLHFDQUFQO0FBQUEsc0NBQ0E7QUFDQyxZQUFJckssU0FBUyxHQUFHLEVBQWhCO0FBQ0Esc0JBQU02TSxhQUFhLENBQUM1SixhQUFkLEdBQThCQyxTQUE5QixDQUF3QyxDQUM3QztBQUNDcUksaUJBQU8sRUFDUDtBQUNDQyxnQkFBSSxFQUFFLGVBRFA7QUFFQ0Msc0JBQVUsRUFBRSxXQUZiO0FBR0NDLHdCQUFZLEVBQUUsS0FIZjtBQUlDQyxjQUFFLEVBQUU7QUFKTDtBQUZELFNBRDZDLEVBVTdDO0FBQUVDLGlCQUFPLEVBQUU7QUFBWCxTQVY2QyxFQVc3QztBQUFDN0gsa0JBQVEsRUFDUjtBQUNDLHNCQUFVLFdBRFg7QUFFQyx1QkFBVyxVQUZaO0FBR0MseUJBQWE7QUFIZDtBQURELFNBWDZDLENBQXhDLEVBa0JIOUMsT0FsQkcsQ0FrQkssVUFBU0MsR0FBVCxFQUFjO0FBQ3hCLGVBQUssSUFBSWlTLElBQVQsSUFBaUJqUyxHQUFHLENBQUNrUyxTQUFyQixFQUFnQztBQUMvQixnQkFBSWxTLEdBQUcsQ0FBQ2tTLFNBQUosQ0FBY0MsY0FBZCxDQUE2QkYsSUFBN0IsQ0FBSixFQUF3QztBQUN2QyxrQkFBSWhTLElBQUksR0FBR0QsR0FBRyxDQUFDK1EsT0FBSixHQUFjLEdBQWQsR0FBb0JrQixJQUEvQjtBQUNBblQsdUJBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkMkssc0JBQU0sRUFBRzlLLEdBQUcsQ0FBQzhLLE1BREM7QUFFZDdLLG9CQUFJLEVBQUVBO0FBRlEsZUFBZjtBQUlBO0FBQ0Q7QUFDRCxTQTVCSyxDQUFOO0FBOEJBLGVBQU9uQixTQUFQO0FBQ0EsT0FsQ0Q7QUFBQSxLQW5GYzs7QUFzSGQ7QUFDTSxxQ0FBTjtBQUFBLHNDQUNBO0FBQ0MsWUFBSXNULFNBQVMsR0FBRyxDQUFoQjtBQUNBLHNCQUFNekcsYUFBYSxDQUFDNUosYUFBZCxHQUE4QkMsU0FBOUIsQ0FBd0MsQ0FDN0M7QUFBQ0MsZ0JBQU0sRUFBRTtBQUFFVCxvQkFBUSxFQUFHO0FBQWI7QUFBVCxTQUQ2QyxDQUF4QyxFQUVIekIsT0FGRyxDQUVLLFVBQVNDLEdBQVQsRUFBYztBQUN4Qm9TLG1CQUFTLEdBQUdBLFNBQVMsR0FBR3JOLFFBQVEsQ0FBQy9FLEdBQUcsQ0FBQ2tTLFNBQUosQ0FBY0csU0FBZCxDQUF3QixDQUF4QixDQUFELENBQWhDO0FBQ0EsU0FKSyxDQUFOLEVBRkQsQ0FPQzs7QUFFQUQsaUJBQVMsR0FBRzNNLFVBQVUsQ0FBQzJNLFNBQVMsR0FBRyxJQUFiLENBQVYsQ0FBNkIxTSxPQUE3QixDQUFxQyxDQUFyQyxDQUFaO0FBQ0EsZUFBTzBNLFNBQVA7QUFDQSxPQVpEO0FBQUE7O0FBdkhjLEdBQWY7QUFxSUE7O0FBQUEsQyxDQUNBOztBQUNEcFUsTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFHZDtBQUNBLDBCQUF3QjhOLE1BQXhCLEVBQ0E7QUFDQyxRQUFJcUUsT0FBTyxHQUFHcEYsYUFBYSxDQUFDOUMsT0FBZCxDQUFzQjtBQUFFaEosU0FBRyxFQUFDNk07QUFBTixLQUF0QixDQUFkOztBQUNBLFFBQUlxRSxPQUFPLElBQUUsSUFBYixFQUFtQjtBQUNsQixhQUFPLElBQVA7QUFDQSxLQUZELE1BSUE7QUFDQyxhQUFPQSxPQUFPLENBQUNBLE9BQWY7QUFDQTtBQUNELEdBZGE7O0FBZWQ7QUFDQSx5QkFBdUJyRSxNQUF2QixFQUNBO0FBQ0MsUUFBSTlMLEdBQUcsR0FBRytLLGFBQWEsQ0FBQzlDLE9BQWQsQ0FBc0I7QUFBRWhKLFNBQUcsRUFBQzZNO0FBQU4sS0FBdEIsRUFBb0M7QUFBQzdNLFNBQUcsRUFBQyxDQUFMO0FBQU9rUixhQUFPLEVBQUMsQ0FBZjtBQUFpQnVCLGlCQUFXLEVBQUMsQ0FBN0I7QUFBK0J4VCxlQUFTLEVBQUMsQ0FBekM7QUFBMkM2TCxnQkFBVSxFQUFDLENBQXREO0FBQXdETyxjQUFRLEVBQUM7QUFBakUsS0FBcEMsQ0FBVjs7QUFDQSxRQUFJdEssR0FBRyxJQUFFLElBQVQsRUFBZTtBQUNkLGFBQU8sSUFBUDtBQUNBLEtBRkQsTUFJQTtBQUNDLGFBQU9BLEdBQVA7QUFDQTtBQUNELEdBMUJhOztBQTRCZDtBQUNBLGlDQUNBO0FBQ0MsUUFBSTJSLFVBQVUsR0FBRyxFQUFqQjtBQUVBNUcsaUJBQWEsQ0FBQ2pOLElBQWQsQ0FBbUIsRUFBbkIsRUFBdUI7QUFBQ2tCLFVBQUksRUFBRTtBQUFDK0ssa0JBQVUsRUFBRSxDQUFDO0FBQWQ7QUFBUCxLQUF2QixFQUFpRDVLLE9BQWpELENBQXlELFVBQVNDLEdBQVQsRUFBYztBQUV0RSxVQUFJeUIsR0FBRyxHQUFHekQsTUFBTSxDQUFDa0gsSUFBUCxDQUFZLHVCQUFaLEVBQW9DbEYsR0FBRyxDQUFDNEssU0FBeEMsQ0FBVjtBQUNBLFVBQUlDLEtBQUssR0FBRzdNLE1BQU0sQ0FBQ2tILElBQVAsQ0FBWSx3QkFBWixFQUFxQ3pELEdBQUcsQ0FBQ1IsSUFBekMsQ0FBWjtBQUVBLFVBQUl1UixVQUFVLEdBQUcsRUFBakIsQ0FMc0UsQ0FNdEU7QUFDQTtBQUNDO0FBQ0M7QUFDQTtBQUNDO0FBQ0E7QUFDQTtBQUNEO0FBQ0E7QUFDRDtBQUNEOztBQUVBRCxnQkFBVSxDQUFDcFMsSUFBWCxDQUFnQjtBQUNmTixXQUFHLEVBQUVHLEdBQUcsQ0FBQ0gsR0FETTtBQUVmaUwsY0FBTSxFQUFFckosR0FBRyxDQUFDUixJQUZHO0FBR2Y0SixhQUFLLEVBQUVBLEtBSFE7QUFJZkUsYUFBSyxFQUFDL0ssR0FBRyxDQUFDNEssU0FKSztBQUtmQSxpQkFBUyxFQUFFbkosR0FBRyxDQUFDeEIsSUFMQTtBQU1mOFEsZUFBTyxFQUFHL1EsR0FBRyxDQUFDK1EsT0FOQztBQU9mdUIsbUJBQVcsRUFBR3RTLEdBQUcsQ0FBQ3NTLFdBUEg7QUFRZnhULGlCQUFTLEVBQUdrQixHQUFHLENBQUNsQixTQVJEO0FBU2YwQyxnQkFBUSxFQUFHeEIsR0FBRyxDQUFDd0IsUUFUQTtBQVVmaVIsa0JBQVUsRUFBR3pTLEdBQUcsQ0FBQ3lTLFVBVkY7QUFXZkMscUJBQWEsRUFBRzFTLEdBQUcsQ0FBQzBTLGFBWEw7QUFZZkMsbUJBQVcsRUFBRzNTLEdBQUcsQ0FBQzJTLFdBWkg7QUFhZkMsY0FBTSxFQUFHNVMsR0FBRyxDQUFDNFMsTUFiRTtBQWNmMUgsZ0JBQVEsRUFBRWxMLEdBQUcsQ0FBQ2tMLFFBZEM7QUFlZmdILGlCQUFTLEVBQUVsUyxHQUFHLENBQUNrUyxTQWZBO0FBZ0JmVyxjQUFNLEVBQUVMO0FBaEJPLE9BQWhCO0FBbUJBLEtBdENEO0FBd0NBLFdBQU9ELFVBQVA7QUFDQSxHQTFFYTs7QUEyRWQ7QUFDQSxvQ0FDQTtBQUNDLFFBQUlBLFVBQVUsR0FBRyxFQUFqQjtBQUNBNUcsaUJBQWEsQ0FBQ2pOLElBQWQsQ0FBbUIsRUFBbkIsRUFBdUI7QUFBQ2tCLFVBQUksRUFBRTtBQUFDK0ssa0JBQVUsRUFBRSxDQUFDO0FBQWQ7QUFBUCxLQUF2QixFQUFpRDVLLE9BQWpELENBQXlELFVBQVNDLEdBQVQsRUFBYztBQUN0RSxVQUFJOEssTUFBTSxHQUFHOU0sTUFBTSxDQUFDa0gsSUFBUCxDQUFZLHVCQUFaLEVBQW9DbEYsR0FBRyxDQUFDNEssU0FBeEMsQ0FBYjtBQUNBMkgsZ0JBQVUsQ0FBQ3BTLElBQVgsQ0FBZ0I7QUFDZk4sV0FBRyxFQUFFRyxHQUFHLENBQUNILEdBRE07QUFFZmlMLGNBQU0sRUFBRUEsTUFGTztBQUdmaUcsZUFBTyxFQUFHL1EsR0FBRyxDQUFDK1E7QUFIQyxPQUFoQjtBQU1BLEtBUkQ7QUFVQSxXQUFPd0IsVUFBUDtBQUNBLEdBMUZhOztBQTJGZDtBQUNBLGlDQUNBO0FBQ0MsUUFBSXpULFNBQVMsR0FBRyxFQUFoQjtBQUNBNk0saUJBQWEsQ0FBQ2pOLElBQWQsR0FBcUJxQixPQUFyQixDQUE2QixVQUFTQyxHQUFULEVBQWM7QUFDMUMsV0FBSyxJQUFJaVMsSUFBVCxJQUFpQmpTLEdBQUcsQ0FBQ2tTLFNBQXJCLEVBQWdDO0FBQy9CLFlBQUlsUyxHQUFHLENBQUNrUyxTQUFKLENBQWNDLGNBQWQsQ0FBNkJGLElBQTdCLENBQUosRUFBd0M7QUFDdkMsY0FBSWhTLElBQUksR0FBR0QsR0FBRyxDQUFDK1EsT0FBSixHQUFjLEdBQWQsR0FBb0JrQixJQUEvQjtBQUNBblQsbUJBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkRixnQkFBSSxFQUFFQSxJQURRO0FBRWRBLGdCQUFJLEVBQUVBO0FBRlEsV0FBZjtBQUlBO0FBQ0Q7QUFDRCxLQVZEO0FBWUEsV0FBT25CLFNBQVA7QUFDQSxHQTVHYTs7QUE2R2Q7QUFDQSxlQUFhaVMsT0FBYixFQUNBO0FBQUUsUUFBSWpTLFNBQVMsR0FBRyxFQUFoQjtBQUNENk0saUJBQWEsQ0FBQ2pOLElBQWQsQ0FBbUI7QUFBQ3FTLGFBQU8sRUFBQ0E7QUFBVCxLQUFuQixFQUFzQ2hSLE9BQXRDLENBQThDLFVBQVNDLEdBQVQsRUFBYztBQUMzRGxCLGVBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkMlMsYUFBSyxFQUFFOVMsR0FBRyxDQUFDa1MsU0FBSixDQUFjWSxLQUFkLENBQW9CLENBQXBCLENBRE87QUFFZEMsV0FBRyxFQUFFL1MsR0FBRyxDQUFDa1MsU0FBSixDQUFjYSxHQUFkLENBQWtCLENBQWxCLENBRlM7QUFHZEMsWUFBSSxFQUFFaFQsR0FBRyxDQUFDa1MsU0FBSixDQUFjYyxJQUFkLENBQW1CLENBQW5CLENBSFE7QUFJZEMsV0FBRyxFQUFFalQsR0FBRyxDQUFDa1MsU0FBSixDQUFjZSxHQUFkLENBQWtCLENBQWxCLENBSlM7QUFLZEMsaUJBQVMsRUFBRWxULEdBQUcsQ0FBQ2tTLFNBQUosQ0FBY2dCLFNBQWQsQ0FBd0IsQ0FBeEIsQ0FMRztBQU1kQyxvQkFBWSxFQUFFblQsR0FBRyxDQUFDa1MsU0FBSixDQUFjaUIsWUFBZCxDQUEyQixDQUEzQixDQU5BO0FBT2RDLFdBQUcsRUFBRXBULEdBQUcsQ0FBQ2tTLFNBQUosQ0FBY2tCLEdBQWQsQ0FBa0IsQ0FBbEIsQ0FQUztBQVFkQyxZQUFJLEVBQUVyVCxHQUFHLENBQUNrUyxTQUFKLENBQWNtQixJQUFkLENBQW1CLENBQW5CO0FBUlEsT0FBZjtBQVVBLEtBWEQ7QUFZQSxXQUFPdlUsU0FBUDtBQUNBLEdBN0hhOztBQThIZDtBQUNBLHlCQUNDaVMsT0FERCxFQUVDdUIsV0FGRCxFQUdDMUgsU0FIRCxFQUlDOUwsU0FKRCxFQUtDMEMsUUFMRCxFQU1DaVIsVUFORCxFQU9DQyxhQVBELEVBUUNDLFdBUkQsRUFTQzFSLElBVEQsRUFVQ3dLLFVBVkQsRUFXQ2QsVUFYRCxFQWFBO0FBQ0MsUUFBSU8sUUFBUSxHQUFHLEVBQWY7QUFDQSxRQUFJMEgsTUFBTSxHQUFFLE1BQVo7QUFDQSxRQUFJVixTQUFTLEdBQUMsRUFBZDtBQUNBLFFBQUlvQixPQUFPLEdBQUcsQ0FBZDs7QUFDQSxZQUFPOVIsUUFBUDtBQUdDLFdBQUssT0FBTDtBQUNDLGdCQUFPaVIsVUFBUDtBQUVDLGVBQUssTUFBTDtBQUNDUCxxQkFBUyxHQUFHO0FBQ1hxQixpQkFBRyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FETTtBQUVYQyxtQkFBSyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUg7QUFGSSxhQUFaO0FBSUF0SSxvQkFBUSxHQUFHLENBQVg7QUFDRDs7QUFDQSxlQUFLLFNBQUw7QUFDQ2dILHFCQUFTLEdBQUc7QUFDWHNCLG1CQUFLLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSDtBQURJLGFBQVo7QUFHQXRJLG9CQUFRLEdBQUcsQ0FBWDtBQUNEOztBQUNBO0FBQ0NvSSxtQkFBTyxHQUFHLENBQVY7QUFDQTtBQWpCRjs7QUFtQkE7O0FBQ0QsV0FBSyxXQUFMO0FBQ0NwQixpQkFBUyxHQUFHO0FBQ1h1QixnQkFBTSxFQUFFLENBQUMsRUFBRCxFQUFJLENBQUosQ0FERztBQUVYQyxnQkFBTSxFQUFFLENBQUMsRUFBRCxFQUFJLENBQUosQ0FGRztBQUdYQyxnQkFBTSxFQUFFLENBQUMsRUFBRCxFQUFJLENBQUosQ0FIRztBQUlYQyxnQkFBTSxFQUFFLENBQUMsRUFBRCxFQUFJLENBQUosQ0FKRztBQUtYQyxnQkFBTSxFQUFFLENBQUMsRUFBRCxFQUFJLENBQUosQ0FMRztBQU1YQyxnQkFBTSxFQUFFLENBQUMsRUFBRCxFQUFJLENBQUosQ0FORztBQU9YQyxnQkFBTSxFQUFFLENBQUMsRUFBRCxFQUFJLENBQUosQ0FQRztBQVFYQyxnQkFBTSxFQUFFLENBQUMsRUFBRCxFQUFJLENBQUosQ0FSRztBQVNYQyxnQkFBTSxFQUFFLENBQUMsSUFBRCxFQUFNLENBQU4sQ0FURztBQVVYWixjQUFJLEVBQUksQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQVZHO0FBV1hhLHFCQUFXLEVBQUcsQ0FBQyxDQUFELEVBQUcsQ0FBSDtBQVhILFNBQVo7QUFhQWhKLGdCQUFRLEdBQUcsRUFBWDtBQUNBOztBQUNELFdBQUssV0FBTDtBQUNDZ0gsaUJBQVMsR0FBRztBQUNYaUMscUJBQVcsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBREY7QUFFWEMsbUJBQVMsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBRkE7QUFHWEMseUJBQWUsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBSE47QUFJWEMsa0JBQVEsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBSkM7QUFLWEMsdUJBQWEsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBTEo7QUFNWEMsc0JBQVksRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBTkg7QUFPWEMsc0JBQVksRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBUEg7QUFRWEMsc0JBQVksRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBUkg7QUFTWEMsdUJBQWEsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBVEo7QUFVWEMsc0JBQVksRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBVkg7QUFXWEMsc0JBQVksRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBWEg7QUFZWEMsc0JBQVksRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBWkg7QUFhWEMsdUJBQWEsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBYko7QUFjWEMsc0JBQVksRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBZEg7QUFlWEMsc0JBQVksRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBZkg7QUFnQlhDLHNCQUFZLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQWhCSDtBQWlCWEMsdUJBQWEsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBakJKO0FBa0JYQyx5QkFBZSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FsQk47QUFtQlhDLHNCQUFZLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQW5CSDtBQW9CWEMsY0FBSSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FwQks7QUFxQlhqRCxtQkFBUyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FyQkE7QUFzQlhrRCxpQkFBTyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0F0QkU7QUF1QlhDLGdCQUFNLEVBQUMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQXZCSTtBQXdCWEMsNEJBQWtCLEVBQUMsQ0FBQyxDQUFELEVBQUcsQ0FBSDtBQXhCUixTQUFaO0FBMEJBdkssZ0JBQVEsR0FBRyxFQUFYO0FBQ0E7O0FBQ0QsV0FBSyxLQUFMO0FBQ0NnSCxpQkFBUyxHQUFHO0FBQ1hZLGVBQUssRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBREk7QUFFWEMsYUFBRyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FGTTtBQUdYQyxjQUFJLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQUhLO0FBSVhDLGFBQUcsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBSk07QUFLWEMsbUJBQVMsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBTEE7QUFNWEMsc0JBQVksRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBTkg7QUFPWHVDLGtCQUFRLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQVBDO0FBUVh0QyxhQUFHLEVBQUcsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQVJLO0FBU1hDLGNBQUksRUFBRyxDQUFDLENBQUQsRUFBRyxDQUFIO0FBVEksU0FBWjtBQVdBbkksZ0JBQVEsR0FBRyxFQUFYO0FBQ0E7O0FBQ0QsV0FBSyxLQUFMO0FBQ0NnSCxpQkFBUyxHQUFHO0FBQ1hZLGVBQUssRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBREk7QUFFWEMsYUFBRyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FGTTtBQUdYQyxjQUFJLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQUhLO0FBSVhDLGFBQUcsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBSk07QUFLWEMsbUJBQVMsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBTEE7QUFNWEMsc0JBQVksRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBTkg7QUFPWEMsYUFBRyxFQUFHLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FQSztBQVFYQyxjQUFJLEVBQUcsQ0FBQyxDQUFELEVBQUcsQ0FBSDtBQVJJLFNBQVo7QUFVQW5JLGdCQUFRLEdBQUcsRUFBWDtBQUNBOztBQUNELFdBQUssT0FBTDtBQUNDLGdCQUFPdUgsVUFBUDtBQUVDLGVBQUssYUFBTDtBQUNBLGVBQUssZUFBTDtBQUNBLGVBQUssb0JBQUwsQ0FKRCxDQUk4Qjs7QUFDN0IsZUFBSyxzQkFBTCxDQUxELENBSzhCOztBQUM3QixlQUFLLHNCQUFMLENBTkQsQ0FNOEI7O0FBQzdCLGVBQUssaUJBQUw7QUFDQ1AscUJBQVMsR0FBRztBQUNYbUIsa0JBQUksRUFBRyxDQUFDLENBQUQsRUFBRyxDQUFILENBREk7QUFFWEQsaUJBQUcsRUFBRyxDQUFDLENBQUQsRUFBRyxDQUFILENBRks7QUFHWEgsaUJBQUcsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBSE07QUFJWEMsdUJBQVMsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBSkE7QUFLWEMsMEJBQVksRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBTEg7QUFNWHVDLHNCQUFRLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSDtBQU5DLGFBQVo7QUFRQXhLLG9CQUFRLEdBQUcsQ0FBWDtBQUNBOztBQUNELGVBQUssaUJBQUw7QUFDQ2dILHFCQUFTLEdBQUc7QUFDWG1CLGtCQUFJLEVBQUcsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQURJO0FBRVhELGlCQUFHLEVBQUcsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQUZLO0FBR1hILGlCQUFHLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQUhNO0FBSVhDLHVCQUFTLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQUpBO0FBS1hDLDBCQUFZLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQUxIO0FBTVh1QyxzQkFBUSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUg7QUFOQyxhQUFaO0FBUUF4SyxvQkFBUSxHQUFHLENBQVg7QUFDQTs7QUFDRCxlQUFLLGNBQUw7QUFDQSxlQUFLLGdCQUFMO0FBQ0EsZUFBSyxvQkFBTDtBQUNBLGVBQUssV0FBTDtBQUNBLGVBQUssWUFBTDtBQUNBLGVBQUssY0FBTDtBQUNDZ0gscUJBQVMsR0FBRztBQUNYbUIsa0JBQUksRUFBRyxDQUFDLENBQUQsRUFBRyxDQUFILENBREk7QUFFWEQsaUJBQUcsRUFBRyxDQUFDLENBQUQsRUFBRyxDQUFILENBRks7QUFHWEgsaUJBQUcsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBSE07QUFJWEMsdUJBQVMsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBSkE7QUFLWEMsMEJBQVksRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFIO0FBTEgsYUFBWjtBQU9Bakksb0JBQVEsR0FBRyxDQUFYO0FBQ0E7O0FBQ0QsZUFBSyxlQUFMO0FBQ0NnSCxxQkFBUyxHQUFHO0FBQ1htQixrQkFBSSxFQUFHLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FESTtBQUVYRCxpQkFBRyxFQUFHLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FGSztBQUdYSCxpQkFBRyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FITTtBQUlYQyx1QkFBUyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FKQTtBQUtYQywwQkFBWSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUg7QUFMSCxhQUFaO0FBT0FqSSxvQkFBUSxHQUFHLENBQVg7QUFDQTs7QUFDRDtBQUNDb0ksbUJBQU8sR0FBRyxDQUFWO0FBQ0E7QUF4REY7O0FBMERBOztBQUNELFdBQUssWUFBTDtBQUNDLGdCQUFPYixVQUFQO0FBRUMsZUFBSyxrQkFBTDtBQUNDUCxxQkFBUyxHQUFHO0FBQ1h5RCxpQkFBRyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FETTtBQUVYQyxnQkFBRSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FGTztBQUdYQyxpQkFBRyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FITTtBQUlYQyxnQkFBRSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FKTztBQUtYdEMsbUJBQUssRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBTEk7QUFNWEgsa0JBQUksRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFIO0FBTkssYUFBWjtBQVFBbkksb0JBQVEsR0FBRyxFQUFYO0FBQ0E7O0FBQ0QsZUFBSyxlQUFMO0FBQ0NnSCxxQkFBUyxHQUFHO0FBQ1h5RCxpQkFBRyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FETTtBQUVYQyxnQkFBRSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FGTztBQUdYQyxpQkFBRyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FITTtBQUlYQyxnQkFBRSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FKTztBQUtYdEMsbUJBQUssRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBTEk7QUFNWHVDLG1CQUFLLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQU5JO0FBT1gxQyxrQkFBSSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUg7QUFQSyxhQUFaO0FBU0FuSSxvQkFBUSxHQUFHLEVBQVg7QUFDQTs7QUFDRDtBQUNDb0ksbUJBQU8sR0FBRyxDQUFWO0FBQ0E7QUEzQkY7O0FBNkJBOztBQUNELFdBQUssT0FBTDtBQUNDcEIsaUJBQVMsR0FBRztBQUNYbUIsY0FBSSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUg7QUFESyxTQUFaO0FBR0FuSSxnQkFBUSxHQUFHLENBQVg7QUFDQTs7QUFDRCxXQUFLLFVBQUw7QUFDQ2dILGlCQUFTLEdBQUc7QUFDWHNCLGVBQUssRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBREk7QUFFWHdDLG9CQUFVLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQUZEO0FBR1hDLGFBQUcsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBSE07QUFJWEMsYUFBRyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FKTTtBQUtYQyxhQUFHLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQUxNO0FBTVg5QyxjQUFJLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQU5LO0FBT1hELGFBQUcsRUFBRyxDQUFDLENBQUQsRUFBRyxDQUFIO0FBUEssU0FBWjtBQVNBbEksZ0JBQVEsR0FBRyxFQUFYO0FBQ0E7O0FBQ0QsV0FBSyxVQUFMO0FBQ0NnSCxpQkFBUyxHQUFHO0FBQ1htQixjQUFJLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSDtBQURLLFNBQVo7QUFHQW5JLGdCQUFRLEdBQUcsQ0FBWDtBQUNBOztBQUNELFdBQUssUUFBTDtBQUNDLGdCQUFPdUgsVUFBUDtBQUVDLGVBQUssTUFBTDtBQUNDUCxxQkFBUyxHQUFHO0FBQ1hxQixpQkFBRyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FETTtBQUVYQyxtQkFBSyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUg7QUFGSSxhQUFaO0FBSUF0SSxvQkFBUSxHQUFHLENBQVg7QUFDRDs7QUFDQSxlQUFLLFNBQUw7QUFDQ2dILHFCQUFTLEdBQUc7QUFDWHNCLG1CQUFLLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSDtBQURJLGFBQVo7QUFHQXRJLG9CQUFRLEdBQUcsQ0FBWDtBQUNEOztBQUNBLGVBQUssZUFBTDtBQUNDZ0gscUJBQVMsR0FBRztBQUNYc0IsbUJBQUssRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFIO0FBREksYUFBWjtBQUdBdEksb0JBQVEsR0FBRyxDQUFYO0FBQ0Q7O0FBQ0EsZUFBSyxNQUFMO0FBQ0NnSCxxQkFBUyxHQUFHO0FBQ1hzQixtQkFBSyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUg7QUFESSxhQUFaO0FBR0F0SSxvQkFBUSxHQUFHLENBQVg7QUFDRDs7QUFDQTtBQUNDb0ksbUJBQU8sR0FBRyxDQUFWO0FBQ0E7QUE3QkY7O0FBK0JBOztBQUNELFdBQUssWUFBTDtBQUNDLGdCQUFPYixVQUFQO0FBRUMsZUFBSyxZQUFMO0FBQ0EsZUFBSyxnQkFBTDtBQUNDUCxxQkFBUyxHQUFHO0FBQ1hrRSxnQkFBRSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FETztBQUVYQyxnQkFBRSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FGTztBQUdYQyxnQkFBRSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FITztBQUlYQyxxQkFBTyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FKRTtBQUtYQyxnQkFBRSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FMTztBQU1YQyxnQkFBRSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FOTztBQU9YQyxnQkFBRSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FQTztBQVFYQyxxQkFBTyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FSRTtBQVNYQyxnQkFBRSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FUTztBQVVYQyxnQkFBRSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FWTztBQVdYQyxnQkFBRSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FYTztBQVlYQyxxQkFBTyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FaRTtBQWFYQywwQkFBWSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FiSDtBQWNYQywwQkFBWSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FkSDtBQWVYQywwQkFBWSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FmSDtBQWdCWEMsNkJBQWUsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBaEJOO0FBaUJYQyxnQkFBRSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FqQk87QUFrQlhDLGdCQUFFLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQWxCTztBQW1CWEMsZ0JBQUUsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBbkJPO0FBb0JYQyxtQkFBSyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FwQkk7QUFxQlhDLGtCQUFJLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQXJCSztBQXNCWEMsaUJBQUcsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBdEJNO0FBdUJYQyxpQkFBRyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0F2Qk07QUF3QlhDLGlCQUFHLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQXhCTTtBQXlCWEMsbUJBQUssRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBekJJO0FBMEJYQyxnQkFBRSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0ExQk87QUEyQlhDLGdCQUFFLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQTNCTztBQTRCWEMsZ0JBQUUsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBNUJPO0FBNkJYQyxtQkFBSyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0E3Qkk7QUE4QlhDLG9CQUFNLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSDtBQTlCRyxhQUFaO0FBZ0NBL00sb0JBQVEsR0FBRyxFQUFYO0FBQ0Q7O0FBQ0E7QUFDQ29JLG1CQUFPLEdBQUcsQ0FBVjtBQUNBO0FBeENGOztBQTBDQTs7QUFFRDtBQUNDQSxlQUFPLEdBQUcsQ0FBVjtBQUNEO0FBblNEOztBQXFTQSxRQUFJQSxPQUFPLElBQUUsQ0FBYixFQUNBLENBQ0M7QUFDQSxLQUhELE1BS0E7QUFDQyxVQUFJM0gsYUFBYSxDQUFDOUMsT0FBZCxDQUFzQjtBQUFFUixZQUFJLEVBQUUsQ0FBRTtBQUFFdUMsbUJBQVMsRUFBRTtBQUFFd0IsZUFBRyxFQUFFeEI7QUFBUDtBQUFiLFNBQUYsRUFBcUM7QUFBRW1HLGlCQUFPLEVBQUU7QUFBRTNFLGVBQUcsRUFBRTJFO0FBQVA7QUFBWCxTQUFyQztBQUFSLE9BQXRCLEtBQXFHLElBQXpHLEVBQ0E7QUFDQyxjQUFNLElBQUkvUyxNQUFNLENBQUN3SyxLQUFYLENBQWlCLHVDQUFqQixDQUFOO0FBQ0EsT0FIRCxNQUtBO0FBQ0NtRCxxQkFBYSxDQUFDaEQsTUFBZCxDQUFxQjtBQUNwQm9JLGlCQURvQjtBQUVwQnVCLHFCQUZvQjtBQUdwQjFILG1CQUhvQjtBQUlwQjlMLG1CQUpvQjtBQUtwQjBDLGtCQUxvQjtBQU1wQmlSLG9CQU5vQjtBQU9wQkMsdUJBUG9CO0FBUXBCQyxxQkFSb0I7QUFTcEJDLGdCQVRvQjtBQVVwQjFILGtCQVZvQjtBQVdwQmdILG1CQVhvQjtBQVlwQmpSLGNBWm9CO0FBYXBCd0ssb0JBYm9CO0FBY3BCZDtBQWRvQixTQUFyQjtBQWdCQTtBQUNEO0FBQ0QsR0FwZGE7O0FBcWRkO0FBQ0Esa0NBQ0M5SyxHQURELEVBRUMyQixRQUZELEVBR0NpUixVQUhELEVBSUN5RixRQUpELEVBS0N2TixVQUxELEVBT0E7QUFDQztBQUNBLFFBQUl1SCxTQUFTLEdBQUMsRUFBZDtBQUNBLFFBQUlvQixPQUFPLEdBQUcsQ0FBZDs7QUFDQSxZQUFPOVIsUUFBUDtBQUVDLFdBQUssUUFBTDtBQUNDLGdCQUFPaVIsVUFBUDtBQUVDLGVBQUssU0FBTDtBQUNDUCxxQkFBUyxHQUFHO0FBQ1hzQixtQkFBSyxFQUFFLENBQUMwRSxRQUFELEVBQVUsQ0FBVjtBQURJLGFBQVo7QUFHQWhOLG9CQUFRLEdBQUcsQ0FBWDtBQUNEOztBQUNBLGVBQUssZUFBTDtBQUNDZ0gscUJBQVMsR0FBRztBQUNYc0IsbUJBQUssRUFBRSxDQUFDMEUsUUFBRCxFQUFVLENBQVY7QUFESSxhQUFaO0FBR0FoTixvQkFBUSxHQUFHLENBQVg7QUFDRDs7QUFDQTtBQUNDb0ksbUJBQU8sR0FBRyxDQUFWO0FBQ0E7QUFoQkY7O0FBa0JBOztBQUVEO0FBQ0NBLGVBQU8sR0FBRyxDQUFWO0FBQ0E7QUF6QkY7O0FBNEJBLFFBQUlBLE9BQU8sSUFBRSxDQUFiLEVBQ0EsQ0FDQztBQUNBLEtBSEQsTUFLQTtBQUNDM0gsbUJBQWEsQ0FBQzNDLE1BQWQsQ0FBcUJuSixHQUFyQixFQUNBO0FBQUVxQyxZQUFJLEVBQUU7QUFDTmdRLG1CQURNO0FBRU52SDtBQUZNO0FBQVIsT0FEQTtBQU1BO0FBRUQsR0EzZ0JhOztBQTRnQmQ7QUFDQSx5QkFDQzlLLEdBREQsRUFFQ2tSLE9BRkQsRUFHQ3VCLFdBSEQsRUFJQzFILFNBSkQsRUFLQzlMLFNBTEQsRUFNQzBDLFFBTkQsRUFPQ2lSLFVBUEQsRUFRQ0MsYUFSRCxFQVNDQyxXQVRELEVBVUMxUixJQVZELEVBV0N3SyxVQVhELEVBWUNkLFVBWkQsRUFjQTtBQUNDLFFBQUlPLFFBQVEsR0FBRyxFQUFmO0FBQ0EsUUFBSTBILE1BQU0sR0FBRSxNQUFaO0FBQ0EsUUFBSVYsU0FBUyxHQUFDLEVBQWQ7QUFDQSxRQUFJb0IsT0FBTyxHQUFHLENBQWQsQ0FKRCxDQUtDOztBQUNBLFlBQU85UixRQUFQO0FBRUMsV0FBSyxPQUFMO0FBQ0MsZ0JBQU9pUixVQUFQO0FBRUMsZUFBSyxNQUFMO0FBQ0NQLHFCQUFTLEdBQUc7QUFDWHFCLGlCQUFHLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQURNO0FBRVhDLG1CQUFLLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSDtBQUZJLGFBQVo7QUFJQXRJLG9CQUFRLEdBQUcsQ0FBWDtBQUNEOztBQUNBLGVBQUssU0FBTDtBQUNDZ0gscUJBQVMsR0FBRztBQUNYc0IsbUJBQUssRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFIO0FBREksYUFBWjtBQUdBdEksb0JBQVEsR0FBRyxDQUFYO0FBQ0Q7O0FBQ0E7QUFDQ29JLG1CQUFPLEdBQUcsQ0FBVjtBQUNBO0FBakJGOztBQW1CQTs7QUFDRCxXQUFLLFdBQUw7QUFDQ3BCLGlCQUFTLEdBQUc7QUFDWHVCLGdCQUFNLEVBQUUsQ0FBQyxFQUFELEVBQUksQ0FBSixDQURHO0FBRVhDLGdCQUFNLEVBQUUsQ0FBQyxFQUFELEVBQUksQ0FBSixDQUZHO0FBR1hDLGdCQUFNLEVBQUUsQ0FBQyxFQUFELEVBQUksQ0FBSixDQUhHO0FBSVhDLGdCQUFNLEVBQUUsQ0FBQyxFQUFELEVBQUksQ0FBSixDQUpHO0FBS1hDLGdCQUFNLEVBQUUsQ0FBQyxFQUFELEVBQUksQ0FBSixDQUxHO0FBTVhDLGdCQUFNLEVBQUUsQ0FBQyxFQUFELEVBQUksQ0FBSixDQU5HO0FBT1hDLGdCQUFNLEVBQUUsQ0FBQyxFQUFELEVBQUksQ0FBSixDQVBHO0FBUVhDLGdCQUFNLEVBQUUsQ0FBQyxFQUFELEVBQUksQ0FBSixDQVJHO0FBU1hDLGdCQUFNLEVBQUUsQ0FBQyxJQUFELEVBQU0sQ0FBTixDQVRHO0FBVVhaLGNBQUksRUFBSSxDQUFDLENBQUQsRUFBRyxDQUFILENBVkc7QUFXWGEscUJBQVcsRUFBRyxDQUFDLENBQUQsRUFBRyxDQUFIO0FBWEgsU0FBWjtBQWFBaEosZ0JBQVEsR0FBRyxFQUFYO0FBQ0E7O0FBQ0QsV0FBSyxXQUFMO0FBQ0NnSCxpQkFBUyxHQUFHO0FBQ1hpQyxxQkFBVyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FERjtBQUVYQyxtQkFBUyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FGQTtBQUdYQyx5QkFBZSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FITjtBQUlYQyxrQkFBUSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FKQztBQUtYQyx1QkFBYSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FMSjtBQU1YQyxzQkFBWSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FOSDtBQU9YQyxzQkFBWSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FQSDtBQVFYQyxzQkFBWSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FSSDtBQVNYQyx1QkFBYSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FUSjtBQVVYQyxzQkFBWSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FWSDtBQVdYQyxzQkFBWSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FYSDtBQVlYQyxzQkFBWSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FaSDtBQWFYQyx1QkFBYSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FiSjtBQWNYQyxzQkFBWSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FkSDtBQWVYQyxzQkFBWSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FmSDtBQWdCWEMsc0JBQVksRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBaEJIO0FBaUJYQyx1QkFBYSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FqQko7QUFrQlhDLHlCQUFlLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQWxCTjtBQW1CWEMsc0JBQVksRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBbkJIO0FBb0JYQyxjQUFJLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQXBCSztBQXFCWGpELG1CQUFTLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQXJCQTtBQXNCWGtELGlCQUFPLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQXRCRTtBQXVCWEMsZ0JBQU0sRUFBQyxDQUFDLENBQUQsRUFBRyxDQUFILENBdkJJO0FBd0JYQyw0QkFBa0IsRUFBQyxDQUFDLENBQUQsRUFBRyxDQUFIO0FBeEJSLFNBQVo7QUEwQkF2SyxnQkFBUSxHQUFHLEVBQVg7QUFDQTs7QUFDRCxXQUFLLEtBQUw7QUFDQ2dILGlCQUFTLEdBQUc7QUFDWFksZUFBSyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FESTtBQUVYQyxhQUFHLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQUZNO0FBR1hDLGNBQUksRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBSEs7QUFJWEMsYUFBRyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FKTTtBQUtYQyxtQkFBUyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FMQTtBQU1YQyxzQkFBWSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FOSDtBQU9YdUMsa0JBQVEsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBUEM7QUFRWHRDLGFBQUcsRUFBRyxDQUFDLENBQUQsRUFBRyxDQUFILENBUks7QUFTWEMsY0FBSSxFQUFHLENBQUMsQ0FBRCxFQUFHLENBQUg7QUFUSSxTQUFaO0FBV0FuSSxnQkFBUSxHQUFHLEVBQVg7QUFDQTs7QUFDRCxXQUFLLEtBQUw7QUFDQ2dILGlCQUFTLEdBQUc7QUFDWFksZUFBSyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FESTtBQUVYQyxhQUFHLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQUZNO0FBR1hDLGNBQUksRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBSEs7QUFJWEMsYUFBRyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FKTTtBQUtYQyxtQkFBUyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FMQTtBQU1YQyxzQkFBWSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FOSDtBQU9YQyxhQUFHLEVBQUcsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQVBLO0FBUVhDLGNBQUksRUFBRyxDQUFDLENBQUQsRUFBRyxDQUFIO0FBUkksU0FBWjtBQVVBbkksZ0JBQVEsR0FBRyxFQUFYO0FBQ0E7O0FBRUQsV0FBSyxPQUFMO0FBQ0MsZ0JBQU91SCxVQUFQO0FBRUMsZUFBSyxhQUFMO0FBQ0EsZUFBSyxlQUFMO0FBQ0EsZUFBSyxvQkFBTCxDQUpELENBSThCOztBQUM3QixlQUFLLHNCQUFMLENBTEQsQ0FLOEI7O0FBQzdCLGVBQUssc0JBQUwsQ0FORCxDQU04Qjs7QUFDN0IsZUFBSyxpQkFBTDtBQUNDUCxxQkFBUyxHQUFHO0FBQ1htQixrQkFBSSxFQUFHLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FESTtBQUVYRCxpQkFBRyxFQUFHLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FGSztBQUdYSCxpQkFBRyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FITTtBQUlYQyx1QkFBUyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FKQTtBQUtYQywwQkFBWSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FMSDtBQU1YdUMsc0JBQVEsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFIO0FBTkMsYUFBWjtBQVFBeEssb0JBQVEsR0FBRyxDQUFYO0FBQ0E7O0FBQ0QsZUFBSyxjQUFMO0FBQ0EsZUFBSyxnQkFBTDtBQUNBLGVBQUssV0FBTDtBQUNBLGVBQUssWUFBTDtBQUNBLGVBQUssY0FBTDtBQUNDZ0gscUJBQVMsR0FBRztBQUNYbUIsa0JBQUksRUFBRyxDQUFDLENBQUQsRUFBRyxDQUFILENBREk7QUFFWEQsaUJBQUcsRUFBRyxDQUFDLENBQUQsRUFBRyxDQUFILENBRks7QUFHWEgsaUJBQUcsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBSE07QUFJWEMsdUJBQVMsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBSkE7QUFLWEMsMEJBQVksRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFIO0FBTEgsYUFBWjtBQU9Bakksb0JBQVEsR0FBRyxDQUFYOztBQUNELGVBQUssZUFBTDtBQUNDZ0gscUJBQVMsR0FBRztBQUNYbUIsa0JBQUksRUFBRyxDQUFDLENBQUQsRUFBRyxDQUFILENBREk7QUFFWEQsaUJBQUcsRUFBRyxDQUFDLENBQUQsRUFBRyxDQUFILENBRks7QUFHWEgsaUJBQUcsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBSE07QUFJWEMsdUJBQVMsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBSkE7QUFLWEMsMEJBQVksRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFIO0FBTEgsYUFBWjtBQU9Bakksb0JBQVEsR0FBRyxDQUFYO0FBQ0E7O0FBQ0Q7QUFDQ29JLG1CQUFPLEdBQUcsQ0FBVjtBQUNBO0FBM0NGOztBQTZDQTs7QUFDRCxXQUFLLFlBQUw7QUFDQyxnQkFBT2IsVUFBUDtBQUVDLGVBQUssa0JBQUw7QUFDQ1AscUJBQVMsR0FBRztBQUNYeUQsaUJBQUcsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBRE07QUFFWEMsZ0JBQUUsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBRk87QUFHWEMsaUJBQUcsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBSE07QUFJWEMsZ0JBQUUsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBSk87QUFLWHRDLG1CQUFLLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQUxJO0FBTVhILGtCQUFJLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSDtBQU5LLGFBQVo7QUFRQW5JLG9CQUFRLEdBQUcsRUFBWDtBQUNBOztBQUNELGVBQUssaUJBQUw7QUFDQ2dILHFCQUFTLEdBQUc7QUFDWHlELGlCQUFHLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQURNO0FBRVhDLGdCQUFFLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQUZPO0FBR1hDLGlCQUFHLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQUhNO0FBSVhDLGdCQUFFLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQUpPO0FBS1h0QyxtQkFBSyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FMSTtBQU1YSCxrQkFBSSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUg7QUFOSyxhQUFaO0FBUUFuSSxvQkFBUSxHQUFHLEVBQVg7QUFDQTs7QUFDRCxlQUFLLGVBQUw7QUFDQ2dILHFCQUFTLEdBQUc7QUFDWHlELGlCQUFHLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQURNO0FBRVhDLGdCQUFFLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQUZPO0FBR1hDLGlCQUFHLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQUhNO0FBSVhDLGdCQUFFLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQUpPO0FBS1h0QyxtQkFBSyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FMSTtBQU1YdUMsbUJBQUssRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBTkk7QUFPWDFDLGtCQUFJLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSDtBQVBLLGFBQVo7QUFTQW5JLG9CQUFRLEdBQUcsRUFBWDtBQUNBOztBQUNEO0FBQ0NvSSxtQkFBTyxHQUFHLENBQVY7QUFDQTtBQXRDRjs7QUF3Q0E7O0FBRUQsV0FBSyxPQUFMO0FBQ0NwQixpQkFBUyxHQUFHO0FBQ1htQixjQUFJLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSDtBQURLLFNBQVo7QUFHQW5JLGdCQUFRLEdBQUcsQ0FBWDtBQUNBOztBQUVELFdBQUssVUFBTDtBQUNDZ0gsaUJBQVMsR0FBRztBQUNYc0IsZUFBSyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FESTtBQUVYd0Msb0JBQVUsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBRkQ7QUFHWG1DLGNBQUksRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBSEs7QUFJWEMsY0FBSSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FKSztBQUtYbkMsYUFBRyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FMTTtBQU1YQyxhQUFHLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQU5NO0FBT1g3QyxjQUFJLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQVBLO0FBUVhELGFBQUcsRUFBRyxDQUFDLENBQUQsRUFBRyxDQUFILENBUks7QUFTWGlGLGtCQUFRLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQVRDO0FBVVhDLGdCQUFNLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSDtBQVZHLFNBQVo7QUFZQXBOLGdCQUFRLEdBQUcsRUFBWDtBQUNBOztBQUNELFdBQUssUUFBTDtBQUNDLGdCQUFPdUgsVUFBUDtBQUVDLGVBQUssTUFBTDtBQUNDUCxxQkFBUyxHQUFHO0FBQ1hxQixpQkFBRyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FETTtBQUVYQyxtQkFBSyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUg7QUFGSSxhQUFaO0FBSUF0SSxvQkFBUSxHQUFHLENBQVg7QUFDRDs7QUFDQSxlQUFLLFNBQUw7QUFDQ2dILHFCQUFTLEdBQUc7QUFDWHNCLG1CQUFLLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSDtBQURJLGFBQVo7QUFHQXRJLG9CQUFRLEdBQUcsQ0FBWDtBQUNEOztBQUNBLGVBQUssZUFBTDtBQUNDZ0gscUJBQVMsR0FBRztBQUNYc0IsbUJBQUssRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFIO0FBREksYUFBWjtBQUdBdEksb0JBQVEsR0FBRyxDQUFYO0FBQ0Q7O0FBQ0EsZUFBSyxNQUFMO0FBQ0NnSCxxQkFBUyxHQUFHO0FBQ1hzQixtQkFBSyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUg7QUFESSxhQUFaO0FBR0F0SSxvQkFBUSxHQUFHLENBQVg7QUFDRDs7QUFDQTtBQUNDb0ksbUJBQU8sR0FBRyxDQUFWO0FBQ0E7QUE3QkY7O0FBK0JBOztBQUVELFdBQUssVUFBTDtBQUNDcEIsaUJBQVMsR0FBRztBQUNYbUIsY0FBSSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUg7QUFESyxTQUFaO0FBR0FuSSxnQkFBUSxHQUFHLENBQVg7QUFDQTs7QUFDRCxXQUFLLFlBQUw7QUFDQyxnQkFBT3VILFVBQVA7QUFFQyxlQUFLLFlBQUw7QUFDQSxlQUFLLGdCQUFMO0FBQ0NQLHFCQUFTLEdBQUc7QUFDWGtFLGdCQUFFLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQURPO0FBRVhDLGdCQUFFLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQUZPO0FBR1hDLGdCQUFFLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQUhPO0FBSVhDLHFCQUFPLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQUpFO0FBS1hDLGdCQUFFLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQUxPO0FBTVhDLGdCQUFFLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQU5PO0FBT1hDLGdCQUFFLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQVBPO0FBUVhDLHFCQUFPLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQVJFO0FBU1hDLGdCQUFFLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQVRPO0FBVVhDLGdCQUFFLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQVZPO0FBV1hDLGdCQUFFLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQVhPO0FBWVhDLHFCQUFPLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQVpFO0FBYVhDLDBCQUFZLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQWJIO0FBY1hDLDBCQUFZLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQWRIO0FBZVhDLDBCQUFZLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQWZIO0FBZ0JYQyw2QkFBZSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FoQk47QUFpQlhDLGdCQUFFLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQWpCTztBQWtCWEMsZ0JBQUUsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBbEJPO0FBbUJYQyxnQkFBRSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FuQk87QUFvQlhDLG1CQUFLLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQXBCSTtBQXFCWEMsa0JBQUksRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBckJLO0FBc0JYQyxpQkFBRyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0F0Qk07QUF1QlhDLGlCQUFHLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQXZCTTtBQXdCWEMsaUJBQUcsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBeEJNO0FBeUJYQyxtQkFBSyxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0F6Qkk7QUEwQlhDLGdCQUFFLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQTFCTztBQTJCWEMsZ0JBQUUsRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFILENBM0JPO0FBNEJYQyxnQkFBRSxFQUFFLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0E1Qk87QUE2QlhDLG1CQUFLLEVBQUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxDQTdCSTtBQThCWEMsb0JBQU0sRUFBRSxDQUFDLENBQUQsRUFBRyxDQUFIO0FBOUJHLGFBQVo7QUFnQ0EvTSxvQkFBUSxHQUFHLEVBQVg7QUFDRDs7QUFDQTtBQUNDb0ksbUJBQU8sR0FBRyxDQUFWO0FBQ0E7QUF4Q0Y7O0FBMENBOztBQUVEO0FBQ0NBLGVBQU8sR0FBRyxDQUFWO0FBQ0Q7QUF2U0Q7O0FBeVNBLFFBQUlBLE9BQU8sSUFBRSxDQUFiLEVBQ0EsQ0FDQztBQUNBLEtBSEQsTUFLQTtBQUNDO0FBQ0EzSCxtQkFBYSxDQUFDM0MsTUFBZCxDQUFxQm5KLEdBQXJCLEVBQ0E7QUFBRXFDLFlBQUksRUFBRTtBQUNONk8saUJBRE07QUFFTnVCLHFCQUZNO0FBR04xSCxtQkFITTtBQUlOOUwsbUJBSk07QUFLTjBDLGtCQUxNO0FBTU5pUixvQkFOTTtBQU9OQyx1QkFQTTtBQVFOQyxxQkFSTTtBQVNOVCxtQkFUTTtBQVVOdkgsb0JBVk07QUFXTk8sa0JBWE07QUFZTmpLLGNBWk07QUFhTndLO0FBYk07QUFBUixPQURBO0FBaUJBO0FBQ0QsR0FuMkJhOztBQW8yQmIseUJBQXVCM0MsTUFBdkIsRUFBK0I7QUFDL0I2QyxpQkFBYSxDQUFDNUMsTUFBZCxDQUFxQkQsTUFBckI7QUFDQzs7QUF0MkJZLENBQWYsRTs7Ozs7Ozs7Ozs7QUN4T0FqTCxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDeWEsV0FBUyxFQUFDLE1BQUlBO0FBQWYsQ0FBZDtBQUF5QyxJQUFJdmEsTUFBSjtBQUFXSCxNQUFNLENBQUNJLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxLQUFKO0FBQVVOLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0UsT0FBSyxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsU0FBSyxHQUFDRCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlzYSxLQUFKO0FBQVUzYSxNQUFNLENBQUNJLElBQVAsQ0FBWSxPQUFaLEVBQW9CO0FBQUNnSixTQUFPLENBQUMvSSxDQUFELEVBQUc7QUFBQ3NhLFNBQUssR0FBQ3RhLENBQU47QUFBUTs7QUFBcEIsQ0FBcEIsRUFBMEMsQ0FBMUM7QUFJeEssTUFBTXFhLFNBQVMsR0FBRyxJQUFJcGEsS0FBSyxDQUFDQyxVQUFWLENBQXFCLFdBQXJCLENBQWxCOztBQUVQLElBQUlKLE1BQU0sQ0FBQ0ssUUFBWCxFQUFxQjtBQUNwQkwsUUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDZDtBQUNNNlosa0JBQU4sQ0FBcUJDLFVBQXJCO0FBQUEsc0NBQ0E7QUFDQyxZQUFJQyxZQUFZLGlCQUFTSCxLQUFLLENBQUNJLEdBQU4sQ0FBVSxtQ0FBVixDQUFULENBQWhCOztBQUNBLFlBQUlELFlBQVksSUFBSSxJQUFwQixFQUNBO0FBQ0MsY0FBSUUsSUFBSSxHQUFHLHFDQUFxQ0YsWUFBWSxDQUFDeFMsSUFBYixDQUFrQjJTLEVBQWxFO0FBQ0EsZ0JBQU1DLEdBQUcsaUJBQVVQLEtBQUssQ0FBQ0ksR0FBTixDQUFVQyxJQUFWLENBQVYsQ0FBVCxDQUZELENBR0M7O0FBQ0EsY0FBSUUsR0FBRyxJQUFJLElBQVgsRUFDQTtBQUNDLGdCQUFJQyxZQUFZLEdBQUdELEdBQUcsQ0FBQzVTLElBQUosQ0FBUzZTLFlBQTVCO0FBQ0EsZ0JBQUlDLElBQUksR0FBTUYsR0FBRyxDQUFDNVMsSUFBSixDQUFTOFMsSUFBdkI7QUFDQSxnQkFBSUMsS0FBSyxHQUFLSCxHQUFHLENBQUM1UyxJQUFKLENBQVMrUyxLQUF2QjtBQUNBLGdCQUFJQyxRQUFRLEdBQUlKLEdBQUcsQ0FBQzVTLElBQUosQ0FBU2dULFFBQXpCO0FBQ0EsZ0JBQUlDLFNBQVMsR0FBTUwsR0FBRyxDQUFDNVMsSUFBSixDQUFTaVQsU0FBNUI7QUFDQSxnQkFBSUMsSUFBSSxHQUFLTixHQUFHLENBQUM1UyxJQUFKLENBQVNrVCxJQUF0QjtBQUVBLGdCQUFJQyxJQUFJLEdBQUcsSUFBSS9ZLElBQUosRUFBWCxDQVJELENBU0M7O0FBQ0EsZ0JBQUlELFNBQVMsR0FBRyxJQUFJQyxJQUFKLENBQVMrWSxJQUFJLENBQUM3WSxjQUFMLENBQW9CLE9BQXBCLEVBQTZCO0FBQUMyRyxzQkFBUSxFQUFFO0FBQVgsYUFBN0IsQ0FBVCxFQUFpRWUsT0FBakUsRUFBaEI7QUFFQW9RLHFCQUFTLENBQUM1UCxNQUFWLENBQWlCO0FBQ2hCckksdUJBRGdCO0FBRWhCb1ksd0JBRmdCO0FBR2hCTSwwQkFIZ0I7QUFJaEJDLGtCQUpnQjtBQUtoQkMsbUJBTGdCO0FBTWhCQyxzQkFOZ0I7QUFPaEJDLHVCQVBnQjtBQVFoQkM7QUFSZ0IsYUFBakI7QUFVQTtBQUNEO0FBQ0QsT0FqQ0Q7QUFBQSxLQUZjOztBQW9DZDtBQUNNRSxlQUFOLENBQWtCYixVQUFsQjtBQUFBLHNDQUNBO0FBQ0MsY0FBTUssR0FBRyxpQkFBVVAsS0FBSyxDQUFDSSxHQUFOLENBQVUsb0JBQVYsQ0FBVixDQUFULENBREQsQ0FFQzs7QUFDQSxZQUFJRyxHQUFHLElBQUksSUFBWCxFQUNBO0FBQ0MsY0FBSVMsUUFBUSxHQUFHVCxHQUFHLENBQUM1UyxJQUFKLENBQVNzVCxHQUFULENBQWE1WSxLQUFiLENBQW1CLEdBQW5CLENBQWY7QUFDQSxjQUFJbVksWUFBWSxHQUFHRCxHQUFHLENBQUM1UyxJQUFKLENBQVN1VCxPQUE1QjtBQUNBLGNBQUlULElBQUksR0FBTUYsR0FBRyxDQUFDNVMsSUFBSixDQUFTOFMsSUFBdkI7QUFDQSxjQUFJQyxLQUFLLEdBQUtILEdBQUcsQ0FBQzVTLElBQUosQ0FBU3dULE1BQXZCO0FBQ0EsY0FBSVIsUUFBUSxHQUFJLEVBQWhCO0FBQ0EsY0FBSUMsU0FBUyxHQUFNLEVBQW5COztBQUNBLGNBQUlJLFFBQVEsQ0FBQ3pZLE1BQVQsR0FBZ0IsQ0FBcEIsRUFDQTtBQUNDb1ksb0JBQVEsR0FBSUssUUFBUSxDQUFDLENBQUQsQ0FBcEI7QUFDQUoscUJBQVMsR0FBTUksUUFBUSxDQUFDLENBQUQsQ0FBdkI7QUFDQTs7QUFDRCxjQUFJSCxJQUFJLEdBQUtOLEdBQUcsQ0FBQzVTLElBQUosQ0FBUzJTLEVBQXRCO0FBRUEsY0FBSVEsSUFBSSxHQUFHLElBQUkvWSxJQUFKLEVBQVgsQ0FkRCxDQWVDOztBQUNBLGNBQUlELFNBQVMsR0FBRyxJQUFJQyxJQUFKLENBQVMrWSxJQUFJLENBQUM3WSxjQUFMLENBQW9CLE9BQXBCLEVBQTZCO0FBQUMyRyxvQkFBUSxFQUFFO0FBQVgsV0FBN0IsQ0FBVCxFQUFpRWUsT0FBakUsRUFBaEI7QUFFQW9RLG1CQUFTLENBQUM1UCxNQUFWLENBQWlCO0FBQ2hCckkscUJBRGdCO0FBRWhCb1ksc0JBRmdCO0FBR2hCTSx3QkFIZ0I7QUFJaEJDLGdCQUpnQjtBQUtoQkMsaUJBTGdCO0FBTWhCQyxvQkFOZ0I7QUFPaEJDLHFCQVBnQjtBQVFoQkM7QUFSZ0IsV0FBakI7QUFVQTtBQUNELE9BbENEO0FBQUEsS0FyQ2M7O0FBeUVkO0FBQ00sdUJBQU47QUFBQSxzQ0FBNEI7QUFDMUIsNkJBQWFkLFNBQVMsQ0FBQ3hXLGFBQVYsR0FBMEJDLFNBQTFCLENBQW9DLENBQ2pEO0FBQUNzQixlQUFLLEVBQUc7QUFBRWhELHFCQUFTLEVBQUcsQ0FBQztBQUFmO0FBQVQsU0FEaUQsRUFFakQ7QUFBQ3VDLGtCQUFRLEVBQUU7QUFDVix5QkFBYTtBQUFFVCwyQkFBYSxFQUFFO0FBQUVDLHNCQUFNLEVBQUUsYUFBVjtBQUF5QkMsb0JBQUksRUFBRTtBQUFDQyxzQkFBSSxFQUFHLENBQUMsSUFBSWhDLElBQUosQ0FBUyxDQUFULENBQUQsRUFBYyxZQUFkO0FBQVIsaUJBQS9CO0FBQXNFaUMsd0JBQVEsRUFBRTtBQUFoRjtBQUFqQixhQURIO0FBRVYsMEJBQWMsYUFGSjtBQUdWLDRCQUFnQixlQUhOO0FBSVYsb0JBQVEsT0FKRTtBQUtWLHFCQUFTLFFBTEM7QUFNVix3QkFBWSxXQU5GO0FBT1YseUJBQWEsWUFQSDtBQVFWLG9CQUFRO0FBUkU7QUFBWCxTQUZpRCxDQUFwQyxFQWFYMkcsT0FiVyxFQUFiO0FBY0QsT0FmRDtBQUFBOztBQTFFYyxHQUFmO0FBMkZBLEM7Ozs7Ozs7Ozs7O0FDbEdELElBQUluTCxNQUFKO0FBQVdILE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLEtBQUo7QUFBVU4sTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRSxPQUFLLENBQUNELENBQUQsRUFBRztBQUFDQyxTQUFLLEdBQUNELENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSTBiLFFBQUo7QUFBYS9iLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLHNCQUFaLEVBQW1DO0FBQUMyYixVQUFRLENBQUMxYixDQUFELEVBQUc7QUFBQzBiLFlBQVEsR0FBQzFiLENBQVQ7QUFBVzs7QUFBeEIsQ0FBbkMsRUFBNkQsQ0FBN0Q7QUFBZ0UsSUFBSXFRLEtBQUo7QUFBVTFRLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLHVCQUFaLEVBQW9DO0FBQUNzUSxPQUFLLENBQUNyUSxDQUFELEVBQUc7QUFBQ3FRLFNBQUssR0FBQ3JRLENBQU47QUFBUTs7QUFBbEIsQ0FBcEMsRUFBd0QsQ0FBeEQ7QUFBMkQsSUFBSXFQLEtBQUo7QUFBVTFQLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQ2dKLFNBQU8sQ0FBQy9JLENBQUQsRUFBRztBQUFDcVAsU0FBSyxHQUFDclAsQ0FBTjtBQUFROztBQUFwQixDQUF6QixFQUErQyxDQUEvQztBQUFrRCxJQUFJc2EsS0FBSjtBQUFVM2EsTUFBTSxDQUFDSSxJQUFQLENBQVksT0FBWixFQUFvQjtBQUFDZ0osU0FBTyxDQUFDL0ksQ0FBRCxFQUFHO0FBQUNzYSxTQUFLLEdBQUN0YSxDQUFOO0FBQVE7O0FBQXBCLENBQXBCLEVBQTBDLENBQTFDOztBQU9wVjtBQUVBLElBQUlGLE1BQU0sQ0FBQ0ssUUFBWCxFQUFxQjtBQUNwQjtBQUNBTCxRQUFNLENBQUNNLE9BQVAsQ0FBZSxVQUFmLEVBQTJCLFlBQVk7QUFDdEMsUUFBSSxDQUFDLEtBQUtpSyxNQUFWLEVBQWtCO0FBQ2pCLGFBQU8sSUFBUDtBQUNBOztBQUNELFdBQU92SyxNQUFNLENBQUM2YixLQUFQLENBQWFuYixJQUFiLENBQWtCLEtBQUs2SixNQUF2QixFQUErQixFQUEvQixDQUFQO0FBQ0EsR0FMRDtBQU9BdkssUUFBTSxDQUFDTSxPQUFQLENBQWUsSUFBZixFQUFxQixZQUFZO0FBQ2hDLFFBQUksS0FBS2lLLE1BQVQsRUFBaUI7QUFDaEIsYUFBT3ZLLE1BQU0sQ0FBQzhiLGNBQVAsQ0FBc0JwYixJQUF0QixDQUEyQjtBQUFFLG9CQUFZLEtBQUs2SjtBQUFuQixPQUEzQixDQUFQO0FBQ0EsS0FGRCxNQUVPO0FBQ04sV0FBS3dSLEtBQUw7QUFDQTtBQUNELEdBTkQ7QUFVQS9iLFFBQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBQ2RvYixlQUFXLEdBQ1g7QUFDQyxhQUFPLEtBQUtDLFVBQUwsQ0FBZ0JDLGFBQXZCO0FBQ0EsS0FKYTs7QUFLZDtBQUNBQyxxQkFBaUIsQ0FBQ2xaLElBQUQsRUFDakI7QUFFQyxVQUFJLENBQUUsS0FBS3NILE1BQVgsRUFBbUI7QUFDbEIsZUFBTyxDQUFQO0FBQ0E7O0FBQ0QsVUFBSTZSLElBQUksR0FBRyxLQUFYO0FBQ0E3TCxXQUFLLENBQUM4TCxnQkFBTixDQUF1QixLQUFLOVIsTUFBNUIsRUFBb0N4SSxPQUFwQyxDQUE0QyxVQUFTZ08sS0FBVCxFQUFnQjtBQUMzRCxZQUFJUyxJQUFJLEdBQUdELEtBQUssQ0FBQytMLGVBQU4sQ0FBc0IsS0FBSy9SLE1BQTNCLEVBQWtDd0YsS0FBbEMsQ0FBWDs7QUFDQSxZQUFJUSxLQUFLLENBQUNHLFlBQU4sQ0FBbUIsS0FBS25HLE1BQXhCLEVBQStCaUcsSUFBL0IsRUFBb0N2TixJQUFwQyxDQUFKLEVBQStDO0FBQzlDbVosY0FBSSxHQUFHLElBQVA7QUFDQTtBQUNBO0FBQ0QsT0FORDtBQU9BLFVBQUlBLElBQUosRUFBVSxPQUFPLENBQVA7QUFDVixhQUFPLENBQVA7QUFDQSxLQXRCYTs7QUF1QmQ7QUFDQUcsb0JBQWdCLEdBQUc7QUFDbEIsVUFBSSxDQUFFLEtBQUtoUyxNQUFYLEVBQW1CO0FBQ2xCLGVBQU9nRixLQUFLLENBQUNLLE1BQWI7QUFDQTs7QUFHRCxVQUFJNVAsTUFBTSxDQUFDNlEsSUFBUCxNQUFpQjdRLE1BQU0sQ0FBQzZRLElBQVAsR0FBYzJMLE9BQW5DLEVBQTRDO0FBQzNDLFlBQUlqTSxLQUFLLENBQUNHLFlBQU4sQ0FBbUIxUSxNQUFNLENBQUN1SyxNQUFQLEVBQW5CLEVBQW9DZ0YsS0FBSyxDQUFDRyxRQUExQyxFQUFxRDFQLE1BQU0sQ0FBQzZRLElBQVAsR0FBYzJMLE9BQWQsQ0FBc0J2WixJQUEzRSxDQUFKLEVBQ0E7QUFDQyxpQkFBT3NNLEtBQUssQ0FBQ0csUUFBYjtBQUNBLFNBSEQsTUFHTyxJQUFJYSxLQUFLLENBQUNHLFlBQU4sQ0FBbUIxUSxNQUFNLENBQUN1SyxNQUFQLEVBQW5CLEVBQW9DZ0YsS0FBSyxDQUFDSSxJQUExQyxFQUFpRDNQLE1BQU0sQ0FBQzZRLElBQVAsR0FBYzJMLE9BQWQsQ0FBc0J2WixJQUF2RSxDQUFKLEVBQ1A7QUFDQyxpQkFBT3NNLEtBQUssQ0FBQ0ksSUFBYjtBQUNBLFNBSE0sTUFHQSxJQUFJWSxLQUFLLENBQUNHLFlBQU4sQ0FBbUIxUSxNQUFNLENBQUN1SyxNQUFQLEVBQW5CLEVBQW9DZ0YsS0FBSyxDQUFDRSxhQUExQyxFQUEwRHpQLE1BQU0sQ0FBQzZRLElBQVAsR0FBYzJMLE9BQWQsQ0FBc0J2WixJQUFoRixDQUFKLEVBQ1A7QUFDQyxpQkFBT3NNLEtBQUssQ0FBQ0UsYUFBYjtBQUNBLFNBSE0sTUFHQyxJQUFJYyxLQUFLLENBQUNHLFlBQU4sQ0FBbUIxUSxNQUFNLENBQUN1SyxNQUFQLEVBQW5CLEVBQW9DZ0YsS0FBSyxDQUFDQyxLQUExQyxFQUFpRHhQLE1BQU0sQ0FBQzZRLElBQVAsR0FBYzJMLE9BQWQsQ0FBc0J2WixJQUF2RSxDQUFKLEVBQ1I7QUFDQyxpQkFBT3NNLEtBQUssQ0FBQ0MsS0FBYjtBQUNBO0FBQ0Q7O0FBQ0QsYUFBT0QsS0FBSyxDQUFDSyxNQUFiO0FBQ0EsS0E5Q2E7O0FBZ0RkO0FBQ002TSx5QkFBTixDQUE0QkMsS0FBNUIsRUFBa0N6WixJQUFsQztBQUFBLHNDQUNBO0FBQ0MsWUFBSSxDQUFFLEtBQUtzSCxNQUFYLEVBQW1CO0FBQ2xCLGdCQUFNLElBQUl2SyxNQUFNLENBQUN3SyxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0E7O0FBRUQsWUFBSSxRQUFRa1MsS0FBWixFQUFtQjtBQUFFO0FBQ3BCLGlCQUFPLENBQVA7QUFDQTs7QUFDRCw2QkFBYW5NLEtBQUssQ0FBQ0csWUFBTixDQUFtQjFRLE1BQU0sQ0FBQ3VLLE1BQVAsRUFBbkIsRUFBb0MsQ0FBQyxPQUFELENBQXBDLEVBQStDdEgsSUFBL0MsQ0FBYjtBQUNBLE9BVkQ7QUFBQSxLQWpEYzs7QUErRGQ7QUFDTSxjQUFOO0FBQUEsc0NBQW1CO0FBQ2xCLFlBQUksQ0FBRSxLQUFLc0gsTUFBWCxFQUFtQjtBQUNsQixnQkFBTSxJQUFJdkssTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNBOztBQUNELFlBQUlxRyxJQUFJLEdBQUcsRUFBWDtBQUNBN1EsY0FBTSxDQUFDNmIsS0FBUCxDQUFhbmIsSUFBYixDQUFrQjtBQUFFbUIsYUFBRyxFQUFFLEtBQUswSTtBQUFaLFNBQWxCLEVBQXdDeEksT0FBeEMsQ0FBZ0QsVUFBU0MsR0FBVCxFQUFjO0FBQzdENk8sY0FBSSxHQUFJN08sR0FBRyxDQUFDdUosUUFBWjtBQUNBLFNBRkQ7QUFHQSxlQUFPc0YsSUFBUDtBQUVBLE9BVkQ7QUFBQSxLQWhFYzs7QUEyRWQ7QUFDQSx1QkFBbUJBLElBQW5CLEVBQXlCO0FBQ3hCLFVBQUlBLElBQUksQ0FBQ3RGLFFBQVQsRUFBbUI7QUFDbEIsWUFBSSxDQUFDZ0YsS0FBSyxDQUFDRyxZQUFOLENBQW1CMVEsTUFBTSxDQUFDdUssTUFBUCxFQUFuQixFQUFvQ2dGLEtBQUssQ0FBQ0MsS0FBMUMsRUFBaUQsSUFBakQsQ0FBTCxFQUNBO0FBQ0MsZ0JBQU0sSUFBSXhQLE1BQU0sQ0FBQ3dLLEtBQVgsQ0FBaUIsd0RBQWpCLENBQU47QUFDQSxTQUhELE1BS0E7QUFDQyxjQUFJeEssTUFBTSxDQUFDNmIsS0FBUCxDQUFhaFIsT0FBYixDQUFxQjtBQUFFVSxvQkFBUSxFQUFDc0YsSUFBSSxDQUFDdEY7QUFBaEIsV0FBckIsS0FBaUQsSUFBckQsRUFDQTtBQUNDLGtCQUFNLElBQUl2TCxNQUFNLENBQUN3SyxLQUFYLENBQWlCLDJDQUFqQixDQUFOO0FBQ0EsV0FIRCxNQUtBO0FBQ0MsZ0JBQUltUyxFQUFFLEdBQUdmLFFBQVEsQ0FBQ2dCLFVBQVQsQ0FBb0I7QUFDNUJyUixzQkFBUSxFQUFFc0YsSUFBSSxDQUFDdEYsUUFEYTtBQUU1QnNSLHNCQUFRLEVBQUVoTSxJQUFJLENBQUNnTSxRQUZhO0FBRzVCTCxxQkFBTyxFQUFFO0FBQ1JNLHVCQUFPLEVBQUVqTSxJQUFJLENBQUNpTTtBQUROO0FBSG1CLGFBQXBCLENBQVQsQ0FERCxDQVFDO0FBQ0M7QUFDQTtBQUNEO0FBQ0E7QUFDRDtBQUNEO0FBQ0QsS0F4R2E7O0FBeUdkO0FBQ0EsdUJBQW1CQyxNQUFuQixFQUEyQmxNLElBQTNCLEVBQWlDO0FBQ2hDLFVBQUksQ0FBQ04sS0FBSyxDQUFDRyxZQUFOLENBQW1CMVEsTUFBTSxDQUFDdUssTUFBUCxFQUFuQixFQUFvQ2dGLEtBQUssQ0FBQ0MsS0FBMUMsRUFBaUQsSUFBakQsQ0FBTCxFQUNBO0FBQ0MsY0FBTSxJQUFJeFAsTUFBTSxDQUFDd0ssS0FBWCxDQUFpQix3REFBakIsQ0FBTjtBQUNBLE9BSEQsTUFLQTtBQUNDLFlBQUksQ0FBRSxLQUFLRCxNQUFYLEVBQW1CO0FBQ2xCLGdCQUFNLElBQUl2SyxNQUFNLENBQUN3SyxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0E7O0FBQ0QsWUFBSWUsUUFBUSxHQUFFdkwsTUFBTSxDQUFDNmIsS0FBUCxDQUFhaFIsT0FBYixDQUFxQixLQUFLTixNQUExQixFQUFrQ2dCLFFBQWhEOztBQUNBLFlBQUtzRixJQUFJLENBQUN0RixRQUFMLElBQWdCQSxRQUFqQixJQUErQkEsUUFBUSxJQUFHLFNBQTlDLEVBQTBEO0FBRXpEO0FBQ0F2TCxnQkFBTSxDQUFDNmIsS0FBUCxDQUFhN1EsTUFBYixDQUFvQitSLE1BQXBCLEVBQTRCO0FBQzNCN1ksZ0JBQUksRUFBRTtBQUNMc1kscUJBQU8sRUFBQztBQUNQTSx1QkFBTyxFQUFFak0sSUFBSSxDQUFDaU07QUFEUDtBQURIO0FBRHFCLFdBQTVCLEVBSHlELENBVXpEOztBQUNBLGNBQUlqTSxJQUFJLENBQUNnTSxRQUFMLElBQWlCLEVBQXJCLEVBQXlCO0FBQ3hCO0FBQ0FqQixvQkFBUSxDQUFDb0IsV0FBVCxDQUFxQkQsTUFBckIsRUFBNkJsTSxJQUFJLENBQUNnTSxRQUFsQyxFQUE0QyxVQUFVSSxHQUFWLEVBQWU7QUFDMUQsa0JBQUksQ0FBQ0EsR0FBTCxFQUFVLENBQ1Q7QUFDQSxlQUZELE1BRU8sQ0FDTjtBQUNBO0FBQ0QsYUFORDtBQU9BO0FBQ0QsU0FyQkQsTUF1QkE7QUFDQyxnQkFBTSxJQUFJamQsTUFBTSxDQUFDd0ssS0FBWCxDQUFpQix3REFBakIsQ0FBTjtBQUNBO0FBQ0Q7QUFDRCxLQWhKYTs7QUFrSmQ7QUFDQSxrQkFBY00sTUFBZCxFQUFzQjtBQUNyQixVQUFJLENBQUN5RixLQUFLLENBQUNHLFlBQU4sQ0FBbUIxUSxNQUFNLENBQUN1SyxNQUFQLEVBQW5CLEVBQW9DZ0YsS0FBSyxDQUFDQyxLQUExQyxFQUFpRCxJQUFqRCxDQUFMLEVBQ0E7QUFDQyxjQUFNLElBQUl4UCxNQUFNLENBQUN3SyxLQUFYLENBQWlCLHdEQUFqQixDQUFOO0FBQ0EsT0FIRCxNQUtBO0FBQ0MsWUFBSWUsUUFBUSxHQUFFdkwsTUFBTSxDQUFDNmIsS0FBUCxDQUFhaFIsT0FBYixDQUFxQkMsTUFBckIsRUFBNkJTLFFBQTNDOztBQUNBLFlBQUtBLFFBQVEsSUFBRSxPQUFYLElBQXdCQSxRQUFRLElBQUUsU0FBdEMsRUFDQTtBQUNDLGdCQUFNLElBQUl2TCxNQUFNLENBQUN3SyxLQUFYLENBQWlCLGlDQUFqQixDQUFOO0FBQ0EsU0FIRCxNQUtBO0FBQ0N4SyxnQkFBTSxDQUFDNmIsS0FBUCxDQUFhOVEsTUFBYixDQUFvQkQsTUFBcEI7QUFDQTtBQUNEO0FBQ0QsS0FwS2E7O0FBcUtkO0FBQ0EsZ0JBQVlBLE1BQVosRUFBb0IrRixJQUFwQixFQUEwQjtBQUN6QixVQUFJLENBQUNOLEtBQUssQ0FBQ0csWUFBTixDQUFtQjFRLE1BQU0sQ0FBQ3VLLE1BQVAsRUFBbkIsRUFBb0NnRixLQUFLLENBQUNDLEtBQTFDLEVBQWlELElBQWpELENBQUwsRUFDQTtBQUNDLGNBQU0sSUFBSXhQLE1BQU0sQ0FBQ3dLLEtBQVgsQ0FBaUIsd0RBQWpCLENBQU47QUFDQSxPQUhELE1BS0E7QUFDQyxZQUFJLENBQUUsS0FBS0QsTUFBWCxFQUFtQjtBQUNsQixnQkFBTSxJQUFJdkssTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNBOztBQUVELFlBQUksQ0FBQytGLEtBQUssQ0FBQ0csWUFBTixDQUFtQjVGLE1BQW5CLEVBQTJCK0YsSUFBSSxDQUFDcU0sTUFBaEMsRUFBd0NyTSxJQUFJLENBQUM1TixJQUE3QyxDQUFMLEVBQ0E7QUFDQ3NOLGVBQUssQ0FBQzRNLFVBQU4sQ0FBaUJ0TSxJQUFJLENBQUNxTSxNQUF0QixFQUE4QjtBQUFDRSx3QkFBWSxFQUFFO0FBQWYsV0FBOUI7QUFDQTdNLGVBQUssQ0FBQzhNLGVBQU4sQ0FBc0J2UyxNQUF0QixFQUE4QitGLElBQUksQ0FBQ3FNLE1BQW5DLEVBQTJDck0sSUFBSSxDQUFDNU4sSUFBaEQ7QUFDQSxTQUpELE1BTUE7QUFDQyxnQkFBTSxJQUFJakQsTUFBTSxDQUFDd0ssS0FBWCxDQUFpQiw2Q0FBakIsQ0FBTjtBQUNBO0FBQ0Q7QUFDRCxLQTNMYTs7QUE0TGQ7QUFDQSxtQkFBZU0sTUFBZixFQUF1QitGLElBQXZCLEVBQTZCO0FBQzVCLFVBQUksQ0FBQ04sS0FBSyxDQUFDRyxZQUFOLENBQW1CMVEsTUFBTSxDQUFDdUssTUFBUCxFQUFuQixFQUFvQ2dGLEtBQUssQ0FBQ0MsS0FBMUMsRUFBaUQsSUFBakQsQ0FBTCxFQUNBO0FBQ0MsY0FBTSxJQUFJeFAsTUFBTSxDQUFDd0ssS0FBWCxDQUFpQixXQUFqQixFQUE2Qix3QkFBN0IsQ0FBTjtBQUNBLE9BSEQsTUFLQTtBQUNDLFlBQUllLFFBQVEsR0FBRXZMLE1BQU0sQ0FBQzZiLEtBQVAsQ0FBYWhSLE9BQWIsQ0FBcUJDLE1BQXJCLEVBQTZCUyxRQUEzQzs7QUFDQSxZQUFLQSxRQUFRLElBQUUsT0FBWCxJQUF3QkEsUUFBUSxJQUFFLFNBQXRDLEVBQWlEO0FBQ2hELGdCQUFNLElBQUl2TCxNQUFNLENBQUN3SyxLQUFYLENBQWlCLHdEQUFqQixDQUFOO0FBQ0EsU0FGRCxNQUlBO0FBQ0MrRixlQUFLLENBQUMrTSxvQkFBTixDQUE0QnhTLE1BQTVCLEVBQW9DK0YsSUFBSSxDQUFDcU0sTUFBekMsRUFBaURyTSxJQUFJLENBQUM1TixJQUF0RDtBQUNBO0FBQ0Q7QUFDRDs7QUE3TWEsR0FBZjtBQStNQTs7QUFFRGpELE1BQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBQ2Q7QUFDQSxtQkFDQTtBQUNDLFFBQUlFLFNBQVMsR0FBRyxFQUFoQjtBQUNBLFFBQUl5YyxnQkFBZ0IsR0FBR3BkLEtBQUssQ0FBQ3FkLFdBQU4sQ0FBa0JDLE1BQWxCLENBQXlCLGlCQUF6QixDQUF2QjtBQUNBemQsVUFBTSxDQUFDdWQsZ0JBQVAsQ0FBd0I3YyxJQUF4QixDQUE2QjtBQUFDLGtCQUFZLEtBQUs2SjtBQUFsQixLQUE3QixFQUF3RHhJLE9BQXhELENBQWdFLFVBQVNDLEdBQVQsRUFBYztBQUM3RWxCLGVBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkTixXQUFHLEVBQUdHLEdBQUcsQ0FBQ0gsR0FESTtBQUVkMk8sWUFBSSxFQUFFeE8sR0FBRyxDQUFDd08sSUFBSixDQUFTM08sR0FGRDtBQUdkb0IsWUFBSSxFQUFFakIsR0FBRyxDQUFDK047QUFISSxPQUFmO0FBS0EsS0FORDtBQU9BLFdBQU9qUCxTQUFQO0FBQ0EsR0FkYTs7QUFlZDtBQUNBLHFCQUNBO0FBQ0MsUUFBSUEsU0FBUyxHQUFHLEVBQWhCO0FBQ0FkLFVBQU0sQ0FBQzZiLEtBQVAsQ0FBYW5iLElBQWIsQ0FBa0IsRUFBbEIsRUFBc0JxQixPQUF0QixDQUE4QixVQUFTQyxHQUFULEVBQWM7QUFDM0M7QUFDQTtBQUNDO0FBQ0Q7QUFDQTtBQUNDbEIsaUJBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkTixhQUFHLEVBQUVHLEdBQUcsQ0FBQ0gsR0FESztBQUVkMEosa0JBQVEsRUFBRXZKLEdBQUcsQ0FBQ3VKLFFBRkE7QUFHZHVSLGlCQUFPLEVBQUU5YSxHQUFHLENBQUN3YSxPQUFKLENBQVlNO0FBSFAsU0FBZjtBQUtBO0FBQ0QsS0FaRDtBQWFBLFdBQU9oYyxTQUFQO0FBQ0EsR0FqQ2E7O0FBa0NkO0FBQ0EsMEJBQ0E7QUFDQyxRQUFJQSxTQUFTLEdBQUcsRUFBaEI7QUFDQWQsVUFBTSxDQUFDNmIsS0FBUCxDQUFhbmIsSUFBYixDQUFrQixFQUFsQixFQUFzQnFCLE9BQXRCLENBQThCLFVBQVNDLEdBQVQsRUFBYztBQUMzQyxVQUFLQSxHQUFHLENBQUN1SixRQUFKLElBQWMsU0FBZixJQUE4QnZKLEdBQUcsQ0FBQ3VKLFFBQUosSUFBYyxlQUFoRCxFQUNBLENBQ0M7QUFDQSxPQUhELE1BSUE7QUFDQ3pLLGlCQUFTLENBQUNxQixJQUFWLENBQWU7QUFDZE4sYUFBRyxFQUFFRyxHQUFHLENBQUNILEdBREs7QUFFZDBKLGtCQUFRLEVBQUV2SixHQUFHLENBQUN1SixRQUZBO0FBR2R1UixpQkFBTyxFQUFFOWEsR0FBRyxDQUFDd2EsT0FBSixDQUFZTTtBQUhQLFNBQWY7QUFLQTtBQUNELEtBWkQ7QUFhQSxXQUFPaGMsU0FBUDtBQUNBLEdBcERhOztBQXFEZDtBQUNBLHFCQUNBO0FBQ0MsUUFBSUEsU0FBUyxHQUFHLEVBQWhCO0FBQ0EsUUFBSUUsS0FBSyxHQUFJLENBQWI7QUFDQWhCLFVBQU0sQ0FBQzZiLEtBQVAsQ0FBYW5iLElBQWIsQ0FBa0IsRUFBbEIsRUFBc0JxQixPQUF0QixDQUE4QixVQUFTQyxHQUFULEVBQWM7QUFDM0N1TyxXQUFLLENBQUM4TCxnQkFBTixDQUF1QnJhLEdBQUcsQ0FBQ0gsR0FBM0IsRUFBZ0NFLE9BQWhDLENBQXdDLFVBQVNnTyxLQUFULEVBQWdCO0FBQ3ZELFlBQUlTLElBQUksR0FBR0QsS0FBSyxDQUFDK0wsZUFBTixDQUFzQnRhLEdBQUcsQ0FBQ0gsR0FBMUIsRUFBOEJrTyxLQUE5QixDQUFYO0FBQ0FqUCxpQkFBUyxDQUFDcUIsSUFBVixDQUFlO0FBQ2RuQixlQUFLLEVBQUVBLEtBRE87QUFFZGEsYUFBRyxFQUFFRyxHQUFHLENBQUNILEdBRks7QUFHZDBKLGtCQUFRLEVBQUV2SixHQUFHLENBQUN1SixRQUhBO0FBSWR0SSxjQUFJLEVBQUU4TSxLQUpRO0FBS2QrTSxpQkFBTyxFQUFFOWEsR0FBRyxDQUFDd2EsT0FBSixDQUFZTSxPQUxQO0FBTWRJLGdCQUFNLEVBQUMxTTtBQU5PLFNBQWY7QUFRQXhQLGFBQUs7QUFDTCxPQVhEO0FBWUEsS0FiRDtBQWNBLFdBQU9GLFNBQVA7QUFDQSxHQXpFYTs7QUEwRWQ7QUFDQSwwQkFDQTtBQUNDLFFBQUlBLFNBQVMsR0FBRyxFQUFoQjtBQUNBLFFBQUlFLEtBQUssR0FBSSxDQUFiO0FBQ0FoQixVQUFNLENBQUM2YixLQUFQLENBQWFuYixJQUFiLENBQWtCLEVBQWxCLEVBQXNCcUIsT0FBdEIsQ0FBOEIsVUFBU0MsR0FBVCxFQUFjO0FBQzNDLFVBQUtBLEdBQUcsQ0FBQ3VKLFFBQUosSUFBYyxTQUFmLElBQThCdkosR0FBRyxDQUFDdUosUUFBSixJQUFjLGVBQWhELEVBQ0EsQ0FDQztBQUNBLE9BSEQsTUFJQTtBQUNDZ0YsYUFBSyxDQUFDOEwsZ0JBQU4sQ0FBdUJyYSxHQUFHLENBQUNILEdBQTNCLEVBQWdDRSxPQUFoQyxDQUF3QyxVQUFTZ08sS0FBVCxFQUFnQjtBQUN2RCxjQUFJUyxJQUFJLEdBQUdELEtBQUssQ0FBQytMLGVBQU4sQ0FBc0J0YSxHQUFHLENBQUNILEdBQTFCLEVBQThCa08sS0FBOUIsQ0FBWDtBQUNBalAsbUJBQVMsQ0FBQ3FCLElBQVYsQ0FBZTtBQUNkbkIsaUJBQUssRUFBRUEsS0FETztBQUVkYSxlQUFHLEVBQUVHLEdBQUcsQ0FBQ0gsR0FGSztBQUdkMEosb0JBQVEsRUFBRXZKLEdBQUcsQ0FBQ3VKLFFBSEE7QUFJZHRJLGdCQUFJLEVBQUU4TSxLQUpRO0FBS2QrTSxtQkFBTyxFQUFFOWEsR0FBRyxDQUFDd2EsT0FBSixDQUFZTSxPQUxQO0FBTWRJLGtCQUFNLEVBQUMxTTtBQU5PLFdBQWY7QUFRQXhQLGVBQUs7QUFDTCxTQVhEO0FBWUE7QUFDRCxLQW5CRDtBQW9CQSxXQUFPRixTQUFQO0FBQ0E7O0FBcEdhLENBQWYsRTs7Ozs7Ozs7Ozs7QUM3T0EsSUFBSWQsTUFBSjtBQUFXSCxNQUFNLENBQUNJLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxLQUFKO0FBQVVOLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0UsT0FBSyxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsU0FBSyxHQUFDRCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtETCxNQUFNLENBQUNJLElBQVAsQ0FBWSxnQ0FBWjtBQUE4Q0osTUFBTSxDQUFDSSxJQUFQLENBQVksK0JBQVo7QUFBNkNKLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGtDQUFaO0FBQWdESixNQUFNLENBQUNJLElBQVAsQ0FBWSwrQkFBWjtBQUE2Q0osTUFBTSxDQUFDSSxJQUFQLENBQVksK0JBQVo7QUFBNkNKLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLG1DQUFaO0FBQWlESixNQUFNLENBQUNJLElBQVAsQ0FBWSxrQ0FBWjtBQUFnREosTUFBTSxDQUFDSSxJQUFQLENBQVksNEJBQVo7QUFBMENKLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLDhCQUFaO0FBQTRDSixNQUFNLENBQUNJLElBQVAsQ0FBWSxrQ0FBWjtBQUFnREosTUFBTSxDQUFDSSxJQUFQLENBQVkscUNBQVo7QUFBbURKLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLDZCQUFaO0FBQTJDSixNQUFNLENBQUNJLElBQVAsQ0FBWSxnQ0FBWjtBQUE4Q0osTUFBTSxDQUFDSSxJQUFQLENBQVksMEJBQVo7QUFBd0NKLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLHVCQUFaO0FBQXFDLElBQUlzUCxLQUFKO0FBQVUxUCxNQUFNLENBQUNJLElBQVAsQ0FBWSx1QkFBWixFQUFvQztBQUFDZ0osU0FBTyxDQUFDL0ksQ0FBRCxFQUFHO0FBQUNxUCxTQUFLLEdBQUNyUCxDQUFOO0FBQVE7O0FBQXBCLENBQXBDLEVBQTBELENBQTFEO0FBQTZETCxNQUFNLENBQUNJLElBQVAsQ0FBWSxnQ0FBWjtBQUE4Q0osTUFBTSxDQUFDSSxJQUFQLENBQVksMEJBQVo7QUFBd0NKLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLDJCQUFaO0FBeUI5N0JELE1BQU0sQ0FBQzBkLE9BQVAsQ0FBZSxNQUFNO0FBQ25CO0FBQ0EsTUFBSTFkLE1BQU0sQ0FBQzZiLEtBQVAsQ0FBYW5iLElBQWIsR0FBb0JpZCxLQUFwQixHQUE0QjVhLE1BQTVCLEtBQXVDLENBQTNDLEVBQThDO0FBRTVDaUgsV0FBTyxDQUFDQyxHQUFSLENBQVksa0JBQVo7QUFDSCxRQUFJNFIsS0FBSyxHQUFHLENBQ1g7QUFBQ3RRLGNBQVEsRUFBRSxTQUFYO0FBQ0FzUixjQUFRLEVBQUUsYUFEVjtBQUVBSCxXQUFLLEVBQUUsQ0FBQ25OLEtBQUssQ0FBQ0MsS0FBUCxDQUZQO0FBR0FnTixhQUFPLEVBQUM7QUFDUE0sZUFBTyxFQUFFO0FBREY7QUFIUixLQURXLEVBT1g7QUFBQ3ZSLGNBQVEsRUFBRSxlQUFYO0FBQ0FzUixjQUFRLEVBQUUsYUFEVjtBQUVBSCxXQUFLLEVBQUUsQ0FBQ25OLEtBQUssQ0FBQ0MsS0FBUCxDQUZQO0FBR0FnTixhQUFPLEVBQUM7QUFDUE0sZUFBTyxFQUFFO0FBREY7QUFIUixLQVBXLENBQVosQ0FIK0MsQ0FpQjVDOztBQUNIakIsU0FBSyxDQUFDOVosT0FBTixDQUFjLFVBQVM4TyxJQUFULEVBQWU7QUFDNUIsVUFBSThMLEVBQUo7QUFDQTNTLGFBQU8sQ0FBQ0MsR0FBUixDQUFZNEcsSUFBWjtBQUNBOEwsUUFBRSxHQUFHZixRQUFRLENBQUNnQixVQUFULENBQW9CO0FBQ3hCclIsZ0JBQVEsRUFBRXNGLElBQUksQ0FBQ3RGLFFBRFM7QUFFeEJzUixnQkFBUSxFQUFFaE0sSUFBSSxDQUFDZ00sUUFGUztBQUd4QkwsZUFBTyxFQUFDO0FBQ1BNLGlCQUFPLEVBQUVqTSxJQUFJLENBQUMyTCxPQUFMLENBQWFNO0FBRGY7QUFIZ0IsT0FBcEIsQ0FBTDs7QUFPQSxVQUFJOWMsTUFBTSxDQUFDOGIsY0FBUCxDQUFzQnBiLElBQXRCLENBQTJCO0FBQUUsb0JBQVlpYztBQUFkLE9BQTNCLEVBQStDbk8sS0FBL0MsT0FBMkQsQ0FBL0QsRUFBa0U7QUFFakVxQyxZQUFJLENBQUM2TCxLQUFMLENBQVczYSxPQUFYLENBQW1CLFVBQVV5TyxJQUFWLEVBQWdCO0FBQ2xDRCxlQUFLLENBQUM0TSxVQUFOLENBQWlCM00sSUFBakIsRUFBdUI7QUFBQzRNLHdCQUFZLEVBQUU7QUFBZixXQUF2QjtBQUNBLFNBRkQ7QUFHQTdNLGFBQUssQ0FBQzhNLGVBQU4sQ0FBc0JWLEVBQXRCLEVBQXlCOUwsSUFBSSxDQUFDNkwsS0FBOUIsRUFBb0MsU0FBcEM7QUFDQW5NLGFBQUssQ0FBQzhNLGVBQU4sQ0FBc0JWLEVBQXRCLEVBQXlCOUwsSUFBSSxDQUFDNkwsS0FBOUIsRUFBb0MsSUFBcEM7QUFDQTtBQUNFLEtBbEJKO0FBbUJDOztBQUFBO0FBQ0QsQ0F4Q0QsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuXHJcbmV4cG9ydCBjb25zdCBBbGFybUV2ZW50ID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2FsYXJtZXZlbnQnKTtcclxuXHJcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcclxuXHQvLyBUaGlzIGNvZGUgb25seSBydW5zIG9uIHRoZSBzZXJ2ZXJcclxuXHRNZXRlb3IucHVibGlzaCgnYWxhcm1zcHVibGljYXRpb25ldmVudCcsIGZ1bmN0aW9uIGFsYXJtc1B1YmxpY2F0aW9uRXZlbnQoYXJndW1lbnRzRmluZCxhcmd1bWVudHNPcHRpb25zKSB7XHJcblx0XHRyZXR1cm4gQWxhcm1FdmVudC5maW5kKGFyZ3VtZW50c0ZpbmQsYXJndW1lbnRzT3B0aW9ucyk7XHJcblx0fSk7XHJcblx0XHJcblx0TWV0ZW9yLnB1Ymxpc2goJ2FsYXJtUmVhbHRpbWUnLCBmdW5jdGlvbiBhbGFybVJlYWx0aW1lKGFyZ3VtZW50c0ZpbmQpIHtcclxuXHRcdHJldHVybiBBbGFybUV2ZW50LmZpbmQoYXJndW1lbnRzRmluZCk7XHJcblx0fSk7XHRcclxuIH1cclxuXHJcbiBNZXRlb3IubWV0aG9kcyh7XHJcbi8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdCBcclxuXHQnYWxhcm1ldmVudC5nZXRBbGFybVJlYWxUaW1lJyhudW1BbGFybSkgXHJcblx0e1xyXG5cdFx0dmFyIGRhdGFCbG9jayA9IFtdO1xyXG5cdFx0dmFyIGRhdGFSZXN1bHQgPSBbXTtcclxuXHRcdHZhciBpbmRleCA9IDA7XHJcblx0XHRsZXQgb3B0aW9ucyA9IHt5ZWFyOiAnMi1kaWdpdCcsIG1vbnRoOiAnbnVtZXJpYycsIGRheTogJ251bWVyaWMnLCBob3VyOiAnMi1kaWdpdCcsbWludXRlOiAnMi1kaWdpdCcsc2Vjb25kOiAnMi1kaWdpdCd9O1xyXG5cdFx0XHJcblx0XHR2YXIgbWVzc2FnZVZTRCA9IFtcIkzhu5dpIEFwdG9tYXQ6IGtow7RuZyBj4bqlcCBuZ3Xhu5NuIGJp4bq/biB04bqnblwiLCBcIktow7RuZyBjw7MgdMOtbiBoaeG7h3UgcGjhuqNuIGjhu5NpIGtoaSBjaOG6oXkgaG/hurdjIGThu6tuZ1wiLCBcIiBM4buXaSBiaeG6v24gdOG6p25cIl1cclxuXHRcdHZhciBtZXNzYWdlVmFsdmUgPSBbXCJM4buXaSBBcHRvbWF0OiBraMO0bmcgY+G6pXAgbmd14buTbiBjaOG6t24gbGnhu4d1XCIsIFwiS2jDtG5nIGPDsyB0w61uIGhp4buHdSBwaOG6o24gaOG7k2kga2hpIG3hu59cIiwgXCJLaMO0bmcgY8OzIHTDrW4gaGnhu4d1IHBo4bqjbiBo4buTaSBraGkgxJHDs25nXCJdXHJcblx0XHR2YXIgbWVzc2FnZVdFSSA9IFtcIk3huqV0IGvhur90IG7hu5FpXCIsIFwiUXXDoSB04bqjaSBob+G6t2MgdGjhuqVwIHThuqNpXCIsIFwiQ8OibiBraMO0bmcg4buVbiDEkeG7i25oXCIsIFwiTOG7l2kga2hpIGzGsHUgdsOgbyBi4buZIG5o4bubIFBMQ1wiXVxyXG5cdFx0dmFyIG1lc3NhZ2VWU0RDb25uZWN0ID0gW1wiTeG6pXQgdHJ1eeG7gW4gdGjDtG5nIHbhu5tpIGJp4bq/biB04bqnbiBCVDFcIixcIk3huqV0IHRydXnhu4FuIHRow7RuZyB24bubaSBiaeG6v24gdOG6p24gQlQyXCIsXCJN4bqldCB0cnV54buBbiB0aMO0bmcgduG7m2kgYmnhur9uIHThuqduIEJUM1wiLFwiTeG6pXQgdHJ1eeG7gW4gdGjDtG5nIHbhu5tpIGJp4bq/biB04bqnbiBCVDRcIixcIk3huqV0IHRydXnhu4FuIHRow7RuZyB24bubaSBiaeG6v24gdOG6p24gQlQ1XCIsXCJN4bqldCB0cnV54buBbiB0aMO0bmcgduG7m2kgYmnhur9uIHThuqduIEJUNlwiLFwiTeG6pXQgdHJ1eeG7gW4gdGjDtG5nIHbhu5tpIGJp4bq/biB04bqnbiBCVDdcIixcIk3huqV0IHRydXnhu4FuIHRow7RuZyB24bubaSBiaeG6v24gdOG6p24gQlQ4XCIsXCJN4bqldCB0cnV54buBbiB0aMO0bmcgduG7m2kgYmnhur9uIHThuqduIEJUOVwiLFwiTeG6pXQgdHJ1eeG7gW4gdGjDtG5nIHbhu5tpIGJp4bq/biB04bqnbiBCVDEwXCIsXCJN4bqldCB0cnV54buBbiB0aMO0bmcgduG7m2kgYmnhur9uIHThuqduIEJUMTFcIixcIk3huqV0IHRydXnhu4FuIHRow7RuZyB24bubaSBiaeG6v24gdOG6p24gQlQxMlwiLFwiTeG6pXQgdHJ1eeG7gW4gdGjDtG5nIHbhu5tpIGJp4bq/biB04bqnbiBCVDEzXCIsXCJN4bqldCB0cnV54buBbiB0aMO0bmcgduG7m2kgYmnhur9uIHThuqduIEJUMTRcIixcIk3huqV0IHRydXnhu4FuIHRow7RuZyB24bubaSBiaeG6v24gdOG6p24gQlQxNVwiXVx0XHRcclxuXHRcdFxyXG5cdFx0QWxhcm1FdmVudC5maW5kKHtcInN0YXRcIiA6IFwiYWN0aXZlXCJ9LHsgc29ydDogeyBfaWQ6IC0xIH0sIGxpbWl0Om51bUFsYXJtfSkuZm9yRWFjaChmdW5jdGlvbihkb2MpIHtcclxuXHRcdFx0dmFyIG5hbWUgPSBkb2MubmFtZTtcclxuXHRcdFx0c3dpdGNoIChkb2MudHlwZSlcclxuXHRcdFx0e1xyXG5cdFx0XHRcdGNhc2UgXCJWU0RcIjpcclxuXHRcdFx0XHRcdGRhdGFCbG9jay5wdXNoKHtcclxuXHRcdFx0XHRcdFx0X2lkXHQ6IGRvYy5faWQsXHJcblx0XHRcdFx0XHRcdG9iak5hbWVcdDogZG9jLm5hbWUsXHJcblx0XHRcdFx0XHRcdHN0YXQgXHQ6ICdhY3RpdmUnLFxyXG5cdFx0XHRcdFx0XHR0aW1lc3RhbXA6IG5ldyBEYXRlKGRvYy5zVGltZSkudG9Mb2NhbGVTdHJpbmcoe30sb3B0aW9ucyksXHJcblx0XHRcdFx0XHRcdG1lc3NhZ2VcdDogbWVzc2FnZVZTRFtkb2MuYml0XVxyXG5cdFx0XHRcdFx0fSk7XHJcblx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRjYXNlIFwiQWxhcm1cIjpcclxuXHRcdFx0XHRcdGRhdGFCbG9jay5wdXNoKHtcclxuXHRcdFx0XHRcdFx0X2lkXHQ6IGRvYy5faWQsXHJcblx0XHRcdFx0XHRcdG9iak5hbWVcdDogZG9jLm5hbWUsXHJcblx0XHRcdFx0XHRcdHN0YXQgXHQ6ICdhY3RpdmUnLFxyXG5cdFx0XHRcdFx0XHR0aW1lc3RhbXA6IG5ldyBEYXRlKGRvYy5zVGltZSkudG9Mb2NhbGVTdHJpbmcoe30sb3B0aW9ucyksXHJcblx0XHRcdFx0XHRcdG1lc3NhZ2VcdDogbWVzc2FnZVZTRENvbm5lY3RbZG9jLmJpdF1cclxuXHRcdFx0XHRcdH0pO1x0XHJcblx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRjYXNlIFwiVmFsdmVcIjpcclxuXHRcdFx0XHRcdGRhdGFCbG9jay5wdXNoKHtcclxuXHRcdFx0XHRcdFx0X2lkXHQ6IGRvYy5faWQsXHJcblx0XHRcdFx0XHRcdG9iak5hbWVcdDogZG9jLm5hbWUsXHJcblx0XHRcdFx0XHRcdHN0YXQgXHQ6ICdhY3RpdmUnLFxyXG5cdFx0XHRcdFx0XHR0aW1lc3RhbXA6IG5ldyBEYXRlKGRvYy5zVGltZSkudG9Mb2NhbGVTdHJpbmcoe30sb3B0aW9ucyksXHJcblx0XHRcdFx0XHRcdG1lc3NhZ2VcdDogbWVzc2FnZVZhbHZlW2RvYy5iaXRdXHJcblx0XHRcdFx0XHR9KTtcclxuXHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdGNhc2UgXCJXZWlnaGluZ1wiOlxyXG5cdFx0XHRcdFx0XHRkYXRhQmxvY2sucHVzaCh7XHJcblx0XHRcdFx0XHRcdF9pZFx0OiBkb2MuX2lkLFxyXG5cdFx0XHRcdFx0XHRcdG9iak5hbWVcdDogZG9jLm5hbWUsXHJcblx0XHRcdFx0XHRcdFx0c3RhdCBcdDogJ2FjdGl2ZScsXHJcblx0XHRcdFx0XHRcdFx0dGltZXN0YW1wOiBuZXcgRGF0ZShkb2Muc1RpbWUpLnRvTG9jYWxlU3RyaW5nKHt9LG9wdGlvbnMpLFxyXG5cdFx0XHRcdFx0XHRcdG1lc3NhZ2VcdDogbWVzc2FnZVdFSVtkb2MuYml0XVxyXG5cdFx0XHRcdFx0XHR9KTtcdFxyXG5cdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0Y2FzZSBcIkVTdG9wXCI6XHJcblx0XHRcdFx0XHR2YXIgdGFnID0gZG9jLm5hbWUuc3BsaXQoXCJFU1RPUFwiKVsxXVxyXG5cdFx0XHRcdFx0aWYgKCh0YWcgPT0gXCJNQUlOXCIpIHx8ICh0YWcgPT0gXCJESzAxXCIpIHx8ICh0YWcgPT0gXCJESzAyXCIpIHx8ICh0YWcgPT0gXCJESzAzXCIpIHx8ICh0YWcgPT0gXCJESzA0XCIpKVxyXG5cdFx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0XHRkYXRhQmxvY2sucHVzaCh7XHJcblx0XHRcdFx0XHRcdFx0X2lkXHQ6IGRvYy5faWQsXHJcblx0XHRcdFx0XHRcdFx0b2JqTmFtZVx0OiBkb2MubmFtZSxcclxuXHRcdFx0XHRcdFx0XHRzdGF0IFx0OiAnYWN0aXZlJyxcclxuXHRcdFx0XHRcdFx0XHR0aW1lc3RhbXA6IG5ldyBEYXRlKGRvYy5zVGltZSkudG9Mb2NhbGVTdHJpbmcoe30sb3B0aW9ucyksXHJcblx0XHRcdFx0XHRcdFx0bWVzc2FnZVx0OiB0YWcuY29uY2F0KFwiOiBE4burbmcga2jhuqluIGPhuqVwIHThu6cgxJFp4buBdSBraGnhu4NuXCIpXHJcblx0XHRcdFx0XHRcdH0pO1x0XHRcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdGVsc2VcclxuXHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdFx0XHRcdF9pZFx0OiBkb2MuX2lkLFxyXG5cdFx0XHRcdFx0XHRcdG9iak5hbWVcdDogZG9jLm5hbWUsXHJcblx0XHRcdFx0XHRcdFx0c3RhdCBcdDogJ2FjdGl2ZScsXHJcblx0XHRcdFx0XHRcdFx0dGltZXN0YW1wOiBuZXcgRGF0ZShkb2Muc1RpbWUpLnRvTG9jYWxlU3RyaW5nKHt9LG9wdGlvbnMpLFxyXG5cdFx0XHRcdFx0XHRcdG1lc3NhZ2VcdDogXCJEw6J5IGdp4bqtdCBraOG6qW4gY+G6pXBcIlxyXG5cdFx0XHRcdFx0XHR9KTtcdFx0XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0fVx0XHRcdFxyXG5cdFx0fSlcclxuXHRcdGlmIChkYXRhQmxvY2subGVuZ3RoID4gbnVtQWxhcm0pXHJcblx0XHR7XHJcblx0XHRcdGRhdGFSZXN1bHQgPSBkYXRhQmxvY2suc2xpY2UoMCxudW1BbGFybSk7XHRcdFx0XHJcblx0XHR9IGVsc2UgXHJcblx0XHR7XHJcblx0XHRcdGRhdGFSZXN1bHQgPSBkYXRhQmxvY2suc2xpY2UoKTtcclxuXHRcdH1cclxuXHRcdHJldHVybiBkYXRhUmVzdWx0O1x0XHRcclxuXHR9LFxyXG4vLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcdFxyXG5cdCdhbGFybWV2ZW50LmdldEhpc3Rvcmlhbicoc2l0ZSxzdGFydFRpbWVQYXJhbSxlbmRUaW1lUGFyYW0pIFxyXG5cdHtcclxuXHRcdHZhciBkYXRhQmxvY2sgXHQ9IFtdO1xyXG5cdFx0dmFyIGluZGV4IFx0XHQ9IDA7XHJcblx0XHR2YXIgZW5kVGltZSBcdD0gXCJcIjtcclxuXHRcdHZhciB0aW1lc3RhbXAgXHQ9IFwiXCI7XHJcblx0XHRcclxuXHRcdGxldCBvcHRpb25zID0ge3llYXI6ICcyLWRpZ2l0JywgbW9udGg6ICdudW1lcmljJywgZGF5OiAnbnVtZXJpYycsaG91cjogJzItZGlnaXQnLG1pbnV0ZTogJzItZGlnaXQnLHNlY29uZDogJzItZGlnaXQnfTtcclxuXHJcblx0XHR2YXIgbWVzc2FnZVdFSSA9IFtcIk3huqV0IGvhur90IG7hu5FpXCIsIFwiUXXDoSB04bqjaSBob+G6t2MgdGjhuqVwIHThuqNpXCIsIFwiQ8OibiBraMO0bmcg4buVbiDEkeG7i25oXCIsIFwiTOG7l2kga2hpIGzGsHUgdsOgbyBi4buZIG5o4bubIFBMQ1wiXVx0XHRcclxuXHRcdHZhciBtZXNzYWdlVlNEID0gW1wiTOG7l2kgQXB0b21hdDoga2jDtG5nIGPhuqVwIG5ndeG7k24gYmnhur9uIHThuqduXCIsIFwiS2jDtG5nIGPDsyB0w61uIGhp4buHdSBwaOG6o24gaOG7k2kga2hpIGNo4bqheSBob+G6t2MgZOG7q25nXCIsIFwiIEzhu5dpIGJp4bq/biB04bqnblwiXVxyXG5cdFx0dmFyIG1lc3NhZ2VWYWx2ZSA9IFtcIkzhu5dpIEFwdG9tYXQ6IGtow7RuZyBj4bqlcCBuZ3Xhu5NuIGNo4bq3biBsaeG7h3VcIiwgXCJLaMO0bmcgY8OzIHTDrW4gaGnhu4d1IHBo4bqjbiBo4buTaSBraGkgbeG7n1wiLCBcIktow7RuZyBjw7MgdMOtbiBoaeG7h3UgcGjhuqNuIGjhu5NpIGtoaSDEkcOzbmdcIl1cclxuXHRcdHZhciBtZXNzYWdlVlNEQ29ubmVjdCA9IFtcIk3huqV0IHRydXnhu4FuIHRow7RuZyB24bubaSBiaeG6v24gdOG6p24gQlQxXCIsXCJN4bqldCB0cnV54buBbiB0aMO0bmcgduG7m2kgYmnhur9uIHThuqduIEJUMlwiLFwiTeG6pXQgdHJ1eeG7gW4gdGjDtG5nIHbhu5tpIGJp4bq/biB04bqnbiBCVDNcIixcIk3huqV0IHRydXnhu4FuIHRow7RuZyB24bubaSBiaeG6v24gdOG6p24gQlQ0XCIsXCJN4bqldCB0cnV54buBbiB0aMO0bmcgduG7m2kgYmnhur9uIHThuqduIEJUNVwiLFwiTeG6pXQgdHJ1eeG7gW4gdGjDtG5nIHbhu5tpIGJp4bq/biB04bqnbiBCVDZcIixcIk3huqV0IHRydXnhu4FuIHRow7RuZyB24bubaSBiaeG6v24gdOG6p24gQlQ3XCIsXCJN4bqldCB0cnV54buBbiB0aMO0bmcgduG7m2kgYmnhur9uIHThuqduIEJUOFwiLFwiTeG6pXQgdHJ1eeG7gW4gdGjDtG5nIHbhu5tpIGJp4bq/biB04bqnbiBCVDlcIixcIk3huqV0IHRydXnhu4FuIHRow7RuZyB24bubaSBiaeG6v24gdOG6p24gQlQxMFwiLFwiTeG6pXQgdHJ1eeG7gW4gdGjDtG5nIHbhu5tpIGJp4bq/biB04bqnbiBCVDExXCIsXCJN4bqldCB0cnV54buBbiB0aMO0bmcgduG7m2kgYmnhur9uIHThuqduIEJUMTJcIixcIk3huqV0IHRydXnhu4FuIHRow7RuZyB24bubaSBiaeG6v24gdOG6p24gQlQxM1wiLFwiTeG6pXQgdHJ1eeG7gW4gdGjDtG5nIHbhu5tpIGJp4bq/biB04bqnbiBCVDE0XCIsXCJN4bqldCB0cnV54buBbiB0aMO0bmcgduG7m2kgYmnhur9uIHThuqduIEJUMTVcIl1cdFxyXG5cdFx0XHJcblx0XHRBbGFybUV2ZW50LmZpbmQoe3NUaW1lOnskZ3RlOiBzdGFydFRpbWVQYXJhbSwkbHRlOmVuZFRpbWVQYXJhbX19LHsgc29ydDogeyBfaWQ6IC0xIH19KS5mb3JFYWNoKGZ1bmN0aW9uKGRvYykge1x0XHRcclxuXHRcdFx0dmFyIG5hbWUgPSBkb2MubmFtZTtcclxuXHRcdFx0aWYgKGRvYy5lVGltZSA9PTApXHJcblx0XHRcdHtcclxuXHRcdFx0XHRlbmRUaW1lID0gXCJcIjtcclxuXHRcdFx0fVxyXG5cdFx0XHRlbHNlXHJcblx0XHRcdHtcclxuXHRcdFx0XHRlbmRUaW1lID0gbmV3IERhdGUoZG9jLmVUaW1lKS50b0xvY2FsZVN0cmluZyh7fSxvcHRpb25zKTtcclxuXHRcdFx0fVxyXG5cdFx0XHR0aW1lc3RhbXAgPSBuZXcgRGF0ZShkb2Muc1RpbWUpLnRvTG9jYWxlU3RyaW5nKHt9LG9wdGlvbnMpO1xyXG5cdFx0XHRcclxuXHRcdFx0c3dpdGNoIChkb2MudHlwZSlcclxuXHRcdFx0e1xyXG5cdFx0XHRcdGNhc2UgXCJWU0RcIjpcclxuXHRcdFx0XHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdFx0XHRcdF9pZFx0OiBkb2MuX2lkLFxyXG5cdFx0XHRcdFx0XHRcdG9iak5hbWVcdDogZG9jLm5hbWUsXHJcblx0XHRcdFx0XHRcdFx0dHlwZURhdGE6IGRvYy50eXBlLFxyXG5cdFx0XHRcdFx0XHRcdHRpbWVzdGFtcDogbmV3IERhdGUoZG9jLnNUaW1lKS50b0xvY2FsZVN0cmluZyh7fSxvcHRpb25zKSxcclxuXHRcdFx0XHRcdFx0XHRlbmRUaW1lXHQ6IGVuZFRpbWUsXHJcblx0XHRcdFx0XHRcdFx0bWVzc2FnZVx0OiBtZXNzYWdlVlNEW2RvYy5iaXRdXHJcblx0XHRcdFx0XHRcdH0pO1x0XHJcblx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRjYXNlIFwiQWxhcm1cIjpcclxuXHRcdFx0XHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdFx0XHRcdF9pZFx0OiBkb2MuX2lkLFxyXG5cdFx0XHRcdFx0XHRcdG9iak5hbWVcdDogZG9jLm5hbWUsXHJcblx0XHRcdFx0XHRcdFx0dHlwZURhdGE6IGRvYy50eXBlLFxyXG5cdFx0XHRcdFx0XHRcdHRpbWVzdGFtcDogbmV3IERhdGUoZG9jLnNUaW1lKS50b0xvY2FsZVN0cmluZyh7fSxvcHRpb25zKSxcclxuXHRcdFx0XHRcdFx0XHRlbmRUaW1lXHQ6IGVuZFRpbWUsXHJcblx0XHRcdFx0XHRcdFx0bWVzc2FnZVx0OiBtZXNzYWdlVlNEQ29ubmVjdFtkb2MuYml0XVxyXG5cdFx0XHRcdFx0XHR9KTtcdFxyXG5cdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0Y2FzZSBcIlZhbHZlXCI6XHJcblx0XHRcdFx0XHRcdGRhdGFCbG9jay5wdXNoKHtcclxuXHRcdFx0XHRcdFx0XHRfaWRcdDogZG9jLl9pZCxcclxuXHRcdFx0XHRcdFx0XHRvYmpOYW1lXHQ6IGRvYy5uYW1lLFxyXG5cdFx0XHRcdFx0XHRcdHR5cGVEYXRhOiBkb2MudHlwZSxcclxuXHRcdFx0XHRcdFx0XHR0aW1lc3RhbXA6IG5ldyBEYXRlKGRvYy5zVGltZSkudG9Mb2NhbGVTdHJpbmcoe30sb3B0aW9ucyksXHJcblx0XHRcdFx0XHRcdFx0ZW5kVGltZVx0OiBlbmRUaW1lLFxyXG5cdFx0XHRcdFx0XHRcdG1lc3NhZ2VcdDogbWVzc2FnZVZhbHZlW2RvYy5iaXRdXHJcblx0XHRcdFx0XHRcdH0pO1x0XHJcblx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRjYXNlIFwiV2VpZ2hpbmdcIjpcclxuXHRcdFx0XHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdFx0XHRcdF9pZFx0OiBkb2MuX2lkLFxyXG5cdFx0XHRcdFx0XHRcdG9iak5hbWVcdDogZG9jLm5hbWUsXHJcblx0XHRcdFx0XHRcdFx0dHlwZURhdGE6IGRvYy50eXBlLFxyXG5cdFx0XHRcdFx0XHRcdHRpbWVzdGFtcDogbmV3IERhdGUoZG9jLnNUaW1lKS50b0xvY2FsZVN0cmluZyh7fSxvcHRpb25zKSxcclxuXHRcdFx0XHRcdFx0XHRlbmRUaW1lXHQ6IGVuZFRpbWUsXHJcblx0XHRcdFx0XHRcdFx0bWVzc2FnZVx0OiBtZXNzYWdlV0VJW2RvYy5iaXRdXHJcblx0XHRcdFx0XHRcdH0pO1x0XHJcblx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRjYXNlIFwiRVN0b3BcIjpcclxuXHRcdFx0XHRcdHZhciB0YWcgPSBkb2MubmFtZS5zcGxpdChcIkVTVE9QXCIpWzFdXHJcblx0XHRcdFx0XHRpZiAoKHRhZyA9PSBcIk1BSU5cIikgfHwgKHRhZyA9PSBcIkRLMDFcIikgfHwgKHRhZyA9PSBcIkRLMDJcIikgfHwgKHRhZyA9PSBcIkRLMDNcIikgfHwgKHRhZyA9PSBcIkRLMDRcIikpXHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdGRhdGFCbG9jay5wdXNoKHtcclxuXHRcdFx0XHRcdFx0XHRfaWRcdDogZG9jLl9pZCxcclxuXHRcdFx0XHRcdFx0XHRvYmpOYW1lXHQ6IGRvYy5uYW1lLFxyXG5cdFx0XHRcdFx0XHRcdHR5cGVEYXRhOiBkb2MudHlwZSxcclxuXHRcdFx0XHRcdFx0XHR0aW1lc3RhbXA6IG5ldyBEYXRlKGRvYy5zVGltZSkudG9Mb2NhbGVTdHJpbmcoe30sb3B0aW9ucyksXHJcblx0XHRcdFx0XHRcdFx0ZW5kVGltZVx0OiBlbmRUaW1lLFxyXG5cdFx0XHRcdFx0XHRcdG1lc3NhZ2VcdDogdGFnLmNvbmNhdChcIjogROG7q25nIGto4bqpbiBj4bqlcCB04bunIMSRaeG7gXUga2hp4buDblwiKVxyXG5cdFx0XHRcdFx0XHR9KTtcdFx0XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRlbHNlXHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdGRhdGFCbG9jay5wdXNoKHtcclxuXHRcdFx0XHRcdFx0XHRfaWRcdDogZG9jLl9pZCxcclxuXHRcdFx0XHRcdFx0XHRvYmpOYW1lXHQ6IGRvYy5uYW1lLFxyXG5cdFx0XHRcdFx0XHRcdHR5cGVEYXRhOiBkb2MudHlwZSxcclxuXHRcdFx0XHRcdFx0XHR0aW1lc3RhbXA6IG5ldyBEYXRlKGRvYy5zVGltZSkudG9Mb2NhbGVTdHJpbmcoe30sb3B0aW9ucyksXHJcblx0XHRcdFx0XHRcdFx0ZW5kVGltZVx0OiBlbmRUaW1lLFxyXG5cdFx0XHRcdFx0XHRcdG1lc3NhZ2VcdDogXCJEw6J5IGdp4bqtdCBraOG6qW4gY+G6pXBcIlxyXG5cdFx0XHRcdFx0XHR9KTtcdFx0XHJcblx0XHRcdFx0XHR9XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0YnJlYWs7XHRcclxuXHRcdFx0XHRjYXNlIFwiSW5zdHJ1bWVudFwiOlxyXG5cdFx0XHRcdFx0XHRkYXRhQmxvY2sucHVzaCh7XHJcblx0XHRcdFx0XHRcdFx0X2lkXHQ6IGRvYy5faWQsXHJcblx0XHRcdFx0XHRcdFx0cGxjXHRcdDogZG9jLnBsYyxcclxuXHRcdFx0XHRcdFx0XHRhcmVhXHQ6IGRvYy5hcmVhLFxyXG5cdFx0XHRcdFx0XHRcdG9iak5hbWVcdDogZG9jLm5hbWUsXHJcblx0XHRcdFx0XHRcdFx0dHlwZURhdGE6IGRvYy50eXBlLFxyXG5cdFx0XHRcdFx0XHRcdHRpbWVzdGFtcDogbmV3IERhdGUoZG9jLnNUaW1lKS50b0xvY2FsZVN0cmluZyh7fSxvcHRpb25zKSxcclxuXHRcdFx0XHRcdFx0XHRlbmRUaW1lXHQ6IGVuZFRpbWUsXHJcblx0XHRcdFx0XHRcdFx0bWVzc2FnZVx0OiBuYW1lLmNvbmNhdChcIiBcIiwgXCI6IHNlbnNvciBpcyBvcGVuIGNpcmN1aXQgb3IgZXJyb3JcIilcclxuXHRcdFx0XHRcdFx0fSk7XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0YnJlYWs7XHRcdFx0XHRcclxuXHRcdFx0fVxyXG5cdFx0fSk7XHJcblx0XHQvL2NvbnNvbGUubG9nKFwiZGF0YUJsb2NrOiBcIiArIGRhdGFCbG9jayk7XHJcblx0XHRyZXR1cm4gZGF0YUJsb2NrO1xyXG5cdH0sXHQgXHJcblx0XHJcbn0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuXHJcbmV4cG9ydCBjb25zdCBCaW9tYXNFdmVudCA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdiaW9tYXNldmVudCcpO1xyXG5cclxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG4gICAgTWV0ZW9yLm1ldGhvZHMoe1xyXG5cdFx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cdFx0YXN5bmMgJ2Jpb21hc2V2ZW50LmdldE1vbnRobHlSZXBvcnQnKHN0YXJ0VGltZSxlbmRUaW1lKSB7XHJcblx0XHRcdHZhciBkYXRhQmxvY2sgXHQ9IFtdO1xyXG5cdFx0XHR2YXIgcmVzdWx0QXJyID0gW107XHJcblx0XHRcdC8vY29uc29sZS5sb2coXCJzdGFydFRpbWVQYXJhbSBcIiArIHN0YXJ0VGltZSArIFwiLCBlbmRUaW1lUGFyYW0gXCIgKyBlbmRUaW1lICsgXCIsIHNlbGVjdEJvaWxlciBcIiArIHNlbGVjdEJvaWxlcik7XHJcblx0XHRcdGNvbnN0IHJlc3VsdCA9IGF3YWl0IEJpb21hc0V2ZW50LnJhd0NvbGxlY3Rpb24oKS5hZ2dyZWdhdGUoW1xyXG4gICAgICAgICAgICAgICAgeyRtYXRjaDogeyBzVGltZTogeyAkZ3RlOiBzdGFydFRpbWUsICRsdGU6IGVuZFRpbWUgfSB9IH0sXHJcbiAgICAgICAgICAgICAgICB7JHNldDogeyBkYXRlc3g6IHsgJGRhdGVUb1N0cmluZzogeyBmb3JtYXQ6IFwiJW0tJWRcIiwgZGF0ZTogeyRhZGQgOiBbbmV3IERhdGUoMCksIFwiJHNUaW1lXCJdIH0sIHRpbWV6b25lOiBcIkFzaWEvSG9fQ2hpX01pbmhcIiB9IH0gfSB9LFxyXG4gICAgICAgICAgICAgICAgeyRzZXQ6IHsgaG91cnN4OiB7ICRkYXRlVG9TdHJpbmc6IHsgZm9ybWF0OiBcIiVZLSVtLSVkICVIXCIsIGRhdGU6IHskYWRkIDogW25ldyBEYXRlKDApLCBcIiRzVGltZVwiXSB9LCB0aW1lem9uZTogXCJBc2lhL0hvX0NoaV9NaW5oXCIgfSB9IH0gfSxcclxuICAgICAgICAgICAgICAgIHskbWF0Y2g6IHsgdmFsdWVFOiB7ICRndDogMCwgJGx0ZTogMTAwMDAgfSB9IH0sXHJcbiAgICAgICAgICAgICAgICB7JG1hdGNoOiB7IHZhbHVlUzogeyAkZ3Q6IDAsICRsdGU6IDEwMDAwIH0gfSB9LCAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIHskcHJvamVjdDpcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9pZDpcIiRuYW1lXCIgLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXRlcmlhbFN1bTogeyAkc3VidHJhY3QgOiBbIFwiJHZhbHVlRVwiLCBcIiR2YWx1ZVNcIiBdfSwgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGVzeDpcIiRkYXRlc3hcIiAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhvdXJzeDpcIiRob3Vyc3hcIiAsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXRlcmlhbDpcIiRtYXRlcmlhbFwiICwgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvaWxlcjpcIiRib2lsZXJcIiBcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgeyRtYXRjaDogeyBtYXRlcmlhbFN1bTogeyAkZ3Q6IDAsICRsdGU6IDEwMDAwIH0gfSB9LFxyXG4gICAgICAgICAgICAgICAgeyRncm91cCA6IFxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgX2lkOntob3Vyc3g6XCIkaG91cnN4XCIsIG5hbWU6XCIkX2lkXCJ9LCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3VtUG9pbnRzOnskc3VtOlwiJG1hdGVyaWFsU3VtXCJ9LCAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZToge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJHB1c2g6IHsgXCJtYXRlcmlhbFwiIDogXCIkbWF0ZXJpYWxcIiwgXCJib2lsZXJcIiA6IFwiJGJvaWxlclwiIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgIH0sICBcclxuICAgICAgICAgICAgICAgIHskc29ydCA6IHsgXCJfaWQuaG91cnN4XCI6MX0gfSxcclxuICAgICAgICAgICAgICAgIHskZ3JvdXAgOiBcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9pZDp7aG91cnN4OlwiJF9pZC5ob3Vyc3hcIn0sIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdW1zOnskc3VtOlwiJHN1bVBvaW50c1wifSwgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGludm9pY2VEYXRlOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAkcHVzaDogeyBcIm15UGxhY2VcIiA6IFwiJF9pZC5uYW1lXCIsIFwibXlTdGFtcFwiIDogXCIkc3VtUG9pbnRzXCIgLCBcInR5cGVcIiA6IFwiJHR5cGVcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgIH0sICBcclxuICAgICAgICAgICAgICAgIHskc29ydCA6IHsgXCJfaWQuaG91cnN4XCI6MX0gfSAgICAgICAgICAgICAgIFxyXG5cdFx0XHRdKS5mb3JFYWNoKGZ1bmN0aW9uKGRvYykge1xyXG5cdFx0XHRcdHJlc3VsdEFyci5wdXNoKGRvYyk7XHRcdFx0XHRcdFxyXG5cdFx0XHR9KVxyXG5cclxuXHRcdFx0dmFyIGxvYWRjZWxsMDFQcnZcdD0gMDtcclxuXHRcdFx0dmFyIGxvYWRjZWxsMDJQcnZcdD0gMDtcclxuXHRcdFx0dmFyIGZpcnN0T2ZEYXlcdFx0PSAwO1xyXG5cdFx0XHR2YXIgbWF0ZXJpYWwgICAgICAgID0gMDtcclxuXHRcdFx0dmFyIGJvaWxlciAgICAgICAgICA9IDA7XHRcclxuXHRcdFx0dmFyIGRhdGVUaW1lICAgICAgICA9IDA7XHJcblx0XHRcdHZhciBkYXRhTEMwMSA9IFtdO1x0XHJcblx0XHRcdHZhciBkYXRhTEMwMiA9IFtdO1x0XHJcblx0XHRcdHZhciBkYXRhVGltZSA9IFtdO1xyXG5cdFx0XHR2YXIgZGF0YVJlcG9ydD1bXTtcclxuXHJcblx0XHRcdHZhciB0b3RhbExDMDFUaGFuIFx0PSAwOyBcclxuXHRcdFx0dmFyIHRvdGFsTEMwMlRoYW4gXHQ9IDA7XHJcblx0XHRcdHZhciB0b3RhbExDMDFCaW9tYXMgPSAwOyBcclxuXHRcdFx0dmFyIHRvdGFsTEMwMkJpb21hcyA9IDA7XHJcblx0XHRcdHZhciB0b3RhbDAxbG8xID0gMDtcclxuXHRcdFx0dmFyIHRvdGFsMDFsbzIgPSAwO1xyXG5cdFx0XHR2YXIgdG90YWwwMmxvMSA9IDA7XHJcblx0XHRcdHZhciB0b3RhbDAybG8yID0gMDtcclxuXHRcdFx0dmFyIHRvdGFsMDNsbzEgPSAwO1xyXG5cdFx0XHR2YXIgdG90YWwwM2xvMiA9IDA7XHJcblx0XHRcdHZhciB0b3RhbDA0bG8xID0gMDtcclxuXHRcdFx0dmFyIHRvdGFsMDRsbzIgPSAwO1x0XHRcclxuXHJcbiAgICBcclxuXHRcdFx0Zm9yICh2YXIgaz0wOyBrIDwgcmVzdWx0QXJyLmxlbmd0aDsgaysrKVxyXG5cdFx0XHR7XHJcbiAgICAgICAgICAgICAgICAgdmFyIG15QXJyYXkgPSByZXN1bHRBcnJba10uX2lkLmhvdXJzeC5zcGxpdChcIiBcIik7ICAgICAgICAgICAgICAgXHJcblx0XHRcdFx0aWYgKChmaXJzdE9mRGF5PT0wKSAmJiAocGFyc2VJbnQobXlBcnJheVsxXSkgPj02KSlcclxuXHRcdFx0XHR7ICAgICAgICAgICAgICAgXHJcblx0XHRcdFx0XHRkYXRlVGltZVx0XHQ9IG15QXJyYXlbMF1cclxuXHRcdFx0XHRcdGZpcnN0T2ZEYXlcdCAgICA9IDE7XHJcblx0XHRcdFx0fSBcclxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGZpcnN0T2ZEYXk9PTEpXHJcblx0XHRcdFx0e1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICgoZGF0ZVRpbWUgIT0gbXlBcnJheVswXSkgJiYgKHBhcnNlSW50KG15QXJyYXlbMV0pID49NikpXHJcblx0XHRcdFx0XHR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgdG90YWxBbGwgID0gbG9hZGNlbGwwMVBydiArIGxvYWRjZWxsMDJQcnY7ICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0TWF0ZXJpYWwgPSBhd2FpdCBNZXRlb3IuY2FsbCgnbWF0ZXJpYWwuZ2V0TWF0ZXJpYWwnLCBteUFycmF5WzBdKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHRNYXRlcmlhbCAhPSBcIlwiKSB7XHJcblx0XHRcdFx0XHRcdFx0Ly8gZGF0YVJlcG9ydC5wdXNoKHtcclxuXHRcdFx0XHRcdFx0XHRcdC8vICdUaOG7nWkgZ2lhbicgOiBkYXRlVGltZSxcclxuXHRcdFx0XHRcdFx0XHRcdC8vICdC4buZIGPDom4wMScgIDpsb2FkY2VsbDAxUHJ2LFxyXG5cdFx0XHRcdFx0XHRcdFx0Ly8gJ0Lhu5kgY8OibjAyJyAgOmxvYWRjZWxsMDJQcnYsXHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnVOG7lW5nJyAgICAgIDogIHRvdGFsQWxsLFxyXG5cdFx0XHRcdFx0XHRcdFx0Ly8gJ1Thu5VuZyBUaGFuJzogdG90YWxMQzAxVGhhbiArIHRvdGFsTEMwMlRoYW4sXHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnVOG7lW5nIEJpb21hcyc6ICB0b3RhbExDMDFCaW9tYXMgKyB0b3RhbExDMDJCaW9tYXMsXHRcdFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnTMOyIFThuqduZyBTw7RpIDEnOiAgdG90YWwwMWxvMSArIHRvdGFsMDFsbzIsXHRcdFx0XHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHRcdC8vICdMw7IgVOG6p25nIFPDtGkgMic6ICB0b3RhbDAybG8xICsgdG90YWwwMmxvMixcdFx0XHRcdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdFx0Ly8gJ0zDsiBU4bqnbmcgU8O0aSAzJzogIHRvdGFsMDNsbzEgKyB0b3RhbDAzbG8yLFx0XHRcdFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnTMOyIFThuqduZyBTw7RpIDQnOiAgdG90YWwwNGxvMSArIHRvdGFsMDRsbzIsXHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnQ+G7p2kgYsSDbSdcdDogcGFyc2VGbG9hdCgodG90YWxBbGwgKiBwYXJzZUZsb2F0KHJlc3VsdE1hdGVyaWFsWzBdLmN1aWJhbSkpIC8gMTAwKS50b0ZpeGVkKDEpLFxyXG5cdFx0XHRcdFx0XHRcdFx0Ly8gJ03DuW4gY8awYSdcdDogcGFyc2VGbG9hdCgodG90YWxBbGwgKiBwYXJzZUZsb2F0KHJlc3VsdE1hdGVyaWFsWzBdLm11bmN1YSkpIC8gMTAwKS50b0ZpeGVkKDEpLFxyXG5cdFx0XHRcdFx0XHRcdFx0Ly8gJ0jhuqF0IMSRaeG7gXUnOiBwYXJzZUZsb2F0KCh0b3RhbEFsbCAqIHBhcnNlRmxvYXQocmVzdWx0TWF0ZXJpYWxbMF0uaGF0ZGlldSkpIC8gMTAwKS50b0ZpeGVkKDEpLFxyXG5cdFx0XHRcdFx0XHRcdFx0Ly8gJ0TEg20gYsOgbydcdDogcGFyc2VGbG9hdCgodG90YWxBbGwgKiBwYXJzZUZsb2F0KHJlc3VsdE1hdGVyaWFsWzBdLmRhbWJhbykpIC8gMTAwKS50b0ZpeGVkKDEpLFxyXG5cdFx0XHRcdFx0XHRcdFx0Ly8gJ1bhu48gY8OieSBuZ2hp4buBbic6cGFyc2VGbG9hdCgodG90YWxBbGwgKiBwYXJzZUZsb2F0KHJlc3VsdE1hdGVyaWFsWzBdLmNheW5naGllbikpIC8gMTAwKS50b0ZpeGVkKDEpLFxyXG5cdFx0XHRcdFx0XHRcdFx0Ly8gJ0Lhu5l0IHjGsOG7m2MnXHQ6IHBhcnNlRmxvYXQoKHRvdGFsQWxsICogcGFyc2VGbG9hdChyZXN1bHRNYXRlcmlhbFswXS5ib3R4dW9jKSkgLyAxMDApLnRvRml4ZWQoMSksXHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnQ+G7p2kgxJHhu5F0J1x0OiBwYXJzZUZsb2F0KCh0b3RhbEFsbCAqIHBhcnNlRmxvYXQocmVzdWx0TWF0ZXJpYWxbMF0uY3VpZG90KSkgLyAxMDApLnRvRml4ZWQoMSksXHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnVHLhuqV1JzogcGFyc2VGbG9hdCgodG90YWxBbGwgKiBwYXJzZUZsb2F0KHJlc3VsdE1hdGVyaWFsWzBdLnRyYXUpKSAvIDEwMCkudG9GaXhlZCgxKSxcclxuXHRcdFx0XHRcdFx0XHRcdC8vICdHw7lpIGLhuq9wJ1x0OiBwYXJzZUZsb2F0KCh0b3RhbEFsbCAqIHBhcnNlRmxvYXQocmVzdWx0TWF0ZXJpYWxbMF0uZ3VpYmFwKSkgLyAxMDApLnRvRml4ZWQoMSksXHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0Ly8gfSk7IFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBiYXNpY1JlcG9ydD1bXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzZWFyY2hDcml0ZXJpYSAgID0ge307XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYXNpY1JlcG9ydCA9IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7J2Rlc2MnOiAnVGjhu51pIGdpYW4nICAgICAsICd2YWx1ZSc6ICBkYXRlVGltZX0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeydkZXNjJzogJ0Lhu5kgY8OibjAxJyAgICAgICwgJ3ZhbHVlJzogIGxvYWRjZWxsMDFQcnZ9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsnZGVzYyc6ICdC4buZIGPDom4wMicgICAgICAsICd2YWx1ZSc6ICBsb2FkY2VsbDAyUHJ2fSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7J2Rlc2MnOiAnVOG7lW5nJyAgICAgICAgICAsICd2YWx1ZSc6ICB0b3RhbEFsbH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeydkZXNjJzogJ1Thu5VuZyBUaGFuJyAgICAgLCAndmFsdWUnOiAgdG90YWxMQzAxVGhhbiArIHRvdGFsTEMwMlRoYW59LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsnZGVzYyc6ICdU4buVbmcgQmlvbWFzJyAgICwgJ3ZhbHVlJzogIHRvdGFsTEMwMUJpb21hcyArIHRvdGFsTEMwMkJpb21hc30sXHRcdFx0XHRcdFx0XHRcdFx0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeydkZXNjJzogJ0zDsiBU4bqnbmcgU8O0aSAxJyAsICd2YWx1ZSc6ICB0b3RhbDAxbG8xICsgdG90YWwwMWxvMn0sXHRcdFx0XHRcdFx0XHRcdFx0XHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7J2Rlc2MnOiAnTMOyIFThuqduZyBTw7RpIDInICwgJ3ZhbHVlJzogIHRvdGFsMDJsbzEgKyB0b3RhbDAybG8yfSxcdFx0XHRcdFx0XHRcdFx0XHRcdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsnZGVzYyc6ICdMw7IgVOG6p25nIFPDtGkgMycgLCAndmFsdWUnOiAgdG90YWwwM2xvMSArIHRvdGFsMDNsbzJ9LFx0XHRcdFx0XHRcdFx0XHRcdFx0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeydkZXNjJzogJ0zDsiBU4bqnbmcgU8O0aSA0JyAsICd2YWx1ZSc6ICB0b3RhbDA0bG8xICsgdG90YWwwNGxvMn0sXHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRNYXRlcmlhbFswXS5tYXRlcmlhbC5mb3JFYWNoKChlbGVtZW50LCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBpdGVtID0gZWxlbWVudC5kZXNjXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbSA9IGl0ZW0uY29uY2F0KFwiKFwiLGVsZW1lbnQudmFsdWUsXCIpXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJpdGVtIFwiICsgaXRlbSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWFyY2hDcml0ZXJpYVtpdGVtXSA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlYXJjaENyaXRlcmlhW2l0ZW1dLnB1c2gocGFyc2VGbG9hdCgodG90YWxBbGwgKiBwYXJzZUZsb2F0KGVsZW1lbnQudmFsdWUpKSAvIDEwMCkudG9GaXhlZCgxKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhc2ljUmVwb3J0LmZvckVhY2goKGVsZW1lbnQsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VhcmNoQ3JpdGVyaWFbZWxlbWVudC5kZXNjXSA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlYXJjaENyaXRlcmlhW2VsZW1lbnQuZGVzY10ucHVzaChlbGVtZW50LnZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGFSZXBvcnQucHVzaChzZWFyY2hDcml0ZXJpYSlcclxuXHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHRlbHNlXHJcblx0XHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0XHRkYXRhUmVwb3J0LnB1c2goe1xyXG5cdFx0XHRcdFx0XHRcdFx0J1Ro4budaSBnaWFuJzogZGF0ZVRpbWUsXHJcblx0XHRcdFx0XHRcdFx0XHQnQuG7mSBjw6JuMDEnIDpsb2FkY2VsbDAxUHJ2LFxyXG5cdFx0XHRcdFx0XHRcdFx0J0Lhu5kgY8OibjAyJyA6bG9hZGNlbGwwMlBydixcclxuXHRcdFx0XHRcdFx0XHRcdCdU4buVbmcnOiAgdG90YWxBbGwsXHJcblx0XHRcdFx0XHRcdFx0XHQnVOG7lW5nIFRoYW4nOiB0b3RhbExDMDFUaGFuICsgdG90YWxMQzAyVGhhbixcclxuXHRcdFx0XHRcdFx0XHRcdCdU4buVbmcgQmlvbWFzJzogIHRvdGFsTEMwMUJpb21hcyArIHRvdGFsTEMwMkJpb21hcyxcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHR9KTsgXHJcblx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdH0gICAgICAgIFxyXG5cdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0ZGF0YUxDMDEucHVzaChcclxuXHRcdFx0XHRcdFx0XHROdW1iZXIobG9hZGNlbGwwMVBydilcclxuXHRcdFx0XHRcdFx0KTtcclxuXHRcdFx0XHRcdFx0ZGF0YUxDMDIucHVzaChcclxuXHRcdFx0XHRcdFx0XHROdW1iZXIobG9hZGNlbGwwMlBydilcclxuXHRcdFx0XHRcdFx0KTtcdFxyXG5cdFx0XHRcdFx0XHRkYXRhVGltZS5wdXNoKFxyXG5cdFx0XHRcdFx0XHRcdGRhdGVUaW1lLnN1YnN0cmluZyg1KVxyXG5cdFx0XHRcdFx0XHQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRlVGltZVx0XHQ9IG15QXJyYXlbMF1cclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGNlbGwwMVBydlx0PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRjZWxsMDJQcnZcdD0gMFx0XHRcclxuXHRcdFx0XHRcdFx0dG90YWxMQzAxQmlvbWFzIFx0PSAwO1xyXG5cdFx0XHRcdFx0XHR0b3RhbExDMDJCaW9tYXMgXHQ9IDA7XHJcblx0XHRcdFx0XHRcdHRvdGFsMDFsbzEgPSAwO1xyXG5cdFx0XHRcdFx0XHR0b3RhbDAxbG8yID0gMDtcclxuXHRcdFx0XHRcdFx0dG90YWwwMmxvMSA9IDA7XHJcblx0XHRcdFx0XHRcdHRvdGFsMDJsbzIgPSAwO1xyXG5cdFx0XHRcdFx0XHR0b3RhbDAzbG8xID0gMDtcclxuXHRcdFx0XHRcdFx0dG90YWwwM2xvMiA9IDA7XHJcblx0XHRcdFx0XHRcdHRvdGFsMDRsbzEgPSAwO1xyXG5cdFx0XHRcdFx0XHR0b3RhbDA0bG8yID0gMDsgICAgICAgICAgICAgICAgICAgICAgICBcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9XHJcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBtPTA7IG08IHJlc3VsdEFycltrXS5pbnZvaWNlRGF0ZS5sZW5ndGg7IG0rKykgXHJcbiAgICAgICAgICAgICAgICB7IFxyXG4gICAgICAgICAgICAgICAgICAgIG1hdGVyaWFsID0gcGFyc2VJbnQocmVzdWx0QXJyW2tdLmludm9pY2VEYXRlW21dLnR5cGVbMF0ubWF0ZXJpYWwpXHJcbiAgICAgICAgICAgICAgICAgICAgYm9pbGVyID0gcGFyc2VJbnQocmVzdWx0QXJyW2tdLmludm9pY2VEYXRlW21dLnR5cGVbMF0uYm9pbGVyKVxyXG4gICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgc3dpdGNoKHJlc3VsdEFycltrXS5pbnZvaWNlRGF0ZVttXS5teVBsYWNlKVxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBcIldlaWdoaW5nMVwiOi8vQmlvbWFzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb2FkY2VsbDAxUHJ2ID0gbG9hZGNlbGwwMVBydiArIHBhcnNlSW50KHJlc3VsdEFycltrXS5pbnZvaWNlRGF0ZVttXS5teVN0YW1wKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3dpdGNoKG1hdGVyaWFsKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMDovL0Jpb21hc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3RhbExDMDFCaW9tYXMgPSB0b3RhbExDMDFCaW9tYXMgKyBwYXJzZUludChyZXN1bHRBcnJba10uaW52b2ljZURhdGVbbV0ubXlTdGFtcCk7XHRcdFx0XHRcdFx0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMTovL1RoYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG90YWxMQzAxVGhhbiA9IHRvdGFsTEMwMlRoYW4gKyBwYXJzZUludChyZXN1bHRBcnJba10uaW52b2ljZURhdGVbbV0ubXlTdGFtcCk7XHRcdFx0XHRcdFx0XHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9ICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN3aXRjaChib2lsZXIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAxOi8vTG8gMVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3RhbDAxbG8xID0gdG90YWwwMWxvMSArIHBhcnNlSW50KHJlc3VsdEFycltrXS5pbnZvaWNlRGF0ZVttXS5teVN0YW1wKTtcdFx0XHRcdFx0XHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAyOi8vTG8gMlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3RhbDAybG8xID0gdG90YWwwMmxvMSArIHBhcnNlSW50KHJlc3VsdEFycltrXS5pbnZvaWNlRGF0ZVttXS5teVN0YW1wKTtcdFx0XHRcdFx0XHRcdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIDM6Ly9MbyAzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsMDNsbzEgPSB0b3RhbDAxM28xICsgcGFyc2VJbnQocmVzdWx0QXJyW2tdLmludm9pY2VEYXRlW21dLm15U3RhbXApO1x0XHRcdFx0XHRcdFx0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgNDovL0xvIDRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG90YWwwNGxvMSA9IHRvdGFsMDRsbzEgKyBwYXJzZUludChyZXN1bHRBcnJba10uaW52b2ljZURhdGVbbV0ubXlTdGFtcCk7XHRcdFx0XHRcdFx0XHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9ICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgXCJXZWlnaGluZzJcIjovL1RoYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRjZWxsMDJQcnYgPSBsb2FkY2VsbDAyUHJ2ICsgcGFyc2VJbnQocmVzdWx0QXJyW2tdLmludm9pY2VEYXRlW21dLm15U3RhbXApXHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN3aXRjaChtYXRlcmlhbClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIDA6Ly9CaW9tYXNcdFx0XHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG90YWxMQzAyQmlvbWFzID0gdG90YWxMQzAyQmlvbWFzICsgcGFyc2VJbnQocmVzdWx0QXJyW2tdLmludm9pY2VEYXRlW21dLm15U3RhbXApXHQ7XHRcdFx0XHRcdFx0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMTovL1RoYW5cdFx0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsTEMwMlRoYW4gPSB0b3RhbExDMDJUaGFuICsgcGFyc2VJbnQocmVzdWx0QXJyW2tdLmludm9pY2VEYXRlW21dLm15U3RhbXApXHQ7XHRcdFx0XHRcdFx0XHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9ICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3dpdGNoKGJvaWxlcilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIDE6Ly9MbyAxXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsMDFsbzIgPSB0b3RhbDAxbG8yICsgcGFyc2VJbnQocmVzdWx0QXJyW2tdLmludm9pY2VEYXRlW21dLm15U3RhbXApXHQ7XHRcdFx0XHRcdFx0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMjovL0xvIDJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG90YWwwMmxvMiA9IHRvdGFsMDJsbzIgKyBwYXJzZUludChyZXN1bHRBcnJba10uaW52b2ljZURhdGVbbV0ubXlTdGFtcClcdDtcdFx0XHRcdFx0XHRcdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIDM6Ly9MbyAzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsMDNsbzIgPSB0b3RhbDAxM28yICsgcGFyc2VJbnQocmVzdWx0QXJyW2tdLmludm9pY2VEYXRlW21dLm15U3RhbXApXHQ7XHRcdFx0XHRcdFx0XHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSA0Oi8vTG8gNFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3RhbDA0bG8yID0gdG90YWwwNGxvMiArIHBhcnNlSW50KHJlc3VsdEFycltrXS5pbnZvaWNlRGF0ZVttXS5teVN0YW1wKVx0O1x0XHRcdFx0XHRcdFx0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH0gXHJcbiAgICAgICAgICAgICAgIFxyXG5cdFx0XHR9XHJcblx0XHRcdFxyXG5cdFx0XHRkYXRhQmxvY2sucHVzaCh7XHJcblx0XHRcdFx0X2lkOiBcIkLhu5kgY8OibiAxXCIsXHJcblx0XHRcdFx0dHlwZTogJ2JhcicsXHJcblx0XHRcdFx0c3RhY2s6ICdTdGFjayAwJyxcclxuXHRcdFx0XHRkYXRhOiBkYXRhTEMwMSxcclxuXHRcdFx0XHR0aW1lOiBkYXRhVGltZVxyXG5cdFx0XHR9KTtcdFxyXG5cdFx0XHRkYXRhQmxvY2sucHVzaCh7XHJcblx0XHRcdFx0X2lkOiBcIkLhu5kgY8OibiAyXCIsXHJcblx0XHRcdFx0dHlwZTogJ2JhcicsXHJcblx0XHRcdFx0c3RhY2s6ICdTdGFjayAwJyxcclxuXHRcdFx0XHRkYXRhOiBkYXRhTEMwMixcclxuXHRcdFx0XHR0aW1lOiBkYXRhVGltZVxyXG5cdFx0XHR9KTtcdFx0XHRcdFxyXG5cdFx0XHRkYXRhQmxvY2sucHVzaCh7XHJcblx0XHRcdFx0X2lkOiBcIlJlcG9ydFwiLFxyXG5cdFx0XHRcdGRhdGE6IGRhdGFSZXBvcnQsXHJcblx0XHRcdH0pO1x0XHRcdFx0XHRcdFxyXG5cdFx0XHRyZXR1cm4gZGF0YUJsb2NrO1x0XHRcdFxyXG5cdFx0fSxcdFx0XHJcbiAgICAgICAgLy89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cdFx0YXN5bmMgJ2Jpb21hc2V2ZW50LmdldEJpb21hc0luVGltZScoc3RhcnRUaW1lLGVuZFRpbWUpIHtcclxuXHRcdFx0dmFyIGRhdGFCbG9jayBcdD0gW107XHJcblx0XHRcdHZhciByZXN1bHRBcnIgPSBbXTtcclxuXHRcdFx0Ly9jb25zb2xlLmxvZyhcInN0YXJ0VGltZVBhcmFtIFwiICsgc3RhcnRUaW1lICsgXCIsIGVuZFRpbWVQYXJhbSBcIiArIGVuZFRpbWUgKTtcclxuXHRcdFx0Y29uc3QgcmVzdWx0ID0gYXdhaXQgQmlvbWFzRXZlbnQucmF3Q29sbGVjdGlvbigpLmFnZ3JlZ2F0ZShbXHJcbiAgICAgICAgICAgICAgICB7JG1hdGNoOiB7IHNUaW1lOiB7ICRndGU6IHN0YXJ0VGltZSwgJGx0ZTogZW5kVGltZSB9IH0gfSxcclxuICAgICAgICAgICAgICAgIHskc2V0OiB7IGRhdGVzeDogeyAkZGF0ZVRvU3RyaW5nOiB7IGZvcm1hdDogXCIlbS0lZFwiLCBkYXRlOiB7JGFkZCA6IFtuZXcgRGF0ZSgwKSwgXCIkc1RpbWVcIl0gfSwgdGltZXpvbmU6IFwiQXNpYS9Ib19DaGlfTWluaFwiIH0gfSB9IH0sXHJcbiAgICAgICAgICAgICAgICB7JHNldDogeyBob3Vyc3g6IHsgJGRhdGVUb1N0cmluZzogeyBmb3JtYXQ6IFwiJVktJW0tJWQgJUg6JU1cIiwgZGF0ZTogeyRhZGQgOiBbbmV3IERhdGUoMCksIFwiJHNUaW1lXCJdIH0sIHRpbWV6b25lOiBcIkFzaWEvSG9fQ2hpX01pbmhcIiB9IH0gfSB9LFxyXG4gICAgICAgICAgICAgICAgeyRtYXRjaDogeyB2YWx1ZUU6IHsgJGd0OiAwLCAkbHRlOiAxMDAwMCB9IH0gfSxcclxuICAgICAgICAgICAgICAgIHskbWF0Y2g6IHsgdmFsdWVTOiB7ICRndDogMCwgJGx0ZTogMTAwMDAgfSB9IH0sICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgeyRwcm9qZWN0OlxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgX2lkOlwiJG5hbWVcIiAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1hdGVyaWFsOiB7ICRzdWJ0cmFjdCA6IFsgXCIkdmFsdWVFXCIsIFwiJHZhbHVlU1wiIF19LCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0ZXN4OlwiJGRhdGVzeFwiICxcclxuICAgICAgICAgICAgICAgICAgICAgICAgaG91cnN4OlwiJGhvdXJzeFwiICwgXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHskbWF0Y2g6IHsgbWF0ZXJpYWw6IHsgJGd0OiAwLCAkbHRlOiAxMDAwMCB9IH0gfSxcclxuICAgICAgICAgICAgICAgIHskZ3JvdXAgOiBcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9pZDp7aG91cnN4OlwiJGhvdXJzeFwiLCBuYW1lOlwiJF9pZFwifSwgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1bVBvaW50czp7JHN1bTpcIiRtYXRlcmlhbFwifVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICB9LCAgXHJcbiAgICAgICAgICAgICAgICB7JHNvcnQgOiB7IFwiX2lkLmhvdXJzeFwiOjF9IH0sXHJcbiAgICAgICAgICAgICAgICB7JGdyb3VwIDogXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBfaWQ6e2hvdXJzeDpcIiRfaWQuaG91cnN4XCJ9LCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3Vtczp7JHN1bTpcIiRzdW1Qb2ludHNcIn0sICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpbnZvaWNlRGF0ZToge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJHB1c2g6IHsgXCJteVBsYWNlXCIgOiBcIiRfaWQubmFtZVwiLCBcIm15U3RhbXBcIiA6IFwiJHN1bVBvaW50c1wiIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgIH0sICBcclxuICAgICAgICAgICAgICAgIHskc29ydCA6IHsgXCJfaWQuaG91cnN4XCI6MX0gfSAgICAgICAgICAgICAgIFxyXG5cdFx0XHRdKS5mb3JFYWNoKGZ1bmN0aW9uKGRvYykge1xyXG5cdFx0XHRcdHJlc3VsdEFyci5wdXNoKGRvYyk7XHRcdFx0XHRcdFxyXG5cdFx0XHR9KVxyXG5cclxuXHRcdFx0dmFyIGxvYWRjZWxsMDFQcnZcdD0gMDtcclxuXHRcdFx0dmFyIGxvYWRjZWxsMDJQcnZcdD0gMDtcclxuXHRcdFx0dmFyIGZpcnN0T2ZEYXlcdFx0PSAwO1xyXG5cdFx0XHR2YXIgZGF0ZVRpbWUgPSAwO1xyXG5cdFx0XHR2YXIgbG9hZCA9IDA7XHRcclxuXHRcdFx0dmFyIGRhdGVUaW1lID0gMDtcclxuXHRcdFx0dmFyIGRhdGFMQzAxID0gW107XHRcclxuXHRcdFx0dmFyIGRhdGFMQzAyID0gW107XHRcclxuXHRcdFx0dmFyIGRhdGFUaW1lID0gW107XHJcblx0XHRcdHZhciBkYXRhUmVwb3J0PVtdO1xyXG4gICAgICAgICAgICB2YXIgdG90YWxBbGwgPSAwO1xyXG5cdFx0XHJcbiAgICBcclxuXHRcdFx0Zm9yICh2YXIgaz0wOyBrIDwgcmVzdWx0QXJyLmxlbmd0aDsgaysrKVxyXG5cdFx0XHR7XHJcbiAgICAgICAgICAgICAgICAgdmFyIG15QXJyYXkgPSByZXN1bHRBcnJba10uX2lkLmhvdXJzeC5zcGxpdChcIiBcIik7ICAgICAgICAgICAgICAgXHJcblx0XHRcdFx0aWYgKChmaXJzdE9mRGF5PT0wKSAmJiAocGFyc2VJbnQobXlBcnJheVsxXSkgPj02KSlcclxuXHRcdFx0XHR7ICAgICAgICAgICAgICAgXHJcblx0XHRcdFx0XHRkYXRlVGltZVx0XHQ9IG15QXJyYXlbMF1cclxuXHRcdFx0XHRcdGZpcnN0T2ZEYXlcdCAgICA9IDE7XHJcblx0XHRcdFx0fSBcclxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGZpcnN0T2ZEYXk9PTEpXHJcblx0XHRcdFx0e1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICgoZGF0ZVRpbWUgIT0gbXlBcnJheVswXSkgJiYgKHBhcnNlSW50KG15QXJyYXlbMV0pID49NikpXHJcblx0XHRcdFx0XHR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0b3RhbEFsbCAgPSBwYXJzZUludCgobG9hZGNlbGwwMVBydiArIGxvYWRjZWxsMDJQcnYpLzEwMDApOyAgICAgICAgICAgICAgICAgICAgICAgXHJcblxyXG5cdFx0XHRcdFx0XHRkYXRhUmVwb3J0LnB1c2goXHJcblx0XHRcdFx0XHRcdFx0dG90YWxBbGxcclxuXHRcdFx0XHRcdFx0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcblx0XHRcdFx0XHRcdGRhdGFUaW1lLnB1c2goXHJcblx0XHRcdFx0XHRcdFx0ZGF0ZVRpbWUuc3Vic3RyaW5nKDUpXHJcblx0XHRcdFx0XHRcdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRlVGltZVx0XHQ9IG15QXJyYXlbMF1cclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGNlbGwwMVBydlx0PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRjZWxsMDJQcnZcdD0gMFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG4gICAgICAgICAgICAgICAgZm9yICh2YXIgbT0wOyBtPCByZXN1bHRBcnJba10uaW52b2ljZURhdGUubGVuZ3RoOyBtKyspIFxyXG4gICAgICAgICAgICAgICAgeyBcclxuICAgICAgICAgICAgICAgICAgICBzd2l0Y2gocmVzdWx0QXJyW2tdLmludm9pY2VEYXRlW21dLm15UGxhY2UpXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIFwiV2VpZ2hpbmcxXCI6Ly9CaW9tYXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRjZWxsMDFQcnYgPSBsb2FkY2VsbDAxUHJ2ICsgcGFyc2VJbnQocmVzdWx0QXJyW2tdLmludm9pY2VEYXRlW21dLm15U3RhbXApXHRcdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgXCJXZWlnaGluZzJcIjovL1RoYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRjZWxsMDJQcnYgPSBsb2FkY2VsbDAyUHJ2ICsgcGFyc2VJbnQocmVzdWx0QXJyW2tdLmludm9pY2VEYXRlW21dLm15U3RhbXApXHRcdFx0XHRcdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9ICBcclxuXHRcdFx0fVxyXG4gICAgICAgICAgICB0b3RhbEFsbCAgPSBwYXJzZUludCgobG9hZGNlbGwwMVBydiArIGxvYWRjZWxsMDJQcnYpLzEwMDApOyAgICAgICAgXHJcbiAgICAgICAgICAgIGlmICgocmVzdWx0QXJyLmxlbmd0aCA+IDUpICYmICh0b3RhbEFsbD4gMCkpXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGRhdGFSZXBvcnQucHVzaChcclxuICAgICAgICAgICAgICAgICAgICBwYXJzZUludCgobG9hZGNlbGwwMVBydiArIGxvYWRjZWxsMDJQcnYpLzEwMDApXHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBkYXRhVGltZS5wdXNoKFxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGVUaW1lLnN1YnN0cmluZyg1KVxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBcclxuXHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdF9pZDogXCJCaW9tYXMoMTAwMGtnKVwiLFxyXG5cdFx0XHRcdHR5cGU6ICdiYXInLFxyXG5cdFx0XHRcdGRhdGE6IGRhdGFSZXBvcnQsXHJcblx0XHRcdFx0dGltZTogZGF0YVRpbWVcclxuXHRcdFx0fSk7XHRcdFxyXG5cdFx0XHRyZXR1cm4gZGF0YUJsb2NrO1x0XHRcdFxyXG5cdFx0fSxcclxuXHRcdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHRcdGFzeW5jICdiaW9tYXNldmVudC5nZXRTaGlmdFdvcmtpbmdEYWlseScoc3RhcnRUaW1lLGVuZFRpbWUsc2VsZWN0Qm9pbGVyKSB7XHJcblx0XHRcdHZhciBkYXRhQmxvY2sgXHQ9IFtdO1xyXG5cdFx0XHR2YXIgcmVzdWx0QXJyID0gW107XHJcblx0XHRcdC8vY29uc29sZS5sb2coXCJzdGFydFRpbWVQYXJhbSBcIiArIHN0YXJ0VGltZSArIFwiLCBlbmRUaW1lUGFyYW0gXCIgKyBlbmRUaW1lICsgXCIsIHNlbGVjdEJvaWxlciBcIiArIHNlbGVjdEJvaWxlcik7XHJcblx0XHRcdGNvbnN0IHJlc3VsdCA9IGF3YWl0IEJpb21hc0V2ZW50LnJhd0NvbGxlY3Rpb24oKS5hZ2dyZWdhdGUoW1xyXG4gICAgICAgICAgICAgICAgeyRtYXRjaDogeyBzVGltZTogeyAkZ3RlOiBzdGFydFRpbWUsICRsdGU6IGVuZFRpbWUgfSB9IH0sXHJcbiAgICAgICAgICAgICAgICB7JHNldDogeyBkYXRlc3g6IHsgJGRhdGVUb1N0cmluZzogeyBmb3JtYXQ6IFwiJW0tJWRcIiwgZGF0ZTogeyRhZGQgOiBbbmV3IERhdGUoMCksIFwiJHNUaW1lXCJdIH0sIHRpbWV6b25lOiBcIkFzaWEvSG9fQ2hpX01pbmhcIiB9IH0gfSB9LFxyXG4gICAgICAgICAgICAgICAgeyRzZXQ6IHsgaG91cnN4OiB7ICRkYXRlVG9TdHJpbmc6IHsgZm9ybWF0OiBcIiVtLSVkICVIXCIsIGRhdGU6IHskYWRkIDogW25ldyBEYXRlKDApLCBcIiRzVGltZVwiXSB9LCB0aW1lem9uZTogXCJBc2lhL0hvX0NoaV9NaW5oXCIgfSB9IH0gfSxcclxuICAgICAgICAgICAgICAgIHskbWF0Y2g6IHsgdmFsdWVFOiB7ICRndDogMCwgJGx0ZTogMTAwMDAgfSB9IH0sXHJcbiAgICAgICAgICAgICAgICB7JG1hdGNoOiB7IHZhbHVlUzogeyAkZ3Q6IDAsICRsdGU6IDEwMDAwIH0gfSB9LCAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIHskcHJvamVjdDpcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9pZDpcIiRuYW1lXCIgLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXRlcmlhbDogeyAkc3VidHJhY3QgOiBbIFwiJHZhbHVlRVwiLCBcIiR2YWx1ZVNcIiBdfSwgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGVzeDpcIiRkYXRlc3hcIiAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhvdXJzeDpcIiRob3Vyc3hcIiAsIFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB7JG1hdGNoOiB7IG1hdGVyaWFsOiB7ICRndDogMCwgJGx0ZTogNDAwMCB9IH0gfSxcclxuICAgICAgICAgICAgICAgIHskZ3JvdXAgOiBcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9pZDp7aG91cnN4OlwiJGhvdXJzeFwiLCBuYW1lOlwiJF9pZFwifSwgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1bVBvaW50czp7JHN1bTpcIiRtYXRlcmlhbFwifVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICB9LCAgXHJcbiAgICAgICAgICAgICAgICB7JHNvcnQgOiB7IFwiX2lkLmhvdXJzeFwiOjF9IH0sXHJcbiAgICAgICAgICAgICAgICB7JGdyb3VwIDogXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBfaWQ6e2hvdXJzeDpcIiRfaWQuaG91cnN4XCJ9LCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3Vtczp7JHN1bTpcIiRzdW1Qb2ludHNcIn0sICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpbnZvaWNlRGF0ZToge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJHB1c2g6IHsgXCJteVBsYWNlXCIgOiBcIiRfaWQubmFtZVwiLCBcIm15U3RhbXBcIiA6IFwiJHN1bVBvaW50c1wiIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgIH0sICBcclxuICAgICAgICAgICAgICAgIHskc29ydCA6IHsgXCJfaWQuaG91cnN4XCI6MX0gfSAgICAgICAgICAgICAgIFxyXG5cdFx0XHRdKS5mb3JFYWNoKGZ1bmN0aW9uKGRvYykge1xyXG5cdFx0XHRcdHJlc3VsdEFyci5wdXNoKGRvYyk7XHRcdFx0XHRcdFxyXG5cdFx0XHR9KVxyXG5cclxuXHRcdFx0dmFyIGxvYWRjZWxsMDFQcnZcdD0gMDtcclxuXHRcdFx0dmFyIGxvYWRjZWxsMDJQcnZcdD0gMDtcclxuXHRcdFx0dmFyIGZpcnN0T2ZEYXlcdFx0PSAwO1xyXG5cdFx0XHR2YXIgaG91cnN4ID0gMDtcclxuXHRcdFx0dmFyIGRhdGVzeCA9IFwiXCI7XHJcblx0XHRcdHZhciBkYXRldGltZSA9IFwiXCI7XHJcblx0XHRcdHZhciBkYXRhTEMwMSA9IFtdO1x0XHJcblx0XHRcdHZhciBkYXRhTEMwMiA9IFtdO1x0XHJcblx0XHRcdHZhciBkYXRhVGltZSA9IFtdO1xyXG5cdFx0XHR2YXIgZGF0YVJlcG9ydD1bXTtcdFx0XHJcbiAgICAgICAgICAgIHZhciB0b3RhbCA9IDA7XHJcbiAgICAgICAgICAgIHZhciBsb2FkY2VsbDAxID0gMDtcclxuICAgICAgICAgICAgdmFyIGxvYWRjZWxsMDIgPSAwO1xyXG4gICAgICAgICAgICB2YXIgc2hpZnRuID0gXCJDYSAxXCJcclxuXHRcdFx0Zm9yICh2YXIgaz0wOyBrIDwgcmVzdWx0QXJyLmxlbmd0aDsgaysrKVxyXG5cdFx0XHR7XHJcbiAgICAgICAgICAgICAgICB2YXIgbXlBcnJheSA9IHJlc3VsdEFycltrXS5faWQuaG91cnN4LnNwbGl0KFwiIFwiKTtcclxuICAgICAgICAgICAgICAgIGhvdXJzeFx0XHQ9IG15QXJyYXlbMV0gXHJcbiAgICAgICAgICAgICAgICBpZiAoKGhvdXJzeD49NikgJiYgKGhvdXJzeDwxNCkpXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2hpZnRuID0gXCJDYSAxXCJcclxuICAgICAgICAgICAgICAgIH0gZWxzZSAgaWYgKChob3Vyc3g+PTE0KSAmJiAoaG91cnN4PDIyKSlcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBzaGlmdG4gPSBcIkNhIDJcIlxyXG4gICAgICAgICAgICAgICAgfSBlbHNlXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgIHNoaWZ0biA9IFwiQ2EgM1wiXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBkYXRldGltZSAgICA9IHJlc3VsdEFycltrXS5faWQuaG91cnN4XHJcbiAgICAgICAgICAgICAgICBsb2FkY2VsbDAxUHJ2XHQ9IDA7XHJcbiAgICAgICAgICAgICAgICBsb2FkY2VsbDAyUHJ2XHQ9IDA7ICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgZm9yICh2YXIgbT0wOyBtPCByZXN1bHRBcnJba10uaW52b2ljZURhdGUubGVuZ3RoOyBtKyspIFxyXG4gICAgICAgICAgICAgICAgeyBcclxuICAgICAgICAgICAgICAgICAgICBzd2l0Y2gocmVzdWx0QXJyW2tdLmludm9pY2VEYXRlW21dLm15UGxhY2UpXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIFwiV2VpZ2hpbmcxXCI6Ly9CaW9tYXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRjZWxsMDFQcnYgPSBwYXJzZUludChyZXN1bHRBcnJba10uaW52b2ljZURhdGVbbV0ubXlTdGFtcClcdFx0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBcIldlaWdoaW5nMlwiOi8vVGhhblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGNlbGwwMlBydiA9IHBhcnNlSW50KHJlc3VsdEFycltrXS5pbnZvaWNlRGF0ZVttXS5teVN0YW1wKVx0XHRcdFx0XHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZGF0YVJlcG9ydC5wdXNoKHtcclxuICAgICAgICAgICAgICAgICAgICB0aW1lOiBkYXRldGltZSxcclxuICAgICAgICAgICAgICAgICAgICBzaGlmdDogc2hpZnRuLFxyXG4gICAgICAgICAgICAgICAgICAgIGJvY2FuMDEgOmxvYWRjZWxsMDFQcnYsXHJcbiAgICAgICAgICAgICAgICAgICAgYm9jYW4wMiA6bG9hZGNlbGwwMlBydixcclxuICAgICAgICAgICAgICAgICAgICB0b3RhbCA6ICByZXN1bHRBcnJba10uc3VtcyxcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgdG90YWwgPSB0b3RhbCArIHBhcnNlSW50KHJlc3VsdEFycltrXS5zdW1zKVxyXG4gICAgICAgICAgICAgICAgbG9hZGNlbGwwMSA9IGxvYWRjZWxsMDEgKyBwYXJzZUludChsb2FkY2VsbDAxUHJ2KVxyXG4gICAgICAgICAgICAgICAgbG9hZGNlbGwwMiA9IGxvYWRjZWxsMDIgKyBwYXJzZUludChsb2FkY2VsbDAyUHJ2KVxyXG4gICAgICAgICAgICAgICAgZGF0YUxDMDEucHVzaChcclxuICAgICAgICAgICAgICAgICAgICBOdW1iZXIobG9hZGNlbGwwMVBydilcclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICBkYXRhTEMwMi5wdXNoKFxyXG4gICAgICAgICAgICAgICAgICAgIE51bWJlcihsb2FkY2VsbDAyUHJ2KVxyXG4gICAgICAgICAgICAgICAgKTtcdFxyXG4gICAgICAgICAgICAgICAgZGF0YVRpbWUucHVzaChcclxuICAgICAgICAgICAgICAgICAgICBkYXRldGltZVxyXG4gICAgICAgICAgICAgICAgKTsgICAgICAgICAgICAgICAgIFxyXG5cdFx0XHR9XHJcblxyXG4gICAgICAgICAgICBkYXRhUmVwb3J0LnB1c2goe1xyXG4gICAgICAgICAgICAgICAgdGltZTogXCJcIixcclxuICAgICAgICAgICAgICAgIHNoaWZ0OiBcIlThu5VuZ1wiLFxyXG4gICAgICAgICAgICAgICAgYm9jYW4wMSA6bG9hZGNlbGwwMSxcclxuICAgICAgICAgICAgICAgIGJvY2FuMDIgOmxvYWRjZWxsMDIsXHJcbiAgICAgICAgICAgICAgICB0b3RhbCA6ICB0b3RhbCxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICBcclxuXHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdF9pZDogXCJC4buZIGPDom4gMVwiLFxyXG5cdFx0XHRcdHR5cGU6ICdiYXInLFxyXG5cdFx0XHRcdHN0YWNrOiAnU3RhY2sgMCcsXHJcblx0XHRcdFx0ZGF0YTogZGF0YUxDMDEsXHJcblx0XHRcdFx0dGltZTogZGF0YVRpbWVcclxuXHRcdFx0fSk7XHRcclxuXHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdF9pZDogXCJC4buZIGPDom4gMlwiLFxyXG5cdFx0XHRcdHR5cGU6ICdiYXInLFxyXG5cdFx0XHRcdHN0YWNrOiAnU3RhY2sgMCcsXHJcblx0XHRcdFx0ZGF0YTogZGF0YUxDMDIsXHJcblx0XHRcdFx0dGltZTogZGF0YVRpbWVcclxuXHRcdFx0fSk7XHRcdFx0XHRcclxuXHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdF9pZDogXCJSZXBvcnRcIixcclxuXHRcdFx0XHRkYXRhOiBkYXRhUmVwb3J0LFxyXG5cdFx0XHR9KTtcdFx0XHRcdFx0XHRcclxuXHRcdFx0cmV0dXJuIGRhdGFCbG9jaztcdFx0XHRcclxuXHRcdH0sICAgICAgICBcclxuICAgIH0pXHJcbiB9XHJcblxyXG4gTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuLy89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHRcclxuXHQnYmlvbWFzZXZlbnQuZ2V0SGlzdG9yaWFuJyhzaXRlLHN0YXJ0VGltZVBhcmFtLGVuZFRpbWVQYXJhbSkgXHJcblx0e1xyXG5cdFx0dmFyIGRhdGFCbG9jayBcdD0gW107XHJcblx0XHR2YXIgaW5kZXggXHRcdD0gMDtcclxuXHRcdHZhciBlbmRUaW1lIFx0PSBcIlwiO1xyXG5cdFx0dmFyIHRpbWVzdGFtcCBcdD0gXCJcIjtcclxuXHRcdFxyXG5cdFx0bGV0IG9wdGlvbnMgPSB7eWVhcjogJzItZGlnaXQnLCBtb250aDogJ251bWVyaWMnLCBkYXk6ICdudW1lcmljJyxob3VyOiAnMi1kaWdpdCcsbWludXRlOiAnMi1kaWdpdCcsc2Vjb25kOiAnMi1kaWdpdCd9O1xyXG5cdFx0XHJcblx0XHRCaW9tYXNFdmVudC5maW5kKHtzVGltZTp7JGd0ZTogc3RhcnRUaW1lUGFyYW0sJGx0ZTplbmRUaW1lUGFyYW19fSx7IHNvcnQ6IHsgX2lkOiAtMSB9fSkuZm9yRWFjaChmdW5jdGlvbihkb2MpIHtcdFx0XHJcblx0XHRcdHZhciBuYW1lID0gZG9jLm5hbWU7XHJcblx0XHRcdGlmIChkb2MuZVRpbWUgPT0wKVxyXG5cdFx0XHR7XHJcblx0XHRcdFx0ZW5kVGltZSA9IFwiXCI7XHJcblx0XHRcdH1cclxuXHRcdFx0ZWxzZVxyXG5cdFx0XHR7XHJcblx0XHRcdFx0ZW5kVGltZSA9IG5ldyBEYXRlKGRvYy5lVGltZSkudG9Mb2NhbGVTdHJpbmcoe30sb3B0aW9ucyk7XHJcblx0XHRcdH1cclxuXHRcdFx0dGltZXN0YW1wID0gbmV3IERhdGUoZG9jLnNUaW1lKS50b0xvY2FsZVN0cmluZyh7fSxvcHRpb25zKTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIGlmICgocGFyc2VJbnQoZG9jLnZhbHVlRSkgPD0wKSB8fCAgKHBhcnNlSW50KGRvYy52YWx1ZVMpIDw9MCkpXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIC8vXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICB7ICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBkYXRhQmxvY2sucHVzaCh7XHJcbiAgICAgICAgICAgICAgICAgICAgX2lkXHQ6IGRvYy5faWQsXHJcbiAgICAgICAgICAgICAgICAgICAgb2JqTmFtZVx0OiBkb2MubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKGRvYy5zVGltZSkudG9Mb2NhbGVTdHJpbmcoe30sb3B0aW9ucyksXHJcbiAgICAgICAgICAgICAgICAgICAgZW5kVGltZVx0OiBlbmRUaW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlU1x0OiBkb2MudmFsdWVTLFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlRVx0OiBkb2MudmFsdWVFLFxyXG4gICAgICAgICAgICAgICAgICAgIHRvdGFsXHQ6IHBhcnNlSW50KGRvYy52YWx1ZUUpIC0gcGFyc2VJbnQoZG9jLnZhbHVlUylcclxuICAgICAgICAgICAgICAgIH0pO1x0XHJcbiAgICAgICAgICAgIH1cclxuXHRcdH0pO1xyXG5cdFx0Ly9jb25zb2xlLmxvZyhcImRhdGFCbG9jazogXCIgKyBkYXRhQmxvY2spO1xyXG5cdFx0cmV0dXJuIGRhdGFCbG9jaztcclxuXHR9XHJcbn0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IFNlY3VyaXR5IGZyb20gJy4vc2VjdXJpdHknOyBcclxuXHJcbmV4cG9ydCBjb25zdCBCaW9tYXNNYXRlcmlhbCA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdiaW9tYXNtYXRlcmlhbCcpO1xyXG5cclxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG5cdE1ldGVvci5tZXRob2RzKHtcdFxyXG5cdFx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0XHRhc3luYyAnYmlvbWFzbWF0ZXJpYWwuZ2V0ZGF0YWJsb2NrJygpIFxyXG5cdFx0e1xyXG5cdFx0XHR2YXIgZGF0YUJsb2NrID0gW107XHJcblx0XHRcdGF3YWl0ICBCaW9tYXNNYXRlcmlhbC5maW5kKHt9LCB7c29ydDoge3N0YXJ0VGltZTogMX19KS5mb3JFYWNoKGZ1bmN0aW9uKGRvYykge1xyXG5cdFx0XHRcdGRhdGFCbG9jay5wdXNoKHtcclxuXHRcdFx0XHRcdF9pZDogZG9jLl9pZCxcdFxyXG5cdFx0XHRcdFx0c3RhcnRUaW1lZHNjOiBuZXcgRGF0ZShkb2Muc3RhcnRUaW1lKS50b0xvY2FsZURhdGVTdHJpbmcoeyB0aW1lWm9uZTogJ0FzaWEvSG9fQ2hpX01pbmgnIH0pLFxyXG5cdFx0XHRcdFx0ZW5kVGltZWRzYzogbmV3IERhdGUoZG9jLmVuZFRpbWUpLnRvTG9jYWxlRGF0ZVN0cmluZyh7IHRpbWVab25lOiAnQXNpYS9Ib19DaGlfTWluaCcgfSksXHJcblx0XHRcdFx0XHRzdGFydFRpbWU6IGRvYy5zdGFydFRpbWUsXHJcblx0XHRcdFx0XHRlbmRUaW1lOiBkb2MuZW5kVGltZSxcclxuXHRcdFx0XHRcdGN1aWJhbVx0OiBkb2MuY3VpYmFtXHQsXHJcblx0XHRcdFx0XHRtdW5jdWFcdDogZG9jLm11bmN1YVx0LFxyXG5cdFx0XHRcdFx0aGF0ZGlldVx0OiBkb2MuaGF0ZGlldVx0LFxyXG5cdFx0XHRcdFx0ZGFtYmFvXHQ6IGRvYy5kYW1iYW9cdCxcclxuXHRcdFx0XHRcdGNheW5naGllbjogZG9jLmNheW5naGllbixcclxuXHRcdFx0XHRcdGJvdHh1b2NcdDogZG9jLmJvdHh1b2NcdCxcclxuXHRcdFx0XHRcdGN1aWRvdFx0OiBkb2MuY3VpZG90XHQsXHJcblx0XHRcdFx0XHR0cmF1XHQ6IGRvYy50cmF1XHRcdCxcclxuXHRcdFx0XHRcdGd1aWJhcFx0OiBkb2MuZ3VpYmFwXHQsXHJcblx0XHRcdFx0fSk7XHRcdFx0XHJcblx0XHRcdFx0XHJcblx0XHRcdH0pO1xyXG5cdFx0XHRcclxuXHRcdFx0cmV0dXJuIGRhdGFCbG9jaztcclxuXHRcdH0sXHRcclxuXHRcdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHRcdGFzeW5jICdiaW9tYXNtYXRlcmlhbC5nZXRNYXRlcmlhbCcoZGF0ZVN0cikge1xyXG5cdFx0XHR2YXIgZGF0YUJsb2NrIFx0PSBbXTtcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZShkYXRlU3RyKTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZGF0ZSk7IC8vIPCfkYnvuI8gV2VkIEp1biAyMiAyMDIyXHJcblxyXG4gICAgICAgICAgICBjb25zdCB0aW1lc3RhbXBJbk1zID0gZGF0ZS5nZXRUaW1lKCk7XHJcblx0XHRcdGNvbnN0IHJlc3VsdCA9IGF3YWl0IEJpb21hc01hdGVyaWFsLnJhd0NvbGxlY3Rpb24oKS5hZ2dyZWdhdGUoW1xyXG5cdFx0XHRcdHskbWF0Y2g6IHtcclxuXHRcdFx0XHQgICAkZXhwcjoge1xyXG5cdFx0XHRcdFx0ICAkYW5kOiBbXHJcblx0XHRcdFx0XHRcdCB7ICRsdGU6IFsgXCIkc3RhcnRUaW1lXCIsdGltZXN0YW1wSW5NcyBdIH0sXHJcblx0XHRcdFx0XHRcdCB7ICRndGU6IFsgXCIkZW5kVGltZVwiLCB0aW1lc3RhbXBJbk1zIF0gfSxcclxuXHRcdFx0XHRcdCAgXVxyXG5cdFx0XHRcdCAgIH1cclxuXHRcdFx0XHR9fVx0XHRcdFxyXG5cdFx0XHRdKS5mb3JFYWNoKGZ1bmN0aW9uKGRvYykge1xyXG5cdFx0XHRcdGRhdGFCbG9jay5wdXNoKGRvYyk7XHRcdFx0XHRcdFxyXG5cdFx0XHR9KVxyXG5cdFx0XHRyZXR1cm4gZGF0YUJsb2NrO1x0XHRcdFxyXG5cdFx0fSxcclxuXHRcdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFxyXG5cdFx0YXN5bmMgJ2Jpb21hc21hdGVyaWFsLmluc2VydCcoXHRcdFxyXG5cdFx0XHRzdGFydFRpbWUsXHJcblx0XHRcdGVuZFRpbWUsXHJcblx0XHRcdGN1aWJhbVx0LFxyXG5cdFx0XHRtdW5jdWFcdCxcclxuXHRcdFx0aGF0ZGlldVx0LFxyXG5cdFx0XHRkYW1iYW9cdCxcclxuXHRcdFx0Y2F5bmdoaWVuLFxyXG5cdFx0XHRib3R4dW9jXHQsXHJcblx0XHRcdGN1aWRvdFx0LFxyXG5cdFx0XHR0cmF1XHQsXHJcblx0XHRcdGd1aWJhcFx0LFxyXG5cdFx0XHQpIFxyXG5cdFx0e1xyXG5cdFx0XHRpZiAoIVNlY3VyaXR5LmNoZWNrUm9sZSh0aGlzLnVzZXJJZCwnT3duZXInKSlcclxuXHRcdFx0e1xyXG5cdFx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJsb2dnZWQtaW5cIixcIllvdSBhcmUgbm90IHBlcm1pdHRlZC5cIik7XHJcblx0XHRcdH1cclxuXHRcdFx0ZWxzZVxyXG5cdFx0XHR7XHJcblx0XHRcdFx0Y29uc3QgcmVzdWx0TWF0ZXJpYWxzID0gYXdhaXQgTWV0ZW9yLmNhbGwoJ2Jpb21hc21hdGVyaWFsLmdldE1hdGVyaWFsJywgc3RhcnRUaW1lKTtcclxuXHRcdFx0XHRjb25zdCByZXN1bHRNYXRlcmlhbGUgPSBhd2FpdCBNZXRlb3IuY2FsbCgnYmlvbWFzbWF0ZXJpYWwuZ2V0TWF0ZXJpYWwnLCBlbmRUaW1lKTtcclxuXHRcdFx0XHRpZiAoKHJlc3VsdE1hdGVyaWFscyAhPSBcIlwiKSB8fCAocmVzdWx0TWF0ZXJpYWxlICE9IFwiXCIpKVxyXG5cdFx0XHRcdHtcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiVHLDuW5nIHRo4budaSBnaWFuLCBow6N5IGtp4buDbSB0cmEgbOG6oWlcIik7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdGVsc2UgXHJcblx0XHRcdFx0e1x0XHRcdFx0XHRcclxuXHRcdFx0XHRcdGF3YWl0IEJpb21hc01hdGVyaWFsLmluc2VydCh7XHJcblx0XHRcdFx0XHRcdHN0YXJ0VGltZSxcclxuXHRcdFx0XHRcdFx0ZW5kVGltZSxcclxuXHRcdFx0XHRcdFx0Y3VpYmFtXHQsXHJcblx0XHRcdFx0XHRcdG11bmN1YVx0LFxyXG5cdFx0XHRcdFx0XHRoYXRkaWV1XHQsXHJcblx0XHRcdFx0XHRcdGRhbWJhb1x0LFxyXG5cdFx0XHRcdFx0XHRjYXluZ2hpZW4sXHJcblx0XHRcdFx0XHRcdGJvdHh1b2NcdCxcclxuXHRcdFx0XHRcdFx0Y3VpZG90XHQsXHJcblx0XHRcdFx0XHRcdHRyYXVcdCxcclxuXHRcdFx0XHRcdFx0Z3VpYmFwXHQsXHJcblx0XHRcdFx0XHR9KTtcclxuXHRcdFx0XHRcdFxyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0XHRyZXR1cm4gMDtcclxuXHRcdH0sXHRcdFxyXG5cdH0pXHJcbn1cclxuLy89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFx0XHJcblx0J2Jpb21hc21hdGVyaWFsLmZpbmRTaXRlJyhuYW1lKSBcclxuXHR7XHRcdFxyXG5cdFx0dmFyIG5hbWVTaXRlID0gQmlvbWFzTWF0ZXJpYWwuZmluZE9uZSh7IG5hbWU6bmFtZX0pO1x0XHRcclxuXHRcdGlmIChuYW1lU2l0ZT09bnVsbCkge1xyXG5cdFx0XHRyZXR1cm4gMDtcclxuXHRcdH1cclxuXHRcdGVsc2VcclxuXHRcdHtcclxuXHRcdFx0cmV0dXJuIDE7XHJcblx0XHR9XHRcdFx0XHJcblx0fSxcclxuXHRcclxuXHRcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQnYmlvbWFzbWF0ZXJpYWwucmVtb3ZlJyh0YXNrSWQpIFxyXG5cdHtcclxuXHRcdGlmICghU2VjdXJpdHkuY2hlY2tSb2xlKHRoaXMudXNlcklkLCdPd25lcicpKVxyXG5cdFx0e1xyXG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibG9nZ2VkLWluXCIsXCJZb3UgYXJlIG5vdCBwZXJtaXR0ZWQuXCIpO1xyXG5cdFx0fVxyXG5cdFx0ZWxzZVxyXG5cdFx0e1xyXG5cdFx0XHRCaW9tYXNNYXRlcmlhbC5yZW1vdmUodGFza0lkKTtcclxuXHRcdH1cclxuXHR9LFxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFxyXG5cdCdiaW9tYXNtYXRlcmlhbC51cGRhdGUnKFxyXG5cdFx0X2lkLFxyXG5cdFx0Y3VpYmFtXHQsXHJcblx0XHRtdW5jdWFcdCxcclxuXHRcdGhhdGRpZXVcdCxcclxuXHRcdGRhbWJhb1x0LFxyXG5cdFx0Y2F5bmdoaWVuLFxyXG5cdFx0Ym90eHVvY1x0LFxyXG5cdFx0Y3VpZG90XHQsXHJcblx0XHR0cmF1XHQsXHJcblx0XHRndWliYXBcdCxcclxuXHQpIFxyXG5cdHtcclxuXHRcdGlmICghU2VjdXJpdHkuY2hlY2tSb2xlKHRoaXMudXNlcklkLCdPd25lcicpKVxyXG5cdFx0e1xyXG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibG9nZ2VkLWluXCIsXCJZb3UgYXJlIG5vdCBwZXJtaXR0ZWQuXCIpO1xyXG5cdFx0fVxyXG5cdFx0ZWxzZVxyXG5cdFx0e1xyXG5cdFx0XHRCaW9tYXNNYXRlcmlhbC51cGRhdGUoX2lkLCBcclxuXHRcdFx0XHR7ICRzZXQ6IHsgXHJcblx0XHRcdFx0XHRjdWliYW1cdCxcclxuXHRcdFx0XHRcdG11bmN1YVx0LFxyXG5cdFx0XHRcdFx0aGF0ZGlldVx0LFxyXG5cdFx0XHRcdFx0ZGFtYmFvXHQsXHJcblx0XHRcdFx0XHRjYXluZ2hpZW4sXHJcblx0XHRcdFx0XHRib3R4dW9jXHQsXHJcblx0XHRcdFx0XHRjdWlkb3RcdCxcclxuXHRcdFx0XHRcdHRyYXVcdCxcclxuXHRcdFx0XHRcdGd1aWJhcFx0LFxyXG5cdFx0XHRcdFx0fSBcclxuXHRcdFx0XHR9KTtcclxuXHRcdH1cclxuXHR9LFxyXG5cdFx0XHJcbn0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuIFxyXG5leHBvcnQgY29uc3QgQ01ESW50ZXJmYWNlcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjbWRpbnRlcmZhY2VzJyk7XHJcblxyXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XHJcbiAgTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuXHRcdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHRcdGFzeW5jICdjbWRpbnRlcmZhY2VzLmdldEhpc3RvcmlhbkNtZCcoc3RhcnRUaW1lUGFyYW0sZW5kVGltZVBhcmFtKSBcclxuXHRcdHtcdFx0XHJcblx0XHRcdFxyXG5cdFx0XHRjb25zdCByZXN1bHQgPSBhd2FpdCBDTURJbnRlcmZhY2VzLnJhd0NvbGxlY3Rpb24oKS5hZ2dyZWdhdGUoW1xyXG5cdFx0XHRcdHskbWF0Y2g6IHsgJGFuZDogWyB7IGNyZWF0ZWRBdDogeyAkZ3RlOiBzdGFydFRpbWVQYXJhbSAsJGx0ZTplbmRUaW1lUGFyYW0gfSB9XSB9fSxcclxuXHRcdFx0XHR7JHNvcnQgOiB7IGNyZWF0ZWRBdCA6IC0xfSB9LFxyXG5cdFx0XHRcdHtcdFxyXG5cdFx0XHRcdFx0JHByb2plY3Q6IHtcclxuXHRcdFx0XHRcdFx0XCJfaWRcIjogXCIkX2lkXCIsXHJcblx0XHRcdFx0XHRcdFwib2JqXCI6IFwiJG9iak5hbWVcIixcclxuXHRcdFx0XHRcdFx0XCJ0aW1lc3RhbXBcIjogeyAkZGF0ZVRvU3RyaW5nOiB7IGZvcm1hdDogXCIlWS0lbS0lZCAlSDolTTolU1wiLCBkYXRlOiB7JGFkZCA6IFtuZXcgRGF0ZSgwKSwgXCIkY3JlYXRlZEF0XCJdIH0sIHRpbWV6b25lOiBcIkFzaWEvSG9fQ2hpX01pbmhcIn19LFxyXG5cdFx0XHRcdFx0XHRcImNtZFwiOiBcIiRuYW1lXCIsXHJcblx0XHRcdFx0XHRcdFwidmFsXCI6XCIkdmFsdWVcIixcclxuXHRcdFx0XHRcdFx0XCJ1c2VybmFtZVwiOiBcIiR1c2VybmFtZVwiXHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRdKTtcclxuXHRcdFx0cmV0dXJuIHJlc3VsdC50b0FycmF5KCk7XHJcblx0XHR9XHJcbiAgfSlcclxufVxyXG5cclxuXHRcclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHQnY21kaW50ZXJmYWNlcy5pbnNlcnQnKFx0XHRcdFxyXG5cdFx0XHRuYW1lLFxyXG5cdFx0XHRvYmpOYW1lLFxyXG5cdFx0XHRwbGMsXHJcblx0XHRcdHR5cGVkYXRhLFxyXG5cdFx0XHRhY3Rpb25zLFxyXG5cdFx0XHRhZGRyZXNzLFxyXG5cdFx0XHR2YWx1ZSxcclxuXHRcdFx0bGVuZ3RoLFxyXG5cdFx0XHR1c2VybmFtZSxcclxuXHRcdFx0Y3JlYXRlQXRcclxuXHRcdCkgXHJcblx0e1xyXG5cdFx0Ly9Ob3RoaW5nXHJcblx0XHRhZGRyZXNzID0gcGFyc2VJbnQoYWRkcmVzcyk7XHJcblx0XHR2YWx1ZSA9IE51bWJlcih2YWx1ZSk7XHJcblx0XHRcclxuXHRcdENNREludGVyZmFjZXMuaW5zZXJ0KHtcclxuXHRcdFx0bmFtZSxcclxuXHRcdFx0b2JqTmFtZSxcclxuXHRcdFx0cGxjLFxyXG5cdFx0XHRhY3Rpb25zLFxyXG5cdFx0XHRhZGRyZXNzLFxyXG5cdFx0XHR2YWx1ZSxcclxuXHRcdFx0bGVuZ3RoLFxyXG5cdFx0XHR1c2VybmFtZSxcclxuXHRcdFx0dHlwZWRhdGFcclxuXHRcdFx0Ly9jcmVhdGVBdFxyXG5cdFx0fSk7XHRcdFx0XHRcdFxyXG5cdH0sXHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cdCdjbWRpbnRlcmZhY2VzLmluc2VydExvY2FsJyhcdFx0XHRcclxuXHRcdFx0bmFtZSxcclxuXHRcdFx0b2JqTmFtZSxcclxuXHRcdFx0cGxjLFxyXG5cdFx0XHR0eXBlZGF0YSxcclxuXHRcdFx0YWN0aW9ucyxcclxuXHRcdFx0YWRkcmVzcyxcclxuXHRcdFx0dmFsdWUsXHJcblx0XHRcdGxlbmd0aCxcclxuXHRcdFx0dXNlcm5hbWUsXHJcblx0XHRcdGNyZWF0ZUF0XHJcblx0XHQpIFxyXG5cdHtcclxuXHRcdGFkZHJlc3MgPSBwYXJzZUludChhZGRyZXNzKTtcclxuXHRcdHZhbHVlID0gTnVtYmVyKHZhbHVlKTtcclxuXHRcdHN3aXRjaChwYXJzZUludCh0eXBlZGF0YSkpXHJcblx0XHR7XHJcblx0XHRcdGNhc2UgMDovL0Jvb2xlYW5cclxuXHRcdFx0XHR2YWx1ZSA9IHBhcnNlSW50KHZhbHVlKTtcclxuXHRcdFx0XHRDTURJbnRlcmZhY2VzLmluc2VydCh7XHJcblx0XHRcdFx0XHRuYW1lLFxyXG5cdFx0XHRcdFx0b2JqTmFtZSxcclxuXHRcdFx0XHRcdHBsYyxcclxuXHRcdFx0XHRcdGFjdGlvbnMsXHJcblx0XHRcdFx0XHRhZGRyZXNzLFxyXG5cdFx0XHRcdFx0dmFsdWUsXHJcblx0XHRcdFx0XHRsZW5ndGgsXHJcblx0XHRcdFx0XHR1c2VybmFtZSxcclxuXHRcdFx0XHRcdC8vY3JlYXRlQXRcclxuXHRcdFx0XHR9KTtcdFx0XHRcclxuXHRcdFx0YnJlYWs7XHJcblx0XHRcdGNhc2UgMTovL0ludGVnZXJcclxuXHRcdFx0XHR2YWx1ZSA9IHBhcnNlSW50KHZhbHVlKTtcclxuXHRcdFx0XHRDTURJbnRlcmZhY2VzLmluc2VydCh7XHJcblx0XHRcdFx0XHRuYW1lLFxyXG5cdFx0XHRcdFx0b2JqTmFtZSxcclxuXHRcdFx0XHRcdHBsYyxcclxuXHRcdFx0XHRcdGFjdGlvbnMsXHJcblx0XHRcdFx0XHRhZGRyZXNzLFxyXG5cdFx0XHRcdFx0dmFsdWUsXHJcblx0XHRcdFx0XHRsZW5ndGgsXHJcblx0XHRcdFx0XHR1c2VybmFtZSxcclxuXHRcdFx0XHRcdC8vY3JlYXRlQXRcclxuXHRcdFx0XHR9KTtcdFx0XHRcdFxyXG5cdFx0XHRicmVhaztcclxuXHRcdFx0Y2FzZSAyOi8vRG91YmxlIGludGVnZXIgZm9yIFBMQyBNMjQxXHJcblx0XHRcdFx0dmFyIGxvdz0gcGFyc2VJbnQodmFsdWUpJiAweEZGRkY7XHJcblx0XHRcdFx0dmFyIGhpZ2g9IHBhcnNlSW50KHZhbHVlKSA+PiAxNjtcclxuXHRcdFx0XHR2YWx1ZSA9IGxvdztcclxuXHRcdFx0XHR2YWx1ZSA9IHBhcnNlSW50KHZhbHVlKTtcclxuXHRcdFx0XHRDTURJbnRlcmZhY2VzLmluc2VydCh7XHJcblx0XHRcdFx0XHRuYW1lLFxyXG5cdFx0XHRcdFx0b2JqTmFtZSxcclxuXHRcdFx0XHRcdHBsYyxcclxuXHRcdFx0XHRcdGFjdGlvbnMsXHJcblx0XHRcdFx0XHRhZGRyZXNzLFxyXG5cdFx0XHRcdFx0dmFsdWUsXHJcblx0XHRcdFx0XHRsZW5ndGgsXHJcblx0XHRcdFx0XHR1c2VybmFtZSxcclxuXHRcdFx0XHRcdC8vY3JlYXRlQXRcdFxyXG5cdFx0XHRcdH0pO1x0XHRcclxuXHRcdFx0XHQvL2NvbnNvbGUubG9nKFwiZGF0YUJsb2NrIGxvdzogXCIgKyBsb3cgKyBcIiB2YWx1ZSBsb3c6IFwiICsgdmFsdWUpO1x0XHJcblx0XHRcdFx0dmFsdWUgPSBoaWdoO1xyXG5cdFx0XHRcdHZhbHVlID0gcGFyc2VJbnQodmFsdWUpO1xyXG5cdFx0XHRcdGFkZHJlc3MgPSBhZGRyZXNzICsgMTtcclxuXHRcdFx0XHRDTURJbnRlcmZhY2VzLmluc2VydCh7XHJcblx0XHRcdFx0XHRuYW1lLFxyXG5cdFx0XHRcdFx0b2JqTmFtZSxcclxuXHRcdFx0XHRcdHBsYyxcclxuXHRcdFx0XHRcdGFjdGlvbnMsXHJcblx0XHRcdFx0XHRhZGRyZXNzLFxyXG5cdFx0XHRcdFx0dmFsdWUsXHJcblx0XHRcdFx0XHRsZW5ndGgsXHJcblx0XHRcdFx0XHR1c2VybmFtZSxcclxuXHRcdFx0XHRcdC8vY3JlYXRlQXRcdFxyXG5cdFx0XHRcdH0pO1x0XHRcdFxyXG5cdFx0XHRicmVhaztcclxuXHRcdFx0Y2FzZSA0Oi8vRG91YmxlIGludGVnZXIgZm9yIExvZ29cclxuXHRcdFx0XHR2YXIgaGlnaD0gcGFyc2VJbnQodmFsdWUpJiAweEZGRkY7XHJcblx0XHRcdFx0dmFyIGxvdz0gcGFyc2VJbnQodmFsdWUpID4+IDE2O1xyXG5cdFx0XHRcdHZhbHVlID0gbG93O1xyXG5cdFx0XHRcdHZhbHVlID0gcGFyc2VJbnQodmFsdWUpO1xyXG5cdFx0XHRcdENNREludGVyZmFjZXMuaW5zZXJ0KHtcclxuXHRcdFx0XHRcdG5hbWUsXHJcblx0XHRcdFx0XHRvYmpOYW1lLFxyXG5cdFx0XHRcdFx0cGxjLFxyXG5cdFx0XHRcdFx0YWN0aW9ucyxcclxuXHRcdFx0XHRcdGFkZHJlc3MsXHJcblx0XHRcdFx0XHR2YWx1ZSxcclxuXHRcdFx0XHRcdGxlbmd0aCxcclxuXHRcdFx0XHRcdHVzZXJuYW1lLFxyXG5cdFx0XHRcdFx0Ly9jcmVhdGVBdFx0XHJcblx0XHRcdFx0fSk7XHRcdFxyXG5cdFx0XHRcdC8vY29uc29sZS5sb2coXCJkYXRhQmxvY2sgbG93OiBcIiArIGxvdyArIFwiIHZhbHVlIGxvdzogXCIgKyB2YWx1ZSk7XHRcclxuXHRcdFx0XHR2YWx1ZSA9IGhpZ2g7XHJcblx0XHRcdFx0dmFsdWUgPSBwYXJzZUludCh2YWx1ZSk7XHJcblx0XHRcdFx0YWRkcmVzcyA9IGFkZHJlc3MgKyAxO1xyXG5cdFx0XHRcdENNREludGVyZmFjZXMuaW5zZXJ0KHtcclxuXHRcdFx0XHRcdG5hbWUsXHJcblx0XHRcdFx0XHRvYmpOYW1lLFxyXG5cdFx0XHRcdFx0cGxjLFxyXG5cdFx0XHRcdFx0YWN0aW9ucyxcclxuXHRcdFx0XHRcdGFkZHJlc3MsXHJcblx0XHRcdFx0XHR2YWx1ZSxcclxuXHRcdFx0XHRcdGxlbmd0aCxcclxuXHRcdFx0XHRcdHVzZXJuYW1lLFxyXG5cdFx0XHRcdFx0Ly9jcmVhdGVBdFx0XHJcblx0XHRcdFx0fSk7XHRcdFx0XHJcblx0XHRcdGJyZWFrO1x0XHRcdFxyXG5cdFx0XHRjYXNlIDM6Ly9SZWFsXHJcblx0XHRcdFx0dmFyIGYzMiA9IG5ldyBGbG9hdDMyQXJyYXkoMSk7XHJcblx0XHRcdFx0ZjMyWzBdID0gdmFsdWU7XHJcblx0XHRcdFx0dmFyIHVpMTYgPSBuZXcgVWludDE2QXJyYXkoZjMyLmJ1ZmZlcik7XHJcblx0XHRcdFx0dmFsdWUgPSAgdWkxNlswXTtcclxuXHRcdFx0XHR2YWx1ZSA9IHBhcnNlSW50KHZhbHVlKTtcclxuXHRcdFx0XHRDTURJbnRlcmZhY2VzLmluc2VydCh7XHJcblx0XHRcdFx0XHRuYW1lLFxyXG5cdFx0XHRcdFx0b2JqTmFtZSxcclxuXHRcdFx0XHRcdHBsYyxcclxuXHRcdFx0XHRcdGFjdGlvbnMsXHJcblx0XHRcdFx0XHRhZGRyZXNzLFxyXG5cdFx0XHRcdFx0dmFsdWUsXHJcblx0XHRcdFx0XHRsZW5ndGgsXHJcblx0XHRcdFx0XHR1c2VybmFtZSxcclxuXHRcdFx0XHRcdC8vY3JlYXRlQXRcdFxyXG5cdFx0XHRcdH0pO1x0XHRcclxuXHRcdFx0XHR2YWx1ZSA9ICB1aTE2WzFdO1xyXG5cdFx0XHRcdHZhbHVlID0gcGFyc2VJbnQodmFsdWUpO1xyXG5cdFx0XHRcdGFkZHJlc3MgPSBhZGRyZXNzICsgMTtcclxuXHRcdFx0XHRDTURJbnRlcmZhY2VzLmluc2VydCh7XHJcblx0XHRcdFx0XHRuYW1lLFxyXG5cdFx0XHRcdFx0b2JqTmFtZSxcclxuXHRcdFx0XHRcdHBsYyxcclxuXHRcdFx0XHRcdGFjdGlvbnMsXHJcblx0XHRcdFx0XHRhZGRyZXNzLFxyXG5cdFx0XHRcdFx0dmFsdWUsXHJcblx0XHRcdFx0XHRsZW5ndGgsXHJcblx0XHRcdFx0XHR1c2VybmFtZSxcclxuXHRcdFx0XHRcdC8vY3JlYXRlQXRcdFxyXG5cdFx0XHRcdH0pO1x0XHRcdFx0XHJcblx0XHRcdGJyZWFrO1xyXG5cdFx0XHRkZWZhdWx0OiBicmVhaztcclxuXHRcdH1cclxuXHR9LFxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHQnY21kaW50ZXJmYWNlcy5pbnNlcnRUTVAnKFx0XHRcdFxyXG5cdFx0XHRuYW1lLFxyXG5cdFx0XHRvYmpOYW1lLFxyXG5cdFx0XHRwbGMsXHJcblx0XHRcdHR5cGVkYXRhLFxyXG5cdFx0XHRhY3Rpb25zLFxyXG5cdFx0XHRhZGRyZXNzLFxyXG5cdFx0XHR2YWx1ZSxcclxuXHRcdFx0bGVuZ3RoLFxyXG5cdFx0XHR1c2VybmFtZSxcclxuXHRcdFx0Y3JlYXRlQXRcclxuXHRcdCkgXHJcblx0e1xyXG5cdFx0YWRkcmVzcyA9IHBhcnNlSW50KGFkZHJlc3MpO1xyXG5cdFx0dmFsdWUgPSBOdW1iZXIodmFsdWUpO1xyXG5cdFx0c3dpdGNoKHBhcnNlSW50KHR5cGVkYXRhKSlcclxuXHRcdHtcclxuXHRcdFx0Y2FzZSAwOi8vQm9vbGVhblxyXG5cdFx0XHRcdHZhbHVlID0gcGFyc2VJbnQodmFsdWUpO1xyXG5cdFx0XHRcdENNREludGVyZmFjZXMuaW5zZXJ0KHtcclxuXHRcdFx0XHRcdG5hbWUsXHJcblx0XHRcdFx0XHRvYmpOYW1lLFxyXG5cdFx0XHRcdFx0cGxjLFxyXG5cdFx0XHRcdFx0YWN0aW9ucyxcclxuXHRcdFx0XHRcdGFkZHJlc3MsXHJcblx0XHRcdFx0XHR2YWx1ZSxcclxuXHRcdFx0XHRcdGxlbmd0aCxcclxuXHRcdFx0XHRcdHVzZXJuYW1lLFxyXG5cdFx0XHRcdFx0Ly9jcmVhdGVBdFxyXG5cdFx0XHRcdH0pO1x0XHRcdFxyXG5cdFx0XHRicmVhaztcclxuXHRcdFx0Y2FzZSAxOi8vSW50ZWdlclxyXG5cdFx0XHRcdHZhbHVlID0gcGFyc2VJbnQodmFsdWUpO1xyXG5cdFx0XHRcdENNREludGVyZmFjZXMuaW5zZXJ0KHtcclxuXHRcdFx0XHRcdG5hbWUsXHJcblx0XHRcdFx0XHRvYmpOYW1lLFxyXG5cdFx0XHRcdFx0cGxjLFxyXG5cdFx0XHRcdFx0YWN0aW9ucyxcclxuXHRcdFx0XHRcdGFkZHJlc3MsXHJcblx0XHRcdFx0XHR2YWx1ZSxcclxuXHRcdFx0XHRcdGxlbmd0aCxcclxuXHRcdFx0XHRcdHVzZXJuYW1lLFxyXG5cdFx0XHRcdFx0Ly9jcmVhdGVBdFxyXG5cdFx0XHRcdH0pO1x0XHRcdFx0XHJcblx0XHRcdGJyZWFrO1xyXG5cdFx0XHRjYXNlIDI6Ly9Eb3VibGUgaW50ZWdlciBmb3IgUExDIE0yNDFcclxuXHRcdFx0XHR2YXIgbG93PSBwYXJzZUludCh2YWx1ZSkmIDB4RkZGRjtcclxuXHRcdFx0XHR2YXIgaGlnaD0gcGFyc2VJbnQodmFsdWUpID4+IDE2O1xyXG5cdFx0XHRcdHZhbHVlID0gbG93O1xyXG5cdFx0XHRcdHZhbHVlID0gcGFyc2VJbnQodmFsdWUpO1xyXG5cdFx0XHRcdENNREludGVyZmFjZXMuaW5zZXJ0KHtcclxuXHRcdFx0XHRcdG5hbWUsXHJcblx0XHRcdFx0XHRvYmpOYW1lLFxyXG5cdFx0XHRcdFx0cGxjLFxyXG5cdFx0XHRcdFx0YWN0aW9ucyxcclxuXHRcdFx0XHRcdGFkZHJlc3MsXHJcblx0XHRcdFx0XHR2YWx1ZSxcclxuXHRcdFx0XHRcdGxlbmd0aCxcclxuXHRcdFx0XHRcdHVzZXJuYW1lLFxyXG5cdFx0XHRcdFx0Ly9jcmVhdGVBdFx0XHJcblx0XHRcdFx0fSk7XHRcdFxyXG5cdFx0XHRcdC8vY29uc29sZS5sb2coXCJkYXRhQmxvY2sgbG93OiBcIiArIGxvdyArIFwiIHZhbHVlIGxvdzogXCIgKyB2YWx1ZSk7XHRcclxuXHRcdFx0XHR2YWx1ZSA9IGhpZ2g7XHJcblx0XHRcdFx0dmFsdWUgPSBwYXJzZUludCh2YWx1ZSk7XHJcblx0XHRcdFx0YWRkcmVzcyA9IGFkZHJlc3MgKyAxO1xyXG5cdFx0XHRcdENNREludGVyZmFjZXMuaW5zZXJ0KHtcclxuXHRcdFx0XHRcdG5hbWUsXHJcblx0XHRcdFx0XHRvYmpOYW1lLFxyXG5cdFx0XHRcdFx0cGxjLFxyXG5cdFx0XHRcdFx0YWN0aW9ucyxcclxuXHRcdFx0XHRcdGFkZHJlc3MsXHJcblx0XHRcdFx0XHR2YWx1ZSxcclxuXHRcdFx0XHRcdGxlbmd0aCxcclxuXHRcdFx0XHRcdHVzZXJuYW1lLFxyXG5cdFx0XHRcdFx0Ly9jcmVhdGVBdFx0XHJcblx0XHRcdFx0fSk7XHRcdFx0XHJcblx0XHRcdGJyZWFrO1xyXG5cdFx0XHRjYXNlIDQ6Ly9Eb3VibGUgaW50ZWdlciBmb3IgTG9nb1xyXG5cdFx0XHRcdHZhciBoaWdoPSBwYXJzZUludCh2YWx1ZSkmIDB4RkZGRjtcclxuXHRcdFx0XHR2YXIgbG93PSBwYXJzZUludCh2YWx1ZSkgPj4gMTY7XHJcblx0XHRcdFx0dmFsdWUgPSBsb3c7XHJcblx0XHRcdFx0dmFsdWUgPSBwYXJzZUludCh2YWx1ZSk7XHJcblx0XHRcdFx0Q01ESW50ZXJmYWNlcy5pbnNlcnQoe1xyXG5cdFx0XHRcdFx0bmFtZSxcclxuXHRcdFx0XHRcdG9iak5hbWUsXHJcblx0XHRcdFx0XHRwbGMsXHJcblx0XHRcdFx0XHRhY3Rpb25zLFxyXG5cdFx0XHRcdFx0YWRkcmVzcyxcclxuXHRcdFx0XHRcdHZhbHVlLFxyXG5cdFx0XHRcdFx0bGVuZ3RoLFxyXG5cdFx0XHRcdFx0dXNlcm5hbWUsXHJcblx0XHRcdFx0XHQvL2NyZWF0ZUF0XHRcclxuXHRcdFx0XHR9KTtcdFx0XHJcblx0XHRcdFx0Ly9jb25zb2xlLmxvZyhcImRhdGFCbG9jayBsb3c6IFwiICsgbG93ICsgXCIgdmFsdWUgbG93OiBcIiArIHZhbHVlKTtcdFxyXG5cdFx0XHRcdHZhbHVlID0gaGlnaDtcclxuXHRcdFx0XHR2YWx1ZSA9IHBhcnNlSW50KHZhbHVlKTtcclxuXHRcdFx0XHRhZGRyZXNzID0gYWRkcmVzcyArIDE7XHJcblx0XHRcdFx0Q01ESW50ZXJmYWNlcy5pbnNlcnQoe1xyXG5cdFx0XHRcdFx0bmFtZSxcclxuXHRcdFx0XHRcdG9iak5hbWUsXHJcblx0XHRcdFx0XHRwbGMsXHJcblx0XHRcdFx0XHRhY3Rpb25zLFxyXG5cdFx0XHRcdFx0YWRkcmVzcyxcclxuXHRcdFx0XHRcdHZhbHVlLFxyXG5cdFx0XHRcdFx0bGVuZ3RoLFxyXG5cdFx0XHRcdFx0dXNlcm5hbWUsXHJcblx0XHRcdFx0XHQvL2NyZWF0ZUF0XHRcclxuXHRcdFx0XHR9KTtcdFx0XHRcclxuXHRcdFx0YnJlYWs7XHRcdFx0XHJcblx0XHRcdGNhc2UgMzovL1JlYWxcclxuXHRcdFx0XHR2YXIgZjMyID0gbmV3IEZsb2F0MzJBcnJheSgxKTtcclxuXHRcdFx0XHRmMzJbMF0gPSB2YWx1ZTtcclxuXHRcdFx0XHR2YXIgdWkxNiA9IG5ldyBVaW50MTZBcnJheShmMzIuYnVmZmVyKTtcclxuXHRcdFx0XHR2YWx1ZSA9ICB1aTE2WzBdO1xyXG5cdFx0XHRcdHZhbHVlID0gcGFyc2VJbnQodmFsdWUpO1xyXG5cdFx0XHRcdENNREludGVyZmFjZXMuaW5zZXJ0KHtcclxuXHRcdFx0XHRcdG5hbWUsXHJcblx0XHRcdFx0XHRvYmpOYW1lLFxyXG5cdFx0XHRcdFx0cGxjLFxyXG5cdFx0XHRcdFx0YWN0aW9ucyxcclxuXHRcdFx0XHRcdGFkZHJlc3MsXHJcblx0XHRcdFx0XHR2YWx1ZSxcclxuXHRcdFx0XHRcdGxlbmd0aCxcclxuXHRcdFx0XHRcdHVzZXJuYW1lLFxyXG5cdFx0XHRcdFx0Ly9jcmVhdGVBdFx0XHJcblx0XHRcdFx0fSk7XHRcdFxyXG5cdFx0XHRcdHZhbHVlID0gIHVpMTZbMV07XHJcblx0XHRcdFx0dmFsdWUgPSBwYXJzZUludCh2YWx1ZSk7XHJcblx0XHRcdFx0YWRkcmVzcyA9IGFkZHJlc3MgKyAxO1xyXG5cdFx0XHRcdENNREludGVyZmFjZXMuaW5zZXJ0KHtcclxuXHRcdFx0XHRcdG5hbWUsXHJcblx0XHRcdFx0XHRvYmpOYW1lLFxyXG5cdFx0XHRcdFx0cGxjLFxyXG5cdFx0XHRcdFx0YWN0aW9ucyxcclxuXHRcdFx0XHRcdGFkZHJlc3MsXHJcblx0XHRcdFx0XHR2YWx1ZSxcclxuXHRcdFx0XHRcdGxlbmd0aCxcclxuXHRcdFx0XHRcdHVzZXJuYW1lLFxyXG5cdFx0XHRcdFx0Ly9jcmVhdGVBdFx0XHJcblx0XHRcdFx0fSk7XHRcdFx0XHRcclxuXHRcdFx0YnJlYWs7XHJcblx0XHRcdGRlZmF1bHQ6IGJyZWFrO1xyXG5cdFx0fVxyXG5cdH0sXHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHRcclxuXHQnY21kaW50ZXJmYWNlcy5nZXRkYXRhaGlzdG9yaWFuJyhzdGFydFRpbWVQYXJhbSkgXHJcblx0e1xyXG5cdFx0dmFyIGRhdGFCbG9jayA9IFtdO1xyXG5cdFx0dmFyIGluZGV4ID0gMDtcclxuXHJcblx0XHRDTURJbnRlcmZhY2VzLmZpbmQoe2NyZWF0ZWRBdDp7JGd0ZTogc3RhcnRUaW1lUGFyYW19fSx7IHNvcnQ6IHsgY3JlYXRlZEF0OiAtMSB9fSkuZm9yRWFjaChmdW5jdGlvbihkb2MpIHtcclxuXHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdF9pZDogZG9jLl9pZCxcclxuXHRcdFx0XHRpbmRleDppbmRleCxcclxuXHRcdFx0XHRvYmo6IGRvYy5vYmpOYW1lLFxyXG5cdFx0XHRcdGNyZWF0ZWRBdDogbmV3IERhdGUoZG9jLmNyZWF0ZWRBdCkudG9Mb2NhbGVTdHJpbmcoKSxcclxuXHRcdFx0XHRjb21tYW5kOiBkb2MubmFtZSxcclxuXHRcdFx0XHR2YWx1ZTpkb2MudmFsdWUsXHJcblx0XHRcdFx0dXNlcm5hbWU6IGRvYy51c2VybmFtZVxyXG5cdFx0XHR9KTtcdFx0XHRcclxuXHRcdFx0aW5kZXg9aW5kZXgrMTtcclxuXHRcdH0pO1xyXG5cdFx0cmV0dXJuIGRhdGFCbG9jaztcclxuXHR9LFxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFx0XHJcblx0J2NtZGludGVyZmFjZXMuZ2V0ZGF0YWhpc3RvcmlhbkZyb20nKHN0YXJ0VGltZVBhcmFtLGVuZFRpbWVQYXJhbSkgXHJcblx0e1xyXG5cdFx0dmFyIGRhdGFCbG9jayA9IFtdO1xyXG5cdFx0dmFyIGluZGV4ID0gMDtcclxuXHJcblx0XHRDTURJbnRlcmZhY2VzLmZpbmQoe2NyZWF0ZWRBdDp7JGd0ZTogc3RhcnRUaW1lUGFyYW0sJGx0ZTplbmRUaW1lUGFyYW19fSx7IHNvcnQ6IHsgY3JlYXRlZEF0OiAtMSB9fSkuZm9yRWFjaChmdW5jdGlvbihkb2MpIHtcdFxyXG5cdFx0XHRkYXRhQmxvY2sucHVzaCh7XHJcblx0XHRcdFx0X2lkOiBkb2MuX2lkLFxyXG5cdFx0XHRcdGluZGV4OmluZGV4LFxyXG5cdFx0XHRcdG9iajogZG9jLm9iak5hbWUsXHJcblx0XHRcdFx0Y3JlYXRlZEF0OiBuZXcgRGF0ZShkb2MuY3JlYXRlZEF0KS50b0xvY2FsZVN0cmluZygpLFxyXG5cdFx0XHRcdGNvbW1hbmQ6IGRvYy5uYW1lLFxyXG5cdFx0XHRcdHZhbHVlOmRvYy52YWx1ZSxcclxuXHRcdFx0XHR1c2VybmFtZTogZG9jLnVzZXJuYW1lXHJcblx0XHRcdH0pO1x0XHRcdFxyXG5cdFx0XHRpbmRleD1pbmRleCsxO1xyXG5cdFx0fSk7XHJcblx0XHRyZXR1cm4gZGF0YUJsb2NrO1xyXG5cdH1cdFx0XHJcbn0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IFNlY3VyaXR5IGZyb20gJy4vc2VjdXJpdHknOyBcclxuXHJcbmV4cG9ydCBjb25zdCBNYXRlcmlhbCA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdtYXRlcmlhbCcpO1xyXG5cclxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG5cdE1ldGVvci5tZXRob2RzKHtcdFxyXG5cdFx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0XHRhc3luYyAnbWF0ZXJpYWwuZ2V0ZGF0YWJsb2NrJygpIFxyXG5cdFx0e1xyXG5cdFx0XHR2YXIgZGF0YUJsb2NrID0gW107XHJcblx0XHRcdGF3YWl0ICBNYXRlcmlhbC5maW5kKHt9LCB7c29ydDoge3N0YXJ0VGltZTogMX19KS5mb3JFYWNoKGZ1bmN0aW9uKGRvYykge1xyXG5cdFx0XHRcdGRhdGFCbG9jay5wdXNoKHtcclxuXHRcdFx0XHRcdF9pZDogZG9jLl9pZCxcdFxyXG5cdFx0XHRcdFx0c3RhcnRUaW1lZHNjOiBuZXcgRGF0ZShkb2Muc3RhcnRUaW1lKS50b0xvY2FsZURhdGVTdHJpbmcoeyB0aW1lWm9uZTogJ0FzaWEvSG9fQ2hpX01pbmgnIH0pLFxyXG5cdFx0XHRcdFx0ZW5kVGltZWRzYzogbmV3IERhdGUoZG9jLmVuZFRpbWUpLnRvTG9jYWxlRGF0ZVN0cmluZyh7IHRpbWVab25lOiAnQXNpYS9Ib19DaGlfTWluaCcgfSksXHJcblx0XHRcdFx0XHRzdGFydFRpbWU6IGRvYy5zdGFydFRpbWUsXHJcblx0XHRcdFx0XHRlbmRUaW1lOiBkb2MuZW5kVGltZSwgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIG1hdGVyaWFsOiBkb2MubWF0ZXJpYWxcclxuXHRcdFx0XHR9KTtcdFx0XHRcclxuXHRcdFx0XHRcclxuXHRcdFx0fSk7XHJcblx0XHRcdFxyXG5cdFx0XHRyZXR1cm4gZGF0YUJsb2NrO1xyXG5cdFx0fSxcdFxyXG5cdFx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cdFx0YXN5bmMgJ21hdGVyaWFsLmdldE1hdGVyaWFsJyhkYXRlU3RyKSB7XHJcblx0XHRcdHZhciBkYXRhQmxvY2sgXHQ9IFtdO1xyXG4gICAgICAgICAgICBjb25zdCBkYXRlID0gbmV3IERhdGUoZGF0ZVN0cik7XHJcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coZGF0ZSk7IC8vIPCfkYnvuI8gV2VkIEp1biAyMiAyMDIyXHJcblxyXG4gICAgICAgICAgICBjb25zdCB0aW1lc3RhbXBJbk1zID0gZGF0ZS5nZXRUaW1lKCk7XHJcbiAgICAgICAgICAgIFxyXG5cdFx0XHRjb25zdCByZXN1bHQgPSBhd2FpdCBNYXRlcmlhbC5yYXdDb2xsZWN0aW9uKCkuYWdncmVnYXRlKFtcclxuXHRcdFx0XHR7JG1hdGNoOiB7XHJcblx0XHRcdFx0ICAgJGV4cHI6IHtcclxuXHRcdFx0XHRcdCAgJGFuZDogW1xyXG5cdFx0XHRcdFx0XHQgeyAkbHRlOiBbIFwiJHN0YXJ0VGltZVwiLHRpbWVzdGFtcEluTXMgXSB9LFxyXG5cdFx0XHRcdFx0XHQgeyAkZ3RlOiBbIFwiJGVuZFRpbWVcIiwgdGltZXN0YW1wSW5NcyBdIH0sXHJcblx0XHRcdFx0XHQgIF1cclxuXHRcdFx0XHQgICB9XHJcblx0XHRcdFx0fX1cdFx0XHRcclxuXHRcdFx0XSkuZm9yRWFjaChmdW5jdGlvbihkb2MpIHtcclxuXHRcdFx0XHQvL2NvbnNvbGUubG9nKFwiZ2V0TWF0ZXJpYWwgXCIgKyBkb2Muc3RhcnRUaW1lICsgXCIsIGVuZFRpbWVQYXJhbSBcIiArIGRvYy5lbmRUaW1lKTtcclxuXHRcdFx0XHRkYXRhQmxvY2sucHVzaChkb2MpO1x0XHRcdFx0XHRcclxuXHRcdFx0fSlcclxuXHRcdFx0cmV0dXJuIGRhdGFCbG9jaztcdFx0XHRcclxuXHRcdH0sXHRcdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHRcdGFzeW5jICdtYXRlcmlhbC5nZXRNYXRlcmlhbFRpbWVzJyh0aW1lc3RhbXBJbk1zKSB7XHJcbiAgICAgICAgICAgIHZhciBkYXRhQmxvY2sgXHQ9IFtdO1xyXG5cdFx0XHRjb25zdCByZXN1bHQgPSBhd2FpdCBNYXRlcmlhbC5yYXdDb2xsZWN0aW9uKCkuYWdncmVnYXRlKFtcclxuXHRcdFx0XHR7JG1hdGNoOiB7XHJcblx0XHRcdFx0ICAgJGV4cHI6IHtcclxuXHRcdFx0XHRcdCAgJGFuZDogW1xyXG5cdFx0XHRcdFx0XHQgeyAkbHRlOiBbIFwiJHN0YXJ0VGltZVwiLHRpbWVzdGFtcEluTXMgXSB9LFxyXG5cdFx0XHRcdFx0XHQgeyAkZ3RlOiBbIFwiJGVuZFRpbWVcIiwgdGltZXN0YW1wSW5NcyBdIH0sXHJcblx0XHRcdFx0XHQgIF1cclxuXHRcdFx0XHQgICB9XHJcblx0XHRcdFx0fX1cdFx0XHRcclxuXHRcdFx0XSkuZm9yRWFjaChmdW5jdGlvbihkb2MpIHtcclxuXHRcdFx0XHQvL2NvbnNvbGUubG9nKFwiZ2V0TWF0ZXJpYWwgXCIgKyBkb2Muc3RhcnRUaW1lICsgXCIsIGVuZFRpbWVQYXJhbSBcIiArIGRvYy5lbmRUaW1lKTtcclxuXHRcdFx0XHRkYXRhQmxvY2sucHVzaChkb2MpO1x0XHRcdFx0XHRcclxuXHRcdFx0fSlcclxuXHRcdFx0cmV0dXJuIGRhdGFCbG9jaztcdFx0XHRcclxuXHRcdH0sXHJcblx0XHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHRcdGFzeW5jICdtYXRlcmlhbC5pbnNlcnQnKFx0XHRcclxuXHRcdFx0c3RhcnRUaW1lLFxyXG5cdFx0XHRlbmRUaW1lLFxyXG4gICAgICAgICAgICBtYXRlcmlhbCxcclxuXHRcdFx0KSBcclxuXHRcdHtcclxuXHRcdFx0aWYgKCFTZWN1cml0eS5jaGVja1JvbGUodGhpcy51c2VySWQsJ093bmVyJykpXHJcblx0XHRcdHtcclxuXHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibG9nZ2VkLWluXCIsXCJZb3UgYXJlIG5vdCBwZXJtaXR0ZWQuXCIpO1xyXG5cdFx0XHR9XHJcblx0XHRcdGVsc2VcclxuXHRcdFx0e1xyXG5cdFx0XHRcdGNvbnN0IHJlc3VsdE1hdGVyaWFscyA9IGF3YWl0IE1ldGVvci5jYWxsKCdtYXRlcmlhbC5nZXRNYXRlcmlhbCcsIHN0YXJ0VGltZSk7XHJcblx0XHRcdFx0Y29uc3QgcmVzdWx0TWF0ZXJpYWxlID0gYXdhaXQgTWV0ZW9yLmNhbGwoJ21hdGVyaWFsLmdldE1hdGVyaWFsJywgZW5kVGltZSk7XHJcblx0XHRcdFx0aWYgKChyZXN1bHRNYXRlcmlhbHMgIT0gXCJcIikgfHwgKHJlc3VsdE1hdGVyaWFsZSAhPSBcIlwiKSlcclxuXHRcdFx0XHR7XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIlRyw7luZyB0aOG7nWkgZ2lhbiwgaMOjeSBraeG7g20gdHJhIGzhuqFpXCIpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRlbHNlIFxyXG5cdFx0XHRcdHtcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRhd2FpdCBNYXRlcmlhbC5pbnNlcnQoe1xyXG5cdFx0XHRcdFx0XHRzdGFydFRpbWUsXHJcblx0XHRcdFx0XHRcdGVuZFRpbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1hdGVyaWFsXHJcblx0XHRcdFx0XHR9KTtcclxuXHRcdFx0XHRcdFxyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0XHRyZXR1cm4gMDtcclxuXHRcdH0sXHRcdFxyXG5cdH0pXHJcbn1cclxuLy89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFx0XHJcblx0J21hdGVyaWFsLmZpbmRTaXRlJyhuYW1lKSBcclxuXHR7XHRcdFxyXG5cdFx0dmFyIG5hbWVTaXRlID0gTWF0ZXJpYWwuZmluZE9uZSh7IG5hbWU6bmFtZX0pO1x0XHRcclxuXHRcdGlmIChuYW1lU2l0ZT09bnVsbCkge1xyXG5cdFx0XHRyZXR1cm4gMDtcclxuXHRcdH1cclxuXHRcdGVsc2VcclxuXHRcdHtcclxuXHRcdFx0cmV0dXJuIDE7XHJcblx0XHR9XHRcdFx0XHJcblx0fSxcclxuXHRcclxuXHRcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQnbWF0ZXJpYWwucmVtb3ZlJyh0YXNrSWQpIFxyXG5cdHtcclxuXHRcdGlmICghU2VjdXJpdHkuY2hlY2tSb2xlKHRoaXMudXNlcklkLCdPd25lcicpKVxyXG5cdFx0e1xyXG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibG9nZ2VkLWluXCIsXCJZb3UgYXJlIG5vdCBwZXJtaXR0ZWQuXCIpO1xyXG5cdFx0fVxyXG5cdFx0ZWxzZVxyXG5cdFx0e1xyXG5cdFx0XHRNYXRlcmlhbC5yZW1vdmUodGFza0lkKTtcclxuXHRcdH1cclxuXHR9LFxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFxyXG5cdCdtYXRlcmlhbC51cGRhdGUnKFxyXG5cdFx0X2lkLFxyXG4gICAgICAgIG1hdGVyaWFsLFxyXG5cdCkgXHJcblx0e1xyXG5cdFx0aWYgKCFTZWN1cml0eS5jaGVja1JvbGUodGhpcy51c2VySWQsJ093bmVyJykpXHJcblx0XHR7XHJcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJsb2dnZWQtaW5cIixcIllvdSBhcmUgbm90IHBlcm1pdHRlZC5cIik7XHJcblx0XHR9XHJcblx0XHRlbHNlXHJcblx0XHR7XHJcblx0XHRcdE1hdGVyaWFsLnVwZGF0ZShfaWQsIFxyXG5cdFx0XHRcdHsgJHNldDogeyBcclxuICAgICAgICAgICAgICAgICAgICBtYXRlcmlhbFxyXG5cdFx0XHRcdFx0fSBcclxuXHRcdFx0XHR9KTtcclxuXHRcdH1cclxuXHR9LFxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFxyXG5cdCdtYXRlcmlhbC51cGRhdGVUaW1lJyhcclxuXHRcdF9pZCxcclxuICAgICAgICBzdGFydFRpbWUsXHJcbiAgICAgICAgZW5kVGltZVxyXG5cdCkgXHJcblx0e1xyXG5cdFx0aWYgKCFTZWN1cml0eS5jaGVja1JvbGUodGhpcy51c2VySWQsJ093bmVyJykpXHJcblx0XHR7XHJcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJsb2dnZWQtaW5cIixcIllvdSBhcmUgbm90IHBlcm1pdHRlZC5cIik7XHJcblx0XHR9XHJcblx0XHRlbHNlXHJcblx0XHR7XHJcblx0XHRcdE1hdGVyaWFsLnVwZGF0ZShfaWQsIFxyXG5cdFx0XHRcdHsgJHNldDogeyBcclxuICAgICAgICAgICAgICAgICAgICBzdGFydFRpbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgZW5kVGltZSxcclxuXHRcdFx0XHRcdH0gXHJcblx0XHRcdFx0fSk7XHJcblx0XHR9XHJcblx0fSxcclxuXHRcdFxyXG59KSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCBTZWN1cml0eSBmcm9tICcuL3NlY3VyaXR5JzsgXHJcbmltcG9ydCBQTENJbnRlcmZhY2VzIGZyb20gJy4vcGxjaW50ZXJmYWNlcy5qcyc7XHJcblxyXG5leHBvcnQgY29uc3QgTW9kYnVzSW50ZXJmYWNlcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdtb2RidXNpbnRlcmZhY2VzJyk7XHJcblxyXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XHJcblx0TWV0ZW9yLm1ldGhvZHMoe1xyXG5cdFx0YXN5bmMgJ21vZGJ1c2ludGVyZmFjZXMuZ2V0ZGF0YWJsb2NrYXN5bmMnKCkge1xyXG5cdFx0XHR2YXIgZGF0YUJsb2NrID0gW107XHJcblx0XHRcdHJldHVybiBhd2FpdCBNb2RidXNJbnRlcmZhY2VzLnJhd0NvbGxlY3Rpb24oKS5hZ2dyZWdhdGUoW1xyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdCRsb29rdXA6XHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdGZyb206IFwicGxjaW50ZXJmYWNlc1wiLFxyXG5cdFx0XHRcdFx0XHRsb2NhbEZpZWxkOiBcInNlbGVjdFBMQ1wiLFxyXG5cdFx0XHRcdFx0XHRmb3JlaWduRmllbGQ6IFwiX2lkXCIsXHJcblx0XHRcdFx0XHRcdGFzOiBcInBsY1wiXHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fSxcclxuXHRcdFx0XHR7ICR1bndpbmQ6IFwiJHBsY1wiIH0sXHJcblx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0JGxvb2t1cDpcclxuXHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0ZnJvbTogXCJzaXRlaW50ZXJmYWNlc1wiLFxyXG5cdFx0XHRcdFx0XHRsb2NhbEZpZWxkOiBcInBsYy5zaXRlXCIsXHJcblx0XHRcdFx0XHRcdGZvcmVpZ25GaWVsZDogXCJfaWRcIixcclxuXHRcdFx0XHRcdFx0YXM6IFwic2l0ZVwiXHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fSxcdFxyXG5cdFx0XHRcdHsgJHVud2luZDogXCIkc2l0ZVwiIH0sXHJcblx0XHRcdFx0eyRwcm9qZWN0OiB7XHJcblx0XHRcdFx0XHRcIl9pZFwiOiBcIiRfaWRcIixcclxuXHRcdFx0XHRcdFwibnNpdGVcIjogXCIkc2l0ZS5uYW1lXCIsXHJcblx0XHRcdFx0XHRcImlkU2l0ZVwiOiBcIiRzaXRlLl9pZFwiLFxyXG5cdFx0XHRcdFx0XCJpZFBMQ1wiOiBcIiRwbGMuX2lkXCIsXHJcblx0XHRcdFx0XHRcInNlbGVjdFBMQ1wiOiBcIiRwbGMubmFtZVwiLFxyXG5cdFx0XHRcdFx0XCJkYXRhYmxvY2tcIjogXCIkZGF0YWJsb2NrXCIsXHJcblx0XHRcdFx0XHRcInN0YXJ0YWRkcmVzc1wiOiBcIiRzdGFydGFkZHJlc3NcIixcclxuXHRcdFx0XHRcdFwicXVhbnRpdHlcIjogXCIkcXVhbnRpdHlcIixcclxuXHRcdFx0XHRcdFwibnVtVGFnXCI6IFwiJG51bVRhZ1wiXHJcblx0XHRcdFx0ICAgfVxyXG5cdFx0XHRcdH1cdFx0XHRcdFxyXG5cdFx0XHRdKS50b0FycmF5KCk7XHRcdFx0XHJcblx0XHR9XHJcblx0fSlcdFx0XHJcbn1cclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQnbW9kYnVzaW50ZXJmYWNlcy5nZXRkYXRhYmxvY2snKCkgXHJcblx0e1xyXG5cdFx0dmFyIGRhdGFCbG9jayA9IFtdO1xyXG5cdFx0TW9kYnVzSW50ZXJmYWNlcy5maW5kKHt9LCB7c29ydDoge2NyZWF0ZURhdGU6IC0xfX0pLmZvckVhY2goZnVuY3Rpb24oZG9jKSB7XHJcblx0XHRcdHZhciBwbGMgPSBNZXRlb3IuY2FsbCgncGxjaW50ZXJmYWNlcy5maW5kcGxjJyxkb2Muc2VsZWN0UExDKTtcclxuXHRcdFx0dmFyIG5zaXRlID0gTWV0ZW9yLmNhbGwoJ3NpdGVpbnRlcmZhY2VzLmdldG5hbWUnLHBsYy5zaXRlKTtcclxuXHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdF9pZDogZG9jLl9pZCxcclxuXHRcdFx0XHRuc2l0ZTogbnNpdGUsXHJcblx0XHRcdFx0aWRTaXRlOiBwbGMuc2l0ZSxcclxuXHRcdFx0XHRzZWxlY3RQTEM6IHBsYy5uYW1lLFxyXG5cdFx0XHRcdGlkUExDOiBkb2Muc2VsZWN0UExDLFxyXG5cdFx0XHRcdGRhdGFibG9jazogZG9jLmRhdGFibG9jayxcclxuXHRcdFx0XHRzdGFydGFkZHJlc3M6IGRvYy5zdGFydGFkZHJlc3MsXHJcblx0XHRcdFx0cXVhbnRpdHk6IGRvYy5xdWFudGl0eVxyXG5cdFx0XHR9KTtcdFxyXG5cdFx0fSk7XHRcdFxyXG5cdFx0cmV0dXJuIGRhdGFCbG9jaztcclxuXHR9LFxyXG5cdFxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFxyXG5cdCdtb2RidXNpbnRlcmZhY2VzLmdldERhdGFibG9ja051bWJlcicoaWRfcGxjLGFkZHJlc3NWYXIsdHlwZURhdGEpIFxyXG5cdHtcclxuXHRcdHZhciBhZGRyZXNzID0gMDtcclxuXHRcdHZhciBzZXRCbG9ja051bWJlciA9IDA7XHJcblx0XHRNb2RidXNJbnRlcmZhY2VzLmZpbmQoeyBzZWxlY3RQTEM6aWRfcGxjfSkuZm9yRWFjaChmdW5jdGlvbihkb2MpIHtcclxuXHRcdFx0aWYgKHR5cGVEYXRhPT1cIkJvb2xcIilcclxuXHRcdFx0e1xyXG5cdFx0XHRcdHZhciB3b3JkcyA9IDA7XHJcblx0XHRcdFx0d29yZHMgPSBhZGRyZXNzVmFyLnNwbGl0KFwiLlwiKTtcclxuXHRcdFx0XHRhZGRyZXNzID0gcGFyc2VJbnQod29yZHNbMF0pO1x0XHRcdFx0XHJcblx0XHRcdH1cclxuXHRcdFx0ZWxzZVxyXG5cdFx0XHR7XHJcblx0XHRcdFx0YWRkcmVzcyA9IHBhcnNlSW50KGFkZHJlc3NWYXIpO1xyXG5cdFx0XHR9XHJcblx0XHRcdHZhciBsYXN0UmVhZCA9IHBhcnNlSW50KGRvYy5zdGFydGFkZHJlc3MpICsgcGFyc2VJbnQoZG9jLnF1YW50aXR5KTtcclxuXHRcdFx0aWYgKChhZGRyZXNzID49IHBhcnNlSW50KGRvYy5zdGFydGFkZHJlc3MpKSYmIChhZGRyZXNzPD1sYXN0UmVhZCkpXHJcblx0XHRcdHtcclxuXHRcdFx0XHRzZXRCbG9ja051bWJlciA9IGRvYy5kYXRhYmxvY2s7XHJcblx0XHRcdH1cclxuXHRcdFxyXG5cdFx0fSk7XHRcdFxyXG5cdFx0aWYgKHNldEJsb2NrTnVtYmVyPT0wKVxyXG5cdFx0e1xyXG5cdFx0XHRyZXR1cm4gbnVsbDtcclxuXHRcdH1cclxuXHRcdHJldHVybiBzZXRCbG9ja051bWJlcjtcclxuXHR9LFxyXG5cdFxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFxyXG5cdCdtb2RidXNpbnRlcmZhY2VzLmluc2VydCcoXHRcdFxyXG5cdFx0c2VsZWN0UExDLFxyXG5cdFx0ZGF0YWJsb2NrMSxcclxuXHRcdHN0YXJ0YWRkcmVzcyxcclxuXHRcdHF1YW50aXR5LFxyXG5cdFx0ZGF0YWNoYW5nZSxcclxuXHRcdGNyZWF0ZURhdGVcclxuXHRcdCkgXHJcblx0e1xyXG5cdFx0dmFyIGRhdGFibG9jayA9IDE7XHJcblx0XHRpZiAoIVNlY3VyaXR5LmNoZWNrUm9sZSh0aGlzLnVzZXJJZCwnT3duZXInKSlcclxuXHRcdHtcclxuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcihcImxvZ2dlZC1pblwiLFwiWW91IGFyZSBub3QgcGVybWl0dGVkLlwiKTtcclxuXHRcdH1cclxuXHRcdGVsc2VcclxuXHRcdHtcclxuXHRcdFx0XHJcblx0XHRcdHZhciBkYXRhID0gTW9kYnVzSW50ZXJmYWNlcy5maW5kT25lKHsgc2VsZWN0UExDOnNlbGVjdFBMQ30se3NvcnQ6eyBkYXRhYmxvY2sgOiAtMSB9LCBsaW1pdDoxfSk7XHJcblx0XHRcdGlmIChkYXRhID09IG51bGwpXHJcblx0XHRcdHtcclxuXHRcdFx0XHQvL1xyXG5cdFx0XHR9XHJcblx0XHRcdGVsc2VcclxuXHRcdFx0e1xyXG5cdFx0XHRcdFx0XHJcblx0XHRcdFx0ZGF0YWJsb2NrICA9IHBhcnNlSW50KGRhdGEuZGF0YWJsb2NrKSAgKyAyO1xyXG5cdFx0XHRcdC8vY29uc29sZS5sb2coXCJkYXRhQmxvY2s6IFwiICsgZGF0YS5kYXRhYmxvY2sgKyBcIiwgXCIgKyBkYXRhYmxvY2spO1xyXG5cdFx0XHR9XHRcdFx0XHJcblx0XHRcdE1vZGJ1c0ludGVyZmFjZXMuaW5zZXJ0KHtcclxuXHRcdFx0XHRzZWxlY3RQTEMsXHJcblx0XHRcdFx0ZGF0YWJsb2NrLFxyXG5cdFx0XHRcdHN0YXJ0YWRkcmVzcyxcclxuXHRcdFx0XHRxdWFudGl0eSxcclxuXHRcdFx0XHRkYXRhY2hhbmdlLFxyXG5cdFx0XHRcdGNyZWF0ZURhdGVcclxuXHRcdFx0fSk7XHJcblx0XHR9XHJcblx0XHRyZXR1cm4gMDtcclxuXHR9LFxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFxyXG5cdCdtb2RidXNpbnRlcmZhY2VzLnJlbW92ZScodGFza0lkKSB7XHJcblx0XHRpZiAoIVNlY3VyaXR5LmNoZWNrUm9sZSh0aGlzLnVzZXJJZCwnT3duZXInKSlcclxuXHRcdHtcclxuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcihcImxvZ2dlZC1pblwiLFwiWW91IGFyZSBub3QgcGVybWl0dGVkLlwiKTtcclxuXHRcdH1cclxuXHRcdGVsc2VcclxuXHRcdHtcclxuXHRcdFx0TW9kYnVzSW50ZXJmYWNlcy5yZW1vdmUodGFza0lkKTtcclxuXHRcdH1cclxuXHR9LFxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFxyXG5cdCdtb2RidXNpbnRlcmZhY2VzLnVwZGF0ZScoXHJcblx0XHRfaWQsXHJcblx0XHRzdGFydGFkZHJlc3MsXHJcblx0XHRxdWFudGl0eSxcclxuXHRcdGRhdGFjaGFuZ2UsXHJcblx0XHRjcmVhdGVEYXRlXHJcblx0KSBcclxuXHR7XHJcblx0XHRpZiAoIVNlY3VyaXR5LmNoZWNrUm9sZSh0aGlzLnVzZXJJZCwnT3duZXInKSlcclxuXHRcdHtcclxuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcihcImxvZ2dlZC1pblwiLFwiWW91IGFyZSBub3QgcGVybWl0dGVkLlwiKTtcclxuXHRcdH1cclxuXHRcdGVsc2VcclxuXHRcdHtcclxuXHRcdFx0TW9kYnVzSW50ZXJmYWNlcy51cGRhdGUoX2lkLCBcclxuXHRcdFx0XHR7ICRzZXQ6IHsgXHJcblx0XHRcdFx0XHRzdGFydGFkZHJlc3MsXHJcblx0XHRcdFx0XHRxdWFudGl0eSxcclxuXHRcdFx0XHRcdGRhdGFjaGFuZ2UsXHJcblx0XHRcdFx0XHRjcmVhdGVEYXRlXHJcblx0XHRcdFx0XHR9IFxyXG5cdFx0XHRcdH0pO1xyXG5cdFx0fVxyXG5cdH1cdFx0XHJcbn0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IFRhZ3NJbnRlcmZhY2UgZnJvbSAnLi90YWdpbnRlcmZhY2VzLmpzJzsgIFxyXG5pbXBvcnQgeyBTY3JlZW5JbnRlcmZhY2VzIH0gZnJvbSAnLi9zY3JlZW5pbnRlcmZhY2VzLmpzJztcclxuaW1wb3J0IFNlY3VyaXR5IGZyb20gJy4vc2VjdXJpdHknO1xyXG5cclxuZXhwb3J0IGNvbnN0IE9iamVjdHNJbnRlcmZhY2VzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ29iamVjdHNpbnRlcmZhY2VzJyk7XHJcblxyXG5cclxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG4gIFx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1QTEFOVFxyXG5cdE1ldGVvci5wdWJsaXNoKCdnZXRPYmplY3RzU3RhdGljJywgZnVuY3Rpb24gZ2V0T2JqZWN0c1N0YXRpYyhhcmd1bWVudHNGaW5kKSB7XHJcblx0XHRjb25zb2xlLmxvZyhcImdldE9iamVjdHNTdGF0aWMgXCIpO1xyXG5cdFx0cmV0dXJuIE9iamVjdHNJbnRlcmZhY2VzLmZpbmQoYXJndW1lbnRzRmluZCk7XHJcblx0fSk7XHRcclxuXHRcclxuXHRNZXRlb3IubWV0aG9kcyh7XHJcblx0XHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHRcdGFzeW5jICdvYmplY3RzaW50ZXJmYWNlcy5pbnNlcnRhc3luYycoXHRcdFx0XHJcblx0XHRcdG9iak5hbWUsXHJcblx0XHRcdGFzc2lnbm1lbnRUYWcsXHJcblx0XHRcdHNjcmVlbixcclxuXHRcdFx0eFBvc2l0b24sXHJcblx0XHRcdHlQb3NpdG9uLFx0XHJcblx0XHRcdHhTY2FsZSxcdFx0XHJcblx0XHRcdHlTY2FsZSxcdFx0XHJcblx0XHRcdGNyZWF0ZURhdGVcclxuXHRcdFx0KSBcclxuXHRcdHtcclxuXHJcblx0XHRcdGlmICghU2VjdXJpdHkuY2hlY2tSb2xlKHRoaXMudXNlcklkLCdPd25lcicpKVxyXG5cdFx0XHR7XHJcblx0XHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcihcImxvZ2dlZC1pblwiLFwiWW91IGFyZSBub3QgcGVybWl0dGVkLlwiKTtcclxuXHRcdFx0fVxyXG5cdFx0XHRlbHNlXHJcblx0XHRcdHtcclxuXHRcdFx0XHRpZiAoYXdhaXQgT2JqZWN0c0ludGVyZmFjZXMuZmluZE9uZSh7ICRhbmQ6IFsgeyBzY3JlZW46IHsgJGVxOiBzY3JlZW4gfSB9LCB7IG9iak5hbWU6IHsgJGVxOiBvYmpOYW1lIH19XX0pICE9bnVsbClcclxuXHRcdFx0XHR7XHJcblx0XHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiRHVwbGljYXRlIHRhZywgUGxlYXNlIGNoZWNrIG5hbWUgb2YgVGFnIGFnYWluXCIpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRlbHNlIFxyXG5cdFx0XHRcdHtcdFx0XHRcdFxyXG5cdFx0XHRcdFx0YXdhaXQgT2JqZWN0c0ludGVyZmFjZXMuaW5zZXJ0KHtcclxuXHRcdFx0XHRcdG9iak5hbWUsXHJcblx0XHRcdFx0XHRhc3NpZ25tZW50VGFnLFxyXG5cdFx0XHRcdFx0c2NyZWVuLFxyXG5cdFx0XHRcdFx0eFBvc2l0b24sXHJcblx0XHRcdFx0XHR5UG9zaXRvbixcdFxyXG5cdFx0XHRcdFx0eFNjYWxlLFx0XHRcclxuXHRcdFx0XHRcdHlTY2FsZSxcdFx0XHJcblx0XHRcdFx0XHRjcmVhdGVEYXRlXHJcblx0XHRcdFx0XHR9KTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0cmV0dXJuIDA7XHJcblx0XHRcdH1cclxuXHRcdH0sXHRcdFxyXG5cdFx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0XHRhc3luYyAnb2JqZWN0c2ludGVyZmFjZXMuZ2V0ZGF0YWJsb2NrYXN5bmMnKCkge1xyXG5cdFx0XHRyZXR1cm4gYXdhaXQgT2JqZWN0c0ludGVyZmFjZXMucmF3Q29sbGVjdGlvbigpLmFnZ3JlZ2F0ZShbXHJcblx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0JGxvb2t1cDpcclxuXHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0ZnJvbTogXCJ0YWdpbnRlcmZhY2VzXCIsXHJcblx0XHRcdFx0XHRcdGxvY2FsRmllbGQ6IFwiYXNzaWdubWVudFRhZ1wiLFxyXG5cdFx0XHRcdFx0XHRmb3JlaWduRmllbGQ6IFwiX2lkXCIsXHJcblx0XHRcdFx0XHRcdGFzOiBcInRhZ1wiXHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fSxcclxuXHRcdFx0XHR7ICR1bndpbmQ6IFwiJHRhZ1wiIH0sXHJcblx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0JGxvb2t1cDpcclxuXHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0ZnJvbTogXCJzY3JlZW5pbnRlcmZhY2VzXCIsXHJcblx0XHRcdFx0XHRcdGxvY2FsRmllbGQ6IFwic2NyZWVuXCIsXHJcblx0XHRcdFx0XHRcdGZvcmVpZ25GaWVsZDogXCJfaWRcIixcclxuXHRcdFx0XHRcdFx0YXM6IFwic2NyZWVuXCJcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9LFx0XHJcblx0XHRcdFx0eyAkdW53aW5kOiBcIiRzY3JlZW5cIiB9LFxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdCRsb29rdXA6XHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdGZyb206IFwic2l0ZWludGVyZmFjZXNcIixcclxuXHRcdFx0XHRcdFx0bG9jYWxGaWVsZDogXCJzY3JlZW4uc2l0ZVwiLFxyXG5cdFx0XHRcdFx0XHRmb3JlaWduRmllbGQ6IFwiX2lkXCIsXHJcblx0XHRcdFx0XHRcdGFzOiBcInNpdGVcIlxyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH0sXHRcclxuXHRcdFx0XHR7ICR1bndpbmQ6IFwiJHNpdGVcIiB9LFxyXG5cdFx0XHRcdHskc29ydCA6IHsgXCJzY3JlZW4ubmFtZVwiOjF9IH0sXHRcclxuXHRcdFx0XHR7JHByb2plY3Q6IHtcclxuXHRcdFx0XHRcdFwiX2lkXCI6IFwiJF9pZFwiLFxyXG5cdFx0XHRcdFx0XCJuc2l0ZVwiOiBcIiRzaXRlLm5hbWVcIixcclxuXHRcdFx0XHRcdFwiaWRTaXRlXCI6IFwiJHNpdGUuX2lkXCIsXHJcblx0XHRcdFx0XHRcIm9iak5hbWVcIiBcdDogXCIkb2JqTmFtZVwiLFxyXG5cdFx0XHRcdFx0XCJpZF90YWdcIlx0OiBcIiR0YWcuX2lkXCIsXHJcblx0XHRcdFx0XHRcImFzc2lnbm1lbnRUYWdcIiA6IFwiJHRhZy50YWdOYW1lXCIsXHJcblx0XHRcdFx0XHRcImlkX3NjcmVlblwiXHQ6IFwiJHNjcmVlbi5faWRcIixcclxuXHRcdFx0XHRcdFwic2NyZWVuXCJcdDogXCIkc2NyZWVuLm5hbWVcIixcclxuXHRcdFx0XHRcdFwieFBvc2l0b25cIiBcdDogXCIkeFBvc2l0b25cIixcclxuXHRcdFx0XHRcdFwieVBvc2l0b25cIiBcdDogXCIkeVBvc2l0b25cIixcdFxyXG5cdFx0XHRcdFx0XCJ4U2NhbGVcIiBcdDogXCIkeFNjYWxlXCIsXHJcblx0XHRcdFx0XHRcInlTY2FsZVwiIFx0OiBcIiR5U2NhbGVcIixcdFxyXG5cdFx0XHRcdFx0XCJyb3RhdGVcIiBcdDogXCIkcm90YXRlXCIsXHJcblx0XHRcdFx0fX1cclxuXHRcdFx0XSkudG9BcnJheSgpO1xyXG5cdFx0fSxcclxuXHRcdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFxyXG5cdFx0YXN5bmMgJ29iamVjdHNpbnRlcmZhY2VzLmdldE9iamVjdHNhc3luY1N0YXRpYycoc2NyZWVuTmFtZSkgXHJcblx0XHR7XHJcblx0XHRcdHJldHVybiBhd2FpdCBPYmplY3RzSW50ZXJmYWNlcy5yYXdDb2xsZWN0aW9uKCkuYWdncmVnYXRlKFtcclxuXHRcdFx0eyRtYXRjaDogeyAkYW5kOiBbIHsgc2NyZWVuOiB7ICRlcTogc2NyZWVuTmFtZSB9IH0sIHsgc3RhdGljT2JqOiB7ICRlcTogMSB9fV0gfX0sXHJcblx0XHRcdHskc29ydCA6IHsgY3JlYXRlRGF0ZSA6IC0xfSB9LFxyXG5cdFx0XHR7XHJcblx0XHRcdCAkbG9va3VwOlxyXG5cdFx0XHQgICB7XHJcblx0XHRcdFx0IGZyb206IFwidGFnaW50ZXJmYWNlc1wiLFxyXG5cdFx0XHRcdCBsb2NhbEZpZWxkOiBcImFzc2lnbm1lbnRUYWdcIixcclxuXHRcdFx0XHQgZm9yZWlnbkZpZWxkOiBcIl9pZFwiLFxyXG5cdFx0XHRcdCBhczogXCJ0YWdzXCJcclxuXHRcdFx0ICAgfVxyXG5cdFx0XHR9LFxyXG5cdFx0XHR7ICR1bndpbmQ6IFwiJHRhZ3NcIiB9XHJcblx0XHRcdF0pLnRvQXJyYXkoKTtcclxuXHRcdH0sXHJcblx0XHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHRcdGFzeW5jICdvYmplY3RzaW50ZXJmYWNlcy5nZXRPYmplY3RzYXN5bmMnKHNjcmVlbk5hbWUpIFxyXG5cdFx0e1x0XHRcdFxyXG5cdFx0XHRyZXR1cm4gYXdhaXQgT2JqZWN0c0ludGVyZmFjZXMucmF3Q29sbGVjdGlvbigpLmFnZ3JlZ2F0ZShbXHJcblx0XHRcdHskbWF0Y2g6IHsgJGFuZDogWyB7IHNjcmVlbjogeyAkZXE6IHNjcmVlbk5hbWUgfSB9LCB7IHN0YXRpY09iajogeyAkZXE6IDAgfX1dIH19LFxyXG5cdFx0XHR7XHJcblx0XHRcdCAkbG9va3VwOlxyXG5cdFx0XHQgICB7XHJcblx0XHRcdFx0IGZyb206IFwidGFnaW50ZXJmYWNlc1wiLFxyXG5cdFx0XHRcdCBsb2NhbEZpZWxkOiBcImFzc2lnbm1lbnRUYWdcIixcclxuXHRcdFx0XHQgZm9yZWlnbkZpZWxkOiBcIl9pZFwiLFxyXG5cdFx0XHRcdCBhczogXCJ0YWdzXCJcclxuXHRcdFx0ICAgfVxyXG5cdFx0XHR9LFxyXG5cdFx0XHR7ICR1bndpbmQ6IFwiJHRhZ3NcIiB9LFxyXG5cdFx0XHR7JHNvcnQgOiB7IFwidGFncy50YWdOYW1lXCI6MX0gfSxcclxuXHRcdFx0XSkudG9BcnJheSgpO1xyXG5cdFx0fSxcdFxyXG5cdFx0XHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHRcdGFzeW5jICdvYmplY3RzaW50ZXJmYWNlcy5jbnRPYmpTdGF0aWMnKFxyXG5cdFx0XHRzY3JlZW4sXHJcblx0XHRcdHR5cGVPYmplY3RzXHJcblx0XHQpXHJcblx0XHR7XHJcblx0XHRcdFxyXG5cdFx0XHRyZXR1cm4gYXdhaXQgT2JqZWN0c0ludGVyZmFjZXMuZmluZCh7ICRhbmQ6IFsgeyBzY3JlZW46IHsgJGVxOiBzY3JlZW4gfSB9LCB7IHR5cGVPYmplY3RzOiB7ICRlcTogdHlwZU9iamVjdHMgfX1dfSkuY291bnQoKTtcclxuXHRcdH0sXHJcblx0fSlcdFx0XHJcbn1cclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQnb2JqZWN0c2ludGVyZmFjZXMuZ2V0ZGF0YWJsb2NrJygpIFxyXG5cdHtcclxuXHRcdHZhciBkYXRhQmxvY2sgPSBbXTtcclxuXHRcdE9iamVjdHNJbnRlcmZhY2VzLmZpbmQoe30se3NvcnQ6eyBjcmVhdGVEYXRlIDogLTEgfX0pLmZvckVhY2goZnVuY3Rpb24oZG9jKSB7XHJcblx0XHRcdHZhciBuYW1lVGFnID0gTWV0ZW9yLmNhbGwoJ3RhZ2ludGVyZmFjZXMuZ2V0bmFtZScsZG9jLmFzc2lnbm1lbnRUYWcpO1x0XHJcblx0XHRcdHZhciBzY3JlZW4gPSBNZXRlb3IuY2FsbCgnc2NyZWVuaW50ZXJmYWNlcy5nZXRzY3JlZW4nLGRvYy5zY3JlZW4pO1x0XHJcblx0XHRcdHZhciBuc2l0ZSA9IE1ldGVvci5jYWxsKCdzaXRlaW50ZXJmYWNlcy5nZXRuYW1lJyxzY3JlZW4uc2l0ZSk7XHJcblx0XHRcdFxyXG5cdFx0XHRkYXRhQmxvY2sucHVzaCh7XHJcblx0XHRcdFx0X2lkOiBkb2MuX2lkLFxyXG5cdFx0XHRcdG5zaXRlOiBuc2l0ZSxcclxuXHRcdFx0XHRpZFNpdGU6IHNjcmVlbi5zaXRlLFxyXG5cdFx0XHRcdG9iak5hbWUgOiBkb2Mub2JqTmFtZSxcclxuXHRcdFx0XHRpZF90YWc6IGRvYy5hc3NpZ25tZW50VGFnLFxyXG5cdFx0XHRcdGFzc2lnbm1lbnRUYWcgOiBuYW1lVGFnLFxyXG5cdFx0XHRcdGlkX3NjcmVlbjogZG9jLnNjcmVlbixcclxuXHRcdFx0XHRzY3JlZW46IHNjcmVlbi5uYW1lLFxyXG5cdFx0XHRcdHhQb3NpdG9uIDogZG9jLnhQb3NpdG9uLFxyXG5cdFx0XHRcdHlQb3NpdG9uIDogZG9jLnlQb3NpdG9uLFx0XHJcblx0XHRcdFx0cm90YXRlIDogZG9jLnJvdGF0ZSxcdFx0XHJcblx0XHRcdFx0eFNjYWxlIDogZG9jLnhTY2FsZSxcclxuXHRcdFx0XHR5U2NhbGUgOiBkb2MueVNjYWxlLFxyXG5cdFx0XHRcdHJvdGF0ZSA6IGRvYy5yb3RhdGUsXHJcblx0XHRcdH0pO1x0XHRcdFxyXG5cdFx0XHRcclxuXHRcdH0pO1xyXG5cdFxyXG5cdFx0cmV0dXJuIGRhdGFCbG9jaztcclxuXHR9LFxyXG5cclxuXHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0J29iamVjdHNpbnRlcmZhY2VzLmdldE9iamVjdHMnKHNjcmVlbk5hbWUpIFxyXG5cdHtcclxuXHRcdHZhciBkYXRhQmxvY2sgPSBbXTtcdFxyXG5cdFx0dmFyIGlkX3NjcmVlbiA9IE1ldGVvci5jYWxsKCdzY3JlZW5pbnRlcmZhY2VzLmdldGlkJyxzY3JlZW5OYW1lKTtcdCBcclxuXHRcdE9iamVjdHNJbnRlcmZhY2VzLmZpbmQoe3NjcmVlbjppZF9zY3JlZW59LHtzY3JlZW46MCxjcmVhdGVEYXRlOjB9KS5mb3JFYWNoKGZ1bmN0aW9uKGRvYykge1x0XHRcdFxyXG5cdFx0XHR2YXIgdGFnID0gTWV0ZW9yLmNhbGwoJ3RhZ2ludGVyZmFjZXMuZ2V0VGFnJyxkb2MuYXNzaWdubWVudFRhZyk7XHJcblx0XHRcdGlmICh0YWchPW51bGwpXHJcblx0XHRcdHtcclxuXHRcdFx0XHRkYXRhQmxvY2sucHVzaCh7XHJcblx0XHRcdFx0XHRfaWQ6IGRvYy5faWQsXHJcblx0XHRcdFx0XHRvYmpOYW1lIDogZG9jLm9iak5hbWUsXHJcblx0XHRcdFx0XHRhc3NpZ25tZW50VGFnIDogZG9jLmFzc2lnbm1lbnRUYWcsXHJcblx0XHRcdFx0XHRzY3JlZW46ZG9jLnNjcmVlbixcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHR0YWdzIDogdGFnLFxyXG5cdFx0XHRcdFx0eFBvc2l0b24gOiBkb2MueFBvc2l0b24sXHJcblx0XHRcdFx0XHR5UG9zaXRvbiA6IGRvYy55UG9zaXRvbixcdFxyXG5cdFx0XHRcdFx0eFNjYWxlIDogZG9jLnhTY2FsZSxcclxuXHRcdFx0XHRcdHlTY2FsZSA6IGRvYy55U2NhbGUsXHJcblx0XHRcdFx0XHRyb3RhdGUgOiBkb2Mucm90YXRlLFxyXG5cdFx0XHRcdH0pO1xyXG5cdFx0XHR9XHJcblx0XHR9KTtcclxuXHRcdHJldHVybiBkYXRhQmxvY2s7XHJcblx0fSxcdFxyXG5cclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQnb2JqZWN0c2ludGVyZmFjZXMuaW5zZXJ0U3RhdGljJyhcdFx0XHRcclxuXHRcdG5hbWUsXHJcblx0XHRhc3NpZ25tZW50VGFnLFxyXG5cdFx0c2NyZWVuLFxyXG5cdFx0eFBvc2l0b24sXHJcblx0XHR5UG9zaXRvbixcdFxyXG5cdFx0eFNjYWxlLFx0XHRcclxuXHRcdHlTY2FsZSxcclxuXHRcdHN0YXRpY09iaixcclxuXHRcdHR5cGVPYmplY3RzLFxyXG5cdFx0Y3JlYXRlRGF0ZVxyXG5cdFx0KSBcclxuXHR7XHJcblx0XHRcdGlmICghU2VjdXJpdHkuY2hlY2tSb2xlKHRoaXMudXNlcklkLCdPd25lcicpKVxyXG5cdFx0XHR7XHJcblx0XHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcihcImxvZ2dlZC1pblwiLFwiWW91IGFyZSBub3QgcGVybWl0dGVkLlwiKTtcclxuXHRcdFx0fVxyXG5cdFx0XHRlbHNlXHJcblx0XHRcdHtcclxuXHJcblx0XHRcdFx0dmFyIG9iak5hbWUgPSBcIlwiO1xyXG5cdFx0XHRcdHZhciBjbnRPYmogXHQgPSAwO1xyXG5cclxuXHRcdFx0XHR2YXIgY250T2JqID0gT2JqZWN0c0ludGVyZmFjZXMuZmluZCh7ICRhbmQ6IFsgeyBzY3JlZW46IHsgJGVxOiBzY3JlZW4gfSB9LCB7IHR5cGVPYmplY3RzOiB7ICRlcTogdHlwZU9iamVjdHMgfX1dfSkuY291bnQoKTtcclxuXHRcdFx0XHRjbnRPYmogPSBjbnRPYmogKyAxO1xyXG5cdFx0XHRcdFxyXG5cdFx0XHRcdHN3aXRjaCh0eXBlT2JqZWN0cylcclxuXHRcdFx0XHR7XHJcblx0XHRcdFx0XHRjYXNlIFwiVENIT2Jqc1wiOlxyXG5cdFx0XHRcdFx0XHRpZiAoY250T2JqPDEwKVxyXG5cdFx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdFx0b2JqTmFtZVx0PSBvYmpOYW1lLmNvbmNhdChuYW1lLFwiLTAwXCIsY250T2JqKTtcclxuXHRcdFx0XHRcdFx0fSBlbHNlIGlmIChjbnRPYmo8MTAwKVxyXG5cdFx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdFx0b2JqTmFtZVx0PSBvYmpOYW1lLmNvbmNhdChuYW1lLFwiLTBcIixjbnRPYmopO1x0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0fSBlbHNlXHJcblx0XHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0XHRvYmpOYW1lXHQ9IG9iak5hbWUuY29uY2F0KG5hbWUsXCItXCIsY250T2JqKTtcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdH1cdFx0XHJcblx0XHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0Y2FzZSBcIk1QRU9ianNcIjpcclxuXHRcdFx0XHRcdFx0aWYgKGNudE9iajwxMClcclxuXHRcdFx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0XHRcdG9iak5hbWVcdD0gb2JqTmFtZS5jb25jYXQobmFtZSxcIi0wXCIsY250T2JqKTtcclxuXHRcdFx0XHRcdFx0fSBlbHNlXHJcblx0XHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0XHRvYmpOYW1lXHQ9IG9iak5hbWUuY29uY2F0KG5hbWUsXCItXCIsY250T2JqKTtcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdH1cdFx0XHJcblx0XHRcdFx0XHRcdGJyZWFrO1x0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0ZGVmYXVsdDpcclxuXHRcdFx0XHRcdFx0b2JqTmFtZVx0PSBvYmpOYW1lLmNvbmNhdChuYW1lLFwiLVwiLGNudE9iaik7XHJcblx0XHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdH1cclxuXHRcdFxyXG5cdFx0XHRcdGlmIChPYmplY3RzSW50ZXJmYWNlcy5maW5kT25lKHsgJGFuZDogWyB7IHNjcmVlbjogeyAkZXE6IHNjcmVlbiB9IH0sIHsgb2JqTmFtZTogeyAkZXE6IG9iak5hbWUgfX1dfSkgIT1udWxsKVxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJEdXBsaWNhdGUgT2JqZWN0LCBQbGVhc2UgY2hlY2sgbmFtZSBvZiBPYmplY3QgYWdhaW5cIik7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdGVsc2UgXHJcblx0XHRcdFx0e1x0XHJcblx0XHRcdFxyXG5cdFx0XHRcdFx0T2JqZWN0c0ludGVyZmFjZXMuaW5zZXJ0KHtcclxuXHRcdFx0XHRcdFx0b2JqTmFtZSxcclxuXHRcdFx0XHRcdFx0YXNzaWdubWVudFRhZyxcclxuXHRcdFx0XHRcdFx0c2NyZWVuLFxyXG5cdFx0XHRcdFx0XHR4UG9zaXRvbixcclxuXHRcdFx0XHRcdFx0eVBvc2l0b24sXHRcclxuXHRcdFx0XHRcdFx0eFNjYWxlLFx0XHRcclxuXHRcdFx0XHRcdFx0eVNjYWxlLFx0XHJcblx0XHRcdFx0XHRcdHN0YXRpY09iaixcclxuXHRcdFx0XHRcdFx0dHlwZU9iamVjdHMsXHJcblx0XHRcdFx0XHRcdGNyZWF0ZURhdGVcclxuXHRcdFx0XHRcdH0pO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRyZXR1cm4gMDtcclxuXHRcdFx0fVxyXG5cdH0sXHRcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQnb2JqZWN0c2ludGVyZmFjZXMuaW5zZXJ0JyhcdFx0XHRcclxuXHRcdG9iak5hbWUsXHJcblx0XHRhc3NpZ25tZW50VGFnLFxyXG5cdFx0c2NyZWVuLFxyXG5cdFx0eFBvc2l0b24sXHJcblx0XHR5UG9zaXRvbixcdFxyXG5cdFx0eFNjYWxlLFx0XHRcclxuXHRcdHlTY2FsZSxcclxuXHRcdHJvdGF0ZSxcclxuXHRcdGRhdGFjaGFuZ2UsXHJcblx0XHRzdGF0aWNPYmosXHJcblx0XHRjcmVhdGVEYXRlXHJcblx0XHQpIFxyXG5cdHtcclxuXHRcdFx0aWYgKCFTZWN1cml0eS5jaGVja1JvbGUodGhpcy51c2VySWQsJ093bmVyJykpXHJcblx0XHRcdHtcclxuXHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibG9nZ2VkLWluXCIsXCJZb3UgYXJlIG5vdCBwZXJtaXR0ZWQuXCIpO1xyXG5cdFx0XHR9XHJcblx0XHRcdGVsc2VcclxuXHRcdFx0e1xyXG5cdFx0XHRcdGlmIChPYmplY3RzSW50ZXJmYWNlcy5maW5kT25lKHsgJGFuZDogWyB7IHNjcmVlbjogeyAkZXE6IHNjcmVlbiB9IH0sIHsgb2JqTmFtZTogeyAkZXE6IG9iak5hbWUgfX1dfSkgIT1udWxsKVxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJEdXBsaWNhdGUgT2JqZWN0LCBQbGVhc2UgY2hlY2sgbmFtZSBvZiBPYmplY3QgYWdhaW5cIik7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdGVsc2UgXHJcblx0XHRcdFx0e1x0XHRcdFx0XHJcblx0XHRcdFx0XHRPYmplY3RzSW50ZXJmYWNlcy5pbnNlcnQoe1xyXG5cdFx0XHRcdFx0XHRvYmpOYW1lLFxyXG5cdFx0XHRcdFx0XHRhc3NpZ25tZW50VGFnLFxyXG5cdFx0XHRcdFx0XHRzY3JlZW4sXHJcblx0XHRcdFx0XHRcdHhQb3NpdG9uLFxyXG5cdFx0XHRcdFx0XHR5UG9zaXRvbixcdFxyXG5cdFx0XHRcdFx0XHR4U2NhbGUsXHRcdFxyXG5cdFx0XHRcdFx0XHR5U2NhbGUsXHRcdFxyXG5cdFx0XHRcdFx0XHRyb3RhdGUsXHJcblx0XHRcdFx0XHRcdGRhdGFjaGFuZ2UsXHJcblx0XHRcdFx0XHRcdHN0YXRpY09iaixcclxuXHRcdFx0XHRcdFx0Y3JlYXRlRGF0ZVxyXG5cdFx0XHRcdFx0fSk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdHJldHVybiAwO1xyXG5cdFx0XHR9XHJcblx0fSxcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQnb2JqZWN0c2ludGVyZmFjZXMudXBkYXRlJyhcdFx0XHJcblx0XHRfaWQsXHJcblx0XHRvYmpOYW1lLFxyXG5cdFx0YXNzaWdubWVudFRhZyxcclxuXHRcdHNjcmVlbixcclxuXHRcdHhQb3NpdG9uLFxyXG5cdFx0eVBvc2l0b24sXHRcclxuXHRcdHhTY2FsZSxcdFx0XHJcblx0XHR5U2NhbGUsXHRcclxuXHRcdHJvdGF0ZSxcclxuXHRcdGRhdGFjaGFuZ2UsXHRcdFxyXG5cdFx0Y3JlYXRlRGF0ZVxyXG5cdFx0KSBcclxuXHR7XHJcblx0XHRpZiAoIVNlY3VyaXR5LmNoZWNrUm9sZSh0aGlzLnVzZXJJZCwnT3duZXInKSlcclxuXHRcdHtcclxuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcihcImxvZ2dlZC1pblwiLFwiWW91IGFyZSBub3QgcGVybWl0dGVkLlwiKTtcclxuXHRcdH1cclxuXHRcdGVsc2VcclxuXHRcdHtcclxuXHRcdFx0XHQvLyBpZiAoT2JqZWN0c0ludGVyZmFjZXMuZmluZE9uZSh7ICRhbmQ6IFsgeyBzY3JlZW46IHsgJGVxOiBzY3JlZW4gfSB9LCB7IG9iak5hbWU6IHsgJGVxOiBvYmpOYW1lIH19XX0pICE9bnVsbClcclxuXHRcdFx0XHQvLyB7XHJcblx0XHRcdFx0XHQvLyB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiRHVwbGljYXRlIE9iamVjdCwgUGxlYXNlIGNoZWNrIG5hbWUgb2YgT2JqZWN0IGFnYWluXCIpO1xyXG5cdFx0XHRcdC8vIH1cclxuXHRcdFx0XHQvLyBlbHNlIFxyXG5cdFx0XHRcdC8vIHtcclxuXHRcdFx0XHRcdHZhciByb3RhdGUgPSBwYXJzZUludChyb3RhdGUpO1xyXG5cdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRPYmplY3RzSW50ZXJmYWNlcy51cGRhdGUoX2lkLFxyXG5cdFx0XHRcdFx0eyAkc2V0OiB7XHJcblx0XHRcdFx0XHRcdFx0b2JqTmFtZSxcclxuXHRcdFx0XHRcdFx0XHRhc3NpZ25tZW50VGFnLFxyXG5cdFx0XHRcdFx0XHRcdHNjcmVlbixcclxuXHRcdFx0XHRcdFx0XHR4UG9zaXRvbixcclxuXHRcdFx0XHRcdFx0XHR5UG9zaXRvbixcdFxyXG5cdFx0XHRcdFx0XHRcdHhTY2FsZSxcdFx0XHJcblx0XHRcdFx0XHRcdFx0eVNjYWxlLFx0XHJcblx0XHRcdFx0XHRcdFx0cm90YXRlLFxyXG5cdFx0XHRcdFx0XHRcdGRhdGFjaGFuZ2UsXHJcblx0XHRcdFx0XHRcdFx0Y3JlYXRlRGF0ZVxyXG5cdFx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdH0pO1xyXG5cdFx0XHRcdC8vfVxyXG5cdFx0fVxyXG5cdH0sXHRcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuICAnb2JqZWN0c2ludGVyZmFjZXMucmVtb3ZlJyh0YXNrSWQpIHtcclxuXHRcdGlmICghU2VjdXJpdHkuY2hlY2tSb2xlKHRoaXMudXNlcklkLCdPd25lcicpKVxyXG5cdFx0e1xyXG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibG9nZ2VkLWluXCIsXCJZb3UgYXJlIG5vdCBwZXJtaXR0ZWQuXCIpO1xyXG5cdFx0fVxyXG5cdFx0ZWxzZVxyXG5cdFx0e1x0ICBcclxuXHRcdFx0T2JqZWN0c0ludGVyZmFjZXMucmVtb3ZlKHRhc2tJZCk7XHJcblx0XHR9XHJcbiAgfSxcclxufSkiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQgU2VjdXJpdHkgZnJvbSAnLi9zZWN1cml0eSc7IFxyXG5pbXBvcnQgU0lURUludGVyZmFjZXMgZnJvbSAnLi9zaXRlaW50ZXJmYWNlcy5qcyc7XHJcblxyXG5leHBvcnQgY29uc3QgUExDSW50ZXJmYWNlcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdwbGNpbnRlcmZhY2VzJyk7XHJcblxyXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XHJcblx0TWV0ZW9yLm1ldGhvZHMoe1x0XHJcblx0Ly8gVGhpcyBjb2RlIG9ubHkgcnVucyBvbiB0aGUgc2VydmVyXHJcblx0XHRhc3luYyAncGxjaW50ZXJmYWNlcy5nZXRkYXRhYmxvY2thc3luYycoKSBcclxuXHRcdHtcclxuXHRcdFx0dmFyIGRhdGFCbG9jayA9IFtdO1xyXG5cdFx0XHRhd2FpdCBQTENJbnRlcmZhY2VzLnJhd0NvbGxlY3Rpb24oKS5hZ2dyZWdhdGUoW1xyXG5cdFx0XHQgICB7XHJcblx0XHRcdFx0ICRsb29rdXA6XHJcblx0XHRcdFx0ICAge1xyXG5cdFx0XHRcdFx0IGZyb206IFwic2l0ZWludGVyZmFjZXNcIixcclxuXHRcdFx0XHRcdCBsb2NhbEZpZWxkOiBcInNpdGVcIixcclxuXHRcdFx0XHRcdCBmb3JlaWduRmllbGQ6IFwiX2lkXCIsXHJcblx0XHRcdFx0XHQgYXM6IFwic2l0ZW5hbWVcIlxyXG5cdFx0XHRcdCAgIH1cclxuXHRcdFx0ICAgfSxcclxuXHRcdFx0ICAgeyAkdW53aW5kOiBcIiRzaXRlbmFtZVwiIH0gLFxyXG5cdFx0XHQgICB7ICRyZXBsYWNlUm9vdDogeyBuZXdSb290OiB7ICRtZXJnZU9iamVjdHM6IFsgXHJcblx0XHRcdFx0XHR7IG5wbGM6IFwiJG5hbWVcIn0sXHJcblx0XHRcdFx0XHR7IGlkX3BsYzogXCIkX2lkXCJ9LFxyXG5cdFx0XHRcdFx0eyBwcm90b2NvbDogXCIkcHJvdG9jb2xcIn0sXHJcblx0XHRcdFx0XHR7IGlwYWRkcmVzczogXCIkaXBhZGRyZXNzXCJ9LCBcclxuXHRcdFx0XHRcdFwiJHNpdGVuYW1lXCIgXHJcblx0XHRcdFx0XHRdIH0gfSBcclxuXHRcdFx0XHR9XHJcblx0XHRcdF0pLmZvckVhY2goZnVuY3Rpb24oZG9jKSB7XHJcblx0XHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdFx0X2lkOiBkb2MuaWRfcGxjLFxyXG5cdFx0XHRcdFx0bnNpdGU6IGRvYy5uYW1lLFxyXG5cdFx0XHRcdFx0aWRTaXRlOiBkb2MuX2lkLFxyXG5cdFx0XHRcdFx0bmFtZTogZG9jLm5wbGMsXHJcblx0XHRcdFx0XHRwcm90b2NvbDogZG9jLnByb3RvY29sLFxyXG5cdFx0XHRcdFx0aXBhZGRyZXNzOiBkb2MuaXBhZGRyZXNzLFxyXG5cdFx0XHRcdH0pO1x0XHRcdFxyXG5cdFx0XHRcdFxyXG5cdFx0XHR9KTtcclxuXHRcdFx0XHJcblx0XHRcdHJldHVybiBkYXRhQmxvY2s7XHJcblx0XHR9LFx0XHRcdFxyXG5cdH0pXHJcbn1cclxuLy89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFxyXG5cdCdwbGNpbnRlcmZhY2VzLmdldGRhdGFibG9jaycoKSBcclxuXHR7XHJcblx0XHR2YXIgZGF0YUJsb2NrID0gW107XHJcblx0XHRQTENJbnRlcmZhY2VzLmZpbmQoe30sIHtzb3J0OiB7bmFtZTogMX19KS5mb3JFYWNoKGZ1bmN0aW9uKGRvYykge1xyXG5cdFx0XHR2YXIgbnNpdGUgPSBNZXRlb3IuY2FsbCgnc2l0ZWludGVyZmFjZXMuZ2V0bmFtZScsZG9jLnNpdGUpO1xyXG5cdFx0XHRkYXRhQmxvY2sucHVzaCh7XHJcblx0XHRcdFx0X2lkOiBkb2MuX2lkLFxyXG5cdFx0XHRcdG5zaXRlOiBuc2l0ZSxcclxuXHRcdFx0XHRpZFNpdGU6IGRvYy5zaXRlLFxyXG5cdFx0XHRcdG5hbWU6IGRvYy5uYW1lLFxyXG5cdFx0XHRcdHByb3RvY29sOiBkb2MucHJvdG9jb2wsXHJcblx0XHRcdFx0aXBhZGRyZXNzOiBkb2MuaXBhZGRyZXNzLFxyXG5cdFx0XHR9KTtcdFx0XHRcclxuXHRcdFx0XHJcblx0XHR9KTtcclxuXHRcdFxyXG5cdFx0cmV0dXJuIGRhdGFCbG9jaztcclxuXHR9LFxyXG5cdCdwbGNpbnRlcmZhY2VzLmZpbmRwbGMnKGlkUExDKSBcclxuXHR7XHJcblx0XHRyZXR1cm4gUExDSW50ZXJmYWNlcy5maW5kT25lKHsgX2lkOmlkUExDfSk7XHJcblx0fSxcdFxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFx0XHJcblx0J3BsY2ludGVyZmFjZXMuZ2V0bmFtZScoaWRQTEMpIFxyXG5cdHtcdFx0XHJcblx0XHR2YXIgbmFtZVBMQyA9IFBMQ0ludGVyZmFjZXMuZmluZE9uZSh7IF9pZDppZFBMQ30pO1x0XHRcclxuXHRcdGlmIChuYW1lUExDPT1udWxsKSB7XHJcblx0XHRcdHJldHVybiBudWxsO1xyXG5cdFx0fVxyXG5cdFx0ZWxzZVxyXG5cdFx0e1xyXG5cdFx0XHRyZXR1cm4gbmFtZVBMQy5uYW1lO1xyXG5cdFx0fVx0XHRcdFxyXG5cdH0sXHRcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcdFxyXG5cdCdwbGNpbnRlcmZhY2VzLmdldHNpdGUnKGlkUExDKSBcclxuXHR7XHRcdFxyXG5cdFx0dmFyIHBsYyA9IFBMQ0ludGVyZmFjZXMuZmluZE9uZSh7IF9pZDppZFBMQ30pO1x0XHRcclxuXHRcdGlmIChwbGM9PW51bGwpIHtcclxuXHRcdFx0cmV0dXJuIG51bGw7XHJcblx0XHR9XHJcblx0XHRlbHNlXHJcblx0XHR7XHJcblx0XHRcdHJldHVybiBwbGMuc2l0ZTtcclxuXHRcdH1cdFx0XHRcclxuXHR9LFx0XHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0J3BsY2ludGVyZmFjZXMuaW5zZXJ0JyhcdFxyXG5cdFx0c2l0ZSxcclxuXHRcdG5hbWUsXHJcblx0XHRwcm90b2NvbCxcclxuXHRcdGlwYWRkcmVzcyxcclxuXHRcdGRhdGFjaGFuZ2UsXHJcblx0XHRjcmVhdGVEYXRlXHJcblx0XHQpIFxyXG5cdHtcclxuXHRcdGlmICghU2VjdXJpdHkuY2hlY2tSb2xlKHRoaXMudXNlcklkLCdPd25lcicpKVxyXG5cdFx0e1xyXG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibG9nZ2VkLWluXCIsXCJZb3UgYXJlIG5vdCBwZXJtaXR0ZWQuXCIpO1xyXG5cdFx0fVxyXG5cdFx0ZWxzZVxyXG5cdFx0e1xyXG5cdFx0XHRpZiAoUExDSW50ZXJmYWNlcy5maW5kT25lKHsgJGFuZDogWyB7IHNpdGU6IHsgJGVxOiBzaXRlIH0gfSwgeyBuYW1lOiB7ICRlcTogbmFtZSB9fV19KSAhPW51bGwpXHJcblx0XHRcdHtcclxuXHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiRHVwbGljYXRlIFBMQywgUGxlYXNlIGNoZWNrIG5hbWUgb3IgYWRkcmVzcyBvZiBQTEMgYWdhaW5cIik7XHJcblx0XHRcdH1cclxuXHRcdFx0ZWxzZSBcclxuXHRcdFx0e1x0XHRcdFxyXG5cdFx0XHRcdFBMQ0ludGVyZmFjZXMuaW5zZXJ0KHtcclxuXHRcdFx0XHRcdHNpdGUsXHJcblx0XHRcdFx0XHRuYW1lLFxyXG5cdFx0XHRcdFx0cHJvdG9jb2wsXHJcblx0XHRcdFx0XHRpcGFkZHJlc3MsXHJcblx0XHRcdFx0XHRkYXRhY2hhbmdlLFxyXG5cdFx0XHRcdFx0Y3JlYXRlRGF0ZVxyXG5cdFx0XHRcdH0pO1xyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0fSxcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQncGxjaW50ZXJmYWNlcy5yZW1vdmUnKHRhc2tJZCkge1xyXG5cdFx0aWYgKCFTZWN1cml0eS5jaGVja1JvbGUodGhpcy51c2VySWQsJ093bmVyJykpXHJcblx0XHR7XHJcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJsb2dnZWQtaW5cIixcIllvdSBhcmUgbm90IHBlcm1pdHRlZC5cIik7XHJcblx0XHR9XHJcblx0XHRlbHNlXHJcblx0XHR7XHJcblx0XHRcdFBMQ0ludGVyZmFjZXMucmVtb3ZlKHRhc2tJZCk7XHJcblx0XHR9XHJcblx0fSxcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQncGxjaW50ZXJmYWNlcy51cGRhdGUnKFxyXG5cdFx0X2lkLFxyXG5cdFx0cHJvdG9jb2wsXHJcblx0XHRpcGFkZHJlc3MsXHJcblx0XHRkYXRhY2hhbmdlLFxyXG5cdFx0Y3JlYXRlRGF0ZVxyXG5cdCkgXHJcblx0e1xyXG5cdFx0aWYgKCFTZWN1cml0eS5jaGVja1JvbGUodGhpcy51c2VySWQsJ093bmVyJykpXHJcblx0XHR7XHJcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJsb2dnZWQtaW5cIixcIllvdSBhcmUgbm90IHBlcm1pdHRlZC5cIik7XHJcblx0XHR9XHJcblx0XHRlbHNlXHJcblx0XHR7XHJcblx0XHRcdFBMQ0ludGVyZmFjZXMudXBkYXRlKF9pZCwgXHJcblx0XHRcdFx0eyAkc2V0OiB7IFxyXG5cdFx0XHRcdFx0cHJvdG9jb2wsXHJcblx0XHRcdFx0XHRpcGFkZHJlc3MsXHJcblx0XHRcdFx0XHRkYXRhY2hhbmdlLFxyXG5cdFx0XHRcdFx0Y3JlYXRlRGF0ZSxcclxuXHRcdFx0XHRcdH0gXHJcblx0XHRcdFx0fSk7XHJcblx0XHR9XHJcblx0fVx0XHRcclxufSkiLCJcclxuY29uc3QgUk9MRVMgPSB7XHJcbiAgT3duZXI6ICdPd25lcicsXHJcbiAgQWRtaW5pc3RyYXRvcjogJ0FkbWluaXN0cmF0b3InLFxyXG4gIE9wZXJhdG9yOiAnT3BlcmF0b3InLFxyXG4gIFZpZXc6ICdWaWV3JyxcclxuICBOU2NvcGU6ICdOUm9sZSdcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFJPTEVTO1xyXG5cclxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IFNlY3VyaXR5IGZyb20gJy4vc2VjdXJpdHknOyBcclxuXHJcbmV4cG9ydCBjb25zdCBSb3V0ZUludGVyZmFjZSA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdyb3V0ZWludGVyZmFjZScpO1xyXG5cclxuLy89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0J3JvdXRlaW50ZXJmYWNlLmdldGRhdGFibG9jaycoKSBcclxuXHR7XHJcblx0XHR2YXIgZGF0YUJsb2NrID0gW107XHJcblx0XHRSb3V0ZUludGVyZmFjZS5maW5kKHt9LCB7c29ydDoge3Njb3BlOiAxfX0pLmZvckVhY2goZnVuY3Rpb24oZG9jKSB7XHJcblx0XHRcdGRhdGFCbG9jay5wdXNoKHtcclxuXHRcdFx0XHRfaWQ6IGRvYy5faWQsXHJcblx0XHRcdFx0cGF0aDogZG9jLnBhdGgsXHJcblx0XHRcdFx0bmFtZTogZG9jLm5hbWUsXHJcblx0XHRcdFx0Y29tcG9uZW50OiBkb2MuY29tcG9uZW50LFxyXG5cdFx0XHRcdHNjb3BlOiBkb2Muc2NvcGUsXHJcblx0XHRcdFx0ZXhjZXB0OiBkb2MuZXhjZXB0LFxyXG5cdFx0XHR9KTtcdFx0XHRcclxuXHRcdFx0XHJcblx0XHR9KTtcclxuXHRcdFxyXG5cdFx0cmV0dXJuIGRhdGFCbG9jaztcclxuXHR9LFxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFxyXG5cdCdyb3V0ZWludGVyZmFjZS5pbnNlcnQnKFx0XHRcclxuXHRcdHBhdGgsXHJcblx0XHRjb21wb25lbnQsXHJcblx0XHRzY29wZSxcclxuXHRcdGV4Y2VwdCxcclxuXHRcdCkgXHJcblx0e1xyXG5cdFx0aWYgKCFTZWN1cml0eS5jaGVja1JvbGUodGhpcy51c2VySWQsJ093bmVyJykpXHJcblx0XHR7XHJcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJsb2dnZWQtaW5cIixcIllvdSBhcmUgbm90IHBlcm1pdHRlZC5cIik7XHJcblx0XHR9XHJcblx0XHRlbHNlXHJcblx0XHR7XHJcblx0XHRcdGlmIChSb3V0ZUludGVyZmFjZS5maW5kT25lKHsgbmFtZTpuYW1lfSkhPW51bGwpXHJcblx0XHRcdHtcclxuXHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiRHVwbGljYXRlIFNpdGUsIFBsZWFzZSBjaGVjayBuYW1lIG9mIFNpdGUgYWdhaW5cIik7XHJcblx0XHRcdH1cclxuXHRcdFx0ZWxzZSBcclxuXHRcdFx0e1xyXG5cdFx0XHRcdFJvdXRlSW50ZXJmYWNlLmluc2VydCh7XHJcblx0XHRcdFx0XHRwYXRoLFxyXG5cdFx0XHRcdFx0Y29tcG9uZW50LFxyXG5cdFx0XHRcdFx0c2NvcGUsXHJcblx0XHRcdFx0XHRleGNlcHQsXHJcblx0XHRcdFx0fSk7XHJcblx0XHRcdFx0XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHR9LFxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFxyXG5cdCdyb3V0ZWludGVyZmFjZS5yZW1vdmUnKHRhc2tJZCkgXHJcblx0e1xyXG5cdFx0aWYgKCFTZWN1cml0eS5jaGVja1JvbGUodGhpcy51c2VySWQsJ093bmVyJykpXHJcblx0XHR7XHJcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJsb2dnZWQtaW5cIixcIllvdSBhcmUgbm90IHBlcm1pdHRlZC5cIik7XHJcblx0XHR9XHJcblx0XHRlbHNlXHJcblx0XHR7XHJcblx0XHRcdFJvdXRlSW50ZXJmYWNlLnJlbW92ZSh0YXNrSWQpO1xyXG5cdFx0fVxyXG5cdH0sXHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0J3JvdXRlaW50ZXJmYWNlLmFkZEV4Y2VwdCcoXHJcblx0XHRfaWQsXHJcblx0XHRleGNlcHQsXHJcblx0KSBcclxuXHR7XHJcblx0XHRjb25zb2xlLmxvZyhcIj09PT09PT09PT09PWV4Y2VwdCBcIiArIGV4Y2VwdClcclxuXHRcdGlmICghU2VjdXJpdHkuY2hlY2tSb2xlKHRoaXMudXNlcklkLCdPd25lcicpKVxyXG5cdFx0e1xyXG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibG9nZ2VkLWluXCIsXCJZb3UgYXJlIG5vdCBwZXJtaXR0ZWQuXCIpO1xyXG5cdFx0fVxyXG5cdFx0ZWxzZVxyXG5cdFx0e1xyXG5cdFx0XHRSb3V0ZUludGVyZmFjZS51cGRhdGUoX2lkLCBcclxuXHRcdFx0XHR7ICRzZXQ6IHsgXHJcblx0XHRcdFx0XHRleGNlcHQsXHJcblx0XHRcdFx0XHR9IFxyXG5cdFx0XHRcdH0pO1xyXG5cdFx0fVxyXG5cdH1cdFxyXG59KSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCBTSVRFSW50ZXJmYWNlcyBmcm9tICcuL3NpdGVpbnRlcmZhY2VzLmpzJztcclxuXHJcbmV4cG9ydCBjb25zdCBTY3JlZW5JbnRlcmZhY2VzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3NjcmVlbmludGVyZmFjZXMnKTtcclxuXHJcbmltcG9ydCBTZWN1cml0eSBmcm9tICcuL3NlY3VyaXR5JztcclxuXHJcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcclxuXHRcclxuXHQvLyBUaGlzIGNvZGUgb25seSBydW5zIG9uIHRoZSBzZXJ2ZXJcclxuXHRNZXRlb3IucHVibGlzaCgnc2NyZWVuQ29udHJvbFN1YicsIGZ1bmN0aW9uIHNjcmVlbkNvbnRyb2xTdWIoYXJndW1lbnRzRmluZCxhcmd1bWVudHNPcHRpb25zKSB7XHJcblx0XHRyZXR1cm4gU2NyZWVuSW50ZXJmYWNlcy5maW5kKGFyZ3VtZW50c0ZpbmQsYXJndW1lbnRzT3B0aW9ucyk7XHJcblx0fSk7XHJcblx0XHJcblx0TWV0ZW9yLm1ldGhvZHMoe1xyXG5cdFx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0XHRhc3luYyAnc2NyZWVuaW50ZXJmYWNlcy5pbnNlcnRhc3luYycoc2l0ZSwgbmFtZSxjcmVhdGVEYXRlKSBcclxuXHRcdHtcclxuXHRcdFx0aWYgKCFTZWN1cml0eS5jaGVja1JvbGUodGhpcy51c2VySWQsJ093bmVyJykpXHJcblx0XHRcdHtcclxuXHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibG9nZ2VkLWluXCIsXCJZb3UgYXJlIG5vdCBwZXJtaXR0ZWQuXCIpO1xyXG5cdFx0XHR9XHJcblx0XHRcdGVsc2VcclxuXHRcdFx0e1xyXG5cdFx0XHRcdGlmIChhd2FpdCBTY3JlZW5JbnRlcmZhY2VzLmZpbmRPbmUoeyAkYW5kOiBbIHsgc2l0ZTogeyAkZXE6IHNpdGUgfSB9LCB7IG5hbWU6IHsgJGVxOiBuYW1lIH19XX0pICE9bnVsbClcclxuXHRcdFx0XHR7XHJcblx0XHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiRHVwbGljYXRlIFNjcmVlbiwgUGxlYXNlIGNoZWNrIG5hbWUgb2YgU2NyZWVuIGFnYWluXCIpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRlbHNlIFxyXG5cdFx0XHRcdHtcdFx0XHRcdFxyXG5cdFx0XHRcdFx0YXdhaXQgU2NyZWVuSW50ZXJmYWNlcy5pbnNlcnQoe1xyXG5cdFx0XHRcdFx0XHRzaXRlLFxyXG5cdFx0XHRcdFx0XHRuYW1lLFxyXG5cdFx0XHRcdFx0XHRjcmVhdGVEYXRlXHJcblx0XHRcdFx0XHR9KTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0cmV0dXJuIDA7XHJcblx0XHRcdH1cclxuXHRcdH0sXHRcclxuXHR9KVxyXG59XHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0Ly8gJ3NjcmVlbmludGVyZmFjZXMuaW5zZXJ0JyhcclxuXHQvLyBuYW1lLFxyXG5cdC8vIGRhdGFjaGFuZ2UsXHJcblx0Ly8gY3JlYXRlRGF0ZSkgXHJcblx0Ly8ge1xyXG5cdFx0Ly8gaWYgKCFTZWN1cml0eS5jaGVja1JvbGUodGhpcy51c2VySWQsJ093bmVyJykpXHJcblx0XHQvLyB7XHJcblx0XHRcdC8vIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJsb2dnZWQtaW5cIixcIllvdSBhcmUgbm90IHBlcm1pdHRlZC5cIik7XHJcblx0XHQvLyB9XHJcblx0XHQvLyBlbHNlXHJcblx0XHQvLyB7XHJcblx0XHRcdC8vIFNjcmVlbkludGVyZmFjZXMuaW5zZXJ0KHtcclxuXHRcdFx0XHQvLyBuYW1lLFxyXG5cdFx0XHRcdC8vIGRhdGFjaGFuZ2UsXHJcblx0XHRcdFx0Ly8gY3JlYXRlRGF0ZVxyXG5cdFx0XHQvLyB9KTtcclxuXHRcdC8vIH1cclxuXHQvLyB9LFxyXG5cdCdzY3JlZW5pbnRlcmZhY2VzLmluc2VydCcoc2l0ZSwgbmFtZSxjcmVhdGVEYXRlKVxyXG5cdHtcclxuXHRcdFx0aWYgKCFTZWN1cml0eS5jaGVja1JvbGUodGhpcy51c2VySWQsJ093bmVyJykpXHJcblx0XHRcdHtcclxuXHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibG9nZ2VkLWluXCIsXCJZb3UgYXJlIG5vdCBwZXJtaXR0ZWQuXCIpO1xyXG5cdFx0XHR9XHJcblx0XHRcdGVsc2VcclxuXHRcdFx0e1xyXG5cdFx0XHRcdGlmIChTY3JlZW5JbnRlcmZhY2VzLmZpbmRPbmUoeyAkYW5kOiBbIHsgc2l0ZTogeyAkZXE6IHNpdGUgfSB9LCB7IG5hbWU6IHsgJGVxOiBuYW1lIH19XX0pICE9bnVsbClcclxuXHRcdFx0XHR7XHJcblx0XHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiRHVwbGljYXRlIFNjcmVlbiwgUGxlYXNlIGNoZWNrIG5hbWUgb2YgU2NyZWVuIGFnYWluXCIpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRlbHNlIFxyXG5cdFx0XHRcdHtcdFx0XHRcdFxyXG5cdFx0XHRcdFx0U2NyZWVuSW50ZXJmYWNlcy5pbnNlcnQoe1xyXG5cdFx0XHRcdFx0XHRzaXRlLFxyXG5cdFx0XHRcdFx0XHRuYW1lLFxyXG5cdFx0XHRcdFx0XHRjcmVhdGVEYXRlXHJcblx0XHRcdFx0XHR9KTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0cmV0dXJuIDA7XHJcblx0XHRcdH1cclxuXHR9LFx0XHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0J3NjcmVlbmludGVyZmFjZXMudXBkYXRlJyhcclxuXHRcdF9pZCxcclxuXHRcdG5hbWUsXHJcblx0XHRkYXRhY2hhbmdlLFxyXG5cdFx0Y3JlYXRlRGF0ZVxyXG5cdCkgXHJcblx0e1xyXG5cdFx0aWYgKCFTZWN1cml0eS5jaGVja1JvbGUodGhpcy51c2VySWQsJ093bmVyJykpXHJcblx0XHR7XHJcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJsb2dnZWQtaW5cIixcIllvdSBhcmUgbm90IHBlcm1pdHRlZC5cIik7XHJcblx0XHR9XHJcblx0XHRlbHNlXHJcblx0XHR7XHJcblx0XHRcdFNjcmVlbkludGVyZmFjZXMudXBkYXRlKF9pZCwgXHJcblx0XHRcdFx0eyAkc2V0OiB7IFxyXG5cdFx0XHRcdFx0bmFtZSxcclxuXHRcdFx0XHRcdGRhdGFjaGFuZ2UsXHJcblx0XHRcdFx0XHRjcmVhdGVEYXRlLFxyXG5cdFx0XHRcdFx0fSBcclxuXHRcdFx0XHR9KTtcclxuXHRcdH1cclxuXHR9LFx0XHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0J3NjcmVlbmludGVyZmFjZXMucmVtb3ZlJyh0YXNrSWQpIHtcclxuXHRcdGlmICghU2VjdXJpdHkuY2hlY2tSb2xlKHRoaXMudXNlcklkLCdPd25lcicpKVxyXG5cdFx0e1xyXG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibG9nZ2VkLWluXCIsXCJZb3UgYXJlIG5vdCBwZXJtaXR0ZWQuXCIpO1xyXG5cdFx0fVxyXG5cdFx0ZWxzZVxyXG5cdFx0e1xyXG5cdFx0XHRTY3JlZW5JbnRlcmZhY2VzLnJlbW92ZSh0YXNrSWQpO1xyXG5cdFx0fVxyXG5cdH0sXHRcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQnc2NyZWVuaW50ZXJmYWNlcy5nZXQnKCkgXHJcblx0e1xyXG5cdFx0dmFyIGRhdGFCbG9jayA9IFtdO1xyXG5cdFx0U2NyZWVuSW50ZXJmYWNlcy5maW5kKHt9LHtzb3J0Onsgc2l0ZSA6IC0xIH19KS5mb3JFYWNoKGZ1bmN0aW9uKGRvYykge1xyXG5cdFx0XHR2YXIgbnNpdGUgPSBNZXRlb3IuY2FsbCgnc2l0ZWludGVyZmFjZXMuZ2V0bmFtZScsZG9jLnNpdGUpO1xyXG5cdFx0XHR2YXIgaWRrZXkgPSBuc2l0ZS5jb25jYXQoXCItXCIsZG9jLm5hbWUpO1xyXG5cdFx0XHRkYXRhQmxvY2sucHVzaCh7XHJcblx0XHRcdFx0X2lkOiBkb2MuX2lkLFxyXG5cdFx0XHRcdG5zaXRlOiBuc2l0ZSxcclxuXHRcdFx0XHRpZFNpdGU6IGRvYy5zaXRlLFxyXG5cdFx0XHRcdGlka2V5OiBpZGtleSxcclxuXHRcdFx0XHRuYW1lIDogZG9jLm5hbWUsXHJcblx0XHRcdFx0Y3JlYXRlRGF0ZTogZG9jLmNyZWF0ZURhdGVcclxuXHRcdFx0fSk7XHJcblx0XHR9KTtcclxuXHRcdHJldHVybiBkYXRhQmxvY2s7XHJcblx0fSxcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcdFxyXG5cdCdzY3JlZW5pbnRlcmZhY2VzLmdldHNjcmVlbicoaWRfc2NyZWVuKSBcclxuXHR7XHRcdFxyXG5cdFx0cmV0dXJuIFNjcmVlbkludGVyZmFjZXMuZmluZE9uZSh7X2lkOmlkX3NjcmVlbn0pO1xyXG5cdH0sXHRcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcdFxyXG5cdCdzY3JlZW5pbnRlcmZhY2VzLmdldG5hbWUnKGlkX3NjcmVlbikgXHJcblx0e1x0XHRcclxuXHRcdHZhciBuYW1lU2NyZWVuID0gU2NyZWVuSW50ZXJmYWNlcy5maW5kT25lKHtfaWQ6aWRfc2NyZWVufSk7XHJcblx0XHRpZiAobmFtZVNjcmVlbj09bnVsbCkge1xyXG5cdFx0XHRyZXR1cm4gbnVsbDtcclxuXHRcdH1cclxuXHRcdGVsc2VcclxuXHRcdHtcclxuXHRcdFx0cmV0dXJuIG5hbWVTY3JlZW4ubmFtZTtcclxuXHRcdH1cdFx0XHRcclxuXHR9LFx0XHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHRcclxuXHQnc2NyZWVuaW50ZXJmYWNlcy5nZXRpZCcoc2NyZWVuKSBcclxuXHR7XHRcdFxyXG5cdFx0dmFyIGlkX3NjcmVlbiA9IFNjcmVlbkludGVyZmFjZXMuZmluZE9uZSh7bmFtZTpzY3JlZW59KTtcdFxyXG5cdFx0aWYgKGlkX3NjcmVlbj09bnVsbCkge1xyXG5cdFx0XHRyZXR1cm4gbnVsbDtcclxuXHRcdH1cclxuXHRcdGVsc2VcclxuXHRcdHtcclxuXHRcdFx0cmV0dXJuIGlkX3NjcmVlbi5faWQ7XHJcblx0XHR9XHRcdFx0XHJcblx0fSxcdFxyXG59KSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcblxyXG5leHBvcnQgY29uc3QgU0NSRXZlbnQgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignc2NyZXZlbnQnKTtcclxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG5cdE1ldGVvci5tZXRob2RzKHtcclxuXHRcdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHRcdGFzeW5jICdzY3JldmVudC5nZXRDTURFdmVudHMnKHN0YXJ0VGltZVBhcmFtLGVuZFRpbWVQYXJhbSkgXHJcblx0XHR7XHRcdFxyXG5cdFx0XHRjb25zdCByZXN1bHQgPSBhd2FpdCBTQ1JFdmVudC5yYXdDb2xsZWN0aW9uKCkuYWdncmVnYXRlKFtcclxuXHRcdFx0XHR7JG1hdGNoOiB7ICRhbmQ6IFsgeyB0aW1lc3RhbXA6IHsgJGd0ZTogc3RhcnRUaW1lUGFyYW0gLCRsdGU6ZW5kVGltZVBhcmFtIH0gfV0gfX0sXHJcblx0XHRcdFx0eyRzb3J0IDogeyB0aW1lc3RhbXAgOiAtMX0gfSxcclxuXHRcdFx0XHR7XHRcclxuXHRcdFx0XHRcdCRwcm9qZWN0OiB7XHJcblx0XHRcdFx0XHRcdFwiX2lkXCI6IFwiJF9pZFwiLFxyXG5cdFx0XHRcdFx0XHRcIm9ialwiOiBcIiRvYmpcIixcclxuXHRcdFx0XHRcdFx0XCJ0aW1lc3RhbXBcIjogeyAkZGF0ZVRvU3RyaW5nOiB7IGZvcm1hdDogXCIlbS0lZC0lWSAlSDolTVwiLCBkYXRlOiB7JGFkZCA6IFtuZXcgRGF0ZSgwKSwgXCIkdGltZXN0YW1wXCJdIH0sIHRpbWV6b25lOiBcIkFzaWEvVG9reW9cIiB9IH0sXHJcblx0XHRcdFx0XHRcdFwiY21kXCI6IFwiJGNtZFwiLFxyXG5cdFx0XHRcdFx0XHRcInZhbFwiOlwiJHZhbFwiXHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRdKTtcclxuXHRcdFx0cmV0dXJuIHJlc3VsdC50b0FycmF5KCk7XHJcblx0XHR9XHJcblx0XHRcclxuICB9KVx0XHJcbiB9IiwiaW1wb3J0IHsgUm9sZXMgfSBmcm9tICdtZXRlb3IvYWxhbm5pbmc6cm9sZXMnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgU2VjdXJpdHkge1xyXG4gICAgc3RhdGljIGNoZWNrUm9sZSh1c2VySWQsIHJvbGUpIHtcclxuXHRcdC8vY2hlY2soc2NvcGUsIFN0cmluZyk7XHJcblx0XHQvL2NvbnNvbGUubG9nKFwiaGFzUm9sZTogXCIsIHJvbGUpO1x0XHJcblx0XHQvL2NvbnNvbGUubG9nKFwidXNlcklkOiBcIiArIHVzZXJJZCArIFwiIE1ldGVvci51c2VySWQoKTogXCIgKyBNZXRlb3IudXNlcklkKCkgKyBcIiBoYXNSb2xlOiBcIiArIFJvbGVzLnVzZXJJc0luUm9sZShNZXRlb3IudXNlcklkKCksIFsnT3duZXInXSkpO1xyXG5cdFx0Ly8gaWYgKCF0aGlzLmhhc1JvbGUodXNlcklkLCByb2xlKSkgXHJcblx0XHQvLyB7XHJcblx0XHRcdC8vIC8vdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcclxuXHRcdFx0Ly8gcmV0dXJuIDA7XHJcblx0XHQvLyB9IGVsc2VcclxuXHRcdC8vIHtcclxuXHRcdFx0Ly8gLy9jb25zb2xlLmxvZyhcInVzZXJJZCBcIiArIE1ldGVvci51c2VySWQoKSArIFwiIGhhc1JvbGUgMFwiICsgUm9sZXMuZ2V0Um9sZXNGb3JVc2VyKCBNZXRlb3IudXNlcklkKCkgKSk7XHRcclxuXHRcdFx0Ly8gcmV0dXJuIDE7XHJcblx0XHQvLyB9XHJcblx0XHRcclxuXHRcdHJldHVybiAxO1xyXG5cdFx0XHJcbiAgICB9XHJcblxyXG4gICAgc3RhdGljIGhhc1JvbGUodXNlcklkLCByb2xlKSB7XHJcbiAgICAgICAgcmV0dXJuIFJvbGVzLnVzZXJJc0luUm9sZShNZXRlb3IudXNlcklkKCksIHJvbGUpO1xyXG4gICAgfVxyXG5cclxuICAgIHN0YXRpYyBjaGVja0xvZ2dlZEluKHVzZXJJZCkge1xyXG4gICAgICAgIGlmICghdXNlcklkKSB7XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJywgJ1lvdSBhcmUgbm90IGF1dGhvcml6ZWQnKTtcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICAvLyBhZGQgb3RoZXIgYnVzaW5lc3MgbG9naWMgY2hlY2tzIGhlcmUgdGhhdCB5b3UgdXNlIHRocm91Z2hvdXQgdGhlIGFwcFxyXG4gICAgLy8gc29tZXRoaW5nIGxpa2U6IGlzVXNlckFsbG93ZWRUb1NlZURvY3VtZW50KClcclxuICAgIC8vIGFsd2F5cyBrZWVwIGRlY291cGxpbmcgeW91ciBjb2RlIGlmIHRoaXMgY2xhc3MgZ2V0cyBodWdlLlxyXG59XHJcblxyXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XHJcblx0TWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuXHQgIGFzeW5jICdnZXRDdXJyZW50VXNlcicoKSB7XHJcblx0XHR2YXIgbG9nZ2VkSW5Vc2VyID0gTWV0ZW9yLnVzZXIoKTtcclxuXHRcdGlmKGxvZ2dlZEluVXNlcilcclxuXHRcdHtcclxuXHRcdFx0cmV0dXJuIGxvZ2dlZEluVXNlcjtcclxuXHRcdH1cclxuXHRcdGVsc2VcclxuXHRcdHtcclxuXHRcdFx0cmV0dXJuIFwiXCI7XHJcblx0XHR9XHJcblx0ICB9LFxyXG5cclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHQgIFxyXG5cdCAgYXN5bmMgJ2NoZWNrUm9sZXNOJygpIHtcclxuXHRcdFx0dmFyIGxvZ2dlZEluVXNlciA9IE1ldGVvci51c2VyKCk7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwibG9nZ2VkSW5Vc2VyOiBcIixsb2dnZWRJblVzZXIpO1xyXG5cdCAgXHJcblx0XHRcdGlmIChSb2xlcy51c2VySXNJblJvbGUobG9nZ2VkSW5Vc2VyLCBbJ093bmVyJywgJ0FkbWluaXN0cmF0b3InXSkpIHtcclxuXHRcdFx0XHRyZXR1cm4gdHJ1ZTtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcigndW5hdXRob3JpemVkJywgXCJOb3QgYXV0aG9yaXplZCB0byBjcmVhdGUgbmV3IHVzZXJzXCIpO1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcImhhc1JvbGUgXCIpO1xyXG5cclxuXHQgIH0sXHJcblx0ICBcclxuXHR9KVxyXG59IiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IFNlY3VyaXR5IGZyb20gJy4vc2VjdXJpdHknOyBcclxuXHJcbmV4cG9ydCBjb25zdCBTaGlmdGhvdXJzSW50ZXJmYWNlID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3NoaWZ0aG91cnNpbnRlcmZhY2UnKTtcclxuXHJcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcclxuXHRNZXRlb3IubWV0aG9kcyh7XHJcblx0XHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHRcdGFzeW5jICdzaGlmdGhvdXJzaW50ZXJmYWNlLmdldEVWTlNpdGVZZWFycycoKSB7XHJcblx0XHRcdHZhciBkYXRhQmxvY2sgPSBbXTtcclxuXHRcdFx0dmFyIGluZGV4ID0gMDtcclxuXHRcdFx0YXdhaXQgU2hpZnRob3Vyc0ludGVyZmFjZS5yYXdDb2xsZWN0aW9uKCkuYWdncmVnYXRlKFtcclxuXHRcdFx0XHR7XHJcblx0XHRcdFx0XHQkZ3JvdXA6IHtcclxuXHRcdFx0XHRcdFx0XCJfaWRcIjoge1xyXG5cdFx0XHRcdFx0XHRcdFwic2l0ZVwiOiBcIiRzaXRlXCIsXHJcblx0XHRcdFx0XHRcdFx0XCJ5ZWFyXCI6IFwiJHllYXJcIlxyXG5cdFx0XHRcdFx0XHR9LFxyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH0sXHJcblx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0JGxvb2t1cDpcclxuXHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0ZnJvbTogXCJzaXRlaW50ZXJmYWNlc1wiLFxyXG5cdFx0XHRcdFx0XHRsb2NhbEZpZWxkOiBcIl9pZC5zaXRlXCIsXHJcblx0XHRcdFx0XHRcdGZvcmVpZ25GaWVsZDogXCJfaWRcIixcclxuXHRcdFx0XHRcdFx0YXM6IFwiZGF0YXNpdGVcIlxyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH0sXHJcblx0XHRcdFx0eyR1bndpbmQ6IFwiJGRhdGFzaXRlXCIgfSxcclxuXHRcdFx0XHR7JHByb2plY3Q6XHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdF9pZCA6IFwiJGRhdGFzaXRlLl9pZFwiICxcclxuXHRcdFx0XHRcdFx0bnNpdGUgOlwiJGRhdGFzaXRlLmRlc2NcIiAsXHJcblx0XHRcdFx0XHRcdHllYXIgOlwiJF9pZC55ZWFyXCIgLFxyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH0sXHRcclxuXHRcdFx0XSkuZm9yRWFjaChmdW5jdGlvbihkb2MpIHtcclxuXHRcdFx0XHRkYXRhQmxvY2sucHVzaCh7XHJcblx0XHRcdFx0XHRfaWQ6IGluZGV4LFxyXG5cdFx0XHRcdFx0c2l0ZTogZG9jLl9pZCxcclxuXHRcdFx0XHRcdG5zaXRlOiBkb2MubnNpdGUsXHJcblx0XHRcdFx0XHR5ZWFyOiBkb2MueWVhcixcclxuXHRcdFx0XHR9KTtcdFx0XHRcclxuXHRcdFx0XHRpbmRleCA9IGluZGV4ICArIDFcclxuXHRcdFx0fSk7XHRcclxuXHRcdFx0cmV0dXJuIGRhdGFCbG9jaztcclxuXHRcdH0sXHRcdFxyXG5cdH0pXHJcbn1cclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQnc2hpZnRob3Vyc2ludGVyZmFjZS5nZXRkYXRhYmxvY2snKHNpdGUseWVhcikgXHJcblx0e1xyXG5cdFx0dmFyIGRhdGFCbG9jayA9IFtdXHJcblx0XHR2YXIgZXZuIFx0XHQ9IFwiTOG7l2lcIlxyXG5cdFx0dmFyIGRheUluV2VlayBcdD0gXCJM4buXaVwiXHJcblx0XHRTaGlmdGhvdXJzSW50ZXJmYWNlLmZpbmQoe1wic2l0ZVwiOnNpdGUsXCJ5ZWFyXCI6eWVhcn0sIHtzb3J0OiB7aG91clN0cjogMX19KS5mb3JFYWNoKGZ1bmN0aW9uKGRvYykge1xyXG5cdFx0XHRldm4gPSBcIkzhu5dpXCJcclxuXHRcdFx0c3dpdGNoKGRvYy5zaGlmdE51bWJlcilcclxuXHRcdFx0e1x0XHRcdFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0Y2FzZSBcIjFcIjpcclxuXHRcdFx0XHRcdGV2biA9IFwiR2nhu50gYsOsbmggdGjGsOG7nW5nXCJcclxuXHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdGNhc2UgXCIyXCI6XHJcblx0XHRcdFx0XHRldm4gPSBcIkdp4budIGNhbyDEkWnhu4NtXCJcclxuXHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdGNhc2UgXCIzXCI6XHJcblx0XHRcdFx0XHRldm4gPSBcIkdp4budIHRo4bqlcCDEkWnhu4NtXCJcclxuXHRcdFx0XHRcdGJyZWFrO1x0XHRcclxuXHRcdFx0XHRkZWZhdWx0OiBicmVhaztcclxuXHRcdFx0fVxyXG5cdFxyXG5cdFx0XHR2YXIgbnNpdGUgPSBNZXRlb3IuY2FsbCgnc2l0ZWludGVyZmFjZXMuZ2V0bmFtZScsZG9jLnNpdGUpO1xyXG5cdFx0XHRkYXRhQmxvY2sucHVzaCh7XHJcblx0XHRcdFx0X2lkXHRcdFx0OiBkb2MuX2lkLFxyXG5cdFx0XHRcdHNpdGVcdFx0OiBkb2Muc2l0ZSxcclxuXHRcdFx0XHRuc2l0ZVx0XHQ6IG5zaXRlLFxyXG5cdFx0XHRcdHllYXJcdFx0OiBkb2MueWVhcixcclxuXHRcdFx0XHRzaGlmdE51bWJlclx0OiBkb2Muc2hpZnROdW1iZXIsXHJcblx0XHRcdFx0aG91clN0clx0XHQ6IGRvYy5ob3VyU3RyLFxyXG5cdFx0XHRcdGhvdXJFbmRcdFx0OiBkb2MuaG91ckVuZFxyXG5cdFx0XHR9KTtcdFxyXG5cdFx0fSk7XHRcdFxyXG5cdFx0cmV0dXJuIGRhdGFCbG9jaztcclxuXHR9LFxyXG5cclxuXHRcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQnc2hpZnRob3Vyc2ludGVyZmFjZS5pbnNlcnQnKFx0XHRcdFxyXG5cdFx0c2l0ZSxcclxuXHRcdHllYXIsXHJcblx0XHRzaGlmdE51bWJlcixcclxuXHRcdGhvdXJTdHIsXHJcblx0XHRob3VyRW5kLFxyXG5cdFx0Y3JlYXRlRGF0ZSkgXHJcblx0e1xyXG5cdFx0aWYgKCFTZWN1cml0eS5jaGVja1JvbGUodGhpcy51c2VySWQsJ093bmVyJykpXHJcblx0XHR7XHJcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJsb2dnZWQtaW5cIixcIllvdSBhcmUgbm90IHBlcm1pdHRlZC5cIik7XHJcblx0XHR9XHJcblx0XHRlbHNlXHJcblx0XHR7XHRcdFxyXG5cdFx0XHRTaGlmdGhvdXJzSW50ZXJmYWNlLmluc2VydCh7XHRcclxuXHRcdFx0XHRzaXRlLFxyXG5cdFx0XHRcdHllYXIsXHJcblx0XHRcdFx0c2hpZnROdW1iZXIsXHJcblx0XHRcdFx0aG91clN0cixcclxuXHRcdFx0XHRob3VyRW5kLFxyXG5cdFx0XHRcdGNyZWF0ZURhdGVcclxuXHRcdFx0fSk7XHJcblx0XHR9XHJcblx0XHRyZXR1cm4gMDtcclxuXHR9LFxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFxyXG5cdCdzaGlmdGhvdXJzaW50ZXJmYWNlLnJlbW92ZScodGFza0lkKSB7XHJcblx0XHRpZiAoIVNlY3VyaXR5LmNoZWNrUm9sZSh0aGlzLnVzZXJJZCwnT3duZXInKSlcclxuXHRcdHtcclxuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcihcImxvZ2dlZC1pblwiLFwiWW91IGFyZSBub3QgcGVybWl0dGVkLlwiKTtcclxuXHRcdH1cclxuXHRcdGVsc2VcclxuXHRcdHtcclxuXHRcdFx0U2hpZnRob3Vyc0ludGVyZmFjZS5yZW1vdmUodGFza0lkKTtcclxuXHRcdH1cclxuXHR9LFxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFxyXG5cdCdzaGlmdGhvdXJzaW50ZXJmYWNlLnVwZGF0ZScoXHJcblx0XHRfaWQsXHJcblx0XHRzaXRlLFxyXG5cdFx0eWVhcixcclxuXHRcdHNoaWZ0TnVtYmVyLFxyXG5cdFx0aG91clN0cixcclxuXHRcdGhvdXJFbmQsXHJcblx0XHRjcmVhdGVEYXRlKSBcclxuXHR7XHJcblx0XHRpZiAoIVNlY3VyaXR5LmNoZWNrUm9sZSh0aGlzLnVzZXJJZCwnT3duZXInKSlcclxuXHRcdHtcclxuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcihcImxvZ2dlZC1pblwiLFwiWW91IGFyZSBub3QgcGVybWl0dGVkLlwiKTtcclxuXHRcdH1cclxuXHRcdGVsc2VcclxuXHRcdHtcclxuXHRcdFx0U2hpZnRob3Vyc0ludGVyZmFjZS51cGRhdGUoX2lkLCBcclxuXHRcdFx0XHR7ICRzZXQ6IHsgXHJcblx0XHRcdFx0XHRzaXRlLFxyXG5cdFx0XHRcdFx0eWVhcixcclxuXHRcdFx0XHRcdHNoaWZ0TnVtYmVyLFxyXG5cdFx0XHRcdFx0aG91clN0cixcclxuXHRcdFx0XHRcdGhvdXJFbmQsXHJcblx0XHRcdFx0XHRjcmVhdGVEYXRlXHJcblx0XHRcdFx0XHR9IFxyXG5cdFx0XHRcdH0pO1xyXG5cdFx0fVxyXG5cdH1cdFx0XHJcbn0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IFNlY3VyaXR5IGZyb20gJy4vc2VjdXJpdHknOyBcclxuXHJcbmV4cG9ydCBjb25zdCBTSVRFSW50ZXJmYWNlcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdzaXRlaW50ZXJmYWNlcycpO1xyXG5cclxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG5cdC8vIFRoaXMgY29kZSBvbmx5IHJ1bnMgb24gdGhlIHNlcnZlclxyXG5cdE1ldGVvci5wdWJsaXNoKCdzaXRlQ29udHJvbFN1YicsIGZ1bmN0aW9uIHNpdGVDb250cm9sU3ViKGFyZ3VtZW50c0ZpbmQpIHtcclxuXHRcdGNvbnNvbGUubG9nKFwiPT09PT09PT09PT09PT09PT09PT09PT1hcmd1bWVudHNGaW5kIFwiICsgYXJndW1lbnRzRmluZCk7XHJcblx0XHRyZXR1cm4gU0lURUludGVyZmFjZXMuZmluZChhcmd1bWVudHNGaW5kKTtcclxuXHR9KTtcclxufVxyXG4vLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQnc2l0ZWludGVyZmFjZXMuZ2V0ZGF0YWJsb2NrJygpIFxyXG5cdHtcclxuXHRcdHZhciBkYXRhQmxvY2sgPSBbXTtcclxuXHRcdFNJVEVJbnRlcmZhY2VzLmZpbmQoe30sIHtzb3J0OiB7ZGVzYzogMX19KS5mb3JFYWNoKGZ1bmN0aW9uKGRvYykge1xyXG5cdFx0XHRkYXRhQmxvY2sucHVzaCh7XHJcblx0XHRcdFx0X2lkOiBkb2MuX2lkLFxyXG5cdFx0XHRcdG5hbWU6IGRvYy5uYW1lLFxyXG5cdFx0XHRcdGRlc2M6IGRvYy5kZXNjLFxyXG5cdFx0XHRcdGRhdGFjaGFuZ2U6IGRvYy5kYXRhY2hhbmdlLFxyXG5cdFx0XHR9KTtcdFx0XHRcclxuXHRcdFx0XHJcblx0XHR9KTtcclxuXHRcdFxyXG5cdFx0cmV0dXJuIGRhdGFCbG9jaztcclxuXHR9LFxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFxyXG5cdCdzaXRlaW50ZXJmYWNlcy5nZXRkYXRhYmxvY2tMb2NhbCcoKSBcclxuXHR7XHJcblx0XHR2YXIgZGF0YUJsb2NrID0gW107XHJcblx0XHRTSVRFSW50ZXJmYWNlcy5maW5kKHt9LCB7c29ydDoge2Rlc2M6IDF9fSkuZm9yRWFjaChmdW5jdGlvbihkb2MpIHtcclxuXHRcdFx0aWYgKGRvYy5uYW1lPT1cImt1d2FuYVwiKSB7XHJcblx0XHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdFx0X2lkOiBkb2MuX2lkLFxyXG5cdFx0XHRcdFx0bmFtZTogZG9jLm5hbWUsXHJcblx0XHRcdFx0XHRkZXNjOiBkb2MuZGVzYyxcclxuXHRcdFx0XHRcdGRhdGFjaGFuZ2U6IGRvYy5kYXRhY2hhbmdlLFxyXG5cdFx0XHRcdH0pO1x0XHRcdFxyXG5cdFx0XHR9XHJcblx0XHR9KTtcclxuXHRcdFxyXG5cdFx0cmV0dXJuIGRhdGFCbG9jaztcclxuXHR9LFx0XHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHRcclxuXHQnc2l0ZWludGVyZmFjZXMuZmluZFNpdGUnKG5hbWUpIFxyXG5cdHtcdFx0XHJcblx0XHR2YXIgbmFtZVNpdGUgPSBTSVRFSW50ZXJmYWNlcy5maW5kT25lKHsgbmFtZTpuYW1lfSk7XHRcdFxyXG5cdFx0aWYgKG5hbWVTaXRlPT1udWxsKSB7XHJcblx0XHRcdHJldHVybiAwO1xyXG5cdFx0fVxyXG5cdFx0ZWxzZVxyXG5cdFx0e1xyXG5cdFx0XHRyZXR1cm4gMTtcclxuXHRcdH1cdFx0XHRcclxuXHR9LFx0XHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHRcclxuXHQnc2l0ZWludGVyZmFjZXMuZ2V0bmFtZScoaWRTaXRlKSBcclxuXHR7XHRcdFxyXG5cdFx0dmFyIG5hbWVTaXRlID0gU0lURUludGVyZmFjZXMuZmluZE9uZSh7IF9pZDppZFNpdGV9KTtcdFx0XHJcblx0XHRpZiAobmFtZVNpdGU9PW51bGwpIHtcclxuXHRcdFx0cmV0dXJuIG51bGw7XHJcblx0XHR9XHJcblx0XHRlbHNlXHJcblx0XHR7XHJcblx0XHRcdHJldHVybiBuYW1lU2l0ZS5uYW1lO1xyXG5cdFx0fVx0XHRcdFxyXG5cdH0sXHRcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQnc2l0ZWludGVyZmFjZXMuaW5zZXJ0JyhcdFx0XHJcblx0XHRuYW1lLFxyXG5cdFx0ZGF0YWNoYW5nZSxcclxuXHRcdGRlc2NcclxuXHRcdCkgXHJcblx0e1xyXG5cdFx0aWYgKCFTZWN1cml0eS5jaGVja1JvbGUodGhpcy51c2VySWQsJ093bmVyJykpXHJcblx0XHR7XHJcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJsb2dnZWQtaW5cIixcIllvdSBhcmUgbm90IHBlcm1pdHRlZC5cIik7XHJcblx0XHR9XHJcblx0XHRlbHNlXHJcblx0XHR7XHJcblx0XHRcdGlmIChTSVRFSW50ZXJmYWNlcy5maW5kT25lKHsgbmFtZTpuYW1lfSkhPW51bGwpXHJcblx0XHRcdHtcclxuXHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiRHVwbGljYXRlIFNpdGUsIFBsZWFzZSBjaGVjayBuYW1lIG9mIFNpdGUgYWdhaW5cIik7XHJcblx0XHRcdH1cclxuXHRcdFx0ZWxzZSBcclxuXHRcdFx0e1xyXG5cdFx0XHRcdFNJVEVJbnRlcmZhY2VzLmluc2VydCh7XHJcblx0XHRcdFx0XHRuYW1lLFxyXG5cdFx0XHRcdFx0ZGF0YWNoYW5nZSxcclxuXHRcdFx0XHRcdGRlc2NcclxuXHRcdFx0XHR9KTtcclxuXHRcdFx0XHRcclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cdH0sXHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0J3NpdGVpbnRlcmZhY2VzLnJlbW92ZScodGFza0lkKSBcclxuXHR7XHJcblx0XHRpZiAoIVNlY3VyaXR5LmNoZWNrUm9sZSh0aGlzLnVzZXJJZCwnT3duZXInKSlcclxuXHRcdHtcclxuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcihcImxvZ2dlZC1pblwiLFwiWW91IGFyZSBub3QgcGVybWl0dGVkLlwiKTtcclxuXHRcdH1cclxuXHRcdGVsc2VcclxuXHRcdHtcclxuXHRcdFx0U0lURUludGVyZmFjZXMucmVtb3ZlKHRhc2tJZCk7XHJcblx0XHR9XHJcblx0fSxcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQnc2l0ZWludGVyZmFjZXMudXBkYXRlJyhcclxuXHRcdF9pZCxcclxuXHRcdGRhdGFjaGFuZ2UsXHJcblx0XHRkZXNjXHJcblx0KSBcclxuXHR7XHJcblx0XHRpZiAoIVNlY3VyaXR5LmNoZWNrUm9sZSh0aGlzLnVzZXJJZCwnT3duZXInKSlcclxuXHRcdHtcclxuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcihcImxvZ2dlZC1pblwiLFwiWW91IGFyZSBub3QgcGVybWl0dGVkLlwiKTtcclxuXHRcdH1cclxuXHRcdGVsc2VcclxuXHRcdHtcclxuXHRcdFx0U0lURUludGVyZmFjZXMudXBkYXRlKF9pZCwgXHJcblx0XHRcdFx0eyAkc2V0OiB7IFxyXG5cdFx0XHRcdFx0ZGF0YWNoYW5nZSxcclxuXHRcdFx0XHRcdGRlc2NcclxuXHRcdFx0XHRcdH0gXHJcblx0XHRcdFx0fSk7XHJcblx0XHR9XHJcblx0fSxcclxuXHRcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQnc2l0ZWludGVyZmFjZXMudXBkYXRlQ29udHJvbCcoXHJcblx0XHRfaWQsXHJcblx0XHRsb2NrLFxyXG5cdFx0dHlwZUNvbnRyb2xcclxuXHQpIFxyXG5cdHtcclxuXHRcdGlmICghU2VjdXJpdHkuY2hlY2tSb2xlKHRoaXMudXNlcklkLCdPd25lcicpKVxyXG5cdFx0e1xyXG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibG9nZ2VkLWluXCIsXCJZb3UgYXJlIG5vdCBwZXJtaXR0ZWQuXCIpO1xyXG5cdFx0fVxyXG5cdFx0ZWxzZVxyXG5cdFx0e1xyXG5cdFx0XHRTSVRFSW50ZXJmYWNlcy51cGRhdGUoX2lkLCBcclxuXHRcdFx0XHR7ICRzZXQ6IHsgXHJcblx0XHRcdFx0XHRsb2NrLFxyXG5cdFx0XHRcdFx0dHlwZUNvbnRyb2xcclxuXHRcdFx0XHRcdH0gXHJcblx0XHRcdFx0fSk7XHJcblx0XHR9XHJcblx0fSxcclxuXHRcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQnc2l0ZWludGVyZmFjZXMudXBkYXRlVGFncycoXHJcblx0XHRfaWQsXHJcblx0XHR1cGRhdGUsXHJcblx0KSBcclxuXHR7XHJcblx0XHRpZiAoIVNlY3VyaXR5LmNoZWNrUm9sZSh0aGlzLnVzZXJJZCwnT3duZXInKSlcclxuXHRcdHtcclxuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcihcImxvZ2dlZC1pblwiLFwiWW91IGFyZSBub3QgcGVybWl0dGVkLlwiKTtcclxuXHRcdH1cclxuXHRcdGVsc2VcclxuXHRcdHtcclxuXHRcdFx0U0lURUludGVyZmFjZXMudXBkYXRlKF9pZCwgXHJcblx0XHRcdFx0eyAkc2V0OiB7IFxyXG5cdFx0XHRcdFx0dXBkYXRlLFxyXG5cdFx0XHRcdFx0fSBcclxuXHRcdFx0XHR9KTtcclxuXHRcdH1cclxuXHR9XHRcdFxyXG59KSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCBCaW9tYXNNYXRlcmlhbCBmcm9tICcuL2Jpb21hc21hdGVyaWFsLmpzJztcclxuXHJcbmV4cG9ydCBjb25zdCBUYWdEYXRhSGlzdG9yaWFuID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3RhZ2RhdGFoaXN0b3JpYW4nKTtcclxuXHRcclxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG5cdE1ldGVvci5tZXRob2RzKHtcdFxyXG5cdFx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cdFx0YXN5bmMgJ3RhZ2RhdGFoaXN0b3JpYW4uZ2V0QmlvbWFzSW5UaW1lJyhzdGFydFRpbWUsZW5kVGltZSkge1xyXG5cdFx0XHR2YXIgZGF0YUJsb2NrIFx0PSBbXTtcclxuXHRcdFx0dmFyIHJlc3VsdEFyciA9IFtdO1xyXG5cclxuXHRcdFx0Y29uc3QgcmVzdWx0ID0gYXdhaXQgVGFnRGF0YUhpc3Rvcmlhbi5yYXdDb2xsZWN0aW9uKCkuYWdncmVnYXRlKFtcclxuXHRcdFx0XHR7JG1hdGNoOiB7IHRpbWVzdGFtcDogeyAkZ3RlOiBzdGFydFRpbWUsICRsdGU6IGVuZFRpbWUgfSB9IH0sXHJcblx0XHRcdFx0eyRzZXQ6IHsgZGF0ZXN4OiB7ICRkYXRlVG9TdHJpbmc6IHsgZm9ybWF0OiBcIiVtLSVkICVIOiVNXCIsIGRhdGU6IHskYWRkIDogW25ldyBEYXRlKDApLCBcIiR0aW1lc3RhbXBcIl0gfSwgdGltZXpvbmU6IFwiQXNpYS9Ib19DaGlfTWluaFwiIH0gfSB9IH0sXHJcblx0XHRcdFx0eyRzZXQ6IHsgZGF0ZURpc3A6IHsgJGRhdGVUb1N0cmluZzogeyBmb3JtYXQ6IFwiJW0tJWRcIiwgZGF0ZTogeyRhZGQgOiBbbmV3IERhdGUoMCksIFwiJHRpbWVzdGFtcFwiXSB9LCB0aW1lem9uZTogXCJBc2lhL0hvX0NoaV9NaW5oXCIgfSB9IH0gfSxcclxuXHRcdFx0XHR7JHByb2plY3Q6XHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdF9pZDpcIiRkYXRlc3hcIiAsXHJcblx0XHRcdFx0XHRcdGxvYWRjZWxsMDE6IHtcclxuXHRcdFx0XHRcdFx0XHQkZmlsdGVyOiB7XHJcblx0XHRcdFx0XHRcdFx0ICAgaW5wdXQ6IFwiJGRhdGFcIixcclxuXHRcdFx0XHRcdFx0XHQgICBhczogXCJkYXRhXCIsXHJcblx0XHRcdFx0XHRcdFx0ICAgY29uZDogeyAkaW46IFsgXCIkJGRhdGEublwiLCBbMV1dfVxyXG5cdFx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0fSxcclxuXHRcdFx0XHRcdFx0bG9hZGNlbGwwMjoge1xyXG5cdFx0XHRcdFx0XHRcdCRmaWx0ZXI6IHtcclxuXHRcdFx0XHRcdFx0XHQgICBpbnB1dDogXCIkZGF0YVwiLFxyXG5cdFx0XHRcdFx0XHRcdCAgIGFzOiBcImRhdGFcIixcclxuXHRcdFx0XHRcdFx0XHQgICBjb25kOiB7ICRpbjogWyBcIiQkZGF0YS5uXCIsIFsyXV19XHJcblx0XHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHR9LFxyXG5cdFx0XHRcdFx0XHRtYXRlcmlhbDoge1xyXG5cdFx0XHRcdFx0XHRcdCRmaWx0ZXI6IHtcclxuXHRcdFx0XHRcdFx0XHQgICBpbnB1dDogXCIkZGF0YVwiLFxyXG5cdFx0XHRcdFx0XHRcdCAgIGFzOiBcImRhdGFcIixcclxuXHRcdFx0XHRcdFx0XHQgICBjb25kOiB7ICRpbjogWyBcIiQkZGF0YS5uXCIsIFszXV19XHJcblx0XHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHR9LFx0XHJcblx0XHRcdFx0XHRcdGxvOiB7XHJcblx0XHRcdFx0XHRcdFx0JGZpbHRlcjoge1xyXG5cdFx0XHRcdFx0XHRcdCAgIGlucHV0OiBcIiRkYXRhXCIsXHJcblx0XHRcdFx0XHRcdFx0ICAgYXM6IFwiZGF0YVwiLFxyXG5cdFx0XHRcdFx0XHRcdCAgIGNvbmQ6IHsgJGluOiBbIFwiJCRkYXRhLm5cIiwgWzRdXX1cclxuXHRcdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdH0sXHRcclxuXHRcdFx0XHRcdFx0dGltZTpcIiR0aW1lc3RhbXBcIiAsXHJcblx0XHRcdFx0XHRcdGRhdGVEaXNwOlwiJGRhdGVEaXNwXCIgLFxyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH0sXHJcblx0XHRcdFx0eyRzb3J0IDogeyBcInRpbWVcIjoxfSB9LFx0XHJcblx0XHRcdFx0eyRwcm9qZWN0OlxyXG5cdFx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0XHRfaWQgXHQ6XCIkX2lkXCIgLFxyXG5cdFx0XHRcdFx0XHRsb2FkY2VsbDAxXHQ6IHsgJHN1bTogXCIkbG9hZGNlbGwwMS52XCIgfSxcclxuXHRcdFx0XHRcdFx0bG9hZGNlbGwwMlx0OiB7ICRzdW06IFwiJGxvYWRjZWxsMDIudlwiIH0sXHJcblx0XHRcdFx0XHRcdG1hdGVyaWFsXHQ6IHsgJHN1bTogXCIkbWF0ZXJpYWwudlwiIH0sXHJcblx0XHRcdFx0XHRcdGxvXHRcdFx0OiB7ICRzdW06IFwiJGxvLnZcIiB9LFxyXG5cdFx0XHRcdFx0XHR0aW1lXHRcdDogXCIkdGltZVwiLFxyXG5cdFx0XHRcdFx0XHRkYXRlRGlzcCAgICA6XCIkZGF0ZURpc3BcIiAsXHJcblx0XHRcdFx0XHRcdGhvdXJzeFx0XHQ6IHsgJGhvdXI6IHtkYXRlOiB7JGFkZCA6IFtuZXcgRGF0ZSgwKSwgXCIkdGltZVwiXSB9LCB0aW1lem9uZTogXCJBc2lhL0hvX0NoaV9NaW5oXCIgfX0sXHJcblx0XHRcdFx0XHRcdG1pbnV0ZXN4XHQ6IHsgJG1pbnV0ZTogeyBkYXRlOiB7JGFkZCA6IFtuZXcgRGF0ZSgwKSwgXCIkdGltZVwiXSB9LCB0aW1lem9uZTogXCJBc2lhL0hvX0NoaV9NaW5oXCIgfX0sXHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fSxcclxuXHRcdFx0XSkuZm9yRWFjaChmdW5jdGlvbihkb2MpIHtcclxuXHRcdFx0XHRyZXN1bHRBcnIucHVzaChkb2MpO1x0XHRcdFx0XHRcclxuXHRcdFx0fSlcclxuXHJcblx0XHRcdHZhciBsb2FkY2VsbDAxUHJ2XHQ9IDA7XHJcblx0XHRcdHZhciBsb2FkY2VsbDAyUHJ2XHQ9IDA7XHJcblx0XHRcdHZhciBob3VyUHJ2XHRcdFx0PSAwO1xyXG5cdFx0XHR2YXIgZmlyc3RPZkRheVx0XHQ9IDA7XHJcblx0XHRcdHZhciB0b3RhbExDMDFIb3VyXHQ9IDA7XHJcblx0XHRcdHZhciB0b3RhbExDMDJIb3VyXHQ9IDA7XHJcblx0XHRcdHZhciB0aW1lID0gXCJcIjtcdFxyXG5cclxuXHRcdFx0dmFyIGRhdGFUaW1lID0gW107XHJcblx0XHRcdHZhciBkYXRhUmVwb3J0PVtdO1xyXG5cdFx0XHRcdFxyXG5cdFx0XHRmb3IgKHZhciBrPTA7IGsgPCByZXN1bHRBcnIubGVuZ3RoOyBrKyspXHJcblx0XHRcdHtcclxuXHRcdFx0XHRpZiAoKGZpcnN0T2ZEYXk9PTApICYmIChyZXN1bHRBcnJba10ubWludXRlc3ggPT0gNDUpICYmIChyZXN1bHRBcnJba10uaG91cnN4ID09IDUpKVxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdGhvdXJQcnZcdFx0XHQ9IHJlc3VsdEFycltrXS5ob3Vyc3hcclxuXHRcdFx0XHRcdHRpbWVcdFx0XHQ9IHJlc3VsdEFycltrXS5kYXRlRGlzcFxyXG5cdFx0XHRcdFx0bG9hZGNlbGwwMVBydlx0PSBwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMSlcdFxyXG5cdFx0XHRcdFx0bG9hZGNlbGwwMlBydlx0PSBwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMilcdFxyXG5cdFx0XHRcdFx0Zmlyc3RPZkRheVx0PSAxO1xyXG5cdFx0XHRcdH0gZWxzZSBpZiAoZmlyc3RPZkRheT09MSlcclxuXHRcdFx0XHR7XHJcblx0XHRcdFx0XHRpZiAoTWF0aC5hYnMocGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDEpIC0gbG9hZGNlbGwwMVBydik+MTAwMDApXHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdC8vXHRcdFx0XHRcclxuXHRcdFx0XHRcdH1cdFxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2VcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsTEMwMUhvdXIgPSB0b3RhbExDMDFIb3VyICsgTWF0aC5hYnMocGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDEpIC0gbG9hZGNlbGwwMVBydik7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cdFx0XHRcdFx0aWYgKE1hdGguYWJzKHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAyKSAtIGxvYWRjZWxsMDJQcnYpPjEwMDAwKVxyXG5cdFx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0XHQvL1x0XHJcblx0XHRcdFx0XHR9XHRcclxuICAgICAgICAgICAgICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0b3RhbExDMDJIb3VyID0gdG90YWxMQzAySG91ciArIE1hdGguYWJzKHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAyKSAtIGxvYWRjZWxsMDJQcnYpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cdFxyXG5cdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRpZiAoKChyZXN1bHRBcnJba10ubWludXRlc3ggPT0gNDUpICYmIChyZXN1bHRBcnJba10uaG91cnN4ID09IDUpKXx8IChrID09IHJlc3VsdEFyci5sZW5ndGgtMSkpXHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdHRvdGFsID0gIHRvdGFsTEMwMUhvdXIgKyB0b3RhbExDMDJIb3VyO1xyXG5cdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0ZGF0YVJlcG9ydC5wdXNoKFxyXG5cdFx0XHRcdFx0XHRcdHBhcnNlRmxvYXQoTnVtYmVyKHRvdGFsKS8xMDAwKS50b0ZpeGVkKDEpXHJcblx0XHRcdFx0XHRcdCk7XHJcblx0XHRcdFx0XHRcdGRhdGFUaW1lLnB1c2goXHJcblx0XHRcdFx0XHRcdFx0dGltZVxyXG5cdFx0XHRcdFx0XHQpO1xyXG5cdFx0XHRcdFx0XHR0b3RhbExDMDFIb3VyIFx0PSAwO1xyXG5cdFx0XHRcdFx0XHR0b3RhbExDMDJIb3VyIFx0PSAwO1xyXG5cdFx0XHRcdFx0XHRob3VyUHJ2XHRcdFx0PSByZXN1bHRBcnJba10uaG91cnN4XHJcblx0XHRcdFx0XHRcdHRpbWVcdFx0XHQ9IHJlc3VsdEFycltrXS5kYXRlRGlzcFx0XHRcdFx0XHJcblx0XHRcdFx0XHR9XHJcbiAgICAgICAgICAgICAgICAgICAgbG9hZGNlbGwwMVBydlx0PSBwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMSlcdFxyXG4gICAgICAgICAgICAgICAgICAgIGxvYWRjZWxsMDJQcnZcdD0gcGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDIpXHRcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdFx0XHJcblx0XHRcdGRhdGFCbG9jay5wdXNoKHtcclxuXHRcdFx0XHRfaWQ6IFwiQmlvbWFzKDEwMDBrZylcIixcclxuXHRcdFx0XHR0eXBlOiAnYmFyJyxcclxuXHRcdFx0XHRkYXRhOiBkYXRhUmVwb3J0LFxyXG5cdFx0XHRcdHRpbWU6IGRhdGFUaW1lXHJcblx0XHRcdH0pO1x0XHRcdFxyXG5cdFx0XHRyZXR1cm4gZGF0YUJsb2NrO1x0XHRcdFxyXG5cdFx0fSxcdFxyXG5cdFx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cdFx0YXN5bmMgJ3RhZ2RhdGFoaXN0b3JpYW4uZ2V0TW9udGhseVJlcG9ydDE0aCcoc3RhcnRUaW1lLGVuZFRpbWUsc2VsZWN0Qm9pbGVyKSB7XHJcblx0XHRcdHZhciBkYXRhQmxvY2sgXHQ9IFtdO1xyXG5cdFx0XHR2YXIgcmVzdWx0QXJyID0gW107XHJcblx0XHRcdC8vY29uc29sZS5sb2coXCJzdGFydFRpbWVQYXJhbSBcIiArIHN0YXJ0VGltZSArIFwiLCBlbmRUaW1lUGFyYW0gXCIgKyBlbmRUaW1lICsgXCIsIHNlbGVjdEJvaWxlciBcIiArIHNlbGVjdEJvaWxlcik7XHJcblx0XHRcdGNvbnN0IHJlc3VsdCA9IGF3YWl0IFRhZ0RhdGFIaXN0b3JpYW4ucmF3Q29sbGVjdGlvbigpLmFnZ3JlZ2F0ZShbXHJcblx0XHRcdFx0eyRtYXRjaDogeyB0aW1lc3RhbXA6IHsgJGd0ZTogc3RhcnRUaW1lLCAkbHRlOiBlbmRUaW1lIH0gfSB9LFxyXG5cdFx0XHRcdHskc2V0OiB7IGRhdGVzeDogeyAkZGF0ZVRvU3RyaW5nOiB7IGZvcm1hdDogXCIlbS0lZCAlSDolTVwiLCBkYXRlOiB7JGFkZCA6IFtuZXcgRGF0ZSgwKSwgXCIkdGltZXN0YW1wXCJdIH0sIHRpbWV6b25lOiBcIkFzaWEvSG9fQ2hpX01pbmhcIiB9IH0gfSB9LFxyXG5cdFx0XHRcdHskcHJvamVjdDpcclxuXHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0X2lkOlwiJGRhdGVzeFwiICxcclxuXHRcdFx0XHRcdFx0bG9hZGNlbGwwMToge1xyXG5cdFx0XHRcdFx0XHRcdCRmaWx0ZXI6IHtcclxuXHRcdFx0XHRcdFx0XHQgICBpbnB1dDogXCIkZGF0YVwiLFxyXG5cdFx0XHRcdFx0XHRcdCAgIGFzOiBcImRhdGFcIixcclxuXHRcdFx0XHRcdFx0XHQgICBjb25kOiB7ICRpbjogWyBcIiQkZGF0YS5uXCIsIFsxXV19XHJcblx0XHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHR9LFxyXG5cdFx0XHRcdFx0XHRsb2FkY2VsbDAyOiB7XHJcblx0XHRcdFx0XHRcdFx0JGZpbHRlcjoge1xyXG5cdFx0XHRcdFx0XHRcdCAgIGlucHV0OiBcIiRkYXRhXCIsXHJcblx0XHRcdFx0XHRcdFx0ICAgYXM6IFwiZGF0YVwiLFxyXG5cdFx0XHRcdFx0XHRcdCAgIGNvbmQ6IHsgJGluOiBbIFwiJCRkYXRhLm5cIiwgWzJdXX1cclxuXHRcdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdH0sXHJcblx0XHRcdFx0XHRcdG1hdGVyaWFsOiB7XHJcblx0XHRcdFx0XHRcdFx0JGZpbHRlcjoge1xyXG5cdFx0XHRcdFx0XHRcdCAgIGlucHV0OiBcIiRkYXRhXCIsXHJcblx0XHRcdFx0XHRcdFx0ICAgYXM6IFwiZGF0YVwiLFxyXG5cdFx0XHRcdFx0XHRcdCAgIGNvbmQ6IHsgJGluOiBbIFwiJCRkYXRhLm5cIiwgWzNdXX1cclxuXHRcdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdH0sXHRcclxuXHRcdFx0XHRcdFx0bG86IHtcclxuXHRcdFx0XHRcdFx0XHQkZmlsdGVyOiB7XHJcblx0XHRcdFx0XHRcdFx0ICAgaW5wdXQ6IFwiJGRhdGFcIixcclxuXHRcdFx0XHRcdFx0XHQgICBhczogXCJkYXRhXCIsXHJcblx0XHRcdFx0XHRcdFx0ICAgY29uZDogeyAkaW46IFsgXCIkJGRhdGEublwiLCBbNF1dfVxyXG5cdFx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0fSxcdFxyXG5cdFx0XHRcdFx0XHR0aW1lOlwiJHRpbWVzdGFtcFwiICxcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9LFxyXG5cdFx0XHRcdHskc29ydCA6IHsgXCJ0aW1lXCI6MX0gfSxcdFxyXG5cdFx0XHRcdHskcHJvamVjdDpcclxuXHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0X2lkIFx0OlwiJF9pZFwiICxcclxuXHRcdFx0XHRcdFx0bG9hZGNlbGwwMVx0OiB7ICRzdW06IFwiJGxvYWRjZWxsMDEudlwiIH0sXHJcblx0XHRcdFx0XHRcdGxvYWRjZWxsMDJcdDogeyAkc3VtOiBcIiRsb2FkY2VsbDAyLnZcIiB9LFxyXG5cdFx0XHRcdFx0XHRtYXRlcmlhbFx0OiB7ICRzdW06IFwiJG1hdGVyaWFsLnZcIiB9LFxyXG5cdFx0XHRcdFx0XHRsb2FkXHRcdDogeyAkc3VtOiBcIiRsby52XCIgfSxcclxuXHRcdFx0XHRcdFx0dGltZVx0XHQ6IFwiJHRpbWVcIixcclxuXHRcdFx0XHRcdFx0aG91cnN4XHRcdDogeyAkaG91cjoge2RhdGU6IHskYWRkIDogW25ldyBEYXRlKDApLCBcIiR0aW1lXCJdIH0sIHRpbWV6b25lOiBcIkFzaWEvSG9fQ2hpX01pbmhcIiB9fSxcclxuXHRcdFx0XHRcdFx0bWludXRlc3hcdDogeyAkbWludXRlOiB7IGRhdGU6IHskYWRkIDogW25ldyBEYXRlKDApLCBcIiR0aW1lXCJdIH0sIHRpbWV6b25lOiBcIkFzaWEvSG9fQ2hpX01pbmhcIiB9fSxcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9LFxyXG5cdFx0XHRdKS5mb3JFYWNoKGZ1bmN0aW9uKGRvYykge1xyXG5cdFx0XHRcdHJlc3VsdEFyci5wdXNoKGRvYyk7XHRcdFx0XHRcdFxyXG5cdFx0XHR9KVxyXG5cclxuXHRcdFx0dmFyIGxvYWRjZWxsMDFQcnZcdD0gMDtcclxuXHRcdFx0dmFyIGxvYWRjZWxsMDJQcnZcdD0gMDtcclxuXHRcdFx0dmFyIGhvdXJQcnZcdFx0XHQ9IDA7XHJcblx0XHRcdHZhciBmaXJzdE9mRGF5XHRcdD0gMDtcclxuXHRcdFx0dmFyIHRvdGFsTEMwMUhvdXJcdD0gMDtcclxuXHRcdFx0dmFyIHRvdGFsTEMwMkhvdXJcdD0gMDtcclxuXHRcdFx0dmFyIHRvdGFsTEMwMVRoYW4gXHQ9IDA7IFxyXG5cdFx0XHR2YXIgdG90YWxMQzAyVGhhbiBcdD0gMDtcclxuXHRcdFx0dmFyIHRvdGFsTEMwMUJpb21hcyA9IDA7IFxyXG5cdFx0XHR2YXIgdG90YWxMQzAyQmlvbWFzID0gMDtcclxuXHRcdFx0dmFyIHRpbWUgPSBcIlwiO1x0XHJcblx0XHRcdHZhciBkYXRlVGltZSA9IDA7XHJcblx0XHRcdHZhciBsb2FkID0gMDtcdFxyXG5cdFx0XHR2YXIgZGF0ZVRpbWUgPSAwO1xyXG5cdFx0XHR2YXIgZGF0YUxDMDEgPSBbXTtcdFxyXG5cdFx0XHR2YXIgZGF0YUxDMDIgPSBbXTtcdFxyXG5cdFx0XHR2YXIgZGF0YVRpbWUgPSBbXTtcclxuXHRcdFx0dmFyIGRhdGFSZXBvcnQ9W107XHJcblx0XHRcdHZhciB0b3RhbDAxbG8xID0gMDtcclxuXHRcdFx0dmFyIHRvdGFsMDFsbzIgPSAwO1xyXG5cdFx0XHR2YXIgdG90YWwwMmxvMSA9IDA7XHJcblx0XHRcdHZhciB0b3RhbDAybG8yID0gMDtcclxuXHRcdFx0dmFyIHRvdGFsMDNsbzEgPSAwO1xyXG5cdFx0XHR2YXIgdG90YWwwM2xvMiA9IDA7XHJcblx0XHRcdHZhciB0b3RhbDA0bG8xID0gMDtcclxuXHRcdFx0dmFyIHRvdGFsMDRsbzIgPSAwO1xyXG5cdFx0XHRcdFxyXG5cdFx0XHRmb3IgKHZhciBrPTA7IGsgPCByZXN1bHRBcnIubGVuZ3RoOyBrKyspXHJcblx0XHRcdHtcclxuXHRcdFx0XHRpZiAoKGZpcnN0T2ZEYXk9PTApICYmIChyZXN1bHRBcnJba10ubWludXRlc3ggPT0gMCkgJiYgKHJlc3VsdEFycltrXS5ob3Vyc3ggPT0gMTQpKVxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdGhvdXJQcnZcdFx0XHQ9IHJlc3VsdEFycltrXS5ob3Vyc3hcclxuXHRcdFx0XHRcdHRpbWVcdFx0XHQ9IHJlc3VsdEFycltrXS5faWRcclxuXHRcdFx0XHRcdGRhdGVUaW1lXHRcdD0gcmVzdWx0QXJyW2tdLnRpbWVcclxuXHRcdFx0XHRcdG1hdGVyaWFsXHRcdD0gcGFyc2VJbnQocmVzdWx0QXJyW2tdLm1hdGVyaWFsKVxyXG5cdFx0XHRcdFx0bG9hZFx0XHRcdD0gcGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWQpXHJcblx0XHRcdFx0XHRsb2FkY2VsbDAxUHJ2XHQ9IHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAxKVx0XHJcblx0XHRcdFx0XHRsb2FkY2VsbDAyUHJ2XHQ9IHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAyKVx0XHJcblx0XHRcdFx0XHRmaXJzdE9mRGF5XHQ9IDE7XHJcblx0XHRcdFx0fSBlbHNlIGlmIChmaXJzdE9mRGF5PT0xKVxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdHRvdGFsTEMwMUhvdXIgPSB0b3RhbExDMDFIb3VyICsgTWF0aC5hYnMocGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDEpIC0gbG9hZGNlbGwwMVBydik7XHRcdFx0XHRcclxuXHRcdFx0XHRcdHRvdGFsTEMwMkhvdXIgPSB0b3RhbExDMDJIb3VyICsgTWF0aC5hYnMocGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDIpIC0gbG9hZGNlbGwwMlBydik7XHJcblx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdHN3aXRjaChtYXRlcmlhbClcclxuXHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0Y2FzZSAwOi8vQmlvbWFzXHJcblx0XHRcdFx0XHRcdFx0dG90YWxMQzAxQmlvbWFzID0gdG90YWxMQzAxQmlvbWFzICsgTWF0aC5hYnMocGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDEpIC0gbG9hZGNlbGwwMVBydik7XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHR0b3RhbExDMDJCaW9tYXMgPSB0b3RhbExDMDJCaW9tYXMgKyBNYXRoLmFicyhwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMikgLSBsb2FkY2VsbDAyUHJ2KTtcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRcdFx0Y2FzZSAxOi8vVGhhblxyXG5cdFx0XHRcdFx0XHRcdHRvdGFsTEMwMVRoYW4gPSB0b3RhbExDMDJUaGFuICsgTWF0aC5hYnMocGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDEpIC0gbG9hZGNlbGwwMVBydik7XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHR0b3RhbExDMDJUaGFuID0gdG90YWxMQzAyVGhhbiArIE1hdGguYWJzKHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAyKSAtIGxvYWRjZWxsMDJQcnYpO1x0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHRcdGRlZmF1bHQ6XHJcblx0XHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRzd2l0Y2gobG9hZClcclxuXHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0Y2FzZSAxOi8vTG8gMVxyXG5cdFx0XHRcdFx0XHRcdHRvdGFsMDFsbzEgPSB0b3RhbDAxbG8xICsgTWF0aC5hYnMocGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDEpIC0gbG9hZGNlbGwwMVBydik7XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHR0b3RhbDAxbG8yID0gdG90YWwwMWxvMiArIE1hdGguYWJzKHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAyKSAtIGxvYWRjZWxsMDJQcnYpO1x0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0XHRjYXNlIDI6Ly9MbyAyXHJcblx0XHRcdFx0XHRcdFx0dG90YWwwMmxvMSA9IHRvdGFsMDJsbzEgKyBNYXRoLmFicyhwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMSkgLSBsb2FkY2VsbDAxUHJ2KTtcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdHRvdGFsMDJsbzIgPSB0b3RhbDAybG8yICsgTWF0aC5hYnMocGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDIpIC0gbG9hZGNlbGwwMlBydik7XHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRcdFx0Y2FzZSAzOi8vTG8gM1xyXG5cdFx0XHRcdFx0XHRcdHRvdGFsMDNsbzEgPSB0b3RhbDAxM28xICsgTWF0aC5hYnMocGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDEpIC0gbG9hZGNlbGwwMVBydik7XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHR0b3RhbDAzbG8yID0gdG90YWwwMTNvMiArIE1hdGguYWJzKHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAyKSAtIGxvYWRjZWxsMDJQcnYpO1x0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHRcdGNhc2UgNDovL0xvIDRcclxuXHRcdFx0XHRcdFx0XHR0b3RhbDA0bG8xID0gdG90YWwwNGxvMSArIE1hdGguYWJzKHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAxKSAtIGxvYWRjZWxsMDFQcnYpO1x0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0dG90YWwwNGxvMiA9IHRvdGFsMDRsbzIgKyBNYXRoLmFicyhwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMikgLSBsb2FkY2VsbDAyUHJ2KTtcdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0XHRkZWZhdWx0OlxyXG5cdFx0XHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0fVx0XHRcdFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdGlmICgocmVzdWx0QXJyW2tdLm1pbnV0ZXN4ID09IDApICYmIChyZXN1bHRBcnJba10uaG91cnN4ID09IDE0KSlcclxuXHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0Y29uc3QgcmVzdWx0TWF0ZXJpYWwgPSBhd2FpdCBNZXRlb3IuY2FsbCgnYmlvbWFzbWF0ZXJpYWwuZ2V0TWF0ZXJpYWwnLCByZXN1bHRBcnJba10udGltZSk7XHJcblx0XHRcdFx0XHRcdGlmIChyZXN1bHRNYXRlcmlhbCAhPSBcIlwiKSB7XHJcblx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnTMOyIFThuqduZyBTw7RpIDEnOiAgdG90YWwwMWxvMSArIHRvdGFsMDFsbzIsXHRcdFx0XHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHRcdC8vICdMw7IgVOG6p25nIFPDtGkgMic6ICB0b3RhbDAybG8xICsgdG90YWwwMmxvMixcdFx0XHRcdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdFx0Ly8gJ0zDsiBU4bqnbmcgU8O0aSAzJzogIHRvdGFsMDNsbzEgKyB0b3RhbDAzbG8yLFx0XHRcdFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnTMOyIFThuqduZyBTw7RpIDQnOiAgdG90YWwwNGxvMSArIHRvdGFsMDRsbzIsXHRcdFx0XHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHR2YXIgdG90YWxBbGwgID0gdG90YWxMQzAxSG91ciArIHRvdGFsTEMwMkhvdXI7XHJcblx0XHRcdFx0XHRcdFx0dmFyIHRvdGFsID0gMDtcclxuXHRcdFx0XHRcdFx0XHRzd2l0Y2gocGFyc2VJbnQoc2VsZWN0Qm9pbGVyKSlcclxuXHRcdFx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdFx0XHRjYXNlIDA6XHJcblx0XHRcdFx0XHRcdFx0XHRcdHRvdGFsICA9IHRvdGFsTEMwMUhvdXIgKyB0b3RhbExDMDJIb3VyO1xyXG5cdFx0XHRcdFx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRcdFx0XHRcdGNhc2UgMTpcclxuXHRcdFx0XHRcdFx0XHRcdFx0dG90YWwgID0gdG90YWwwMWxvMSArIHRvdGFsMDFsbzI7XHJcblx0XHRcdFx0XHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0XHRcdFx0Y2FzZSAyOlxyXG5cdFx0XHRcdFx0XHRcdFx0XHR0b3RhbCAgPSB0b3RhbDAybG8xICsgdG90YWwwMmxvMjtcclxuXHRcdFx0XHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHRcdFx0XHRjYXNlIDM6XHJcblx0XHRcdFx0XHRcdFx0XHRcdHRvdGFsICA9IHRvdGFsMDNsbzEgKyB0b3RhbDAzbG8yO1xyXG5cdFx0XHRcdFx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRcdFx0XHRcdGNhc2UgNDpcclxuXHRcdFx0XHRcdFx0XHRcdFx0dG90YWwgID0gdG90YWwwNGxvMSArIHRvdGFsMDRsbzI7XHJcblx0XHRcdFx0XHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0XHQvLyBkYXRhUmVwb3J0LnB1c2goe1xyXG5cdFx0XHRcdFx0XHRcdFx0Ly8gJ1Ro4budaSBnaWFuJzogdGltZS5jb25jYXQoXCIgIC0gIFwiLHJlc3VsdEFycltrXS5faWQpLFxyXG5cdFx0XHRcdFx0XHRcdFx0Ly8gJ0Lhu5kgY8OibjAxJyA6dG90YWxMQzAxSG91cixcclxuXHRcdFx0XHRcdFx0XHRcdC8vICdC4buZIGPDom4wMicgOnRvdGFsTEMwMkhvdXIsXHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnVOG7lW5nJzogIHRvdGFsLFxyXG5cdFx0XHRcdFx0XHRcdFx0Ly8gJ1Thu5VuZyBUaGFuJzogdG90YWxMQzAxVGhhbiArIHRvdGFsTEMwMlRoYW4sXHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnVOG7lW5nIEJpb21hcyc6ICB0b3RhbExDMDFCaW9tYXMgKyB0b3RhbExDMDJCaW9tYXMsXHRcdFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnTMOyIFThuqduZyBTw7RpIDEnOiAgdG90YWwwMWxvMSArIHRvdGFsMDFsbzIsXHRcdFx0XHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHRcdC8vICdMw7IgVOG6p25nIFPDtGkgMic6ICB0b3RhbDAybG8xICsgdG90YWwwMmxvMixcdFx0XHRcdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdFx0Ly8gJ0zDsiBU4bqnbmcgU8O0aSAzJzogIHRvdGFsMDNsbzEgKyB0b3RhbDAzbG8yLFx0XHRcdFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnTMOyIFThuqduZyBTw7RpIDQnOiAgdG90YWwwNGxvMSArIHRvdGFsMDRsbzIsXHRcdFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnJSBD4bunaSBixINtJ1x0OiByZXN1bHRNYXRlcmlhbFswXS5jdWliYW0sXHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnQ+G7p2kgYsSDbSdcdDogcGFyc2VGbG9hdCgodG90YWwgKiBwYXJzZUZsb2F0KHJlc3VsdE1hdGVyaWFsWzBdLmN1aWJhbSkpIC8gMTAwKS50b0ZpeGVkKDEpLFxyXG5cdFx0XHRcdFx0XHRcdFx0Ly8gJyUgTcO5biBjxrBhJ1x0OiByZXN1bHRNYXRlcmlhbFswXS5tdW5jdWEsXHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnTcO5biBjxrBhJ1x0OiBwYXJzZUZsb2F0KCh0b3RhbCAqIHBhcnNlRmxvYXQocmVzdWx0TWF0ZXJpYWxbMF0ubXVuY3VhKSkgLyAxMDApLnRvRml4ZWQoMSksXHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnJSBI4bqhdCDEkWnhu4F1JzogcmVzdWx0TWF0ZXJpYWxbMF0uaGF0ZGlldSxcclxuXHRcdFx0XHRcdFx0XHRcdC8vICdI4bqhdCDEkWnhu4F1JzogcGFyc2VGbG9hdCgodG90YWwgKiBwYXJzZUZsb2F0KHJlc3VsdE1hdGVyaWFsWzBdLmhhdGRpZXUpKSAvIDEwMCkudG9GaXhlZCgxKSxcclxuXHRcdFx0XHRcdFx0XHRcdC8vICclIETEg20gYsOgbydcdDogcmVzdWx0TWF0ZXJpYWxbMF0uZGFtYmFvLFxyXG5cdFx0XHRcdFx0XHRcdFx0Ly8gJ0TEg20gYsOgbydcdDogcGFyc2VGbG9hdCgodG90YWwgKiBwYXJzZUZsb2F0KHJlc3VsdE1hdGVyaWFsWzBdLmRhbWJhbykpIC8gMTAwKS50b0ZpeGVkKDEpLFxyXG5cdFx0XHRcdFx0XHRcdFx0Ly8gJyUgVuG7jyBjw6J5IG5naGnhu4FuJzpyZXN1bHRNYXRlcmlhbFswXS5jYXluZ2hpZW4sXHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnVuG7jyBjw6J5IG5naGnhu4FuJzpwYXJzZUZsb2F0KCh0b3RhbCAqIHBhcnNlRmxvYXQocmVzdWx0TWF0ZXJpYWxbMF0uY2F5bmdoaWVuKSkgLyAxMDApLnRvRml4ZWQoMSksXHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnJSBC4buZdCB4xrDhu5tjJ1x0OiByZXN1bHRNYXRlcmlhbFswXS5ib3R4dW9jLFxyXG5cdFx0XHRcdFx0XHRcdFx0Ly8gJ0Lhu5l0IHjGsOG7m2MnXHQ6IHBhcnNlRmxvYXQoKHRvdGFsICogcGFyc2VGbG9hdChyZXN1bHRNYXRlcmlhbFswXS5ib3R4dW9jKSkgLyAxMDApLnRvRml4ZWQoMSksXHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnJSBD4bunaSDEkeG7kXQnXHQ6IHJlc3VsdE1hdGVyaWFsWzBdLmN1aWRvdCxcclxuXHRcdFx0XHRcdFx0XHRcdC8vICdD4bunaSDEkeG7kXQnXHQ6IHBhcnNlRmxvYXQoKHRvdGFsICogcGFyc2VGbG9hdChyZXN1bHRNYXRlcmlhbFswXS5jdWlkb3QpKSAvIDEwMCkudG9GaXhlZCgxKSxcclxuXHRcdFx0XHRcdFx0XHRcdC8vICclIFRy4bqldSc6IHJlc3VsdE1hdGVyaWFsWzBdLnRyYXUsXHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnVHLhuqV1JzogcGFyc2VGbG9hdCgodG90YWwgKiBwYXJzZUZsb2F0KHJlc3VsdE1hdGVyaWFsWzBdLnRyYXUpKSAvIDEwMCkudG9GaXhlZCgxKSxcclxuXHRcdFx0XHRcdFx0XHRcdC8vICclIEfDuWkgYuG6r3AnXHQ6IHJlc3VsdE1hdGVyaWFsWzBdLmd1aWJhcCxcdFx0XHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnR8O5aSBi4bqvcCdcdDogcGFyc2VGbG9hdCgodG90YWwgKiBwYXJzZUZsb2F0KHJlc3VsdE1hdGVyaWFsWzBdLmd1aWJhcCkpIC8gMTAwKS50b0ZpeGVkKDEpLFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdC8vIH0pOyBcclxuXHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHRkYXRhUmVwb3J0LnB1c2goe1xyXG5cdFx0XHRcdFx0XHRcdFx0J1Ro4budaSBnaWFuJzogdGltZS5jb25jYXQoXCIgIC0gIFwiLHJlc3VsdEFycltrXS5faWQpLFxyXG5cdFx0XHRcdFx0XHRcdFx0J0Lhu5kgY8OibjAxJyA6dG90YWxMQzAxSG91cixcclxuXHRcdFx0XHRcdFx0XHRcdCdC4buZIGPDom4wMicgOnRvdGFsTEMwMkhvdXIsXHJcblx0XHRcdFx0XHRcdFx0XHQnVOG7lW5nJzogIHRvdGFsQWxsLFxyXG5cdFx0XHRcdFx0XHRcdFx0J1Thu5VuZyBUaGFuJzogdG90YWxMQzAxVGhhbiArIHRvdGFsTEMwMlRoYW4sXHJcblx0XHRcdFx0XHRcdFx0XHQnVOG7lW5nIEJpb21hcyc6ICB0b3RhbExDMDFCaW9tYXMgKyB0b3RhbExDMDJCaW9tYXMsXHRcdFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0XHQnTMOyIFThuqduZyBTw7RpIDEnOiAgdG90YWwwMWxvMSArIHRvdGFsMDFsbzIsXHRcdFx0XHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHRcdCdMw7IgVOG6p25nIFPDtGkgMic6ICB0b3RhbDAybG8xICsgdG90YWwwMmxvMixcdFx0XHRcdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdFx0J0zDsiBU4bqnbmcgU8O0aSAzJzogIHRvdGFsMDNsbzEgKyB0b3RhbDAzbG8yLFx0XHRcdFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0XHQnTMOyIFThuqduZyBTw7RpIDQnOiAgdG90YWwwNGxvMSArIHRvdGFsMDRsbzIsXHJcblx0XHRcdFx0XHRcdFx0XHQnQ+G7p2kgYsSDbSdcdDogcGFyc2VGbG9hdCgodG90YWwgKiBwYXJzZUZsb2F0KHJlc3VsdE1hdGVyaWFsWzBdLmN1aWJhbSkpIC8gMTAwKS50b0ZpeGVkKDEpLFxyXG5cdFx0XHRcdFx0XHRcdFx0J03DuW4gY8awYSdcdDogcGFyc2VGbG9hdCgodG90YWwgKiBwYXJzZUZsb2F0KHJlc3VsdE1hdGVyaWFsWzBdLm11bmN1YSkpIC8gMTAwKS50b0ZpeGVkKDEpLFxyXG5cdFx0XHRcdFx0XHRcdFx0J0jhuqF0IMSRaeG7gXUnOiBwYXJzZUZsb2F0KCh0b3RhbCAqIHBhcnNlRmxvYXQocmVzdWx0TWF0ZXJpYWxbMF0uaGF0ZGlldSkpIC8gMTAwKS50b0ZpeGVkKDEpLFxyXG5cdFx0XHRcdFx0XHRcdFx0J0TEg20gYsOgbydcdDogcGFyc2VGbG9hdCgodG90YWwgKiBwYXJzZUZsb2F0KHJlc3VsdE1hdGVyaWFsWzBdLmRhbWJhbykpIC8gMTAwKS50b0ZpeGVkKDEpLFxyXG5cdFx0XHRcdFx0XHRcdFx0J1bhu48gY8OieSBuZ2hp4buBbic6cGFyc2VGbG9hdCgodG90YWwgKiBwYXJzZUZsb2F0KHJlc3VsdE1hdGVyaWFsWzBdLmNheW5naGllbikpIC8gMTAwKS50b0ZpeGVkKDEpLFxyXG5cdFx0XHRcdFx0XHRcdFx0J0Lhu5l0IHjGsOG7m2MnXHQ6IHBhcnNlRmxvYXQoKHRvdGFsICogcGFyc2VGbG9hdChyZXN1bHRNYXRlcmlhbFswXS5ib3R4dW9jKSkgLyAxMDApLnRvRml4ZWQoMSksXHJcblx0XHRcdFx0XHRcdFx0XHQnQ+G7p2kgxJHhu5F0J1x0OiBwYXJzZUZsb2F0KCh0b3RhbCAqIHBhcnNlRmxvYXQocmVzdWx0TWF0ZXJpYWxbMF0uY3VpZG90KSkgLyAxMDApLnRvRml4ZWQoMSksXHJcblx0XHRcdFx0XHRcdFx0XHQnVHLhuqV1JzogcGFyc2VGbG9hdCgodG90YWwgKiBwYXJzZUZsb2F0KHJlc3VsdE1hdGVyaWFsWzBdLnRyYXUpKSAvIDEwMCkudG9GaXhlZCgxKSxcclxuXHRcdFx0XHRcdFx0XHRcdCdHw7lpIGLhuq9wJ1x0OiBwYXJzZUZsb2F0KCh0b3RhbCAqIHBhcnNlRmxvYXQocmVzdWx0TWF0ZXJpYWxbMF0uZ3VpYmFwKSkgLyAxMDApLnRvRml4ZWQoMSksXHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0fSk7IFxyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdGVsc2VcclxuXHRcdFx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0XHRcdGRhdGFSZXBvcnQucHVzaCh7XHJcblx0XHRcdFx0XHRcdFx0XHQnVGjhu51pIGdpYW4nOiB0aW1lLmNvbmNhdChcIiAgLSAgXCIscmVzdWx0QXJyW2tdLl9pZCksXHJcblx0XHRcdFx0XHRcdFx0XHQnQuG7mSBjw6JuMDEnIDp0b3RhbExDMDFIb3VyLFxyXG5cdFx0XHRcdFx0XHRcdFx0J0Lhu5kgY8OibjAyJyA6dG90YWxMQzAySG91cixcclxuXHRcdFx0XHRcdFx0XHRcdCdU4buVbmcnOiAgdG90YWxBbGwsXHJcblx0XHRcdFx0XHRcdFx0XHQnVOG7lW5nIFRoYW4nOiB0b3RhbExDMDFUaGFuICsgdG90YWxMQzAyVGhhbixcclxuXHRcdFx0XHRcdFx0XHRcdCdU4buVbmcgQmlvbWFzJzogIHRvdGFsTEMwMUJpb21hcyArIHRvdGFsTEMwMkJpb21hcyxcdFx0XHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHRcdCdMw7IgVOG6p25nIFPDtGkgMSc6ICB0b3RhbDAxbG8xICsgdG90YWwwMWxvMixcdFx0XHRcdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdFx0J0zDsiBU4bqnbmcgU8O0aSAyJzogIHRvdGFsMDJsbzEgKyB0b3RhbDAybG8yLFx0XHRcdFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0XHQnTMOyIFThuqduZyBTw7RpIDMnOiAgdG90YWwwM2xvMSArIHRvdGFsMDNsbzIsXHRcdFx0XHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHRcdCdMw7IgVOG6p25nIFPDtGkgNCc6ICB0b3RhbDA0bG8xICsgdG90YWwwNGxvMixcdFxyXG5cdFx0XHRcdFx0XHRcdH0pOyBcclxuXHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0ZGF0YUxDMDEucHVzaChcclxuXHRcdFx0XHRcdFx0XHROdW1iZXIodG90YWxMQzAxSG91cilcclxuXHRcdFx0XHRcdFx0KTtcclxuXHRcdFx0XHRcdFx0ZGF0YUxDMDIucHVzaChcclxuXHRcdFx0XHRcdFx0XHROdW1iZXIodG90YWxMQzAySG91cilcclxuXHRcdFx0XHRcdFx0KTtcdFxyXG5cdFx0XHRcdFx0XHRkYXRhVGltZS5wdXNoKFxyXG5cdFx0XHRcdFx0XHRcdHRpbWVcclxuXHRcdFx0XHRcdFx0KTtcclxuXHRcdFx0XHRcdFx0dG90YWxMQzAxSG91ciBcdD0gMDtcclxuXHRcdFx0XHRcdFx0dG90YWxMQzAySG91ciBcdD0gMDtcclxuXHRcdFx0XHRcdFx0dG90YWxMQzAxVGhhbiBcdD0gMDtcclxuXHRcdFx0XHRcdFx0dG90YWxMQzAyVGhhbiBcdD0gMDtcclxuXHRcdFx0XHRcdFx0dG90YWxMQzAxQmlvbWFzIFx0PSAwO1xyXG5cdFx0XHRcdFx0XHR0b3RhbExDMDJCaW9tYXMgXHQ9IDA7XHJcblx0XHRcdFx0XHRcdHRvdGFsMDFsbzEgPSAwO1xyXG5cdFx0XHRcdFx0XHR0b3RhbDAxbG8yID0gMDtcclxuXHRcdFx0XHRcdFx0dG90YWwwMmxvMSA9IDA7XHJcblx0XHRcdFx0XHRcdHRvdGFsMDJsbzIgPSAwO1xyXG5cdFx0XHRcdFx0XHR0b3RhbDAzbG8xID0gMDtcclxuXHRcdFx0XHRcdFx0dG90YWwwM2xvMiA9IDA7XHJcblx0XHRcdFx0XHRcdHRvdGFsMDRsbzEgPSAwO1xyXG5cdFx0XHRcdFx0XHR0b3RhbDA0bG8yID0gMDtcclxuXHRcdFx0XHRcdFx0aG91clBydlx0XHRcdD0gcmVzdWx0QXJyW2tdLmhvdXJzeFxyXG5cdFx0XHRcdFx0XHR0aW1lXHRcdFx0PSByZXN1bHRBcnJba10uX2lkXHJcblx0XHRcdFx0XHRcdGRhdGVUaW1lXHRcdD0gcmVzdWx0QXJyW2tdLnRpbWVcclxuXHRcdFx0XHRcdFx0bWF0ZXJpYWxcdFx0PSBwYXJzZUludChyZXN1bHRBcnJba10ubWF0ZXJpYWwpXHJcblx0XHRcdFx0XHRcdGxvYWRcdFx0XHQ9IHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkKVxyXG5cdFx0XHRcdFx0XHRsb2FkY2VsbDAxUHJ2XHQ9IHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAxKVx0XHJcblx0XHRcdFx0XHRcdGxvYWRjZWxsMDJQcnZcdD0gcGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDIpXHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdFx0XHJcblx0XHRcdGRhdGFCbG9jay5wdXNoKHtcclxuXHRcdFx0XHRfaWQ6IFwiQuG7mSBjw6JuIDFcIixcclxuXHRcdFx0XHR0eXBlOiAnYmFyJyxcclxuXHRcdFx0XHRzdGFjazogJ1N0YWNrIDAnLFxyXG5cdFx0XHRcdGRhdGE6IGRhdGFMQzAxLFxyXG5cdFx0XHRcdHRpbWU6IGRhdGFUaW1lXHJcblx0XHRcdH0pO1x0XHJcblx0XHRcdGRhdGFCbG9jay5wdXNoKHtcclxuXHRcdFx0XHRfaWQ6IFwiQuG7mSBjw6JuIDJcIixcclxuXHRcdFx0XHR0eXBlOiAnYmFyJyxcclxuXHRcdFx0XHRzdGFjazogJ1N0YWNrIDAnLFxyXG5cdFx0XHRcdGRhdGE6IGRhdGFMQzAyLFxyXG5cdFx0XHRcdHRpbWU6IGRhdGFUaW1lXHJcblx0XHRcdH0pO1x0XHRcdFx0XHJcblx0XHRcdGRhdGFCbG9jay5wdXNoKHtcclxuXHRcdFx0XHRfaWQ6IFwiUmVwb3J0XCIsXHJcblx0XHRcdFx0ZGF0YTogZGF0YVJlcG9ydCxcclxuXHRcdFx0fSk7XHRcdFx0XHRcdFx0XHJcblx0XHRcdHJldHVybiBkYXRhQmxvY2s7XHRcdFx0XHJcblx0XHR9LFx0XHJcblx0XHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblx0XHRhc3luYyAndGFnZGF0YWhpc3Rvcmlhbi5nZXRNb250aGx5UmVwb3J0JyhzdGFydFRpbWUsZW5kVGltZSxzZWxlY3RCb2lsZXIpIHtcclxuXHRcdFx0dmFyIGRhdGFCbG9jayBcdD0gW107XHJcblx0XHRcdHZhciByZXN1bHRBcnIgPSBbXTtcclxuXHRcdFx0Ly9jb25zb2xlLmxvZyhcInN0YXJ0VGltZVBhcmFtIFwiICsgc3RhcnRUaW1lICsgXCIsIGVuZFRpbWVQYXJhbSBcIiArIGVuZFRpbWUgKyBcIiwgc2VsZWN0Qm9pbGVyIFwiICsgc2VsZWN0Qm9pbGVyKTtcclxuXHRcdFx0Y29uc3QgcmVzdWx0ID0gYXdhaXQgVGFnRGF0YUhpc3Rvcmlhbi5yYXdDb2xsZWN0aW9uKCkuYWdncmVnYXRlKFtcclxuXHRcdFx0XHR7JG1hdGNoOiB7IHRpbWVzdGFtcDogeyAkZ3RlOiBzdGFydFRpbWUsICRsdGU6IGVuZFRpbWUgfSB9IH0sXHJcblx0XHRcdFx0eyRzZXQ6IHsgZGF0ZXN4OiB7ICRkYXRlVG9TdHJpbmc6IHsgZm9ybWF0OiBcIiVtLSVkICVIOiVNXCIsIGRhdGU6IHskYWRkIDogW25ldyBEYXRlKDApLCBcIiR0aW1lc3RhbXBcIl0gfSwgdGltZXpvbmU6IFwiQXNpYS9Ib19DaGlfTWluaFwiIH0gfSB9IH0sXHJcblx0XHRcdFx0eyRzZXQ6IHsgZGF0ZURpc3A6IHsgJGRhdGVUb1N0cmluZzogeyBmb3JtYXQ6IFwiJW0tJWRcIiwgZGF0ZTogeyRhZGQgOiBbbmV3IERhdGUoMCksIFwiJHRpbWVzdGFtcFwiXSB9LCB0aW1lem9uZTogXCJBc2lhL0hvX0NoaV9NaW5oXCIgfSB9IH0gfSwgICAgICAgICAgICAgICAgXHJcblx0XHRcdFx0eyRwcm9qZWN0OlxyXG5cdFx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0XHRfaWQ6XCIkZGF0ZXN4XCIgLFxyXG5cdFx0XHRcdFx0XHRsb2FkY2VsbDAxOiB7XHJcblx0XHRcdFx0XHRcdFx0JGZpbHRlcjoge1xyXG5cdFx0XHRcdFx0XHRcdCAgIGlucHV0OiBcIiRkYXRhXCIsXHJcblx0XHRcdFx0XHRcdFx0ICAgYXM6IFwiZGF0YVwiLFxyXG5cdFx0XHRcdFx0XHRcdCAgIGNvbmQ6IHsgJGluOiBbIFwiJCRkYXRhLm5cIiwgWzFdXX1cclxuXHRcdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdH0sXHJcblx0XHRcdFx0XHRcdGxvYWRjZWxsMDI6IHtcclxuXHRcdFx0XHRcdFx0XHQkZmlsdGVyOiB7XHJcblx0XHRcdFx0XHRcdFx0ICAgaW5wdXQ6IFwiJGRhdGFcIixcclxuXHRcdFx0XHRcdFx0XHQgICBhczogXCJkYXRhXCIsXHJcblx0XHRcdFx0XHRcdFx0ICAgY29uZDogeyAkaW46IFsgXCIkJGRhdGEublwiLCBbMl1dfVxyXG5cdFx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0fSxcclxuXHRcdFx0XHRcdFx0bWF0ZXJpYWw6IHtcclxuXHRcdFx0XHRcdFx0XHQkZmlsdGVyOiB7XHJcblx0XHRcdFx0XHRcdFx0ICAgaW5wdXQ6IFwiJGRhdGFcIixcclxuXHRcdFx0XHRcdFx0XHQgICBhczogXCJkYXRhXCIsXHJcblx0XHRcdFx0XHRcdFx0ICAgY29uZDogeyAkaW46IFsgXCIkJGRhdGEublwiLCBbM11dfVxyXG5cdFx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0fSxcdFxyXG5cdFx0XHRcdFx0XHRsbzoge1xyXG5cdFx0XHRcdFx0XHRcdCRmaWx0ZXI6IHtcclxuXHRcdFx0XHRcdFx0XHQgICBpbnB1dDogXCIkZGF0YVwiLFxyXG5cdFx0XHRcdFx0XHRcdCAgIGFzOiBcImRhdGFcIixcclxuXHRcdFx0XHRcdFx0XHQgICBjb25kOiB7ICRpbjogWyBcIiQkZGF0YS5uXCIsIFs0XV19XHJcblx0XHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHR9LFx0XHJcblx0XHRcdFx0XHRcdHRpbWU6XCIkdGltZXN0YW1wXCIgLFxyXG5cdFx0XHRcdFx0XHRkYXRlRGlzcDpcIiRkYXRlRGlzcFwiICxcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9LFxyXG5cdFx0XHRcdHskc29ydCA6IHsgXCJ0aW1lXCI6MX0gfSxcdFxyXG5cdFx0XHRcdHskcHJvamVjdDpcclxuXHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0X2lkIFx0OlwiJF9pZFwiICxcclxuXHRcdFx0XHRcdFx0bG9hZGNlbGwwMVx0OiB7ICRzdW06IFwiJGxvYWRjZWxsMDEudlwiIH0sXHJcblx0XHRcdFx0XHRcdGxvYWRjZWxsMDJcdDogeyAkc3VtOiBcIiRsb2FkY2VsbDAyLnZcIiB9LFxyXG5cdFx0XHRcdFx0XHRtYXRlcmlhbFx0OiB7ICRzdW06IFwiJG1hdGVyaWFsLnZcIiB9LFxyXG5cdFx0XHRcdFx0XHRsb2FkXHRcdDogeyAkc3VtOiBcIiRsby52XCIgfSxcclxuXHRcdFx0XHRcdFx0dGltZVx0XHQ6IFwiJHRpbWVcIixcclxuXHRcdFx0XHRcdFx0ZGF0ZURpc3A6XCIkZGF0ZURpc3BcIiAsXHJcblx0XHRcdFx0XHRcdGhvdXJzeFx0XHQ6IHsgJGhvdXI6IHtkYXRlOiB7JGFkZCA6IFtuZXcgRGF0ZSgwKSwgXCIkdGltZVwiXSB9LCB0aW1lem9uZTogXCJBc2lhL0hvX0NoaV9NaW5oXCIgfX0sXHJcblx0XHRcdFx0XHRcdG1pbnV0ZXN4XHQ6IHsgJG1pbnV0ZTogeyBkYXRlOiB7JGFkZCA6IFtuZXcgRGF0ZSgwKSwgXCIkdGltZVwiXSB9LCB0aW1lem9uZTogXCJBc2lhL0hvX0NoaV9NaW5oXCIgfX0sXHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fSxcclxuXHRcdFx0XSkuZm9yRWFjaChmdW5jdGlvbihkb2MpIHtcclxuXHRcdFx0XHRyZXN1bHRBcnIucHVzaChkb2MpO1x0XHRcdFx0XHRcclxuXHRcdFx0fSlcclxuXHJcblx0XHRcdHZhciBsb2FkY2VsbDAxUHJ2XHQ9IDA7XHJcblx0XHRcdHZhciBsb2FkY2VsbDAyUHJ2XHQ9IDA7XHJcblx0XHRcdHZhciBob3VyUHJ2XHRcdFx0PSAwO1xyXG5cdFx0XHR2YXIgZmlyc3RPZkRheVx0XHQ9IDA7XHJcblx0XHRcdHZhciB0b3RhbExDMDFIb3VyXHQ9IDA7XHJcblx0XHRcdHZhciB0b3RhbExDMDJIb3VyXHQ9IDA7XHJcblx0XHRcdHZhciB0b3RhbExDMDFUaGFuIFx0PSAwOyBcclxuXHRcdFx0dmFyIHRvdGFsTEMwMlRoYW4gXHQ9IDA7XHJcblx0XHRcdHZhciB0b3RhbExDMDFCaW9tYXMgPSAwOyBcclxuXHRcdFx0dmFyIHRvdGFsTEMwMkJpb21hcyA9IDA7XHJcblx0XHRcdHZhciB0aW1lID0gXCJcIjtcdFxyXG5cdFx0XHR2YXIgZGF0ZVRpbWUgPSAwO1xyXG5cdFx0XHR2YXIgbG9hZCA9IDA7XHRcclxuXHRcdFx0dmFyIGRhdGVUaW1lID0gMDtcclxuXHRcdFx0dmFyIGRhdGFMQzAxID0gW107XHRcclxuXHRcdFx0dmFyIGRhdGFMQzAyID0gW107XHRcclxuXHRcdFx0dmFyIGRhdGFUaW1lID0gW107XHJcblx0XHRcdHZhciBkYXRhUmVwb3J0PVtdO1xyXG5cdFx0XHR2YXIgdG90YWwwMWxvMSA9IDA7XHJcblx0XHRcdHZhciB0b3RhbDAxbG8yID0gMDtcclxuXHRcdFx0dmFyIHRvdGFsMDJsbzEgPSAwO1xyXG5cdFx0XHR2YXIgdG90YWwwMmxvMiA9IDA7XHJcblx0XHRcdHZhciB0b3RhbDAzbG8xID0gMDtcclxuXHRcdFx0dmFyIHRvdGFsMDNsbzIgPSAwO1xyXG5cdFx0XHR2YXIgdG90YWwwNGxvMSA9IDA7XHJcblx0XHRcdHZhciB0b3RhbDA0bG8yID0gMDtcclxuICAgICAgICAgICAgdmFyIGRhdGVEaXNwID0gXCJcIlxyXG5cdFx0XHRcdFxyXG5cdFx0XHRmb3IgKHZhciBrPTA7IGsgPCByZXN1bHRBcnIubGVuZ3RoOyBrKyspXHJcblx0XHRcdHtcclxuXHRcdFx0XHRpZiAoKGZpcnN0T2ZEYXk9PTApICYmIChyZXN1bHRBcnJba10ubWludXRlc3ggPT0gNDUpICYmIChyZXN1bHRBcnJba10uaG91cnN4ID09IDUpKVxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdGhvdXJQcnZcdFx0XHQ9IHJlc3VsdEFycltrXS5ob3Vyc3hcclxuXHRcdFx0XHRcdHRpbWVcdFx0XHQ9IHJlc3VsdEFycltrXS5faWRcclxuXHRcdFx0XHRcdGRhdGVUaW1lXHRcdD0gcmVzdWx0QXJyW2tdLnRpbWVcclxuXHRcdFx0XHRcdGRhdGVEaXNwXHRcdD0gcmVzdWx0QXJyW2tdLmRhdGVEaXNwXHJcblx0XHRcdFx0XHRtYXRlcmlhbFx0XHQ9IHBhcnNlSW50KHJlc3VsdEFycltrXS5tYXRlcmlhbClcclxuXHRcdFx0XHRcdGxvYWRcdFx0XHQ9IHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkKVxyXG5cdFx0XHRcdFx0bG9hZGNlbGwwMVBydlx0PSBwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMSlcdFxyXG5cdFx0XHRcdFx0bG9hZGNlbGwwMlBydlx0PSBwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMilcdFxyXG5cdFx0XHRcdFx0Zmlyc3RPZkRheVx0PSAxO1xyXG5cdFx0XHRcdH0gZWxzZSBpZiAoZmlyc3RPZkRheT09MSlcclxuXHRcdFx0XHR7XHJcblxyXG5cdFx0XHRcdFx0aWYgKE1hdGguYWJzKHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAxKSAtIGxvYWRjZWxsMDFQcnYpPjEwMDAwKVxyXG5cdFx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0XHQvL1x0XHRcdFx0XHJcblx0XHRcdFx0XHR9XHRcclxuICAgICAgICAgICAgICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0b3RhbExDMDFIb3VyID0gdG90YWxMQzAxSG91ciArIE1hdGguYWJzKHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAxKSAtIGxvYWRjZWxsMDFQcnYpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzd2l0Y2gobWF0ZXJpYWwpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMDovL0Jpb21hc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsTEMwMUJpb21hcyA9IHRvdGFsTEMwMUJpb21hcyArIE1hdGguYWJzKHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAxKSAtIGxvYWRjZWxsMDFQcnYpO1x0XHRcdFx0XHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMTovL1RoYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3RhbExDMDFUaGFuID0gdG90YWxMQzAyVGhhbiArIE1hdGguYWJzKHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAxKSAtIGxvYWRjZWxsMDFQcnYpO1x0XHRcdFx0XHRcdFx0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN3aXRjaChsb2FkKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIDE6Ly9MbyAxXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG90YWwwMWxvMSA9IHRvdGFsMDFsbzEgKyBNYXRoLmFicyhwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMSkgLSBsb2FkY2VsbDAxUHJ2KTtcdFx0XHRcdFx0XHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMjovL0xvIDJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3RhbDAybG8xID0gdG90YWwwMmxvMSArIE1hdGguYWJzKHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAxKSAtIGxvYWRjZWxsMDFQcnYpO1x0XHRcdFx0XHRcdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAzOi8vTG8gM1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsMDNsbzEgPSB0b3RhbDAxM28xICsgTWF0aC5hYnMocGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDEpIC0gbG9hZGNlbGwwMVBydik7XHRcdFx0XHRcdFx0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIDQ6Ly9MbyA0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG90YWwwNGxvMSA9IHRvdGFsMDRsbzEgKyBNYXRoLmFicyhwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMSkgLSBsb2FkY2VsbDAxUHJ2KTtcdFx0XHRcdFx0XHRcdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHRcdFx0XHRcdGlmIChNYXRoLmFicyhwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMikgLSBsb2FkY2VsbDAyUHJ2KT4xMDAwMClcclxuXHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0Ly9cdFxyXG5cdFx0XHRcdFx0fVx0XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdG90YWxMQzAySG91ciA9IHRvdGFsTEMwMkhvdXIgKyBNYXRoLmFicyhwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMikgLSBsb2FkY2VsbDAyUHJ2KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3dpdGNoKG1hdGVyaWFsKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIDA6Ly9CaW9tYXNcdFx0XHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3RhbExDMDJCaW9tYXMgPSB0b3RhbExDMDJCaW9tYXMgKyBNYXRoLmFicyhwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMikgLSBsb2FkY2VsbDAyUHJ2KTtcdFx0XHRcdFx0XHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMTovL1RoYW5cdFx0XHRcdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsTEMwMlRoYW4gPSB0b3RhbExDMDJUaGFuICsgTWF0aC5hYnMocGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDIpIC0gbG9hZGNlbGwwMlBydik7XHRcdFx0XHRcdFx0XHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgc3dpdGNoKGxvYWQpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMTovL0xvIDFcdFx0XHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3RhbDAxbG8yID0gdG90YWwwMWxvMiArIE1hdGguYWJzKHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAyKSAtIGxvYWRjZWxsMDJQcnYpO1x0XHRcdFx0XHRcdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAyOi8vTG8gMlx0XHRcdFx0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG90YWwwMmxvMiA9IHRvdGFsMDJsbzIgKyBNYXRoLmFicyhwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMikgLSBsb2FkY2VsbDAyUHJ2KTtcdFx0XHRcdFx0XHRcdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAzOi8vTG8gM1x0XHRcdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsMDNsbzIgPSB0b3RhbDAxM28yICsgTWF0aC5hYnMocGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDIpIC0gbG9hZGNlbGwwMlBydik7XHRcdFx0XHRcdFx0XHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgNDovL0xvIDRcdFx0XHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3RhbDA0bG8yID0gdG90YWwwNGxvMiArIE1hdGguYWJzKHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAyKSAtIGxvYWRjZWxsMDJQcnYpO1x0XHRcdFx0XHRcdFx0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9ICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgfVx0XHJcblx0XHRcdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRpZiAoKHJlc3VsdEFycltrXS5taW51dGVzeCA9PSA0NSkgJiYgKHJlc3VsdEFycltrXS5ob3Vyc3ggPT0gNSkpXHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdGNvbnN0IHJlc3VsdE1hdGVyaWFsID0gYXdhaXQgTWV0ZW9yLmNhbGwoJ2Jpb21hc21hdGVyaWFsLmdldE1hdGVyaWFsJywgcmVzdWx0QXJyW2tdLnRpbWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgdG90YWxBbGwgICAgICAgICA9IHRvdGFsTEMwMUhvdXIgKyB0b3RhbExDMDJIb3VyO1xyXG5cdFx0XHRcdFx0XHRpZiAocmVzdWx0TWF0ZXJpYWwgIT0gXCJcIikge1xyXG5cdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdFx0Ly8gJ0zDsiBU4bqnbmcgU8O0aSAxJzogIHRvdGFsMDFsbzEgKyB0b3RhbDAxbG8yLFx0XHRcdFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0XHQvLyAnTMOyIFThuqduZyBTw7RpIDInOiAgdG90YWwwMmxvMSArIHRvdGFsMDJsbzIsXHRcdFx0XHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHRcdC8vICdMw7IgVOG6p25nIFPDtGkgMyc6ICB0b3RhbDAzbG8xICsgdG90YWwwM2xvMixcdFx0XHRcdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdFx0Ly8gJ0zDsiBU4bqnbmcgU8O0aSA0JzogIHRvdGFsMDRsbzEgKyB0b3RhbDA0bG8yLFx0XHRcdFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0dmFyIHRvdGFsQWxsICA9IHRvdGFsTEMwMUhvdXIgKyB0b3RhbExDMDJIb3VyO1xyXG5cdFx0XHRcdFx0XHRcdHZhciB0b3RhbCA9IDA7XHJcblx0XHRcdFx0XHRcdFx0c3dpdGNoKHBhcnNlSW50KHNlbGVjdEJvaWxlcikpXHJcblx0XHRcdFx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0XHRcdFx0Y2FzZSAwOlxyXG5cdFx0XHRcdFx0XHRcdFx0XHR0b3RhbCAgPSB0b3RhbExDMDFIb3VyICsgdG90YWxMQzAySG91cjtcclxuXHRcdFx0XHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHRcdFx0XHRjYXNlIDE6XHJcblx0XHRcdFx0XHRcdFx0XHRcdHRvdGFsICA9IHRvdGFsMDFsbzEgKyB0b3RhbDAxbG8yO1xyXG5cdFx0XHRcdFx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRcdFx0XHRcdGNhc2UgMjpcclxuXHRcdFx0XHRcdFx0XHRcdFx0dG90YWwgID0gdG90YWwwMmxvMSArIHRvdGFsMDJsbzI7XHJcblx0XHRcdFx0XHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0XHRcdFx0Y2FzZSAzOlxyXG5cdFx0XHRcdFx0XHRcdFx0XHR0b3RhbCAgPSB0b3RhbDAzbG8xICsgdG90YWwwM2xvMjtcclxuXHRcdFx0XHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHRcdFx0XHRjYXNlIDQ6XHJcblx0XHRcdFx0XHRcdFx0XHRcdHRvdGFsICA9IHRvdGFsMDRsbzEgKyB0b3RhbDA0bG8yO1xyXG5cdFx0XHRcdFx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRcdFx0XHR9XHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHRkYXRhUmVwb3J0LnB1c2goe1xyXG5cdFx0XHRcdFx0XHRcdFx0J1Ro4budaSBnaWFuJzogdGltZS5jb25jYXQoXCIgIC0gIFwiLHJlc3VsdEFycltrXS5faWQpLFxyXG5cdFx0XHRcdFx0XHRcdFx0J0Lhu5kgY8OibjAxJyA6dG90YWxMQzAxSG91cixcclxuXHRcdFx0XHRcdFx0XHRcdCdC4buZIGPDom4wMicgOnRvdGFsTEMwMkhvdXIsXHJcblx0XHRcdFx0XHRcdFx0XHQnVOG7lW5nJzogIHRvdGFsQWxsLFxyXG5cdFx0XHRcdFx0XHRcdFx0J1Thu5VuZyBUaGFuJzogdG90YWxMQzAxVGhhbiArIHRvdGFsTEMwMlRoYW4sXHJcblx0XHRcdFx0XHRcdFx0XHQnVOG7lW5nIEJpb21hcyc6ICB0b3RhbExDMDFCaW9tYXMgKyB0b3RhbExDMDJCaW9tYXMsXHRcdFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0XHQnTMOyIFThuqduZyBTw7RpIDEnOiAgdG90YWwwMWxvMSArIHRvdGFsMDFsbzIsXHRcdFx0XHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHRcdCdMw7IgVOG6p25nIFPDtGkgMic6ICB0b3RhbDAybG8xICsgdG90YWwwMmxvMixcdFx0XHRcdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdFx0J0zDsiBU4bqnbmcgU8O0aSAzJzogIHRvdGFsMDNsbzEgKyB0b3RhbDAzbG8yLFx0XHRcdFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0XHQnTMOyIFThuqduZyBTw7RpIDQnOiAgdG90YWwwNGxvMSArIHRvdGFsMDRsbzIsXHJcblx0XHRcdFx0XHRcdFx0XHQnQ+G7p2kgYsSDbSdcdDogcGFyc2VGbG9hdCgodG90YWwgKiBwYXJzZUZsb2F0KHJlc3VsdE1hdGVyaWFsWzBdLmN1aWJhbSkpIC8gMTAwKS50b0ZpeGVkKDEpLFxyXG5cdFx0XHRcdFx0XHRcdFx0J03DuW4gY8awYSdcdDogcGFyc2VGbG9hdCgodG90YWwgKiBwYXJzZUZsb2F0KHJlc3VsdE1hdGVyaWFsWzBdLm11bmN1YSkpIC8gMTAwKS50b0ZpeGVkKDEpLFxyXG5cdFx0XHRcdFx0XHRcdFx0J0jhuqF0IMSRaeG7gXUnOiBwYXJzZUZsb2F0KCh0b3RhbCAqIHBhcnNlRmxvYXQocmVzdWx0TWF0ZXJpYWxbMF0uaGF0ZGlldSkpIC8gMTAwKS50b0ZpeGVkKDEpLFxyXG5cdFx0XHRcdFx0XHRcdFx0J0TEg20gYsOgbydcdDogcGFyc2VGbG9hdCgodG90YWwgKiBwYXJzZUZsb2F0KHJlc3VsdE1hdGVyaWFsWzBdLmRhbWJhbykpIC8gMTAwKS50b0ZpeGVkKDEpLFxyXG5cdFx0XHRcdFx0XHRcdFx0J1bhu48gY8OieSBuZ2hp4buBbic6cGFyc2VGbG9hdCgodG90YWwgKiBwYXJzZUZsb2F0KHJlc3VsdE1hdGVyaWFsWzBdLmNheW5naGllbikpIC8gMTAwKS50b0ZpeGVkKDEpLFxyXG5cdFx0XHRcdFx0XHRcdFx0J0Lhu5l0IHjGsOG7m2MnXHQ6IHBhcnNlRmxvYXQoKHRvdGFsICogcGFyc2VGbG9hdChyZXN1bHRNYXRlcmlhbFswXS5ib3R4dW9jKSkgLyAxMDApLnRvRml4ZWQoMSksXHJcblx0XHRcdFx0XHRcdFx0XHQnQ+G7p2kgxJHhu5F0J1x0OiBwYXJzZUZsb2F0KCh0b3RhbCAqIHBhcnNlRmxvYXQocmVzdWx0TWF0ZXJpYWxbMF0uY3VpZG90KSkgLyAxMDApLnRvRml4ZWQoMSksXHJcblx0XHRcdFx0XHRcdFx0XHQnVHLhuqV1JzogcGFyc2VGbG9hdCgodG90YWwgKiBwYXJzZUZsb2F0KHJlc3VsdE1hdGVyaWFsWzBdLnRyYXUpKSAvIDEwMCkudG9GaXhlZCgxKSxcclxuXHRcdFx0XHRcdFx0XHRcdCdHw7lpIGLhuq9wJ1x0OiBwYXJzZUZsb2F0KCh0b3RhbCAqIHBhcnNlRmxvYXQocmVzdWx0TWF0ZXJpYWxbMF0uZ3VpYmFwKSkgLyAxMDApLnRvRml4ZWQoMSksXHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0fSk7IFxyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdGVsc2VcclxuXHRcdFx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0XHRcdGRhdGFSZXBvcnQucHVzaCh7XHJcblx0XHRcdFx0XHRcdFx0XHQnVGjhu51pIGdpYW4nOiB0aW1lLmNvbmNhdChcIiAgLSAgXCIscmVzdWx0QXJyW2tdLl9pZCksXHJcblx0XHRcdFx0XHRcdFx0XHQnQuG7mSBjw6JuMDEnIDp0b3RhbExDMDFIb3VyLFxyXG5cdFx0XHRcdFx0XHRcdFx0J0Lhu5kgY8OibjAyJyA6dG90YWxMQzAySG91cixcclxuXHRcdFx0XHRcdFx0XHRcdCdU4buVbmcnOiAgdG90YWxBbGwsXHJcblx0XHRcdFx0XHRcdFx0XHQnVOG7lW5nIFRoYW4nOiB0b3RhbExDMDFUaGFuICsgdG90YWxMQzAyVGhhbixcclxuXHRcdFx0XHRcdFx0XHRcdCdU4buVbmcgQmlvbWFzJzogIHRvdGFsTEMwMUJpb21hcyArIHRvdGFsTEMwMkJpb21hcyxcdFx0XHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHRcdCdMw7IgVOG6p25nIFPDtGkgMSc6ICB0b3RhbDAxbG8xICsgdG90YWwwMWxvMixcdFx0XHRcdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdFx0J0zDsiBU4bqnbmcgU8O0aSAyJzogIHRvdGFsMDJsbzEgKyB0b3RhbDAybG8yLFx0XHRcdFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0XHQnTMOyIFThuqduZyBTw7RpIDMnOiAgdG90YWwwM2xvMSArIHRvdGFsMDNsbzIsXHRcdFx0XHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHRcdCdMw7IgVOG6p25nIFPDtGkgNCc6ICB0b3RhbDA0bG8xICsgdG90YWwwNGxvMixcdFxyXG5cdFx0XHRcdFx0XHRcdH0pOyBcclxuXHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0ZGF0YUxDMDEucHVzaChcclxuXHRcdFx0XHRcdFx0XHROdW1iZXIodG90YWxMQzAxSG91cilcclxuXHRcdFx0XHRcdFx0KTtcclxuXHRcdFx0XHRcdFx0ZGF0YUxDMDIucHVzaChcclxuXHRcdFx0XHRcdFx0XHROdW1iZXIodG90YWxMQzAySG91cilcclxuXHRcdFx0XHRcdFx0KTtcdFxyXG5cdFx0XHRcdFx0XHRkYXRhVGltZS5wdXNoKFxyXG5cdFx0XHRcdFx0XHRcdGRhdGVEaXNwXHJcblx0XHRcdFx0XHRcdCk7XHJcblx0XHRcdFx0XHRcdHRvdGFsTEMwMUhvdXIgXHQ9IDA7XHJcblx0XHRcdFx0XHRcdHRvdGFsTEMwMkhvdXIgXHQ9IDA7XHJcblx0XHRcdFx0XHRcdHRvdGFsTEMwMVRoYW4gXHQ9IDA7XHJcblx0XHRcdFx0XHRcdHRvdGFsTEMwMlRoYW4gXHQ9IDA7XHJcblx0XHRcdFx0XHRcdHRvdGFsTEMwMUJpb21hcyBcdD0gMDtcclxuXHRcdFx0XHRcdFx0dG90YWxMQzAyQmlvbWFzIFx0PSAwO1xyXG5cdFx0XHRcdFx0XHR0b3RhbDAxbG8xID0gMDtcclxuXHRcdFx0XHRcdFx0dG90YWwwMWxvMiA9IDA7XHJcblx0XHRcdFx0XHRcdHRvdGFsMDJsbzEgPSAwO1xyXG5cdFx0XHRcdFx0XHR0b3RhbDAybG8yID0gMDtcclxuXHRcdFx0XHRcdFx0dG90YWwwM2xvMSA9IDA7XHJcblx0XHRcdFx0XHRcdHRvdGFsMDNsbzIgPSAwO1xyXG5cdFx0XHRcdFx0XHR0b3RhbDA0bG8xID0gMDtcclxuXHRcdFx0XHRcdFx0dG90YWwwNGxvMiA9IDA7XHJcblx0XHRcdFx0XHRcdGhvdXJQcnZcdFx0XHQ9IHJlc3VsdEFycltrXS5ob3Vyc3hcclxuXHRcdFx0XHRcdFx0dGltZVx0XHRcdD0gcmVzdWx0QXJyW2tdLl9pZFxyXG5cdFx0XHRcdFx0XHRkYXRlVGltZVx0XHQ9IHJlc3VsdEFycltrXS50aW1lXHJcblx0XHRcdFx0XHRcdGRhdGVEaXNwXHRcdD0gcmVzdWx0QXJyW2tdLmRhdGVEaXNwXHJcblx0XHRcdFx0XHRcdG1hdGVyaWFsXHRcdD0gcGFyc2VJbnQocmVzdWx0QXJyW2tdLm1hdGVyaWFsKVxyXG5cdFx0XHRcdFx0XHRsb2FkXHRcdFx0PSBwYXJzZUludChyZXN1bHRBcnJba10ubG9hZClcclxuXHRcdFx0XHRcdFx0bG9hZGNlbGwwMVBydlx0PSBwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMSlcdFxyXG5cdFx0XHRcdFx0XHRsb2FkY2VsbDAyUHJ2XHQ9IHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAyKVx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdGhvdXJQcnZcdFx0XHQ9IHBhcnNlSW50KHJlc3VsdEFycltrXS5ob3Vyc3gpXHJcblx0XHRcdFx0XHRsb2FkY2VsbDAxUHJ2XHQ9IHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAxKVx0XHJcblx0XHRcdFx0XHRsb2FkY2VsbDAyUHJ2XHQ9IHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAyKVx0XHRcdFxyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0XHRcclxuXHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdF9pZDogXCJC4buZIGPDom4gMVwiLFxyXG5cdFx0XHRcdHR5cGU6ICdiYXInLFxyXG5cdFx0XHRcdHN0YWNrOiAnU3RhY2sgMCcsXHJcblx0XHRcdFx0ZGF0YTogZGF0YUxDMDEsXHJcblx0XHRcdFx0dGltZTogZGF0YVRpbWVcclxuXHRcdFx0fSk7XHRcclxuXHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdF9pZDogXCJC4buZIGPDom4gMlwiLFxyXG5cdFx0XHRcdHR5cGU6ICdiYXInLFxyXG5cdFx0XHRcdHN0YWNrOiAnU3RhY2sgMCcsXHJcblx0XHRcdFx0ZGF0YTogZGF0YUxDMDIsXHJcblx0XHRcdFx0dGltZTogZGF0YVRpbWVcclxuXHRcdFx0fSk7XHRcdFx0XHRcclxuXHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdF9pZDogXCJSZXBvcnRcIixcclxuXHRcdFx0XHRkYXRhOiBkYXRhUmVwb3J0LFxyXG5cdFx0XHR9KTtcdFx0XHRcdFx0XHRcclxuXHRcdFx0cmV0dXJuIGRhdGFCbG9jaztcdFx0XHRcclxuXHRcdH0sXHJcblx0XHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblx0XHRhc3luYyAndGFnZGF0YWhpc3Rvcmlhbi5nZXRTaGlmdFdvcmtpbmdEYWlseTE0aCcoc3RhcnRUaW1lLGVuZFRpbWUpIHtcdFx0XHJcblx0XHRcdHZhciBkYXRhQmxvY2sgXHQ9IFtdO1xyXG5cdFx0XHR2YXIgcmVzdWx0QXJyID0gW107XHJcblx0XHRcdC8vY29uc29sZS5sb2coXCJzdGFydFRpbWVQYXJhbSBcIiArIHN0YXJ0VGltZSArIFwiLCBlbmRUaW1lUGFyYW0gXCIgKyBlbmRUaW1lKTtcclxuXHRcdFx0Y29uc3QgcmVzdWx0ID0gYXdhaXQgVGFnRGF0YUhpc3Rvcmlhbi5yYXdDb2xsZWN0aW9uKCkuYWdncmVnYXRlKFtcclxuXHRcdFx0XHR7JG1hdGNoOiB7IHRpbWVzdGFtcDogeyAkZ3RlOiBzdGFydFRpbWUsICRsdGU6IGVuZFRpbWUgfSB9IH0sXHJcblx0XHRcdFx0eyRzZXQ6IHsgZGF0ZXN4OiB7ICRkYXRlVG9TdHJpbmc6IHsgZm9ybWF0OiBcIiVtLSVkICVIOiVNXCIsIGRhdGU6IHskYWRkIDogW25ldyBEYXRlKDApLCBcIiR0aW1lc3RhbXBcIl0gfSwgdGltZXpvbmU6IFwiQXNpYS9Ib19DaGlfTWluaFwiIH0gfSB9IH0sXHJcblx0XHRcdFx0eyRwcm9qZWN0OlxyXG5cdFx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0XHRfaWQ6XCIkZGF0ZXN4XCIgLFxyXG5cdFx0XHRcdFx0XHRsb2FkY2VsbDAxOiB7XHJcblx0XHRcdFx0XHRcdFx0JGZpbHRlcjoge1xyXG5cdFx0XHRcdFx0XHRcdCAgIGlucHV0OiBcIiRkYXRhXCIsXHJcblx0XHRcdFx0XHRcdFx0ICAgYXM6IFwiZGF0YVwiLFxyXG5cdFx0XHRcdFx0XHRcdCAgIGNvbmQ6IHsgJGluOiBbIFwiJCRkYXRhLm5cIiwgWzFdXX1cclxuXHRcdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdH0sXHJcblx0XHRcdFx0XHRcdGxvYWRjZWxsMDI6IHtcclxuXHRcdFx0XHRcdFx0XHQkZmlsdGVyOiB7XHJcblx0XHRcdFx0XHRcdFx0ICAgaW5wdXQ6IFwiJGRhdGFcIixcclxuXHRcdFx0XHRcdFx0XHQgICBhczogXCJkYXRhXCIsXHJcblx0XHRcdFx0XHRcdFx0ICAgY29uZDogeyAkaW46IFsgXCIkJGRhdGEublwiLCBbMl1dfVxyXG5cdFx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0fSxcdFxyXG5cdFx0XHRcdFx0XHR0aW1lOlwiJHRpbWVzdGFtcFwiICxcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9LFxyXG5cdFx0XHRcdHskc29ydCA6IHsgXCJ0aW1lXCI6MX0gfSxcdFxyXG5cdFx0XHRcdHskcHJvamVjdDpcclxuXHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0X2lkIFx0OlwiJF9pZFwiICxcclxuXHRcdFx0XHRcdFx0bG9hZGNlbGwwMVx0OiB7ICRzdW06IFwiJGxvYWRjZWxsMDEudlwiIH0sXHJcblx0XHRcdFx0XHRcdGxvYWRjZWxsMDJcdDogeyAkc3VtOiBcIiRsb2FkY2VsbDAyLnZcIiB9LFxyXG5cdFx0XHRcdFx0XHR0aW1lXHRcdDogXCIkdGltZVwiLFxyXG5cdFx0XHRcdFx0XHRob3Vyc3hcdFx0OiB7ICRob3VyOiB7ZGF0ZTogeyRhZGQgOiBbbmV3IERhdGUoMCksIFwiJHRpbWVcIl0gfSwgdGltZXpvbmU6IFwiQXNpYS9Ib19DaGlfTWluaFwiIH19LFxyXG5cdFx0XHRcdFx0XHRtaW51dGVzeFx0OiB7ICRtaW51dGU6IHsgZGF0ZTogeyRhZGQgOiBbbmV3IERhdGUoMCksIFwiJHRpbWVcIl0gfSwgdGltZXpvbmU6IFwiQXNpYS9Ib19DaGlfTWluaFwiIH19LFxyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH0sXHJcblx0XHRcdF0pLmZvckVhY2goZnVuY3Rpb24oZG9jKSB7XHJcblx0XHRcdFx0cmVzdWx0QXJyLnB1c2goZG9jKTtcdFx0XHRcdFx0XHJcblx0XHRcdH0pXHJcblxyXG5cdFx0XHR2YXIgbG9hZGNlbGwwMVBydlx0PSAwO1xyXG5cdFx0XHR2YXIgbG9hZGNlbGwwMlBydlx0PSAwO1xyXG5cdFx0XHR2YXIgaG91clBydlx0XHRcdD0gMDtcclxuXHRcdFx0dmFyIGZpcnN0T2ZEYXlcdFx0PSAwO1xyXG5cdFx0XHR2YXIgdG90YWxMQzAxXHRcdD0gMDtcclxuXHRcdFx0dmFyIHRvdGFsTEMwMlx0XHQ9IDA7XHJcblx0XHRcdHZhciB0b3RhbExDMDFIb3VyXHQ9IDA7XHJcblx0XHRcdHZhciB0b3RhbExDMDJIb3VyXHQ9IDA7XHJcblx0XHRcdHZhciB0b3RhbCA9IDA7XHJcblx0XHRcdHZhciB0aW1lID0gXCJcIjtcdFxyXG5cdFx0XHR2YXIgZGF0YUxDMDEgPSBbXTtcdFxyXG5cdFx0XHR2YXIgZGF0YUxDMDIgPSBbXTtcdFxyXG5cdFx0XHR2YXIgZGF0YVRpbWUgPSBbXTtcclxuXHRcdFx0dmFyIGRhdGFSZXBvcnQ9W107XHJcblx0XHRcdFx0XHJcblx0XHRcdGZvciAodmFyIGs9MDsgayA8IHJlc3VsdEFyci5sZW5ndGg7IGsrKylcclxuXHRcdFx0e1xyXG5cdFx0XHRcdGlmICgoZmlyc3RPZkRheT09MCkgJiYgKHJlc3VsdEFycltrXS5ob3Vyc3ggPT0gMTQpKVxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdGhvdXJQcnZcdFx0XHQ9IHJlc3VsdEFycltrXS5ob3Vyc3hcclxuXHRcdFx0XHRcdHRpbWVcdFx0XHQ9IHJlc3VsdEFycltrXS5faWRcclxuXHRcdFx0XHRcdGxvYWRjZWxsMDFQcnZcdD0gcGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDEpXHRcclxuXHRcdFx0XHRcdGxvYWRjZWxsMDJQcnZcdD0gcGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDIpXHRcclxuXHRcdFx0XHRcdGZpcnN0T2ZEYXlcdD0gMTtcclxuXHRcdFx0XHR9IGVsc2UgaWYgKGZpcnN0T2ZEYXk9PTEpXHJcblx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0Ly9pZiAocGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDEpIC0gbG9hZGNlbGwwMVBydiA+MClcclxuXHRcdFx0XHRcdC8ve1xyXG5cdFx0XHRcdFx0XHR0b3RhbExDMDFIb3VyID0gdG90YWxMQzAxSG91ciArIE1hdGguYWJzKHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAxKSAtIGxvYWRjZWxsMDFQcnYpO1x0XHRcdFx0XHJcblx0XHRcdFx0XHQvL31cdFx0XHJcblx0XHRcdFx0XHQvL2lmIChwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMikgLSBsb2FkY2VsbDAyUHJ2ID4wKVxyXG5cdFx0XHRcdFx0Ly97XHJcblx0XHRcdFx0XHRcdHRvdGFsTEMwMkhvdXIgPSB0b3RhbExDMDJIb3VyICsgTWF0aC5hYnMocGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDIpIC0gbG9hZGNlbGwwMlBydik7XHRcclxuXHRcdFx0XHRcdC8vfVxyXG5cdFx0XHRcdFx0Ly9jb25zb2xlLmxvZyhcIiwgaG91cnN4IFwiICsgcmVzdWx0QXJyW2tdLmhvdXJzeCk7XHJcblx0XHRcdFx0XHRpZiAocmVzdWx0QXJyW2tdLm1pbnV0ZXN4ID09IDApXHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdGRhdGFSZXBvcnQucHVzaCh7XHJcblx0XHRcdFx0XHRcdFx0dGltZTogdGltZS5jb25jYXQoXCIgIC0gIFwiLHJlc3VsdEFycltrXS5faWQpLFxyXG5cdFx0XHRcdFx0XHRcdHNoaWZ0OiBcIlwiLFxyXG5cdFx0XHRcdFx0XHRcdGJvY2FuMDEgOnRvdGFsTEMwMUhvdXIsXHJcblx0XHRcdFx0XHRcdFx0Ym9jYW4wMiA6dG90YWxMQzAySG91cixcclxuXHRcdFx0XHRcdFx0XHR0b3RhbCA6ICBcIlwiLFxyXG5cdFx0XHRcdFx0XHR9KTtcclxuXHRcdFx0XHRcdFx0dG90YWxMQzAxID0gdG90YWxMQzAxICsgdG90YWxMQzAxSG91cjtcclxuXHRcdFx0XHRcdFx0dG90YWxMQzAyID0gdG90YWxMQzAyICsgdG90YWxMQzAySG91cjtcclxuXHJcblx0XHRcdFx0XHRcdHRvdGFsID0gdG90YWxMQzAxICsgdG90YWxMQzAyXHJcblx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRkYXRhTEMwMS5wdXNoKFxyXG5cdFx0XHRcdFx0XHRcdE51bWJlcih0b3RhbExDMDFIb3VyKVxyXG5cdFx0XHRcdFx0XHQpO1xyXG5cdFx0XHRcdFx0XHRkYXRhTEMwMi5wdXNoKFxyXG5cdFx0XHRcdFx0XHRcdE51bWJlcih0b3RhbExDMDJIb3VyKVxyXG5cdFx0XHRcdFx0XHQpO1x0XHJcblx0XHRcdFx0XHRcdGRhdGFUaW1lLnB1c2goXHJcblx0XHRcdFx0XHRcdFx0aG91clBydlxyXG5cdFx0XHRcdFx0XHQpO1x0XHJcblx0XHRcdFx0XHRcdC8vY29uc29sZS5sb2coXCIsIGhvdXJzeCBcIiArIHJlc3VsdEFycltrXS5ob3Vyc3gpO1xyXG5cdFx0XHRcdFx0XHRpZiAocmVzdWx0QXJyW2tdLmhvdXJzeD09MjIpXHJcblx0XHRcdFx0XHRcdHtcdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdGRhdGFSZXBvcnQucHVzaCh7XHJcblx0XHRcdFx0XHRcdFx0XHR0aW1lOiAnQ2EgQ2hp4buBdSAxNGggxJHhur9uIDIwaCcsXHJcblx0XHRcdFx0XHRcdFx0XHRzaGlmdDonVOG7lW5nJyxcclxuXHRcdFx0XHRcdFx0XHRcdGJvY2FuMDEgOiB0b3RhbExDMDEsXHJcblx0XHRcdFx0XHRcdFx0XHRib2NhbjAyIDogdG90YWxMQzAyLFxyXG5cdFx0XHRcdFx0XHRcdFx0dG90YWwgOiB0b3RhbFxyXG5cdFx0XHRcdFx0XHRcdH0pO1x0XHJcblx0XHRcdFx0XHRcdFx0dG90YWxMQzAxIFx0XHQ9IDA7XHJcblx0XHRcdFx0XHRcdFx0dG90YWxMQzAyIFx0XHQ9IDA7XHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0fSBlbHNlIGlmIChyZXN1bHRBcnJba10uaG91cnN4PT02KVxyXG5cdFx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdFx0ZGF0YVJlcG9ydC5wdXNoKHtcclxuXHRcdFx0XHRcdFx0XHRcdHRpbWU6ICdDYSBU4buRaSAyMGggxJHhur9uIDZoJyxcclxuXHRcdFx0XHRcdFx0XHRcdHNoaWZ0OidU4buVbmcnLFxyXG5cdFx0XHRcdFx0XHRcdFx0Ym9jYW4wMSA6IHRvdGFsTEMwMSxcclxuXHRcdFx0XHRcdFx0XHRcdGJvY2FuMDIgOiB0b3RhbExDMDIsXHJcblx0XHRcdFx0XHRcdFx0XHR0b3RhbCA6IHRvdGFsXHJcblx0XHRcdFx0XHRcdFx0fSk7XHRcclxuXHRcdFx0XHRcdFx0XHR0b3RhbExDMDEgXHRcdD0gMDtcclxuXHRcdFx0XHRcdFx0XHR0b3RhbExDMDIgXHRcdD0gMDtcdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHR9IGlmIChyZXN1bHRBcnJba10uaG91cnN4PT0xNClcclxuXHRcdFx0XHRcdFx0e1x0XHJcblx0XHRcdFx0XHRcdFx0ZGF0YVJlcG9ydC5wdXNoKHtcclxuXHRcdFx0XHRcdFx0XHRcdHRpbWU6ICdDYSBTw6FuZyA2aCDEkeG6v24gMTRoJyxcclxuXHRcdFx0XHRcdFx0XHRcdHNoaWZ0OidU4buVbmcnLFxyXG5cdFx0XHRcdFx0XHRcdFx0Ym9jYW4wMSA6IHRvdGFsTEMwMSxcclxuXHRcdFx0XHRcdFx0XHRcdGJvY2FuMDIgOiB0b3RhbExDMDIsXHJcblx0XHRcdFx0XHRcdFx0XHR0b3RhbCA6IHRvdGFsXHJcblx0XHRcdFx0XHRcdFx0fSk7XHRcclxuXHRcdFx0XHRcdFx0XHR0b3RhbExDMDEgXHRcdD0gMDtcclxuXHRcdFx0XHRcdFx0XHR0b3RhbExDMDIgXHRcdD0gMDtcdFx0XHJcblx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0dG90YWxMQzAxSG91ciBcdD0gMDtcclxuXHRcdFx0XHRcdFx0dG90YWxMQzAySG91ciBcdD0gMDtcclxuXHRcdFx0XHRcdFx0dGltZVx0XHRcdD0gcmVzdWx0QXJyW2tdLl9pZFxyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRob3VyUHJ2XHRcdFx0PSBwYXJzZUludChyZXN1bHRBcnJba10uaG91cnN4KVxyXG5cdFx0XHRcdFx0bG9hZGNlbGwwMVBydlx0PSBwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMSlcdFxyXG5cdFx0XHRcdFx0bG9hZGNlbGwwMlBydlx0PSBwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMilcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdFx0XHJcblx0XHRcdGRhdGFCbG9jay5wdXNoKHtcclxuXHRcdFx0XHRfaWQ6IFwiQuG7mSBjw6JuIDFcIixcclxuXHRcdFx0XHR0eXBlOiAnYmFyJyxcclxuXHRcdFx0XHRzdGFjazogJ1N0YWNrIDAnLFxyXG5cdFx0XHRcdGRhdGE6IGRhdGFMQzAxLFxyXG5cdFx0XHRcdHRpbWU6IGRhdGFUaW1lXHJcblx0XHRcdH0pO1x0XHJcblx0XHRcdGRhdGFCbG9jay5wdXNoKHtcclxuXHRcdFx0XHRfaWQ6IFwiQuG7mSBjw6JuIDJcIixcclxuXHRcdFx0XHR0eXBlOiAnYmFyJyxcclxuXHRcdFx0XHRzdGFjazogJ1N0YWNrIDAnLFxyXG5cdFx0XHRcdGRhdGE6IGRhdGFMQzAyLFxyXG5cdFx0XHRcdHRpbWU6IGRhdGFUaW1lXHJcblx0XHRcdH0pO1x0XHRcdFx0XHJcblx0XHRcdGRhdGFCbG9jay5wdXNoKHtcclxuXHRcdFx0XHRfaWQ6IFwiUmVwb3J0XCIsXHJcblx0XHRcdFx0ZGF0YTogZGF0YVJlcG9ydCxcclxuXHRcdFx0fSk7XHRcdFx0XHRcdFx0XHJcblx0XHRcdHJldHVybiBkYXRhQmxvY2s7XHRcdFxyXG5cdFx0fSxcclxuXHRcdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHRcdGFzeW5jICd0YWdkYXRhaGlzdG9yaWFuLmdldFNoaWZ0V29ya2luZ0RhaWx5NWgnKHN0YXJ0VGltZSxlbmRUaW1lKSB7XHRcdFxyXG5cdFx0XHR2YXIgZGF0YUJsb2NrIFx0PSBbXTtcclxuXHRcdFx0dmFyIHJlc3VsdEFyciA9IFtdO1xyXG5cdFx0XHQvL2NvbnNvbGUubG9nKFwic3RhcnRUaW1lUGFyYW0gXCIgKyBzdGFydFRpbWUgKyBcIiwgZW5kVGltZVBhcmFtIFwiICsgZW5kVGltZSk7XHJcblx0XHRcdGNvbnN0IHJlc3VsdCA9IGF3YWl0IFRhZ0RhdGFIaXN0b3JpYW4ucmF3Q29sbGVjdGlvbigpLmFnZ3JlZ2F0ZShbXHJcblx0XHRcdFx0eyRtYXRjaDogeyB0aW1lc3RhbXA6IHsgJGd0ZTogc3RhcnRUaW1lLCAkbHRlOiBlbmRUaW1lIH0gfSB9LFxyXG5cdFx0XHRcdHskc2V0OiB7IGRhdGVzeDogeyAkZGF0ZVRvU3RyaW5nOiB7IGZvcm1hdDogXCIlbS0lZCAlSDolTVwiLCBkYXRlOiB7JGFkZCA6IFtuZXcgRGF0ZSgwKSwgXCIkdGltZXN0YW1wXCJdIH0sIHRpbWV6b25lOiBcIkFzaWEvSG9fQ2hpX01pbmhcIiB9IH0gfSB9LFxyXG5cdFx0XHRcdHskcHJvamVjdDpcclxuXHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0X2lkOlwiJGRhdGVzeFwiICxcclxuXHRcdFx0XHRcdFx0bG9hZGNlbGwwMToge1xyXG5cdFx0XHRcdFx0XHRcdCRmaWx0ZXI6IHtcclxuXHRcdFx0XHRcdFx0XHQgICBpbnB1dDogXCIkZGF0YVwiLFxyXG5cdFx0XHRcdFx0XHRcdCAgIGFzOiBcImRhdGFcIixcclxuXHRcdFx0XHRcdFx0XHQgICBjb25kOiB7ICRpbjogWyBcIiQkZGF0YS5uXCIsIFsxXV19XHJcblx0XHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHR9LFxyXG5cdFx0XHRcdFx0XHRsb2FkY2VsbDAyOiB7XHJcblx0XHRcdFx0XHRcdFx0JGZpbHRlcjoge1xyXG5cdFx0XHRcdFx0XHRcdCAgIGlucHV0OiBcIiRkYXRhXCIsXHJcblx0XHRcdFx0XHRcdFx0ICAgYXM6IFwiZGF0YVwiLFxyXG5cdFx0XHRcdFx0XHRcdCAgIGNvbmQ6IHsgJGluOiBbIFwiJCRkYXRhLm5cIiwgWzJdXX1cclxuXHRcdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdH0sXHRcclxuXHRcdFx0XHRcdFx0dGltZTpcIiR0aW1lc3RhbXBcIiAsXHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fSxcclxuXHRcdFx0XHR7JHNvcnQgOiB7IFwidGltZVwiOjF9IH0sXHRcclxuXHRcdFx0XHR7JHByb2plY3Q6XHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdF9pZCBcdDpcIiRfaWRcIiAsXHJcblx0XHRcdFx0XHRcdGxvYWRjZWxsMDFcdDogeyAkc3VtOiBcIiRsb2FkY2VsbDAxLnZcIiB9LFxyXG5cdFx0XHRcdFx0XHRsb2FkY2VsbDAyXHQ6IHsgJHN1bTogXCIkbG9hZGNlbGwwMi52XCIgfSxcclxuXHRcdFx0XHRcdFx0dGltZVx0XHQ6IFwiJHRpbWVcIixcclxuXHRcdFx0XHRcdFx0aG91cnN4XHRcdDogeyAkaG91cjoge2RhdGU6IHskYWRkIDogW25ldyBEYXRlKDApLCBcIiR0aW1lXCJdIH0sIHRpbWV6b25lOiBcIkFzaWEvSG9fQ2hpX01pbmhcIiB9fSxcclxuXHRcdFx0XHRcdFx0bWludXRlc3hcdDogeyAkbWludXRlOiB7IGRhdGU6IHskYWRkIDogW25ldyBEYXRlKDApLCBcIiR0aW1lXCJdIH0sIHRpbWV6b25lOiBcIkFzaWEvSG9fQ2hpX01pbmhcIiB9fSxcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9LFxyXG5cdFx0XHRdKS5mb3JFYWNoKGZ1bmN0aW9uKGRvYykge1xyXG5cdFx0XHRcdHJlc3VsdEFyci5wdXNoKGRvYyk7XHRcdFx0XHRcdFxyXG5cdFx0XHR9KVxyXG5cclxuXHRcdFx0dmFyIGxvYWRjZWxsMDFQcnZcdD0gMDtcclxuXHRcdFx0dmFyIGxvYWRjZWxsMDJQcnZcdD0gMDtcclxuXHRcdFx0dmFyIGhvdXJQcnZcdFx0XHQ9IDA7XHJcblx0XHRcdHZhciBmaXJzdE9mRGF5XHRcdD0gMDtcclxuXHRcdFx0dmFyIHRvdGFsTEMwMVx0XHQ9IDA7XHJcblx0XHRcdHZhciB0b3RhbExDMDJcdFx0PSAwO1xyXG5cdFx0XHR2YXIgdG90YWxMQzAxSG91clx0PSAwO1xyXG5cdFx0XHR2YXIgdG90YWxMQzAySG91clx0PSAwO1xyXG5cdFx0XHR2YXIgdG90YWwgPSAwO1xyXG5cdFx0XHR2YXIgdGltZSA9IFwiXCI7XHRcclxuXHRcdFx0dmFyIGRhdGFMQzAxID0gW107XHRcclxuXHRcdFx0dmFyIGRhdGFMQzAyID0gW107XHRcclxuXHRcdFx0dmFyIGRhdGFUaW1lID0gW107XHJcblx0XHRcdHZhciBkYXRhUmVwb3J0PVtdO1xyXG5cdFx0XHRcdFxyXG5cdFx0XHRmb3IgKHZhciBrPTA7IGsgPCByZXN1bHRBcnIubGVuZ3RoOyBrKyspXHJcblx0XHRcdHtcclxuXHRcdFx0XHRpZiAoKGZpcnN0T2ZEYXk9PTApICYmIChyZXN1bHRBcnJba10uaG91cnN4ID09IDUpJiYgKHJlc3VsdEFycltrXS5taW51dGVzeCA9PSA0NSkpXHJcblx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0aG91clBydlx0XHRcdD0gcmVzdWx0QXJyW2tdLmhvdXJzeFxyXG5cdFx0XHRcdFx0dGltZVx0XHRcdD0gcmVzdWx0QXJyW2tdLl9pZFxyXG5cdFx0XHRcdFx0bG9hZGNlbGwwMVBydlx0PSBwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMSlcdFxyXG5cdFx0XHRcdFx0bG9hZGNlbGwwMlBydlx0PSBwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMilcdFxyXG5cdFx0XHRcdFx0Zmlyc3RPZkRheVx0PSAxO1xyXG5cdFx0XHRcdH0gZWxzZSBpZiAoZmlyc3RPZkRheT09MSlcclxuXHRcdFx0XHR7ICAgICAgICAgICAgICAgIFxyXG5cdFx0XHRcdFx0aWYgKE1hdGguYWJzKHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAxKSAtIGxvYWRjZWxsMDFQcnYpPjEwMDAwKVxyXG5cdFx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0XHQvL1x0XHRcdFx0XHJcblx0XHRcdFx0XHR9XHRcclxuICAgICAgICAgICAgICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0b3RhbExDMDFIb3VyID0gdG90YWxMQzAxSG91ciArIE1hdGguYWJzKHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAxKSAtIGxvYWRjZWxsMDFQcnYpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHRcdFx0XHRcdGlmIChNYXRoLmFicyhwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMikgLSBsb2FkY2VsbDAyUHJ2KT4xMDAwMClcclxuXHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0Ly9cdFxyXG5cdFx0XHRcdFx0fVx0XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdG90YWxMQzAySG91ciA9IHRvdGFsTEMwMkhvdXIgKyBNYXRoLmFicyhwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMikgLSBsb2FkY2VsbDAyUHJ2KTtcclxuICAgICAgICAgICAgICAgICAgICB9IFxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG5cdFx0XHRcdFx0aWYgKHJlc3VsdEFycltrXS5taW51dGVzeCA9PSA0NSlcclxuXHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0ZGF0YVJlcG9ydC5wdXNoKHtcclxuXHRcdFx0XHRcdFx0XHR0aW1lOiB0aW1lLmNvbmNhdChcIiAgLSAgXCIscmVzdWx0QXJyW2tdLl9pZCksXHJcblx0XHRcdFx0XHRcdFx0c2hpZnQ6IFwiXCIsXHJcblx0XHRcdFx0XHRcdFx0Ym9jYW4wMSA6dG90YWxMQzAxSG91cixcclxuXHRcdFx0XHRcdFx0XHRib2NhbjAyIDp0b3RhbExDMDJIb3VyLFxyXG5cdFx0XHRcdFx0XHRcdHRvdGFsIDogIFwiXCIsXHJcblx0XHRcdFx0XHRcdH0pO1xyXG5cdFx0XHRcdFx0XHR0b3RhbExDMDEgPSB0b3RhbExDMDEgKyB0b3RhbExDMDFIb3VyO1xyXG5cdFx0XHRcdFx0XHR0b3RhbExDMDIgPSB0b3RhbExDMDIgKyB0b3RhbExDMDJIb3VyO1xyXG5cclxuXHRcdFx0XHRcdFx0dG90YWwgPSB0b3RhbExDMDEgKyB0b3RhbExDMDJcclxuXHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdGRhdGFMQzAxLnB1c2goXHJcblx0XHRcdFx0XHRcdFx0TnVtYmVyKHRvdGFsTEMwMUhvdXIpXHJcblx0XHRcdFx0XHRcdCk7XHJcblx0XHRcdFx0XHRcdGRhdGFMQzAyLnB1c2goXHJcblx0XHRcdFx0XHRcdFx0TnVtYmVyKHRvdGFsTEMwMkhvdXIpXHJcblx0XHRcdFx0XHRcdCk7XHRcclxuXHRcdFx0XHRcdFx0ZGF0YVRpbWUucHVzaChcclxuXHRcdFx0XHRcdFx0XHRob3VyUHJ2XHJcblx0XHRcdFx0XHRcdCk7XHRcclxuXHRcdFx0XHRcdFx0Ly9jb25zb2xlLmxvZyhcIiwgaG91cnN4IFwiICsgcmVzdWx0QXJyW2tdLmhvdXJzeCk7XHJcblx0XHRcdFx0XHRcdGlmIChyZXN1bHRBcnJba10uaG91cnN4PT0xMylcclxuXHRcdFx0XHRcdFx0e1x0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0ZGF0YVJlcG9ydC5wdXNoKHtcclxuXHRcdFx0XHRcdFx0XHRcdHRpbWU6ICdDYSAxJyxcclxuXHRcdFx0XHRcdFx0XHRcdHNoaWZ0OidU4buVbmcnLFxyXG5cdFx0XHRcdFx0XHRcdFx0Ym9jYW4wMSA6IHRvdGFsTEMwMSxcclxuXHRcdFx0XHRcdFx0XHRcdGJvY2FuMDIgOiB0b3RhbExDMDIsXHJcblx0XHRcdFx0XHRcdFx0XHR0b3RhbCA6IHRvdGFsXHJcblx0XHRcdFx0XHRcdFx0fSk7XHRcclxuXHRcdFx0XHRcdFx0XHR0b3RhbExDMDEgXHRcdD0gMDtcclxuXHRcdFx0XHRcdFx0XHR0b3RhbExDMDIgXHRcdD0gMDtcdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHR9IGVsc2UgaWYgKHJlc3VsdEFycltrXS5ob3Vyc3g9PTIxKVxyXG5cdFx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdFx0ZGF0YVJlcG9ydC5wdXNoKHtcclxuXHRcdFx0XHRcdFx0XHRcdHRpbWU6ICdDYSAyJyxcclxuXHRcdFx0XHRcdFx0XHRcdHNoaWZ0OidU4buVbmcnLFxyXG5cdFx0XHRcdFx0XHRcdFx0Ym9jYW4wMSA6IHRvdGFsTEMwMSxcclxuXHRcdFx0XHRcdFx0XHRcdGJvY2FuMDIgOiB0b3RhbExDMDIsXHJcblx0XHRcdFx0XHRcdFx0XHR0b3RhbCA6IHRvdGFsXHJcblx0XHRcdFx0XHRcdFx0fSk7XHRcclxuXHRcdFx0XHRcdFx0XHR0b3RhbExDMDEgXHRcdD0gMDtcclxuXHRcdFx0XHRcdFx0XHR0b3RhbExDMDIgXHRcdD0gMDtcdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHR9IGlmIChyZXN1bHRBcnJba10uaG91cnN4PT01KVxyXG5cdFx0XHRcdFx0XHR7XHRcclxuXHRcdFx0XHRcdFx0XHRkYXRhUmVwb3J0LnB1c2goe1xyXG5cdFx0XHRcdFx0XHRcdFx0dGltZTogJ0NhIDMnLFxyXG5cdFx0XHRcdFx0XHRcdFx0c2hpZnQ6J1Thu5VuZycsXHJcblx0XHRcdFx0XHRcdFx0XHRib2NhbjAxIDogdG90YWxMQzAxLFxyXG5cdFx0XHRcdFx0XHRcdFx0Ym9jYW4wMiA6IHRvdGFsTEMwMixcclxuXHRcdFx0XHRcdFx0XHRcdHRvdGFsIDogdG90YWxcclxuXHRcdFx0XHRcdFx0XHR9KTtcdFxyXG5cdFx0XHRcdFx0XHRcdHRvdGFsTEMwMSBcdFx0PSAwO1xyXG5cdFx0XHRcdFx0XHRcdHRvdGFsTEMwMiBcdFx0PSAwO1x0XHRcclxuXHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHR0b3RhbExDMDFIb3VyIFx0PSAwO1xyXG5cdFx0XHRcdFx0XHR0b3RhbExDMDJIb3VyIFx0PSAwO1xyXG5cdFx0XHRcdFx0XHR0aW1lXHRcdFx0PSByZXN1bHRBcnJba10uX2lkXHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdGhvdXJQcnZcdFx0XHQ9IHBhcnNlSW50KHJlc3VsdEFycltrXS5ob3Vyc3gpXHJcblx0XHRcdFx0XHRsb2FkY2VsbDAxUHJ2XHQ9IHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAxKVx0XHJcblx0XHRcdFx0XHRsb2FkY2VsbDAyUHJ2XHQ9IHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAyKVx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0XHRcclxuXHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdF9pZDogXCJC4buZIGPDom4gMVwiLFxyXG5cdFx0XHRcdHR5cGU6ICdiYXInLFxyXG5cdFx0XHRcdHN0YWNrOiAnU3RhY2sgMCcsXHJcblx0XHRcdFx0ZGF0YTogZGF0YUxDMDEsXHJcblx0XHRcdFx0dGltZTogZGF0YVRpbWVcclxuXHRcdFx0fSk7XHRcclxuXHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdF9pZDogXCJC4buZIGPDom4gMlwiLFxyXG5cdFx0XHRcdHR5cGU6ICdiYXInLFxyXG5cdFx0XHRcdHN0YWNrOiAnU3RhY2sgMCcsXHJcblx0XHRcdFx0ZGF0YTogZGF0YUxDMDIsXHJcblx0XHRcdFx0dGltZTogZGF0YVRpbWVcclxuXHRcdFx0fSk7XHRcdFx0XHRcclxuXHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdF9pZDogXCJSZXBvcnRcIixcclxuXHRcdFx0XHRkYXRhOiBkYXRhUmVwb3J0LFxyXG5cdFx0XHR9KTtcdFx0XHRcdFx0XHRcclxuXHRcdFx0cmV0dXJuIGRhdGFCbG9jaztcdFx0XHJcblx0XHR9LCAgICAgICAgIFxyXG5cdFx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cdFx0YXN5bmMgJ3RhZ2RhdGFoaXN0b3JpYW4uZ2V0U2hpZnRXb3JraW5nRGFpbHknKHN0YXJ0VGltZSxlbmRUaW1lKSB7XHRcdFxyXG5cdFx0XHR2YXIgZGF0YUJsb2NrIFx0PSBbXTtcclxuXHRcdFx0dmFyIHJlc3VsdEFyciA9IFtdO1xyXG5cdFx0XHQvL2NvbnNvbGUubG9nKFwic3RhcnRUaW1lUGFyYW0gXCIgKyBzdGFydFRpbWUgKyBcIiwgZW5kVGltZVBhcmFtIFwiICsgZW5kVGltZSk7XHJcblx0XHRcdGNvbnN0IHJlc3VsdCA9IGF3YWl0IFRhZ0RhdGFIaXN0b3JpYW4ucmF3Q29sbGVjdGlvbigpLmFnZ3JlZ2F0ZShbXHJcblx0XHRcdFx0eyRtYXRjaDogeyB0aW1lc3RhbXA6IHsgJGd0ZTogc3RhcnRUaW1lLCAkbHRlOiBlbmRUaW1lIH0gfSB9LFxyXG5cdFx0XHRcdHskc2V0OiB7IGRhdGVzeDogeyAkZGF0ZVRvU3RyaW5nOiB7IGZvcm1hdDogXCIlbS0lZCAlSDolTVwiLCBkYXRlOiB7JGFkZCA6IFtuZXcgRGF0ZSgwKSwgXCIkdGltZXN0YW1wXCJdIH0sIHRpbWV6b25lOiBcIkFzaWEvSG9fQ2hpX01pbmhcIiB9IH0gfSB9LFxyXG5cdFx0XHRcdHskcHJvamVjdDpcclxuXHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0X2lkOlwiJGRhdGVzeFwiICxcclxuXHRcdFx0XHRcdFx0bG9hZGNlbGwwMToge1xyXG5cdFx0XHRcdFx0XHRcdCRmaWx0ZXI6IHtcclxuXHRcdFx0XHRcdFx0XHQgICBpbnB1dDogXCIkZGF0YVwiLFxyXG5cdFx0XHRcdFx0XHRcdCAgIGFzOiBcImRhdGFcIixcclxuXHRcdFx0XHRcdFx0XHQgICBjb25kOiB7ICRpbjogWyBcIiQkZGF0YS5uXCIsIFsxXV19XHJcblx0XHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHR9LFxyXG5cdFx0XHRcdFx0XHRsb2FkY2VsbDAyOiB7XHJcblx0XHRcdFx0XHRcdFx0JGZpbHRlcjoge1xyXG5cdFx0XHRcdFx0XHRcdCAgIGlucHV0OiBcIiRkYXRhXCIsXHJcblx0XHRcdFx0XHRcdFx0ICAgYXM6IFwiZGF0YVwiLFxyXG5cdFx0XHRcdFx0XHRcdCAgIGNvbmQ6IHsgJGluOiBbIFwiJCRkYXRhLm5cIiwgWzJdXX1cclxuXHRcdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdH0sXHRcclxuXHRcdFx0XHRcdFx0dGltZTpcIiR0aW1lc3RhbXBcIiAsXHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fSxcclxuXHRcdFx0XHR7JHNvcnQgOiB7IFwidGltZVwiOjF9IH0sXHRcclxuXHRcdFx0XHR7JHByb2plY3Q6XHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdF9pZCBcdDpcIiRfaWRcIiAsXHJcblx0XHRcdFx0XHRcdGxvYWRjZWxsMDFcdDogeyAkc3VtOiBcIiRsb2FkY2VsbDAxLnZcIiB9LFxyXG5cdFx0XHRcdFx0XHRsb2FkY2VsbDAyXHQ6IHsgJHN1bTogXCIkbG9hZGNlbGwwMi52XCIgfSxcclxuXHRcdFx0XHRcdFx0dGltZVx0XHQ6IFwiJHRpbWVcIixcclxuXHRcdFx0XHRcdFx0aG91cnN4XHRcdDogeyAkaG91cjoge2RhdGU6IHskYWRkIDogW25ldyBEYXRlKDApLCBcIiR0aW1lXCJdIH0sIHRpbWV6b25lOiBcIkFzaWEvSG9fQ2hpX01pbmhcIiB9fSxcclxuXHRcdFx0XHRcdFx0bWludXRlc3hcdDogeyAkbWludXRlOiB7IGRhdGU6IHskYWRkIDogW25ldyBEYXRlKDApLCBcIiR0aW1lXCJdIH0sIHRpbWV6b25lOiBcIkFzaWEvSG9fQ2hpX01pbmhcIiB9fSxcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9LFxyXG5cdFx0XHRdKS5mb3JFYWNoKGZ1bmN0aW9uKGRvYykge1xyXG5cdFx0XHRcdHJlc3VsdEFyci5wdXNoKGRvYyk7XHRcdFx0XHRcdFxyXG5cdFx0XHR9KVxyXG5cclxuXHRcdFx0dmFyIGxvYWRjZWxsMDFQcnZcdD0gMDtcclxuXHRcdFx0dmFyIGxvYWRjZWxsMDJQcnZcdD0gMDtcclxuXHRcdFx0dmFyIGhvdXJQcnZcdFx0XHQ9IDA7XHJcblx0XHRcdHZhciBmaXJzdE9mRGF5XHRcdD0gMDtcclxuXHRcdFx0dmFyIHRvdGFsTEMwMVx0XHQ9IDA7XHJcblx0XHRcdHZhciB0b3RhbExDMDJcdFx0PSAwO1xyXG5cdFx0XHR2YXIgdG90YWxMQzAxSG91clx0PSAwO1xyXG5cdFx0XHR2YXIgdG90YWxMQzAySG91clx0PSAwO1xyXG5cdFx0XHR2YXIgdG90YWwgPSAwO1xyXG5cdFx0XHR2YXIgdGltZSA9IFwiXCI7XHRcclxuXHRcdFx0dmFyIGRhdGFMQzAxID0gW107XHRcclxuXHRcdFx0dmFyIGRhdGFMQzAyID0gW107XHRcclxuXHRcdFx0dmFyIGRhdGFUaW1lID0gW107XHJcblx0XHRcdHZhciBkYXRhUmVwb3J0PVtdO1xyXG5cdFx0XHRcdFxyXG5cdFx0XHRmb3IgKHZhciBrPTA7IGsgPCByZXN1bHRBcnIubGVuZ3RoOyBrKyspXHJcblx0XHRcdHtcclxuXHRcdFx0XHRpZiAoKGZpcnN0T2ZEYXk9PTApICYmIChyZXN1bHRBcnJba10uaG91cnN4ID09IDE3KSYmIChyZXN1bHRBcnJba10ubWludXRlc3ggPT0gNDUpKVxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdGhvdXJQcnZcdFx0XHQ9IHJlc3VsdEFycltrXS5ob3Vyc3hcclxuXHRcdFx0XHRcdHRpbWVcdFx0XHQ9IHJlc3VsdEFycltrXS5faWRcclxuXHRcdFx0XHRcdGxvYWRjZWxsMDFQcnZcdD0gcGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDEpXHRcclxuXHRcdFx0XHRcdGxvYWRjZWxsMDJQcnZcdD0gcGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDIpXHRcclxuXHRcdFx0XHRcdGZpcnN0T2ZEYXlcdD0gMTtcclxuXHRcdFx0XHR9IGVsc2UgaWYgKGZpcnN0T2ZEYXk9PTEpXHJcblx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0Ly9pZiAocGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDEpIC0gbG9hZGNlbGwwMVBydiA+MClcclxuXHRcdFx0XHRcdC8ve1xyXG5cdFx0XHRcdFx0XHR0b3RhbExDMDFIb3VyID0gdG90YWxMQzAxSG91ciArIE1hdGguYWJzKHBhcnNlSW50KHJlc3VsdEFycltrXS5sb2FkY2VsbDAxKSAtIGxvYWRjZWxsMDFQcnYpO1x0XHRcdFx0XHJcblx0XHRcdFx0XHQvL31cdFx0XHJcblx0XHRcdFx0XHQvL2lmIChwYXJzZUludChyZXN1bHRBcnJba10ubG9hZGNlbGwwMikgLSBsb2FkY2VsbDAyUHJ2ID4wKVxyXG5cdFx0XHRcdFx0Ly97XHJcblx0XHRcdFx0XHRcdHRvdGFsTEMwMkhvdXIgPSB0b3RhbExDMDJIb3VyICsgTWF0aC5hYnMocGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDIpIC0gbG9hZGNlbGwwMlBydik7XHRcclxuXHRcdFx0XHRcdC8vfVxyXG5cdFx0XHRcdFx0Ly9jb25zb2xlLmxvZyhcIiwgaG91cnN4IFwiICsgcmVzdWx0QXJyW2tdLmhvdXJzeCk7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcblx0XHRcdFx0XHRpZiAocmVzdWx0QXJyW2tdLm1pbnV0ZXN4ID09IDQ1KVxyXG5cdFx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0XHRkYXRhUmVwb3J0LnB1c2goe1xyXG5cdFx0XHRcdFx0XHRcdHRpbWU6IHRpbWUuY29uY2F0KFwiICAtICBcIixyZXN1bHRBcnJba10uX2lkKSxcclxuXHRcdFx0XHRcdFx0XHRzaGlmdDogXCJcIixcclxuXHRcdFx0XHRcdFx0XHRib2NhbjAxIDp0b3RhbExDMDFIb3VyLFxyXG5cdFx0XHRcdFx0XHRcdGJvY2FuMDIgOnRvdGFsTEMwMkhvdXIsXHJcblx0XHRcdFx0XHRcdFx0dG90YWwgOiAgXCJcIixcclxuXHRcdFx0XHRcdFx0fSk7XHJcblx0XHRcdFx0XHRcdHRvdGFsTEMwMSA9IHRvdGFsTEMwMSArIHRvdGFsTEMwMUhvdXI7XHJcblx0XHRcdFx0XHRcdHRvdGFsTEMwMiA9IHRvdGFsTEMwMiArIHRvdGFsTEMwMkhvdXI7XHJcblxyXG5cdFx0XHRcdFx0XHR0b3RhbCA9IHRvdGFsTEMwMSArIHRvdGFsTEMwMlxyXG5cdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0ZGF0YUxDMDEucHVzaChcclxuXHRcdFx0XHRcdFx0XHROdW1iZXIodG90YWxMQzAxSG91cilcclxuXHRcdFx0XHRcdFx0KTtcclxuXHRcdFx0XHRcdFx0ZGF0YUxDMDIucHVzaChcclxuXHRcdFx0XHRcdFx0XHROdW1iZXIodG90YWxMQzAySG91cilcclxuXHRcdFx0XHRcdFx0KTtcdFxyXG5cdFx0XHRcdFx0XHRkYXRhVGltZS5wdXNoKFxyXG5cdFx0XHRcdFx0XHRcdGhvdXJQcnZcclxuXHRcdFx0XHRcdFx0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdEFycltrXS5ob3Vyc3ggPT0gMTcpXHJcblx0XHRcdFx0XHRcdHtcdFxyXG5cdFx0XHRcdFx0XHRcdGRhdGFSZXBvcnQucHVzaCh7XHJcblx0XHRcdFx0XHRcdFx0XHR0aW1lOiAnMTdoNDUgbmfDoHkgdHLGsOG7m2MgxJHhur9uIDE3aDQ1IG5nw6B5IHNhdScsXHJcblx0XHRcdFx0XHRcdFx0XHRzaGlmdDonVOG7lW5nJyxcclxuXHRcdFx0XHRcdFx0XHRcdGJvY2FuMDEgOiB0b3RhbExDMDEsXHJcblx0XHRcdFx0XHRcdFx0XHRib2NhbjAyIDogdG90YWxMQzAyLFxyXG5cdFx0XHRcdFx0XHRcdFx0dG90YWwgOiB0b3RhbFxyXG5cdFx0XHRcdFx0XHRcdH0pO1x0XHJcblx0XHRcdFx0XHRcdFx0dG90YWxMQzAxIFx0XHQ9IDA7XHJcblx0XHRcdFx0XHRcdFx0dG90YWxMQzAyIFx0XHQ9IDA7XHRcdFxyXG5cdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdHRvdGFsTEMwMUhvdXIgXHQ9IDA7XHJcblx0XHRcdFx0XHRcdHRvdGFsTEMwMkhvdXIgXHQ9IDA7XHJcblx0XHRcdFx0XHRcdHRpbWVcdFx0XHQ9IHJlc3VsdEFycltrXS5faWRcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0aG91clBydlx0XHRcdD0gcGFyc2VJbnQocmVzdWx0QXJyW2tdLmhvdXJzeClcclxuXHRcdFx0XHRcdGxvYWRjZWxsMDFQcnZcdD0gcGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDEpXHRcclxuXHRcdFx0XHRcdGxvYWRjZWxsMDJQcnZcdD0gcGFyc2VJbnQocmVzdWx0QXJyW2tdLmxvYWRjZWxsMDIpXHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHRcdFxyXG5cdFx0XHRkYXRhQmxvY2sucHVzaCh7XHJcblx0XHRcdFx0X2lkOiBcIkLhu5kgY8OibiAxXCIsXHJcblx0XHRcdFx0dHlwZTogJ2JhcicsXHJcblx0XHRcdFx0c3RhY2s6ICdTdGFjayAwJyxcclxuXHRcdFx0XHRkYXRhOiBkYXRhTEMwMSxcclxuXHRcdFx0XHR0aW1lOiBkYXRhVGltZVxyXG5cdFx0XHR9KTtcdFxyXG5cdFx0XHRkYXRhQmxvY2sucHVzaCh7XHJcblx0XHRcdFx0X2lkOiBcIkLhu5kgY8OibiAyXCIsXHJcblx0XHRcdFx0dHlwZTogJ2JhcicsXHJcblx0XHRcdFx0c3RhY2s6ICdTdGFjayAwJyxcclxuXHRcdFx0XHRkYXRhOiBkYXRhTEMwMixcclxuXHRcdFx0XHR0aW1lOiBkYXRhVGltZVxyXG5cdFx0XHR9KTtcdFx0XHRcdFxyXG5cdFx0XHRkYXRhQmxvY2sucHVzaCh7XHJcblx0XHRcdFx0X2lkOiBcIlJlcG9ydFwiLFxyXG5cdFx0XHRcdGRhdGE6IGRhdGFSZXBvcnQsXHJcblx0XHRcdH0pO1x0XHRcdFx0XHRcdFxyXG5cdFx0XHRyZXR1cm4gZGF0YUJsb2NrO1x0XHRcclxuXHRcdH1cdFx0XHJcblx0fSlcclxufSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCBTZWN1cml0eSBmcm9tICcuL3NlY3VyaXR5JzsgXHJcblxyXG5pbXBvcnQgVGFnc0ludGVyZmFjZSBmcm9tICcuL3RhZ2ludGVyZmFjZXMuanMnO1xyXG5cclxuZXhwb3J0IGNvbnN0IFRhZ0hpc3RvcmlhbiA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd0YWdoaXN0b3JpYW4nKTtcclxuXHJcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblx0TWV0ZW9yLnB1Ymxpc2goJ3RhZ0hpc3RvcmlhblJUaW1lJywgZnVuY3Rpb24gdGFnSGlzdG9yaWFuUlRpbWUoZmluZCxvcHRpb25zKSB7XHJcblx0XHRyZXR1cm4gVGFnSGlzdG9yaWFuLmZpbmQoZmluZCxvcHRpb25zKTtcclxuXHR9KTtcclxuXHRcclxuXHRNZXRlb3IubWV0aG9kcyh7XHJcblx0XHRhc3luYyAndGFnaGlzdG9yaWFuLmdldE9wZXJhdGluZ0hvdXJzJygpIFxyXG5cdFx0e1xyXG5cdFx0XHRyZXR1cm4gVGFnSGlzdG9yaWFuLmFnZ3JlZ2F0ZShbXHJcblx0XHRcdFx0eyRtYXRjaDogeyB0eXBlUmVwb3J0OiB7ICRlcTogXCJPcGVyYXRpbmdIb3Vyc1wiIH0gfX0sXHJcblx0XHRcdFx0eyRwcm9qZWN0OlxyXG5cdFx0XHRcdFx0e1x0X2lkOiAwLFxyXG5cdFx0XHRcdFx0XHRhc3NpZ25tZW50VGFnOjEgLFxyXG5cdFx0XHRcdFx0XHRhcmVhOiAxXHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdF1cclxuXHRcdFx0KS50b0FycmF5KCk7XHJcblx0XHR9LFx0XHJcblx0XHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHRcdGFzeW5jICd0YWdoaXN0b3JpYW4uZ2V0ZGF0YWJsb2NrYXN5bmNBeGlzJyhheGlzaWQpIFxyXG5cdFx0e1xyXG5cdFx0XHRyZXR1cm4gYXdhaXQgVGFnSGlzdG9yaWFuLnJhd0NvbGxlY3Rpb24oKS5hZ2dyZWdhdGUoW1xyXG5cdFx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0XHQkbG9va3VwOlxyXG5cdFx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdFx0ZnJvbTogXCJzaXRlaW50ZXJmYWNlc1wiLFxyXG5cdFx0XHRcdFx0XHRcdGxvY2FsRmllbGQ6IFwic2l0ZVwiLFxyXG5cdFx0XHRcdFx0XHRcdGZvcmVpZ25GaWVsZDogXCJfaWRcIixcclxuXHRcdFx0XHRcdFx0XHRhczogXCJzaXRlXCJcclxuXHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0fSxcdFxyXG5cdFx0XHRcdFx0eyAkdW53aW5kOiBcIiRzaXRlXCIgfSxcclxuXHRcdFx0XHRcdHskbWF0Y2g6IHsgYXhpc2lkOiB7ICRpbjogYXhpc2lkIH0gfX0sXHJcblx0XHRcdFx0XHR7JHNvcnQgOiB7IFwidW5pcXVlSURcIjoxfSB9LFx0XHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdCRwcm9qZWN0OiBcclxuXHRcdFx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0XHRcdFwiX2lkXCI6IFwiJF9pZFwiLFxyXG5cdFx0XHRcdFx0XHRcdFwibnNpdGVcIjogXCIkc2l0ZS5uYW1lXCIsXHJcblx0XHRcdFx0XHRcdFx0XCJpZFNpdGVcIjogXCIkc2l0ZS5faWRcIixcclxuXHRcdFx0XHRcdFx0XHRcImFzc2lnbm1lbnRUYWdcIjogXCIkYXNzaWdubWVudFRhZ1wiLFxyXG5cdFx0XHRcdFx0XHRcdFwidHlwZVJlcG9ydFwiIDogXCIkdHlwZVJlcG9ydFwiLFxyXG5cdFx0XHRcdFx0XHRcdFwiYXhpc2lkXCI6IFwiJGF4aXNpZFwiLFxyXG5cdFx0XHRcdFx0XHRcdFwiZGVzY1wiOiBcIiRkZXNjXCIsXHJcblx0XHRcdFx0XHRcdFx0XCJ0eXBlSGlzdFwiOiBcIiR0eXBlSGlzdFwiLFxyXG5cdFx0XHRcdFx0XHRcdFwic2NhbGVcIjogXCIkc2NhbGVcIixcclxuXHRcdFx0XHRcdFx0XHRcInVuaXF1ZUlEXCI6IFwiJHVuaXF1ZUlEXCIsXHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdH1cdFx0XHRcdFx0XHJcblx0XHRcdFx0XSkudG9BcnJheSgpXHJcblx0XHR9LFxyXG5cdFx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0XHRhc3luYyAndGFnaGlzdG9yaWFuLmdldGRhdGFibG9ja2FzeW5jRGVzYycoZGVzYykgXHJcblx0XHR7XHJcblx0XHRcdHJldHVybiBhd2FpdCBUYWdIaXN0b3JpYW4ucmF3Q29sbGVjdGlvbigpLmFnZ3JlZ2F0ZShbXHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdCRsb29rdXA6XHJcblx0XHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0XHRmcm9tOiBcInNpdGVpbnRlcmZhY2VzXCIsXHJcblx0XHRcdFx0XHRcdFx0bG9jYWxGaWVsZDogXCJzaXRlXCIsXHJcblx0XHRcdFx0XHRcdFx0Zm9yZWlnbkZpZWxkOiBcIl9pZFwiLFxyXG5cdFx0XHRcdFx0XHRcdGFzOiBcInNpdGVcIlxyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHR9LFx0XHJcblx0XHRcdFx0XHR7ICR1bndpbmQ6IFwiJHNpdGVcIiB9LFxyXG5cdFx0XHRcdFx0eyRtYXRjaDogeyBkZXNjOiB7ICRpbjogZGVzYyB9IH19LFxyXG5cdFx0XHRcdFx0eyRzb3J0IDogeyBcInVuaXF1ZUlEXCI6MX0gfSxcdFxyXG5cdFx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0XHQkcHJvamVjdDogXHJcblx0XHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0XHRcIl9pZFwiOiBcIiRfaWRcIixcclxuXHRcdFx0XHRcdFx0XHRcIm5zaXRlXCI6IFwiJHNpdGUubmFtZVwiLFxyXG5cdFx0XHRcdFx0XHRcdFwiaWRTaXRlXCI6IFwiJHNpdGUuX2lkXCIsXHJcblx0XHRcdFx0XHRcdFx0XCJhc3NpZ25tZW50VGFnXCI6IFwiJGFzc2lnbm1lbnRUYWdcIixcclxuXHRcdFx0XHRcdFx0XHRcInR5cGVSZXBvcnRcIiA6IFwiJHR5cGVSZXBvcnRcIixcclxuXHRcdFx0XHRcdFx0XHRcImF4aXNpZFwiOiBcIiRheGlzaWRcIixcclxuXHRcdFx0XHRcdFx0XHRcImRlc2NcIjogXCIkZGVzY1wiLFxyXG5cdFx0XHRcdFx0XHRcdFwidHlwZUhpc3RcIjogXCIkdHlwZUhpc3RcIixcclxuXHRcdFx0XHRcdFx0XHRcInNjYWxlXCI6IFwiJHNjYWxlXCIsXHJcblx0XHRcdFx0XHRcdFx0XCJ1bmlxdWVJRFwiOiBcIiR1bmlxdWVJRFwiLFxyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHR9XHRcdFx0XHRcdFxyXG5cdFx0XHRcdF0pLnRvQXJyYXkoKVxyXG5cdFx0fSxcdFx0XHJcblx0XHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHRcdGFzeW5jICd0YWdoaXN0b3JpYW4uZ2V0ZGF0YWJsb2NrYXN5bmMnKCkgXHJcblx0XHR7XHJcblx0XHRcdHJldHVybiBhd2FpdCBUYWdIaXN0b3JpYW4ucmF3Q29sbGVjdGlvbigpLmFnZ3JlZ2F0ZShbXHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdCRsb29rdXA6XHJcblx0XHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0XHRmcm9tOiBcInNpdGVpbnRlcmZhY2VzXCIsXHJcblx0XHRcdFx0XHRcdFx0bG9jYWxGaWVsZDogXCJzaXRlXCIsXHJcblx0XHRcdFx0XHRcdFx0Zm9yZWlnbkZpZWxkOiBcIl9pZFwiLFxyXG5cdFx0XHRcdFx0XHRcdGFzOiBcInNpdGVcIlxyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHR9LFx0XHJcblx0XHRcdFx0XHR7ICR1bndpbmQ6IFwiJHNpdGVcIiB9LFxyXG5cdFx0XHRcdFx0eyRzb3J0IDogeyBcInVuaXF1ZUlEXCI6MX0gfSxcdFxyXG5cdFx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0XHQkcHJvamVjdDogXHJcblx0XHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0XHRcIl9pZFwiOiBcIiRfaWRcIixcclxuXHRcdFx0XHRcdFx0XHRcIm5zaXRlXCI6IFwiJHNpdGUubmFtZVwiLFxyXG5cdFx0XHRcdFx0XHRcdFwiaWRTaXRlXCI6IFwiJHNpdGUuX2lkXCIsXHJcblx0XHRcdFx0XHRcdFx0XCJhc3NpZ25tZW50VGFnXCI6IFwiJGFzc2lnbm1lbnRUYWdcIixcclxuXHRcdFx0XHRcdFx0XHRcInR5cGVSZXBvcnRcIiA6IFwiJHR5cGVSZXBvcnRcIixcclxuXHRcdFx0XHRcdFx0XHRcImF4aXNpZFwiOiBcIiRheGlzaWRcIixcclxuXHRcdFx0XHRcdFx0XHRcImRlc2NcIjogXCIkZGVzY1wiLFxyXG5cdFx0XHRcdFx0XHRcdFwidHlwZUhpc3RcIjogXCIkdHlwZUhpc3RcIixcclxuXHRcdFx0XHRcdFx0XHRcInNjYWxlXCI6IFwiJHNjYWxlXCIsXHJcblx0XHRcdFx0XHRcdFx0XCJ1bmlxdWVJRFwiOiBcIiR1bmlxdWVJRFwiLFxyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHR9XHRcdFx0XHRcdFxyXG5cdFx0XHRcdF0pLnRvQXJyYXkoKVxyXG5cdFx0fSxcdFx0XHJcblx0fSk7XHJcbn1cclxuXHRcdFx0XHRcdFxyXG4gTWV0ZW9yLm1ldGhvZHMoe1xyXG4vL3sgXCJfaWRcIiA6IFwiemdaS3FQY2RjQnF5SDRyVDJcIiwgXCJzaXRlXCIgOiBcIkxhZ3pUc3o5MzVFeG5BcmtvXCIsIFwiZGVzY1wiIDogXCJub3RlXCIsIFwidHlwZVJlcG9ydFwiIDogMiwgXCJ1bmlxdWVJRFwiIDogMTA1LCBcImFzc2lnbm1lbnRUYWdcIiA6IFwiNFBUMy5WQUxVRVwiLCBcImNyZWF0ZURhdGVcIiA6IElTT0RhdGUoXCIyMDE5LTA2LTA3VDA3OjQ4OjAwLjY1NlpcIikgfVx0IFxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdCBcclxuXHQndGFnaGlzdG9yaWFuLmluc2VydCcoXHJcblx0XHRzaXRlLFxyXG5cdFx0YXNzaWdubWVudFRhZyxcclxuXHRcdHR5cGVSZXBvcnQsXHJcblx0XHRkZXNjLFxyXG5cdFx0YXhpc2lkLFxyXG5cdFx0c2NhbGUsIFxyXG5cdFx0dHlwZUhpc3QsIFxyXG5cdFx0ZGF0YWNoYW5nZVx0XHRcclxuXHRcdCkgXHJcblx0e1xyXG5cdFx0aWYgKCFTZWN1cml0eS5jaGVja1JvbGUodGhpcy51c2VySWQsJ093bmVyJykpXHJcblx0XHR7XHJcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJsb2dnZWQtaW5cIixcIllvdSBhcmUgbm90IHBlcm1pdHRlZC5cIik7XHJcblx0XHR9XHJcblx0XHRlbHNlXHJcblx0XHR7XHJcblx0XHRcdGlmIChUYWdIaXN0b3JpYW4uZmluZE9uZSh7ICRhbmQ6IFsgeyBzaXRlOiB7ICRlcTogc2l0ZSB9IH0sIHsgdHlwZUhpc3Q6IHsgJGVxOiB0eXBlSGlzdCB9IH0sIHsgYXNzaWdubWVudFRhZzogeyAkZXE6IGFzc2lnbm1lbnRUYWcgfX1dfSkgIT1udWxsKVxyXG5cdFx0XHR7XHJcblx0XHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIkR1cGxpY2F0ZSBUYWcgaGlzdG9yaWFuXCIpO1xyXG5cdFx0XHR9XHJcblx0XHRcdGVsc2UgXHJcblx0XHRcdHtcdFx0XHJcblx0XHRcdFx0dmFyIHVuaXF1ZUlEID0gMTtcclxuXHRcdFx0XHR2YXIgZGF0YSA9IFRhZ0hpc3Rvcmlhbi5maW5kT25lKHsgc2l0ZTpzaXRlfSx7c29ydDp7IHVuaXF1ZUlEIDogLTEgfSwgbGltaXQ6MX0pO1xyXG5cdFx0XHRcdGlmIChkYXRhID09IG51bGwpXHJcblx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0Ly9cclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0ZWxzZVxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdHVuaXF1ZUlEICA9IHBhcnNlSW50KGRhdGEudW5pcXVlSUQpICArIDE7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHJcblx0XHRcdFx0VGFnSGlzdG9yaWFuLmluc2VydCh7XHJcblx0XHRcdFx0XHRzaXRlLFxyXG5cdFx0XHRcdFx0YXNzaWdubWVudFRhZyxcclxuXHRcdFx0XHRcdHR5cGVSZXBvcnQsXHJcblx0XHRcdFx0XHRkZXNjLFxyXG5cdFx0XHRcdFx0YXhpc2lkLFxyXG5cdFx0XHRcdFx0c2NhbGUsIFxyXG5cdFx0XHRcdFx0dHlwZUhpc3QsXHJcblx0XHRcdFx0XHRkYXRhY2hhbmdlLFxyXG5cdFx0XHRcdFx0dW5pcXVlSURcclxuXHRcdFx0XHR9KTtcclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cdH0sXHRcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQndGFnaGlzdG9yaWFuLnVwZGF0ZScoXHRcdFxyXG5cdFx0X2lkLFxyXG5cdFx0c2l0ZSxcclxuXHRcdGFzc2lnbm1lbnRUYWcsXHJcblx0XHR0eXBlUmVwb3J0LFxyXG5cdFx0ZGVzYyxcclxuXHRcdGF4aXNpZCxcclxuXHRcdHNjYWxlLCBcclxuXHRcdHR5cGVIaXN0LFxyXG5cdFx0ZGF0YWNoYW5nZVxyXG5cdFx0KSBcclxuXHR7XHRcclxuXHRcdGlmICghU2VjdXJpdHkuY2hlY2tSb2xlKHRoaXMudXNlcklkLCdPd25lcicpKVxyXG5cdFx0e1xyXG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibG9nZ2VkLWluXCIsXCJZb3UgYXJlIG5vdCBwZXJtaXR0ZWQuXCIpO1xyXG5cdFx0fVxyXG5cdFx0ZWxzZVxyXG5cdFx0e1xyXG5cdFx0XHQvLyBpZiAoVGFnSGlzdG9yaWFuLmZpbmRPbmUoeyAkYW5kOiBbIHsgc2l0ZTogeyAkZXE6IHNpdGUgfSB9LCB7IGFzc2lnbm1lbnRUYWc6IHsgJGVxOiBhc3NpZ25tZW50VGFnIH19XX0pICE9bnVsbClcclxuXHRcdFx0Ly8ge1xyXG5cdFx0XHRcdC8vIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJEdXBsaWNhdGUgVGFnIGhpc3RvcmlhblwiKTtcclxuXHRcdFx0Ly8gfVxyXG5cdFx0XHQvLyBlbHNlIFxyXG5cdFx0XHQvLyB7XHRcdFx0XHJcblx0XHRcdFx0VGFnSGlzdG9yaWFuLnVwZGF0ZShfaWQsXHJcblx0XHRcdFx0eyAkc2V0OiB7XHJcblx0XHRcdFx0XHRcdGFzc2lnbm1lbnRUYWcsXHJcblx0XHRcdFx0XHRcdGRlc2MsXHJcblx0XHRcdFx0XHRcdHR5cGVSZXBvcnQsXHJcblx0XHRcdFx0XHRcdGF4aXNpZCxcclxuXHRcdFx0XHRcdFx0c2NhbGUsIFxyXG5cdFx0XHRcdFx0XHR0eXBlSGlzdCxcclxuXHRcdFx0XHRcdFx0ZGF0YWNoYW5nZVxyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fSk7XHJcblx0XHRcdC8vfVxyXG5cdFx0fVxyXG5cdH0sXHRcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQndGFnaGlzdG9yaWFuLnJlbW92ZScodGFza0lkKSB7XHJcblx0XHRpZiAoIVNlY3VyaXR5LmNoZWNrUm9sZSh0aGlzLnVzZXJJZCwnT3duZXInKSlcclxuXHRcdHtcclxuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcihcImxvZ2dlZC1pblwiLFwiWW91IGFyZSBub3QgcGVybWl0dGVkLlwiKTtcclxuXHRcdH1cclxuXHRcdGVsc2VcclxuXHRcdHtcdFx0XHJcblx0XHRcdFRhZ0hpc3Rvcmlhbi5yZW1vdmUodGFza0lkKTtcclxuXHRcdH1cclxuXHR9LFx0XHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0J3RhZ2hpc3Rvcmlhbi5nZXRkYXRhYmxvY2snKCkgXHJcblx0e1xyXG5cdFx0dmFyIGRhdGFCbG9jayA9IFtdO1xyXG5cdFx0dmFyIGluZGV4ICA9IDA7XHJcblx0XHRUYWdIaXN0b3JpYW4uZmluZCgpLmZvckVhY2goZnVuY3Rpb24oZG9jKSB7XHJcblx0XHRcdGRhdGFCbG9jay5wdXNoKHtcclxuXHRcdFx0XHRfaWQ6IGRvYy5faWQsXHJcblx0XHRcdFx0aW5kZXg6IGluZGV4LFxyXG5cdFx0XHRcdGFzc2lnbm1lbnRUYWcgOiBkb2MuYXNzaWdubWVudFRhZyxcclxuXHRcdFx0XHRkZXNjOiBkb2MuZGVzYyxcclxuXHRcdFx0XHR0eXBlUmVwb3J0IDogZG9jLnR5cGVSZXBvcnRcclxuXHRcdFx0fSk7XHRcdFx0XHJcblx0XHRcdGluZGV4ID0gaW5kZXggKyAxO1xyXG5cdFx0XHRcclxuXHRcdH0pO1x0XHRcclxuXHRcdHJldHVybiBkYXRhQmxvY2s7XHJcblx0fSxcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQndGFnaGlzdG9yaWFuLmdldE9wZXJhdGluZ0hvdXInKCkgXHJcblx0e1xyXG5cdFx0dmFyIGRhdGFCbG9jayA9IFtdO1xyXG5cdFx0VGFnSGlzdG9yaWFuLmZpbmQoe3R5cGVSZXBvcnQ6XCJPcGVyYXRpbmdIb3Vyc1wifSkuZm9yRWFjaChmdW5jdGlvbihkb2MpIHtcclxuXHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdGFzc2lnbm1lbnRUYWcgOiBkb2MuYXNzaWdubWVudFRhZy5zcGxpdChcIi5cIiwgMSlbMF0sXHJcblx0XHRcdFx0ZGVzYzogZG9jLmRlc2NcclxuXHRcdFx0fSk7XHRcdFx0XHJcblx0XHR9KTtcclxuXHRcdFxyXG5cdFx0cmV0dXJuIGRhdGFCbG9jaztcclxuXHR9LFx0XHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0J3RhZ2hpc3Rvcmlhbi5nZXRQcm9jZXNzRGF0YScoKSBcclxuXHR7XHJcblx0XHR2YXIgZGF0YUJsb2NrID0gW107XHJcblx0XHRUYWdIaXN0b3JpYW4uZmluZCh7dHlwZVJlcG9ydDpcIlByb2Nlc3NEYXRhXCJ9KS5mb3JFYWNoKGZ1bmN0aW9uKGRvYykge1xyXG5cdFx0XHR2YXIgdGFnTmFtZSA9IGRvYy5hc3NpZ25tZW50VGFnLnNwbGl0KFwiLlwiLCAxKVswXTtcclxuXHRcdFx0dmFyIHVuaXQgPSBNZXRlb3IuY2FsbCgndGFnaW50ZXJmYWNlcy5nZXRVbml0Jyx0YWdOYW1lKTtcclxuXHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdGFzc2lnbm1lbnRUYWcgOiB0YWdOYW1lLFxyXG5cdFx0XHRcdGRlc2M6IGRvYy5kZXNjLFxyXG5cdFx0XHRcdHVuaXQ6IHVuaXRcclxuXHRcdFx0fSk7XHRcdFx0XHJcblx0XHR9KTtcclxuXHRcdFxyXG5cdFx0cmV0dXJuIGRhdGFCbG9jaztcclxuXHR9LFx0XHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0J3RhZ2hpc3Rvcmlhbi5nZXRFbGVjdHJpY2FsU3lzdGVtJygpIFxyXG5cdHtcclxuXHRcdHZhciBkYXRhQmxvY2sgPSBbXTtcclxuXHRcdFRhZ0hpc3Rvcmlhbi5maW5kKHt0eXBlUmVwb3J0OlwiRWxlY3RyaWNhbFN5c3RlbVwifSkuZm9yRWFjaChmdW5jdGlvbihkb2MpIHtcclxuXHRcdFx0dmFyIHRhZ05hbWUgPSBkb2MuYXNzaWdubWVudFRhZy5zcGxpdChcIi5cIiwgMSlbMF07XHJcblx0XHRcdHZhciB1bml0ID0gTWV0ZW9yLmNhbGwoJ3RhZ2ludGVyZmFjZXMuZ2V0VW5pdCcsdGFnTmFtZSk7XHJcblx0XHRcdGRhdGFCbG9jay5wdXNoKHtcclxuXHRcdFx0XHRhc3NpZ25tZW50VGFnIDogdGFnTmFtZSxcclxuXHRcdFx0XHRkZXNjOiBkb2MuZGVzYyxcclxuXHRcdFx0XHR1bml0OiB1bml0XHJcblx0XHRcdH0pO1x0XHRcdFxyXG5cdFx0fSk7XHJcblx0XHRcclxuXHRcdHJldHVybiBkYXRhQmxvY2s7XHJcblx0fSxcdFx0XHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0J3RhZ2hpc3Rvcmlhbi5maW5kVGFncycoKSBcclxuXHR7XHJcblx0XHR2YXIgYXJyYXlEYXRhPVtcIkZJVF8xMDMwMV9WQUxVRS5WQUxVRVwiXTtcdFx0XHJcblx0XHR2YXIgZGF0YUJsb2NrID0gW107XHJcblx0XHRUYWdIaXN0b3JpYW4uZmluZCh7YXNzaWdubWVudFRhZzogeyRpbjphcnJheURhdGF9fSkuZm9yRWFjaChmdW5jdGlvbihkb2MpIHtcclxuXHRcdFx0dmFyIHRhZ05hbWUgPSBkb2MuYXNzaWdubWVudFRhZy5zcGxpdChcIi5cIiwgMSlbMF07XHJcblx0XHRcdHZhciB1bml0ID0gTWV0ZW9yLmNhbGwoJ3RhZ2ludGVyZmFjZXMuZ2V0VW5pdCcsdGFnTmFtZSk7XHJcblx0XHRcdGRhdGFCbG9jay5wdXNoKHtcclxuXHRcdFx0XHRhc3NpZ25tZW50VGFnIDogdGFnTmFtZSxcclxuXHRcdFx0XHRkZXNjOiBkb2MuZGVzY1xyXG5cdFx0XHR9KTtcdFx0XHRcclxuXHRcdH0pO1xyXG5cdFx0XHJcblx0XHRyZXR1cm4gZGF0YUJsb2NrO1xyXG5cdH0sXHRcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQndGFnaGlzdG9yaWFuLmdldFRhZycoZGF0YWFycixzaXRlKSBcclxuXHR7XHJcblx0XHR2YXIgZGF0YUJsb2NrID0gW107XHJcblx0XHR2YXIgcG9zaXRpb24gID0gJ2xlZnQnO1xyXG5cdFx0dmFyIHVuaXF1ZSBcdCAgPSAnSGVsbG8nO1xyXG5cdFx0dmFyIGdyaWRMaW5lcyA9IHRydWU7XHJcblx0XHRUYWdIaXN0b3JpYW4uZmluZCh7dW5pcXVlSUQ6eyRpbjpkYXRhYXJyfSxzaXRlOnNpdGV9LHtzb3J0OnsgYXhpc2lkIDogLTEgfX0pLmZvckVhY2goZnVuY3Rpb24oZG9jKSB7XHJcblx0XHRcdGlmICh1bmlxdWUgPT0gZG9jLmF4aXNpZClcclxuXHRcdFx0e1xyXG5cdFx0XHRcdC8vXHJcblx0XHRcdH0gZWxzZSBpZiAodW5pcXVlICE9ICcnKSB7XHJcblx0XHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdFx0dW5pcXVlSUQ6IGRvYy51bmlxdWVJRCxcclxuXHRcdFx0XHRcdGF4aXNpZFx0OiBkb2MuYXhpc2lkLFxyXG5cdFx0XHRcdFx0ZGVzY1x0OiBkb2MuZGVzYyxcclxuXHRcdFx0XHRcdGdyaWRMaW5lczogZ3JpZExpbmVzLFxyXG5cdFx0XHRcdFx0cG9zaXRpb246IHBvc2l0aW9uXHJcblx0XHRcdFx0fSlcclxuXHRcdFx0XHRpZiAocG9zaXRpb24gPT0gJ2xlZnQnKVxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdHBvc2l0aW9uICA9ICdyaWdodCc7XHJcblx0XHRcdFx0fSBlbHNlIFxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdHBvc2l0aW9uICA9ICdsZWZ0JztcclxuXHRcdFx0XHR9XHRcdFx0XHRcclxuXHRcdFx0XHRncmlkTGluZXMgXHQ9IGZhbHNlO1x0XHRcdFx0XHJcblx0XHRcdH1cclxuXHRcdFx0dW5pcXVlID0gZG9jLmF4aXNpZDtcclxuXHRcdH0pO1x0XHRcclxuXHRcdHJldHVybiBkYXRhQmxvY2s7XHJcblx0fVxyXG59KSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbi8vaW1wb3J0IHtKc29uUm91dGV9IGZyb20gJ2pzb24tcm91dGluZyc7XHJcblxyXG5pbXBvcnQgUExDSW50ZXJmYWNlcyBmcm9tICcuL3BsY2ludGVyZmFjZXMuanMnOyBcclxuZXhwb3J0IGNvbnN0IFRhZ3NJbnRlcmZhY2UgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndGFnaW50ZXJmYWNlcycpO1xyXG4vL3Bvc3RNQDIwMjBcclxuLy9odHRwczovL3d3dy5jb2RlbWVudG9yLmlvL0Bjb2RlZm9yZ2Vlay9yZXN0LWNydWQtb3BlcmF0aW9uLXVzaW5nLW1ldGVvci1kdTEwODA4bTVcclxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG5cclxuXHRNZXRlb3IucHVibGlzaCgndGFnaW50ZXJmYWNlc05NU2V0dGluZycsIGZ1bmN0aW9uIHRhZ2ludGVyZmFjZXNOTVNldHRpbmcoYXJndW1lbnRzRmluZCxhcmd1bWVudHNPcHRpb25zKSB7XHJcblx0XHRyZXR1cm4gVGFnc0ludGVyZmFjZS5maW5kKGFyZ3VtZW50c0ZpbmQsYXJndW1lbnRzT3B0aW9ucyk7XHJcblx0fSk7XHRcclxuXHRcclxuICBcdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09UExBTlRcclxuXHRNZXRlb3IucHVibGlzaCgndGFnQWxhcm1FdmVudCcsIGZ1bmN0aW9uIHRhZ0FsYXJtRXZlbnQoYXJndW1lbnRzRmluZCxhcmd1bWVudHNPcHRpb25zKSB7XHJcblx0XHRyZXR1cm4gVGFnc0ludGVyZmFjZS5maW5kKGFyZ3VtZW50c0ZpbmQsYXJndW1lbnRzT3B0aW9ucyk7XHJcblx0fSk7XHRcclxuXHQvL1RoaXMgY29kZSBvbmx5IHJ1bnMgb24gdGhlIHNlcnZlciBmb3IgUExBTlRcclxuXHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PU9iamVjdHNcclxuXHRNZXRlb3IucHVibGlzaCgndGFnaW50ZXJmYWNlc05NQ29udHJvbCcsIGZ1bmN0aW9uIHRhZ2ludGVyZmFjZXNOTUNvbnRyb2woYXJndW1lbnRzRmluZCxhcmd1bWVudHNPcHRpb25zKSB7XHJcblx0XHRyZXR1cm4gVGFnc0ludGVyZmFjZS5maW5kKGFyZ3VtZW50c0ZpbmQsYXJndW1lbnRzT3B0aW9ucyk7XHJcblx0fSk7XHJcblxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1PYmplY3RzXHJcblx0TWV0ZW9yLnB1Ymxpc2goJ29iamVjdHNUTVBSZWFsVGltZScsIGZ1bmN0aW9uIG9iamVjdHNUTVBSZWFsVGltZShhcmd1bWVudHNGaW5kLGFyZ3VtZW50c09wdGlvbnMpIHtcclxuXHRcdHJldHVybiBUYWdzSW50ZXJmYWNlLmZpbmQoYXJndW1lbnRzRmluZCxhcmd1bWVudHNPcHRpb25zKTtcclxuXHR9KTtcdFxyXG5cdFxyXG5cdE1ldGVvci5wdWJsaXNoKCdvYmplY3N0RE9MUmVhbHRpbWUnLCBmdW5jdGlvbiBvYmplY3N0RE9MUmVhbHRpbWUoYXJndW1lbnRzRmluZCxhcmd1bWVudHNPcHRpb25zKSB7XHJcblx0XHRyZXR1cm4gVGFnc0ludGVyZmFjZS5maW5kKGFyZ3VtZW50c0ZpbmQsYXJndW1lbnRzT3B0aW9ucyk7XHJcblx0fSk7XHRcclxuXHRcdFxyXG5cdFxyXG5cdE1ldGVvci5wdWJsaXNoKCdvYmplY3N0VmFsdmVSZWFsdGltZScsIGZ1bmN0aW9uIG9iamVjc3RWYWx2ZVJlYWx0aW1lKGFyZ3VtZW50c0ZpbmQsYXJndW1lbnRzT3B0aW9ucykge1xyXG5cdFx0cmV0dXJuIFRhZ3NJbnRlcmZhY2UuZmluZChhcmd1bWVudHNGaW5kLGFyZ3VtZW50c09wdGlvbnMpO1xyXG5cdH0pO1x0XHJcblx0XHJcblx0TWV0ZW9yLnB1Ymxpc2goJ29iamVjc3RWU0RyZWFsdGltZScsIGZ1bmN0aW9uIG9iamVjc3RWU0RyZWFsdGltZShhcmd1bWVudHNGaW5kLGFyZ3VtZW50c09wdGlvbnMpIHtcclxuXHRcdHJldHVybiBUYWdzSW50ZXJmYWNlLmZpbmQoYXJndW1lbnRzRmluZCxhcmd1bWVudHNPcHRpb25zKTtcclxuXHR9KTtcdFxyXG4gIFxyXG5cdE1ldGVvci5wdWJsaXNoKCdvYmplY3N0SW5zdHJ1bWVudFJlYWx0aW1lJywgZnVuY3Rpb24gb2JqZWNzdEluc3RydW1lbnRSZWFsdGltZShhcmd1bWVudHNGaW5kLGFyZ3VtZW50c09wdGlvbnMpIHtcclxuXHRcdHJldHVybiBUYWdzSW50ZXJmYWNlLmZpbmQoYXJndW1lbnRzRmluZCxhcmd1bWVudHNPcHRpb25zKTtcclxuXHR9KTtcdFxyXG5cclxuXHRNZXRlb3IucHVibGlzaCgnb2JqZWNzdExldmVsUmVhbHRpbWUnLCBmdW5jdGlvbiBvYmplY3N0TGV2ZWxSZWFsdGltZShhcmd1bWVudHNGaW5kLGFyZ3VtZW50c09wdGlvbnMpIHtcclxuXHRcdHJldHVybiBUYWdzSW50ZXJmYWNlLmZpbmQoYXJndW1lbnRzRmluZCxhcmd1bWVudHNPcHRpb25zKTtcclxuXHR9KTtcdFxyXG5cclxuXHRNZXRlb3IucHVibGlzaCgnb2JqZWNzdFBJRFJlYWx0aW1lJywgZnVuY3Rpb24gb2JqZWNzdFBJRFJlYWx0aW1lKGFyZ3VtZW50c0ZpbmQsYXJndW1lbnRzT3B0aW9ucykge1xyXG5cdFx0cmV0dXJuIFRhZ3NJbnRlcmZhY2UuZmluZChhcmd1bWVudHNGaW5kLGFyZ3VtZW50c09wdGlvbnMpO1xyXG5cdH0pO1x0XHRcclxuICBcclxuICBcdE1ldGVvci5wdWJsaXNoKCdvYmplY3N0VGV4dHJlYWx0aW1lJywgZnVuY3Rpb24gb2JqZWNzdFRleHRyZWFsdGltZShhcmd1bWVudHNGaW5kLGFyZ3VtZW50c09wdGlvbnMpIHtcclxuXHRcdHJldHVybiBUYWdzSW50ZXJmYWNlLmZpbmQoYXJndW1lbnRzRmluZCxhcmd1bWVudHNPcHRpb25zKTtcclxuXHR9KTtcdFxyXG5cclxuXHRNZXRlb3IubWV0aG9kcyh7XHJcblx0XHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHRcdGFzeW5jICdnZXRkYXRhYmxvY2tPYmphc3luYycoKSB7XHJcblx0XHRcdCByZXR1cm4gYXdhaXQgVGFnc0ludGVyZmFjZS5yYXdDb2xsZWN0aW9uKCkuYWdncmVnYXRlKFtcclxuXHRcdFx0XHR7XHJcblx0XHRcdFx0XHQkbG9va3VwOlxyXG5cdFx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0XHRmcm9tOiBcInBsY2ludGVyZmFjZXNcIixcclxuXHRcdFx0XHRcdFx0bG9jYWxGaWVsZDogXCJzZWxlY3RQTENcIixcclxuXHRcdFx0XHRcdFx0Zm9yZWlnbkZpZWxkOiBcIl9pZFwiLFxyXG5cdFx0XHRcdFx0XHRhczogXCJwbGNcIlxyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH0sXHJcblx0XHRcdFx0eyAkdW53aW5kOiBcIiRwbGNcIiB9LFxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdCRsb29rdXA6XHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdGZyb206IFwic2l0ZWludGVyZmFjZXNcIixcclxuXHRcdFx0XHRcdFx0bG9jYWxGaWVsZDogXCJwbGMuc2l0ZVwiLFxyXG5cdFx0XHRcdFx0XHRmb3JlaWduRmllbGQ6IFwiX2lkXCIsXHJcblx0XHRcdFx0XHRcdGFzOiBcInNpdGVcIlxyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH0sXHRcclxuXHRcdFx0XHR7ICR1bndpbmQ6IFwiJHNpdGVcIiB9LFxyXG5cdFx0XHRcdHskc29ydCA6IHsgc2VsZWN0UExDOjF9IH0sXHJcblx0XHRcdFx0eyRwcm9qZWN0OiB7XHJcblx0XHRcdFx0XHRcIl9pZFwiOiBcIiRfaWRcIixcclxuXHRcdFx0XHRcdFwibnNpdGVcIjogXCIkc2l0ZS5uYW1lXCIsXHJcblx0XHRcdFx0XHRcImlkU2l0ZVwiOiBcIiRzaXRlLl9pZFwiLFxyXG5cdFx0XHRcdFx0XCJ2YWx1ZVwiOiBcIiRfaWRcIixcclxuXHRcdFx0XHRcdFwic2VsZWN0UExDXCI6IFwiJHBsYy5uYW1lXCIsXHJcblx0XHRcdFx0XHRcImxhYmVsXCI6IFwiJHRhZ05hbWVcIixcclxuXHRcdFx0XHQgICB9XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRdKS50b0FycmF5KCk7XHRcclxuXHRcdH1cclxuXHR9KVxyXG5cdFx0XHJcblx0TWV0ZW9yLm1ldGhvZHMoe1xyXG5cdFxyXG5cdFx0YXN5bmMgJ3RhZ2ludGVyZmFjZXMuZ2V0ZGF0YWJsb2NrT2JqYXN5bmMnKCkge1xyXG5cdFx0XHRyZXR1cm4gYXdhaXQgVGFnc0ludGVyZmFjZS5yYXdDb2xsZWN0aW9uKCkuYWdncmVnYXRlKFtcclxuXHRcdFx0XHR7XHJcblx0XHRcdFx0XHQkbG9va3VwOlxyXG5cdFx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0XHRmcm9tOiBcInBsY2ludGVyZmFjZXNcIixcclxuXHRcdFx0XHRcdFx0bG9jYWxGaWVsZDogXCJzZWxlY3RQTENcIixcclxuXHRcdFx0XHRcdFx0Zm9yZWlnbkZpZWxkOiBcIl9pZFwiLFxyXG5cdFx0XHRcdFx0XHRhczogXCJwbGNcIlxyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH0sXHJcblx0XHRcdFx0eyAkdW53aW5kOiBcIiRwbGNcIiB9LFxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdCRsb29rdXA6XHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdGZyb206IFwic2l0ZWludGVyZmFjZXNcIixcclxuXHRcdFx0XHRcdFx0bG9jYWxGaWVsZDogXCJwbGMuc2l0ZVwiLFxyXG5cdFx0XHRcdFx0XHRmb3JlaWduRmllbGQ6IFwiX2lkXCIsXHJcblx0XHRcdFx0XHRcdGFzOiBcInNpdGVcIlxyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH0sXHRcclxuXHRcdFx0XHR7ICR1bndpbmQ6IFwiJHNpdGVcIiB9LFxyXG5cdFx0XHRcdHskc29ydCA6IHsgc2VsZWN0UExDOjF9IH0sXHJcblx0XHRcdFx0eyRwcm9qZWN0OiB7XHJcblx0XHRcdFx0XHRcIl9pZFwiOiBcIiRfaWRcIixcclxuXHRcdFx0XHRcdFwibnNpdGVcIjogXCIkc2l0ZS5uYW1lXCIsXHJcblx0XHRcdFx0XHRcImlkU2l0ZVwiOiBcIiRzaXRlLl9pZFwiLFxyXG5cdFx0XHRcdFx0XCJ2YWx1ZVwiOiBcIiRfaWRcIixcclxuXHRcdFx0XHRcdFwic2VsZWN0UExDXCI6IFwiJHBsYy5uYW1lXCIsXHJcblx0XHRcdFx0XHRcImxhYmVsXCI6IFwiJHRhZ05hbWVcIixcclxuXHRcdFx0XHQgICB9XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRdKS50b0FycmF5KCk7XHRcdFx0XHRcclxuXHRcdH0sXHJcblx0XHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHRcdGFzeW5jICd0YWdpbnRlcmZhY2VzLmdldGRhdGFibG9ja2FzeW5jJygpIHtcclxuXHRcdFx0cmV0dXJuIGF3YWl0IFRhZ3NJbnRlcmZhY2UucmF3Q29sbGVjdGlvbigpLmFnZ3JlZ2F0ZShbXHJcblx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0JGxvb2t1cDpcclxuXHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0ZnJvbTogXCJwbGNpbnRlcmZhY2VzXCIsXHJcblx0XHRcdFx0XHRcdGxvY2FsRmllbGQ6IFwic2VsZWN0UExDXCIsXHJcblx0XHRcdFx0XHRcdGZvcmVpZ25GaWVsZDogXCJfaWRcIixcclxuXHRcdFx0XHRcdFx0YXM6IFwicGxjXCJcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9LFxyXG5cdFx0XHRcdHsgJHVud2luZDogXCIkcGxjXCIgfSxcclxuXHRcdFx0XHR7XHJcblx0XHRcdFx0XHQkbG9va3VwOlxyXG5cdFx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0XHRmcm9tOiBcInNpdGVpbnRlcmZhY2VzXCIsXHJcblx0XHRcdFx0XHRcdGxvY2FsRmllbGQ6IFwicGxjLnNpdGVcIixcclxuXHRcdFx0XHRcdFx0Zm9yZWlnbkZpZWxkOiBcIl9pZFwiLFxyXG5cdFx0XHRcdFx0XHRhczogXCJzaXRlXCJcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9LFx0XHJcblx0XHRcdFx0eyAkdW53aW5kOiBcIiRzaXRlXCIgfSxcclxuXHRcdFx0XHR7JHNvcnQgOiB7IHNlbGVjdFBMQzoxfSB9LFxyXG5cdFx0XHRcdHskcHJvamVjdDoge1xyXG5cdFx0XHRcdFx0XCJfaWRcIjogXCIkX2lkXCIsXHJcblx0XHRcdFx0XHRcIm5zaXRlXCI6IFwiJHNpdGUubmFtZVwiLFxyXG5cdFx0XHRcdFx0XCJpZFNpdGVcIjogXCIkc2l0ZS5faWRcIixcclxuXHRcdFx0XHRcdFwiaWRQTENcIjogXCIkcGxjLl9pZFwiLFxyXG5cdFx0XHRcdFx0XCJzZWxlY3RQTENcIjogXCIkcGxjLm5hbWVcIixcclxuXHRcdFx0XHRcdFwidGFnTmFtZVwiOiBcIiR0YWdOYW1lXCIsXHJcblx0XHRcdFx0XHRcImRlc2NyaXB0aW9uXCI6IFwiJGRlc2NyaXB0aW9uXCIsXHJcblx0XHRcdFx0XHRcImRhdGFCbG9ja1wiOiBcIiRkYXRhQmxvY2tcIixcclxuXHRcdFx0XHRcdFwidHlwZURhdGFcIjogXCIkdHlwZURhdGFcIixcclxuXHRcdFx0XHRcdFwidHlwZU9iamVjdFwiOiBcIiR0eXBlT2JqZWN0XCIsXHRcdFx0XHRcclxuXHRcdFx0XHRcdFwiYWRkcmVzc01vZGJ1c1wiOiBcIiRhZGRyZXNzTW9kYnVzXCIsXHJcblx0XHRcdFx0XHRcImFsYXJtRW5hYmxlXCI6IFwiJGFsYXJtRW5hYmxlXCIsXHJcblx0XHRcdFx0XHRcInN0YXR1c1wiOiBcIiRzdGF0dXNcIixcclxuXHRcdFx0XHRcdFwicXVhbnRpdHlcIjogXCIkcXVhbnRpdHlcIixcclxuXHRcdFx0XHRcdFwiYXR0cmlidXRlXCI6IFwiJGF0dHJpYnV0ZVwiLFxyXG5cdFx0XHRcdFx0XCJ2YWx1ZVwiOiBcIiRfaWRcIixcclxuXHRcdFx0XHRcdFwibGFiZWxcIjogXCIkdGFnTmFtZVwiLFxyXG5cdFx0XHRcdCAgIH1cclxuXHRcdFx0XHR9XHJcblx0XHRcdF0pLnRvQXJyYXkoKTtcdFx0XHRcdFxyXG5cdFx0fSxcdFx0XHJcblx0XHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHRcdGFzeW5jICAndGFnaW50ZXJmYWNlcy5nZXRhdHRyaWJ1dGVhc3luYycoKSBcclxuXHRcdHtcclxuXHRcdFx0dmFyIGRhdGFCbG9jayA9IFtdO1xyXG5cdFx0XHRhd2FpdCBUYWdzSW50ZXJmYWNlLnJhd0NvbGxlY3Rpb24oKS5hZ2dyZWdhdGUoW1xyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdCRsb29rdXA6XHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdGZyb206IFwicGxjaW50ZXJmYWNlc1wiLFxyXG5cdFx0XHRcdFx0XHRsb2NhbEZpZWxkOiBcInNlbGVjdFBMQ1wiLFxyXG5cdFx0XHRcdFx0XHRmb3JlaWduRmllbGQ6IFwiX2lkXCIsXHJcblx0XHRcdFx0XHRcdGFzOiBcInBsY1wiXHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fSxcclxuXHRcdFx0XHR7ICR1bndpbmQ6IFwiJHBsY1wiIH0sXHJcblx0XHRcdFx0eyRwcm9qZWN0OiBcclxuXHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0XCJpZFNpdGVcIjogXCIkcGxjLnNpdGVcIixcclxuXHRcdFx0XHRcdFx0XCJ0YWdOYW1lXCI6IFwiJHRhZ05hbWVcIixcclxuXHRcdFx0XHRcdFx0XCJhdHRyaWJ1dGVcIjogXCIkYXR0cmlidXRlXCIsXHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVx0XHRcdFx0XHRcclxuXHRcdFx0XSkuZm9yRWFjaChmdW5jdGlvbihkb2MpIHtcclxuXHRcdFx0XHRmb3IgKHZhciBwcm9wIGluIGRvYy5hdHRyaWJ1dGUpIHtcclxuXHRcdFx0XHRcdGlmIChkb2MuYXR0cmlidXRlLmhhc093blByb3BlcnR5KHByb3ApKSB7XHJcblx0XHRcdFx0XHRcdHZhciBuYW1lID0gZG9jLnRhZ05hbWUgKyBcIi5cIiArIHByb3A7XHJcblx0XHRcdFx0XHRcdGRhdGFCbG9jay5wdXNoKHtcclxuXHRcdFx0XHRcdFx0XHRpZFNpdGU6ICBkb2MuaWRTaXRlLFxyXG5cdFx0XHRcdFx0XHRcdG5hbWU6IG5hbWVcclxuXHRcdFx0XHRcdFx0fSk7XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH1cclxuXHRcdFx0fSk7XHJcblx0XHRcdFxyXG5cdFx0XHRyZXR1cm4gZGF0YUJsb2NrO1xyXG5cdFx0fSxcdFxyXG5cdFx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHRcclxuXHRcdGFzeW5jICd0YWdpbnRlcmZhY2VzLmdldFBvd2VyUmF0ZURhaWx5JygpIFxyXG5cdFx0e1x0XHRcclxuXHRcdFx0dmFyIGxvYWRQb3dlciA9IDA7XHJcblx0XHRcdGF3YWl0IFRhZ3NJbnRlcmZhY2UucmF3Q29sbGVjdGlvbigpLmFnZ3JlZ2F0ZShbXHJcblx0XHRcdFx0eyRtYXRjaDogeyB0eXBlRGF0YSA6IFwiU0NST2JqZWN0XCIgfX0gXHJcblx0XHRcdF0pLmZvckVhY2goZnVuY3Rpb24oZG9jKSB7XHJcblx0XHRcdFx0bG9hZFBvd2VyID0gbG9hZFBvd2VyICsgcGFyc2VJbnQoZG9jLmF0dHJpYnV0ZS5Mb2FkUG93ZXJbMF0pXHRcdFx0XHJcblx0XHRcdH0pO1x0XHRcclxuXHRcdFx0Ly9XIHVuaXQgdG8ga1dcclxuXHRcdFx0XHJcblx0XHRcdGxvYWRQb3dlciA9IHBhcnNlRmxvYXQobG9hZFBvd2VyIC8gMTAwMCkudG9GaXhlZCgyKTtcclxuXHRcdFx0cmV0dXJuIGxvYWRQb3dlcjtcdFx0XHJcblx0XHR9LFx0XHRcclxuXHR9KVxyXG59O1xyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuXHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHRcclxuXHQndGFnaW50ZXJmYWNlcy5nZXRuYW1lJyhpZF90YWcpIFxyXG5cdHtcdFx0XHJcblx0XHR2YXIgdGFnTmFtZSA9IFRhZ3NJbnRlcmZhY2UuZmluZE9uZSh7IF9pZDppZF90YWd9KTtcdFx0XHJcblx0XHRpZiAodGFnTmFtZT09bnVsbCkge1xyXG5cdFx0XHRyZXR1cm4gbnVsbDtcclxuXHRcdH1cclxuXHRcdGVsc2VcclxuXHRcdHtcclxuXHRcdFx0cmV0dXJuIHRhZ05hbWUudGFnTmFtZTtcclxuXHRcdH1cdFx0XHRcclxuXHR9LFx0XHRcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcdFxyXG5cdCd0YWdpbnRlcmZhY2VzLmdldFRhZycoaWRfdGFnKSBcclxuXHR7XHRcdFxyXG5cdFx0dmFyIHRhZyA9IFRhZ3NJbnRlcmZhY2UuZmluZE9uZSh7IF9pZDppZF90YWd9LHtfaWQ6MCx0YWdOYW1lOjAsZGVzY3JpcHRpb246MCxkYXRhQmxvY2s6MCxjcmVhdGVEYXRlOjAscXVhbnRpdHk6MH0pO1x0XHRcclxuXHRcdGlmICh0YWc9PW51bGwpIHtcclxuXHRcdFx0cmV0dXJuIG51bGw7XHJcblx0XHR9XHJcblx0XHRlbHNlXHJcblx0XHR7XHJcblx0XHRcdHJldHVybiB0YWc7XHJcblx0XHR9XHRcdFx0XHJcblx0fSxcclxuXHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHRcclxuXHQndGFnaW50ZXJmYWNlcy5nZXRkYXRhYmxvY2snKCkgXHJcblx0e1xyXG5cdFx0dmFyIGRhdGFCbG9jazEgPSBbXTtcclxuXHRcdFxyXG5cdFx0VGFnc0ludGVyZmFjZS5maW5kKHt9LCB7c29ydDoge2NyZWF0ZURhdGU6IC0xfX0pLmZvckVhY2goZnVuY3Rpb24oZG9jKSB7XHJcblx0XHRcdFxyXG5cdFx0XHR2YXIgcGxjID0gTWV0ZW9yLmNhbGwoJ3BsY2ludGVyZmFjZXMuZmluZHBsYycsZG9jLnNlbGVjdFBMQyk7XHJcblx0XHRcdHZhciBuc2l0ZSA9IE1ldGVvci5jYWxsKCdzaXRlaW50ZXJmYWNlcy5nZXRuYW1lJyxwbGMuc2l0ZSk7XHJcblx0XHRcdFxyXG5cdFx0XHR2YXIgZGF0YUV4cGFuZCA9IFtdO1xyXG5cdFx0XHQvLyB2YXIgYWRkciA9IHBhcnNlSW50KGRvYy5hZGRyZXNzTW9kYnVzKTtcclxuXHRcdFx0Ly8gZm9yICh2YXIgcHJvcCBpbiBkb2MuYXR0cmlidXRlKSB7XHJcblx0XHRcdFx0Ly8gaWYgKGRvYy5hdHRyaWJ1dGUuaGFzT3duUHJvcGVydHkocHJvcCkpIHtcclxuXHRcdFx0XHRcdC8vIHZhciBuYW1lID0gZG9jLnRhZ05hbWUgKyBcIi5cIiArIHByb3A7XHJcblx0XHRcdFx0XHQvLyBkYXRhRXhwYW5kLnB1c2goe1xyXG5cdFx0XHRcdFx0XHQvLyBmaWVsZEE6IHByb3AsXHJcblx0XHRcdFx0XHRcdC8vIGZpZWxkQjogYWRkcixcclxuXHRcdFx0XHRcdFx0Ly8gZmllbGRDOiBkb2MuYXR0cmlidXRlW3Byb3BdWzBdXHJcblx0XHRcdFx0XHQvLyB9KTtcdFxyXG5cdFx0XHRcdFx0Ly8gYWRkciA9IGFkZHIgKyBwYXJzZUludChkb2MuYXR0cmlidXRlW3Byb3BdWzFdKTtcclxuXHRcdFx0XHQvLyB9XHJcblx0XHRcdC8vIH1cdFxyXG5cdFx0XHRcclxuXHRcdFx0ZGF0YUJsb2NrMS5wdXNoKHtcclxuXHRcdFx0XHRfaWQ6IGRvYy5faWQsXHJcblx0XHRcdFx0aWRTaXRlOiBwbGMuc2l0ZSxcclxuXHRcdFx0XHRuc2l0ZTogbnNpdGUsXHJcblx0XHRcdFx0aWRQTEM6ZG9jLnNlbGVjdFBMQyxcclxuXHRcdFx0XHRzZWxlY3RQTEM6IHBsYy5uYW1lLFxyXG5cdFx0XHRcdHRhZ05hbWUgOiBkb2MudGFnTmFtZSxcclxuXHRcdFx0XHRkZXNjcmlwdGlvbiA6IGRvYy5kZXNjcmlwdGlvbixcdFx0XHRcdFxyXG5cdFx0XHRcdGRhdGFCbG9jayA6IGRvYy5kYXRhQmxvY2ssXHJcblx0XHRcdFx0dHlwZURhdGEgOiBkb2MudHlwZURhdGEsXHJcblx0XHRcdFx0dHlwZU9iamVjdCA6IGRvYy50eXBlT2JqZWN0LFx0XHRcdFx0XHJcblx0XHRcdFx0YWRkcmVzc01vZGJ1cyA6IGRvYy5hZGRyZXNzTW9kYnVzLFx0XHRcclxuXHRcdFx0XHRhbGFybUVuYWJsZSA6IGRvYy5hbGFybUVuYWJsZSxcclxuXHRcdFx0XHRzdGF0dXMgOiBkb2Muc3RhdHVzLFxyXG5cdFx0XHRcdHF1YW50aXR5OiBkb2MucXVhbnRpdHksXHJcblx0XHRcdFx0YXR0cmlidXRlOiBkb2MuYXR0cmlidXRlLFxyXG5cdFx0XHRcdGV4cGFuZDogZGF0YUV4cGFuZFx0XHRcclxuXHRcdFx0fSk7XHRcdFx0XHJcblx0XHRcdFxyXG5cdFx0fSk7XHJcblx0XHRcclxuXHRcdHJldHVybiBkYXRhQmxvY2sxO1xyXG5cdH0sXHRcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcdFxyXG5cdCd0YWdpbnRlcmZhY2VzLmdldGRhdGFibG9ja09iaicoKSBcclxuXHR7XHJcblx0XHR2YXIgZGF0YUJsb2NrMSA9IFtdO1xyXG5cdFx0VGFnc0ludGVyZmFjZS5maW5kKHt9LCB7c29ydDoge2NyZWF0ZURhdGU6IC0xfX0pLmZvckVhY2goZnVuY3Rpb24oZG9jKSB7XHRcdFx0IFxyXG5cdFx0XHR2YXIgaWRTaXRlID0gTWV0ZW9yLmNhbGwoJ3BsY2ludGVyZmFjZXMuZ2V0c2l0ZScsZG9jLnNlbGVjdFBMQyk7XHRcdFx0XHJcblx0XHRcdGRhdGFCbG9jazEucHVzaCh7XHJcblx0XHRcdFx0X2lkOiBkb2MuX2lkLFxyXG5cdFx0XHRcdGlkU2l0ZTogaWRTaXRlLFxyXG5cdFx0XHRcdHRhZ05hbWUgOiBkb2MudGFnTmFtZVxyXG5cdFx0XHR9KTtcdFx0XHRcclxuXHRcdFx0XHJcblx0XHR9KTtcclxuXHRcdFxyXG5cdFx0cmV0dXJuIGRhdGFCbG9jazE7XHJcblx0fSxcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQndGFnaW50ZXJmYWNlcy5nZXRhdHRyaWJ1dGUnKCkgXHJcblx0e1xyXG5cdFx0dmFyIGRhdGFCbG9jayA9IFtdO1xyXG5cdFx0VGFnc0ludGVyZmFjZS5maW5kKCkuZm9yRWFjaChmdW5jdGlvbihkb2MpIHtcclxuXHRcdFx0Zm9yICh2YXIgcHJvcCBpbiBkb2MuYXR0cmlidXRlKSB7XHJcblx0XHRcdFx0aWYgKGRvYy5hdHRyaWJ1dGUuaGFzT3duUHJvcGVydHkocHJvcCkpIHtcclxuXHRcdFx0XHRcdHZhciBuYW1lID0gZG9jLnRhZ05hbWUgKyBcIi5cIiArIHByb3A7XHJcblx0XHRcdFx0XHRkYXRhQmxvY2sucHVzaCh7XHJcblx0XHRcdFx0XHRcdG5hbWU6IG5hbWUsXHJcblx0XHRcdFx0XHRcdG5hbWU6IG5hbWVcclxuXHRcdFx0XHRcdH0pO1x0XHRcdFx0XHRcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdH0pO1xyXG5cdFx0XHJcblx0XHRyZXR1cm4gZGF0YUJsb2NrO1xyXG5cdH0sXHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0J2dldE9iamVjdHMnKHRhZ05hbWUpIFxyXG5cdHtcdHZhciBkYXRhQmxvY2sgPSBbXTtcclxuXHRcdFRhZ3NJbnRlcmZhY2UuZmluZCh7dGFnTmFtZTp0YWdOYW1lfSkuZm9yRWFjaChmdW5jdGlvbihkb2MpIHtcclxuXHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdENUREVNOiBkb2MuYXR0cmlidXRlLkNUREVNWzBdLFxyXG5cdFx0XHRcdENUTTogZG9jLmF0dHJpYnV0ZS5DVE1bMF0sXHJcblx0XHRcdFx0Q1RNSjogZG9jLmF0dHJpYnV0ZS5DVE1KWzBdLFxyXG5cdFx0XHRcdFRNUzogZG9jLmF0dHJpYnV0ZS5UTVNbMF0sXHJcblx0XHRcdFx0RVRBVF9NT0RFOiBkb2MuYXR0cmlidXRlLkVUQVRfTU9ERVswXSxcclxuXHRcdFx0XHRFVEFUX1JVTk5JTkc6IGRvYy5hdHRyaWJ1dGUuRVRBVF9SVU5OSU5HWzBdLFxyXG5cdFx0XHRcdENNRDogZG9jLmF0dHJpYnV0ZS5DTURbMF0sXHJcblx0XHRcdFx0RVRBVDogZG9jLmF0dHJpYnV0ZS5FVEFUWzBdXHJcblx0XHRcdH0pO1xyXG5cdFx0fSk7XHJcblx0XHRyZXR1cm4gZGF0YUJsb2NrO1xyXG5cdH0sXHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0J3RhZ2ludGVyZmFjZXMuaW5zZXJ0JyhcdFx0XHRcclxuXHRcdHRhZ05hbWUsXHJcblx0XHRkZXNjcmlwdGlvbixcclxuXHRcdHNlbGVjdFBMQyxcclxuXHRcdGRhdGFCbG9jayxcclxuXHRcdHR5cGVEYXRhLFx0XHJcblx0XHR0eXBlT2JqZWN0LFxyXG5cdFx0YWRkcmVzc01vZGJ1cyxcdFx0XHJcblx0XHRhbGFybUVuYWJsZSxcclxuXHRcdHNpdGUsXHJcblx0XHRkYXRhY2hhbmdlLFxyXG5cdFx0Y3JlYXRlRGF0ZVxyXG5cdFx0KSBcclxuXHR7XHJcblx0XHR2YXIgcXVhbnRpdHkgPSAxMDtcclxuXHRcdHZhciBzdGF0dXMgPVwiZ29vZFwiO1xyXG5cdFx0dmFyIGF0dHJpYnV0ZT1bXTtcclxuXHRcdHZhciB1bnZhbGlkID0gMDtcclxuXHRcdHN3aXRjaCh0eXBlRGF0YSlcclxuXHRcdHtcclxuXHRcdFx0XHJcblx0XHRcdGNhc2UgXCJBbGFybVwiOlxyXG5cdFx0XHRcdHN3aXRjaCh0eXBlT2JqZWN0KVxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdGNhc2UgXCJCb29sXCI6XHJcblx0XHRcdFx0XHRcdGF0dHJpYnV0ZSA9IHtcclxuXHRcdFx0XHRcdFx0XHRSRUc6IFswLDFdLFxyXG5cdFx0XHRcdFx0XHRcdFZBTFVFOiBbMCwxXVx0XHRcclxuXHRcdFx0XHRcdFx0fVx0XHRcdFxyXG5cdFx0XHRcdFx0XHRxdWFudGl0eSA9IDI7XHRcdFx0XHRcclxuXHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0Y2FzZSBcIkludGVnZXJcIjpcclxuXHRcdFx0XHRcdFx0YXR0cmlidXRlID0ge1xyXG5cdFx0XHRcdFx0XHRcdFZBTFVFOiBbMCwxXVx0XHRcclxuXHRcdFx0XHRcdFx0fVx0XHRcdFxyXG5cdFx0XHRcdFx0XHRxdWFudGl0eSA9IDE7XHRcdFx0XHRcclxuXHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0ZGVmYXVsdDogXHJcblx0XHRcdFx0XHRcdHVudmFsaWQgPSAxO1xyXG5cdFx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0YnJlYWs7XHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0Y2FzZSBcIlRNUE9iamVjdFwiOlxyXG5cdFx0XHRcdGF0dHJpYnV0ZSA9IHtcclxuXHRcdFx0XHRcdFZBTFVFMDogWzIxLDJdLFxyXG5cdFx0XHRcdFx0VkFMVUUxOiBbMjIsMl0sXHJcblx0XHRcdFx0XHRWQUxVRTI6IFsyMywyXSxcclxuXHRcdFx0XHRcdFZBTFVFMzogWzI0LDJdLFxyXG5cdFx0XHRcdFx0VkFMVUU0OiBbMjUsMl0sXHJcblx0XHRcdFx0XHRWQUxVRTU6IFsyNiwyXSxcclxuXHRcdFx0XHRcdFZBTFVFNjogWzI3LDJdLFxyXG5cdFx0XHRcdFx0VkFMVUU3OiBbMjgsMl0sXHJcblx0XHRcdFx0XHRWQUxVRTg6IFsyNC41LDJdLFxyXG5cdFx0XHRcdFx0RVRBVCAgOiBbMCwxXSxcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRBTEFSTV9VU1JFUiA6IFswLDJdLFxyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRxdWFudGl0eSA9IDE5O1xyXG5cdFx0XHRcdGJyZWFrO1x0XHJcblx0XHRcdGNhc2UgXCJTQ1JPYmplY3RcIjpcclxuXHRcdFx0XHRhdHRyaWJ1dGUgPSB7XHJcblx0XHRcdFx0XHRMb2NhbFJlbW90ZTogWzAsMV0sXHJcblx0XHRcdFx0XHRDTURSZW1vdGU6IFswLDFdLFxyXG5cdFx0XHRcdFx0Q2xlYXJFcnJvckxhdGNoOiBbMCwxXSxcclxuXHRcdFx0XHRcdFNldHBvaW50OiBbMCwyXSxcclxuXHRcdFx0XHRcdExpbmVGcmVxdWVuY3k6IFswLDJdLFxyXG5cdFx0XHRcdFx0TGluZVZvbHRhZ2VBOiBbMCwyXSxcclxuXHRcdFx0XHRcdExvYWRWb2x0YWdlQTogWzAsMl0sXHJcblx0XHRcdFx0XHRMb2FkQ3VycmVudEE6IFswLDJdLFxyXG5cdFx0XHRcdFx0SGVhdHNpbmtUZW1wQTogWzAsMl0sXHJcblx0XHRcdFx0XHRMaW5lVm9sdGFnZUI6IFswLDJdLFxyXG5cdFx0XHRcdFx0TG9hZFZvbHRhZ2VCOiBbMCwyXSxcclxuXHRcdFx0XHRcdExvYWRDdXJyZW50QjogWzAsMl0sXHJcblx0XHRcdFx0XHRIZWF0c2lua1RlbXBCOiBbMCwyXSxcclxuXHRcdFx0XHRcdExpbmVWb2x0YWdlQzogWzAsMl0sXHJcblx0XHRcdFx0XHRMb2FkVm9sdGFnZUM6IFswLDJdLFxyXG5cdFx0XHRcdFx0TG9hZEN1cnJlbnRDOiBbMCwyXSxcclxuXHRcdFx0XHRcdEhlYXRzaW5rVGVtcEM6IFswLDJdLFxyXG5cdFx0XHRcdFx0Q29udHJvbGxlclN0YXRlOiBbMCwxXSxcclxuXHRcdFx0XHRcdFdhcm5pbmdBbGFybTogWzAsMV0sXHJcblx0XHRcdFx0XHREdXR5OiBbMCwyXSxcclxuXHRcdFx0XHRcdExvYWRQb3dlcjogWzAsMl0sXHJcblx0XHRcdFx0XHRJbmhpYml0OiBbMCwyXSxcclxuXHRcdFx0XHRcdEVuZXJneTpbMCwyXSxcclxuXHRcdFx0XHRcdEFMb3N0Q29tbXVuaWNhdGlvbjpbMCwyXSxcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0cXVhbnRpdHkgPSAzNztcclxuXHRcdFx0XHRicmVhaztcdFx0XHRcdFx0XHJcblx0XHRcdGNhc2UgXCJWU0RcIjpcclxuXHRcdFx0XHRhdHRyaWJ1dGUgPSB7XHJcblx0XHRcdFx0XHRDVERFTTogWzAsMl0sXHJcblx0XHRcdFx0XHRDVE06IFswLDJdLFxyXG5cdFx0XHRcdFx0Q1RNSjogWzAsMl0sXHJcblx0XHRcdFx0XHRUTVM6IFswLDFdLFxyXG5cdFx0XHRcdFx0RVRBVF9NT0RFOiBbMCwxXSxcclxuXHRcdFx0XHRcdEVUQVRfUlVOTklORzogWzAsMV0sXHJcblx0XHRcdFx0XHRGRUVEQkFDSzogWzAsMV0sXHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0Q01EOiAgWzAsMV0sXHJcblx0XHRcdFx0XHRFVEFUOiAgWzAsMV1cclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0cXVhbnRpdHkgPSAxMjtcclxuXHRcdFx0XHRicmVhaztcdFx0XHRcclxuXHRcdFx0Y2FzZSBcIkRPTFwiOlxyXG5cdFx0XHRcdGF0dHJpYnV0ZSA9IHtcclxuXHRcdFx0XHRcdENUREVNOiBbMCwyXSxcclxuXHRcdFx0XHRcdENUTTogWzAsMl0sXHJcblx0XHRcdFx0XHRDVE1KOiBbMCwyXSxcclxuXHRcdFx0XHRcdFRNUzogWzAsMV0sXHJcblx0XHRcdFx0XHRFVEFUX01PREU6IFswLDFdLFxyXG5cdFx0XHRcdFx0RVRBVF9SVU5OSU5HOiBbMCwxXSxcdFx0XHRcdFxyXG5cdFx0XHRcdFx0Q01EOiAgWzAsMV0sXHJcblx0XHRcdFx0XHRFVEFUOiAgWzAsMV1cclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0cXVhbnRpdHkgPSAxMTtcclxuXHRcdFx0XHRicmVhaztcdFxyXG5cdFx0XHRjYXNlIFwiVmFsdmVcIjpcclxuXHRcdFx0XHRzd2l0Y2godHlwZU9iamVjdClcclxuXHRcdFx0XHR7XHJcblx0XHRcdFx0XHRjYXNlIFwiQW5hbG9nVmFsdmVcIjpcclxuXHRcdFx0XHRcdGNhc2UgXCJBbmFsb2dWYWx2ZTkwXCI6XHJcblx0XHRcdFx0XHRjYXNlIFwiQW5hbG9nVmFsdmVDb250cm9sXCI6ICAgLy9TY2FsZSBmcm9tIDAtMTBcclxuXHRcdFx0XHRcdGNhc2UgXCJBbmFsb2dWYWx2ZUNvbnRyb2wwMlwiOiAvL1NjYWxlIGZyb20gMC0yMFxyXG5cdFx0XHRcdFx0Y2FzZSBcIkFuYWxvZ1ZhbHZlQ29udHJvbDAzXCI6IC8vU2NhbGUgZnJvbSAwLTEwMFxyXG5cdFx0XHRcdFx0Y2FzZSBcIkFuYWxvZ0dhdGVWYWx2ZVwiOlx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0YXR0cmlidXRlID0ge1x0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHRFVEFUOiAgWzAsMV0sXHJcblx0XHRcdFx0XHRcdFx0Q01EOiAgWzAsMV0sXHJcblx0XHRcdFx0XHRcdFx0VE1TOiBbMCwxXSxcclxuXHRcdFx0XHRcdFx0XHRFVEFUX01PREU6IFswLDFdLFxyXG5cdFx0XHRcdFx0XHRcdEVUQVRfUlVOTklORzogWzAsMV0sXHJcblx0XHRcdFx0XHRcdFx0RkVFREJBQ0s6IFswLDFdLFx0XHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0cXVhbnRpdHkgPSA2O1xyXG5cdFx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRcdGNhc2UgXCJBbmFsb2dHYXRlVmFsdmVcIjpcclxuXHRcdFx0XHRcdFx0YXR0cmlidXRlID0ge1x0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHRFVEFUOiAgWzAsMV0sXHJcblx0XHRcdFx0XHRcdFx0Q01EOiAgWzAsMV0sXHJcblx0XHRcdFx0XHRcdFx0VE1TOiBbMCwxXSxcclxuXHRcdFx0XHRcdFx0XHRFVEFUX01PREU6IFswLDFdLFxyXG5cdFx0XHRcdFx0XHRcdEVUQVRfUlVOTklORzogWzAsMV0sXHJcblx0XHRcdFx0XHRcdFx0RkVFREJBQ0s6IFswLDFdLFx0XHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0cXVhbnRpdHkgPSA2O1xyXG5cdFx0XHRcdFx0XHRicmVhaztcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdGNhc2UgXCJEaWdpdGFsVmFsdmVcIjpcclxuXHRcdFx0XHRcdGNhc2UgXCJEaWdpdGFsVmFsdmU5MFwiOlxyXG5cdFx0XHRcdFx0Y2FzZSBcIkRpZ2l0YWxWYWx2ZTkwTGVmdFwiOlxyXG5cdFx0XHRcdFx0Y2FzZSBcIkdhdGVWYWx2ZVwiOlx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdGNhc2UgXCJDdWFQaGFpT0lLXCI6XHJcblx0XHRcdFx0XHRjYXNlIFwiQ3VhUGhhaU9JSzkwXCI6XHJcblx0XHRcdFx0XHRcdGF0dHJpYnV0ZSA9IHtcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0RVRBVDogIFswLDFdLFxyXG5cdFx0XHRcdFx0XHRcdENNRDogIFswLDFdLFxyXG5cdFx0XHRcdFx0XHRcdFRNUzogWzAsMV0sXHJcblx0XHRcdFx0XHRcdFx0RVRBVF9NT0RFOiBbMCwxXSxcclxuXHRcdFx0XHRcdFx0XHRFVEFUX1JVTk5JTkc6IFswLDFdXHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0cXVhbnRpdHkgPSA1O1x0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHRjYXNlIFwiR2F0ZVZhbHZlTG9uZ1wiOlxyXG5cdFx0XHRcdFx0XHRhdHRyaWJ1dGUgPSB7XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdEVUQVQ6ICBbMCwxXSxcclxuXHRcdFx0XHRcdFx0XHRDTUQ6ICBbMCwxXSxcclxuXHRcdFx0XHRcdFx0XHRUTVM6IFswLDFdLFxyXG5cdFx0XHRcdFx0XHRcdEVUQVRfTU9ERTogWzAsMV0sXHJcblx0XHRcdFx0XHRcdFx0RVRBVF9SVU5OSU5HOiBbMCwxXVxyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdHF1YW50aXR5ID0gNTtcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0ZGVmYXVsdDogXHJcblx0XHRcdFx0XHRcdHVudmFsaWQgPSAxO1xyXG5cdFx0XHRcdFx0XHRicmVhaztcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdGNhc2UgXCJJbnN0cnVtZW50XCI6XHJcblx0XHRcdFx0c3dpdGNoKHR5cGVPYmplY3QpXHJcblx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0Y2FzZSBcIkNvbW1vbkluc3RydW1lbnRcIjpcdFxyXG5cdFx0XHRcdFx0XHRhdHRyaWJ1dGUgPSB7XHJcblx0XHRcdFx0XHRcdFx0SEhWOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRIVjogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0TExWOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRMVjogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0VkFMVUU6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdEVUQVQ6IFswLDFdXHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0fVx0XHRcdFxyXG5cdFx0XHRcdFx0XHRxdWFudGl0eSA9IDExO1xyXG5cdFx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRcdGNhc2UgXCJGSVRJbnN0cnVtZW50XCI6XHRcclxuXHRcdFx0XHRcdFx0YXR0cmlidXRlID0ge1xyXG5cdFx0XHRcdFx0XHRcdEhIVjogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0SFY6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdExMVjogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0TFY6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdFZBTFVFOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRUT1RBTDogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0RVRBVDogWzAsMV1cdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHR9XHRcdFx0XHJcblx0XHRcdFx0XHRcdHF1YW50aXR5ID0gMTM7XHJcblx0XHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0ZGVmYXVsdDogXHJcblx0XHRcdFx0XHRcdHVudmFsaWQgPSAxOyBcclxuXHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0fVx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRjYXNlIFwiTGV2ZWxcIjpcclxuXHRcdFx0XHRhdHRyaWJ1dGUgPSB7XHJcblx0XHRcdFx0XHRFVEFUOiBbMCwxXVx0XHRcdFx0XHJcblx0XHRcdFx0fVx0XHRcdFxyXG5cdFx0XHRcdHF1YW50aXR5ID0gMTtcclxuXHRcdFx0XHRicmVhaztcdFxyXG5cdFx0XHRjYXNlIFwiV2VpZ2hpbmdcIjpcclxuXHRcdFx0XHRhdHRyaWJ1dGUgPSB7XHJcblx0XHRcdFx0XHRWQUxVRTogWzAsMl0sXHJcblx0XHRcdFx0XHRWQUxVRV9TQVZFOiBbMCwyXSxcclxuXHRcdFx0XHRcdEhSVjogWzAsMl0sXHJcblx0XHRcdFx0XHRMUlY6IFswLDJdLFxyXG5cdFx0XHRcdFx0VExHOiBbMCwyXSxcclxuXHRcdFx0XHRcdEVUQVQ6IFswLDJdLFx0XHJcblx0XHRcdFx0XHRDTURcdDogWzAsMl0sXHRcdFxyXG5cdFx0XHRcdH1cdFx0XHRcclxuXHRcdFx0XHRxdWFudGl0eSA9IDEyO1xyXG5cdFx0XHRcdGJyZWFrO1x0XHRcdFx0XHRcclxuXHRcdFx0Y2FzZSBcIkVMRUNUUklDXCI6XHJcblx0XHRcdFx0YXR0cmlidXRlID0ge1xyXG5cdFx0XHRcdFx0RVRBVDogWzAsMV1cdFx0XHRcdFxyXG5cdFx0XHRcdH1cdFx0XHRcclxuXHRcdFx0XHRxdWFudGl0eSA9IDE7XHJcblx0XHRcdFx0YnJlYWs7XHRcdFx0XHRcclxuXHRcdFx0Y2FzZSBcIk51bWJlclwiOlxyXG5cdFx0XHRcdHN3aXRjaCh0eXBlT2JqZWN0KVxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdGNhc2UgXCJCb29sXCI6XHJcblx0XHRcdFx0XHRcdGF0dHJpYnV0ZSA9IHtcclxuXHRcdFx0XHRcdFx0XHRSRUc6IFswLDFdLFxyXG5cdFx0XHRcdFx0XHRcdFZBTFVFOiBbMCwxXVx0XHRcclxuXHRcdFx0XHRcdFx0fVx0XHRcdFxyXG5cdFx0XHRcdFx0XHRxdWFudGl0eSA9IDI7XHRcdFx0XHRcclxuXHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0Y2FzZSBcIkludGVnZXJcIjpcclxuXHRcdFx0XHRcdFx0YXR0cmlidXRlID0ge1xyXG5cdFx0XHRcdFx0XHRcdFZBTFVFOiBbMCwxXVx0XHRcclxuXHRcdFx0XHRcdFx0fVx0XHRcdFxyXG5cdFx0XHRcdFx0XHRxdWFudGl0eSA9IDE7XHRcdFx0XHRcclxuXHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0Y2FzZSBcIkRvdWJsZUludGVnZXJcIjpcclxuXHRcdFx0XHRcdFx0YXR0cmlidXRlID0ge1xyXG5cdFx0XHRcdFx0XHRcdFZBTFVFOiBbMCwyXVx0XHRcclxuXHRcdFx0XHRcdFx0fVx0XHRcdFxyXG5cdFx0XHRcdFx0XHRxdWFudGl0eSA9IDI7XHRcdFx0XHRcclxuXHRcdFx0XHRcdGJyZWFrO1x0XHRcdFxyXG5cdFx0XHRcdFx0Y2FzZSBcIlJlYWxcIjpcclxuXHRcdFx0XHRcdFx0YXR0cmlidXRlID0ge1xyXG5cdFx0XHRcdFx0XHRcdFZBTFVFOiBbMCwyXVx0XHRcclxuXHRcdFx0XHRcdFx0fVx0XHRcdFxyXG5cdFx0XHRcdFx0XHRxdWFudGl0eSA9IDI7XHRcdFx0XHRcclxuXHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0ZGVmYXVsdDogXHJcblx0XHRcdFx0XHRcdHVudmFsaWQgPSAxO1xyXG5cdFx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdGNhc2UgXCJQT1dFUk1FVEVSXCI6XHJcblx0XHRcdFx0c3dpdGNoKHR5cGVPYmplY3QpXHJcblx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0Y2FzZSBcIlBvd2VyTWV0ZXJcIjpcclxuXHRcdFx0XHRcdGNhc2UgXCJQb3dlck1ldGVyMjIwMFwiOlxyXG5cdFx0XHRcdFx0XHRhdHRyaWJ1dGUgPSB7XHJcblx0XHRcdFx0XHRcdFx0UDE6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdFAyOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRQMzogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0UF9UT1RBTDogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0UTE6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdFEyOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRRMzogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0UV9UT1RBTDogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0UzE6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdFMyOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRTMzogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0U19UT1RBTDogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0UE9XRVJGQUNUT1IxOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRQT1dFUkZBQ1RPUjI6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdFBPV0VSRkFDVE9SMzogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0UE9XRVJGQUNUT1JfQVZHOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRJMTogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0STI6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdEkzOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRJX0FWRzogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0RlJFUTogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0VTEyOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRVMjM6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdFUzMTogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0VV9BVkc6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdFYxOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRWMjogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0VjM6IFswLDJdLFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdFZfQVZHOiBbMCwyXSxcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHRFTkVSR1k6IFswLDJdLFx0XHRcdFxyXG5cdFx0XHRcdFx0XHR9XHRcdFx0XHJcblx0XHRcdFx0XHRcdHF1YW50aXR5ID0gNjA7XHJcblx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRcdGRlZmF1bHQ6IFxyXG5cdFx0XHRcdFx0XHR1bnZhbGlkID0gMTsgXHJcblx0XHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdH1cdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRicmVhaztcdFx0XHJcblx0XHRcdFx0XHJcblx0XHRcdGRlZmF1bHQ6XHJcblx0XHRcdFx0dW52YWxpZCA9IDE7XHJcblx0XHRcdGJyZWFrO1xyXG5cdFx0fVxyXG5cdFx0aWYgKHVudmFsaWQ9PTEpXHJcblx0XHR7XHJcblx0XHRcdC8vTm90aGluZ1xyXG5cdFx0fVxyXG5cdFx0ZWxzZVxyXG5cdFx0e1xyXG5cdFx0XHRpZiAoVGFnc0ludGVyZmFjZS5maW5kT25lKHsgJGFuZDogWyB7IHNlbGVjdFBMQzogeyAkZXE6IHNlbGVjdFBMQyB9IH0sIHsgdGFnTmFtZTogeyAkZXE6IHRhZ05hbWUgfX1dfSkgIT1udWxsKVxyXG5cdFx0XHR7XHJcblx0XHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIkR1cGxpY2F0ZSBUYWduYW1lLCBQbGVhc2UgY2hlY2sgYWdhaW5cIik7XHJcblx0XHRcdH1cclxuXHRcdFx0ZWxzZSBcclxuXHRcdFx0e1x0XHRcdFx0XHJcblx0XHRcdFx0VGFnc0ludGVyZmFjZS5pbnNlcnQoe1xyXG5cdFx0XHRcdFx0dGFnTmFtZSxcclxuXHRcdFx0XHRcdGRlc2NyaXB0aW9uLFxyXG5cdFx0XHRcdFx0c2VsZWN0UExDLFxyXG5cdFx0XHRcdFx0ZGF0YUJsb2NrLFxyXG5cdFx0XHRcdFx0dHlwZURhdGEsXHRcclxuXHRcdFx0XHRcdHR5cGVPYmplY3QsXHJcblx0XHRcdFx0XHRhZGRyZXNzTW9kYnVzLFx0XHRcclxuXHRcdFx0XHRcdGFsYXJtRW5hYmxlLFxyXG5cdFx0XHRcdFx0c3RhdHVzLFxyXG5cdFx0XHRcdFx0cXVhbnRpdHksXHJcblx0XHRcdFx0XHRhdHRyaWJ1dGUsXHJcblx0XHRcdFx0XHRzaXRlLFxyXG5cdFx0XHRcdFx0ZGF0YWNoYW5nZSxcclxuXHRcdFx0XHRcdGNyZWF0ZURhdGVcclxuXHRcdFx0XHR9KTtcclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cdH0sXHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0J3RhZ2ludGVyZmFjZXMudXBkYXRlQXR0cmlidXRlJyhcdFx0XHJcblx0XHRfaWQsXHJcblx0XHR0eXBlRGF0YSxcclxuXHRcdHR5cGVPYmplY3QsXHRcclxuXHRcdHZhbHVlY21kLFxyXG5cdFx0Y3JlYXRlRGF0ZVxyXG5cdFx0KSBcclxuXHR7XHJcblx0XHQvL2NvbnNvbGUubG9nKFwidHlwZURhdGE6IFwiICsgdHlwZURhdGEgKyBcIiwgdHlwZU9iamVjdDogXCIgKyB0eXBlT2JqZWN0KVxyXG5cdFx0dmFyIGF0dHJpYnV0ZT1bXTtcclxuXHRcdHZhciB1bnZhbGlkID0gMDtcclxuXHRcdHN3aXRjaCh0eXBlRGF0YSlcclxuXHRcdHtcclxuXHRcdFx0Y2FzZSBcIk51bWJlclwiOlxyXG5cdFx0XHRcdHN3aXRjaCh0eXBlT2JqZWN0KVxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdGNhc2UgXCJJbnRlZ2VyXCI6XHJcblx0XHRcdFx0XHRcdGF0dHJpYnV0ZSA9IHtcclxuXHRcdFx0XHRcdFx0XHRWQUxVRTogW3ZhbHVlY21kLDFdXHRcdFxyXG5cdFx0XHRcdFx0XHR9XHRcdFx0XHJcblx0XHRcdFx0XHRcdHF1YW50aXR5ID0gMTtcdFx0XHRcdFxyXG5cdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHRjYXNlIFwiRG91YmxlSW50ZWdlclwiOlxyXG5cdFx0XHRcdFx0XHRhdHRyaWJ1dGUgPSB7XHJcblx0XHRcdFx0XHRcdFx0VkFMVUU6IFt2YWx1ZWNtZCwyXVx0XHRcclxuXHRcdFx0XHRcdFx0fVx0XHRcdFxyXG5cdFx0XHRcdFx0XHRxdWFudGl0eSA9IDI7XHRcdFx0XHRcclxuXHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0ZGVmYXVsdDogXHJcblx0XHRcdFx0XHRcdHVudmFsaWQgPSAxO1xyXG5cdFx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0YnJlYWs7XHRcclxuXHJcblx0XHRcdGRlZmF1bHQ6IFxyXG5cdFx0XHRcdHVudmFsaWQgPSAxO1xyXG5cdFx0XHRcdGJyZWFrO1x0XHRcdFx0XHJcblx0XHR9XHRcdFx0XHJcblx0XHRcclxuXHRcdGlmICh1bnZhbGlkPT0xKVxyXG5cdFx0e1xyXG5cdFx0XHQvL05vdGhpbmdcclxuXHRcdH1cclxuXHRcdGVsc2VcclxuXHRcdHtcclxuXHRcdFx0VGFnc0ludGVyZmFjZS51cGRhdGUoX2lkLFxyXG5cdFx0XHR7ICRzZXQ6IHtcclxuXHRcdFx0XHRcdGF0dHJpYnV0ZSxcclxuXHRcdFx0XHRcdGNyZWF0ZURhdGVcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0fSk7XHJcblx0XHR9XHJcblx0XHRcclxuXHR9LFx0XHRcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQndGFnaW50ZXJmYWNlcy51cGRhdGUnKFx0XHRcclxuXHRcdF9pZCxcclxuXHRcdHRhZ05hbWUsXHJcblx0XHRkZXNjcmlwdGlvbixcclxuXHRcdHNlbGVjdFBMQyxcclxuXHRcdGRhdGFCbG9jayxcclxuXHRcdHR5cGVEYXRhLFxyXG5cdFx0dHlwZU9iamVjdCxcdFx0XHJcblx0XHRhZGRyZXNzTW9kYnVzLFx0XHRcclxuXHRcdGFsYXJtRW5hYmxlLFx0XHJcblx0XHRzaXRlLFxyXG5cdFx0ZGF0YWNoYW5nZSxcclxuXHRcdGNyZWF0ZURhdGVcclxuXHRcdCkgXHJcblx0e1xyXG5cdFx0dmFyIHF1YW50aXR5ID0gMTA7XHJcblx0XHR2YXIgc3RhdHVzID1cImdvb2RcIjtcclxuXHRcdHZhciBhdHRyaWJ1dGU9W107XHJcblx0XHR2YXIgdW52YWxpZCA9IDA7XHJcblx0XHQvL2NvbnNvbGUubG9nKFwidHlwZURhdGEgXCIgKyB0eXBlRGF0YSArIFwiIFwiICsgXCJhZGRyZXNzTW9kYnVzIFwiICsgYWRkcmVzc01vZGJ1cyk7XHJcblx0XHRzd2l0Y2godHlwZURhdGEpXHJcblx0XHR7XHJcblx0XHRcdGNhc2UgXCJBbGFybVwiOlxyXG5cdFx0XHRcdHN3aXRjaCh0eXBlT2JqZWN0KVxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdGNhc2UgXCJCb29sXCI6XHJcblx0XHRcdFx0XHRcdGF0dHJpYnV0ZSA9IHtcclxuXHRcdFx0XHRcdFx0XHRSRUc6IFswLDFdLFxyXG5cdFx0XHRcdFx0XHRcdFZBTFVFOiBbMCwxXVx0XHRcclxuXHRcdFx0XHRcdFx0fVx0XHRcdFxyXG5cdFx0XHRcdFx0XHRxdWFudGl0eSA9IDI7XHRcdFx0XHRcclxuXHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0Y2FzZSBcIkludGVnZXJcIjpcclxuXHRcdFx0XHRcdFx0YXR0cmlidXRlID0ge1xyXG5cdFx0XHRcdFx0XHRcdFZBTFVFOiBbMCwxXVx0XHRcclxuXHRcdFx0XHRcdFx0fVx0XHRcdFxyXG5cdFx0XHRcdFx0XHRxdWFudGl0eSA9IDE7XHRcdFx0XHRcclxuXHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0ZGVmYXVsdDogXHJcblx0XHRcdFx0XHRcdHVudmFsaWQgPSAxO1xyXG5cdFx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0YnJlYWs7XHRcdFx0XHRcclxuXHRcdFx0Y2FzZSBcIlRNUE9iamVjdFwiOlxyXG5cdFx0XHRcdGF0dHJpYnV0ZSA9IHtcclxuXHRcdFx0XHRcdFZBTFVFMDogWzIxLDJdLFxyXG5cdFx0XHRcdFx0VkFMVUUxOiBbMjIsMl0sXHJcblx0XHRcdFx0XHRWQUxVRTI6IFsyMywyXSxcclxuXHRcdFx0XHRcdFZBTFVFMzogWzI0LDJdLFxyXG5cdFx0XHRcdFx0VkFMVUU0OiBbMjUsMl0sXHJcblx0XHRcdFx0XHRWQUxVRTU6IFsyNiwyXSxcclxuXHRcdFx0XHRcdFZBTFVFNjogWzI3LDJdLFxyXG5cdFx0XHRcdFx0VkFMVUU3OiBbMjgsMl0sXHJcblx0XHRcdFx0XHRWQUxVRTg6IFsyNC41LDJdLFxyXG5cdFx0XHRcdFx0RVRBVCAgOiBbMCwxXSxcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRBTEFSTV9VU1JFUiA6IFswLDJdLFxyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRxdWFudGl0eSA9IDE5O1xyXG5cdFx0XHRcdGJyZWFrO1x0XHJcblx0XHRcdGNhc2UgXCJTQ1JPYmplY3RcIjpcclxuXHRcdFx0XHRhdHRyaWJ1dGUgPSB7XHJcblx0XHRcdFx0XHRMb2NhbFJlbW90ZTogWzAsMV0sXHJcblx0XHRcdFx0XHRDTURSZW1vdGU6IFswLDFdLFxyXG5cdFx0XHRcdFx0Q2xlYXJFcnJvckxhdGNoOiBbMCwxXSxcclxuXHRcdFx0XHRcdFNldHBvaW50OiBbMCwyXSxcclxuXHRcdFx0XHRcdExpbmVGcmVxdWVuY3k6IFswLDJdLFxyXG5cdFx0XHRcdFx0TGluZVZvbHRhZ2VBOiBbMCwyXSxcclxuXHRcdFx0XHRcdExvYWRWb2x0YWdlQTogWzAsMl0sXHJcblx0XHRcdFx0XHRMb2FkQ3VycmVudEE6IFswLDJdLFxyXG5cdFx0XHRcdFx0SGVhdHNpbmtUZW1wQTogWzAsMl0sXHJcblx0XHRcdFx0XHRMaW5lVm9sdGFnZUI6IFswLDJdLFxyXG5cdFx0XHRcdFx0TG9hZFZvbHRhZ2VCOiBbMCwyXSxcclxuXHRcdFx0XHRcdExvYWRDdXJyZW50QjogWzAsMl0sXHJcblx0XHRcdFx0XHRIZWF0c2lua1RlbXBCOiBbMCwyXSxcclxuXHRcdFx0XHRcdExpbmVWb2x0YWdlQzogWzAsMl0sXHJcblx0XHRcdFx0XHRMb2FkVm9sdGFnZUM6IFswLDJdLFxyXG5cdFx0XHRcdFx0TG9hZEN1cnJlbnRDOiBbMCwyXSxcclxuXHRcdFx0XHRcdEhlYXRzaW5rVGVtcEM6IFswLDJdLFxyXG5cdFx0XHRcdFx0Q29udHJvbGxlclN0YXRlOiBbMCwxXSxcclxuXHRcdFx0XHRcdFdhcm5pbmdBbGFybTogWzAsMl0sXHJcblx0XHRcdFx0XHREdXR5OiBbMCwyXSxcclxuXHRcdFx0XHRcdExvYWRQb3dlcjogWzAsMl0sXHJcblx0XHRcdFx0XHRJbmhpYml0OiBbMCwyXSxcclxuXHRcdFx0XHRcdEVuZXJneTpbMCwyXSxcclxuXHRcdFx0XHRcdEFMb3N0Q29tbXVuaWNhdGlvbjpbMCwyXSxcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0cXVhbnRpdHkgPSAzNztcclxuXHRcdFx0XHRicmVhaztcdFx0XHRcdFxyXG5cdFx0XHRjYXNlIFwiVlNEXCI6XHJcblx0XHRcdFx0YXR0cmlidXRlID0ge1xyXG5cdFx0XHRcdFx0Q1RERU06IFswLDJdLFxyXG5cdFx0XHRcdFx0Q1RNOiBbMCwyXSxcclxuXHRcdFx0XHRcdENUTUo6IFswLDJdLFxyXG5cdFx0XHRcdFx0VE1TOiBbMCwxXSxcclxuXHRcdFx0XHRcdEVUQVRfTU9ERTogWzAsMV0sXHJcblx0XHRcdFx0XHRFVEFUX1JVTk5JTkc6IFswLDFdLFxyXG5cdFx0XHRcdFx0RkVFREJBQ0s6IFswLDFdLFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdENNRDogIFswLDFdLFxyXG5cdFx0XHRcdFx0RVRBVDogIFswLDFdXHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdHF1YW50aXR5ID0gMTI7XHJcblx0XHRcdFx0YnJlYWs7XHRcdFx0XHJcblx0XHRcdGNhc2UgXCJET0xcIjpcclxuXHRcdFx0XHRhdHRyaWJ1dGUgPSB7XHJcblx0XHRcdFx0XHRDVERFTTogWzAsMl0sXHJcblx0XHRcdFx0XHRDVE06IFswLDJdLFxyXG5cdFx0XHRcdFx0Q1RNSjogWzAsMl0sXHJcblx0XHRcdFx0XHRUTVM6IFswLDFdLFxyXG5cdFx0XHRcdFx0RVRBVF9NT0RFOiBbMCwxXSxcclxuXHRcdFx0XHRcdEVUQVRfUlVOTklORzogWzAsMV0sXHRcdFx0XHRcclxuXHRcdFx0XHRcdENNRDogIFswLDFdLFxyXG5cdFx0XHRcdFx0RVRBVDogIFswLDFdXHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdHF1YW50aXR5ID0gMTE7XHJcblx0XHRcdFx0YnJlYWs7XHRcclxuXHRcdFx0XHJcblx0XHRcdGNhc2UgXCJWYWx2ZVwiOlxyXG5cdFx0XHRcdHN3aXRjaCh0eXBlT2JqZWN0KVxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdGNhc2UgXCJBbmFsb2dWYWx2ZVwiOlxyXG5cdFx0XHRcdFx0Y2FzZSBcIkFuYWxvZ1ZhbHZlOTBcIjpcclxuXHRcdFx0XHRcdGNhc2UgXCJBbmFsb2dWYWx2ZUNvbnRyb2xcIjogICAvL1NjYWxlIGZyb20gMC0xMFxyXG5cdFx0XHRcdFx0Y2FzZSBcIkFuYWxvZ1ZhbHZlQ29udHJvbDAyXCI6IC8vU2NhbGUgZnJvbSAwLTIwXHJcblx0XHRcdFx0XHRjYXNlIFwiQW5hbG9nVmFsdmVDb250cm9sMDNcIjogLy9TY2FsZSBmcm9tIDAtMTAwXHJcblx0XHRcdFx0XHRjYXNlIFwiQW5hbG9nR2F0ZVZhbHZlXCI6XHJcblx0XHRcdFx0XHRcdGF0dHJpYnV0ZSA9IHtcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0RVRBVDogIFswLDFdLFxyXG5cdFx0XHRcdFx0XHRcdENNRDogIFswLDFdLFxyXG5cdFx0XHRcdFx0XHRcdFRNUzogWzAsMV0sXHJcblx0XHRcdFx0XHRcdFx0RVRBVF9NT0RFOiBbMCwxXSxcclxuXHRcdFx0XHRcdFx0XHRFVEFUX1JVTk5JTkc6IFswLDFdLFxyXG5cdFx0XHRcdFx0XHRcdEZFRURCQUNLOiBbMCwxXSxcdFxyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdHF1YW50aXR5ID0gNjtcclxuXHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHRjYXNlIFwiRGlnaXRhbFZhbHZlXCI6XHJcblx0XHRcdFx0XHRjYXNlIFwiRGlnaXRhbFZhbHZlOTBcIjpcclxuXHRcdFx0XHRcdGNhc2UgXCJHYXRlVmFsdmVcIjpcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRjYXNlIFwiQ3VhUGhhaU9JS1wiOlxyXG5cdFx0XHRcdFx0Y2FzZSBcIkN1YVBoYWlPSUs5MFwiOlxyXG5cdFx0XHRcdFx0XHRhdHRyaWJ1dGUgPSB7XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdEVUQVQ6ICBbMCwxXSxcclxuXHRcdFx0XHRcdFx0XHRDTUQ6ICBbMCwxXSxcclxuXHRcdFx0XHRcdFx0XHRUTVM6IFswLDFdLFxyXG5cdFx0XHRcdFx0XHRcdEVUQVRfTU9ERTogWzAsMV0sXHJcblx0XHRcdFx0XHRcdFx0RVRBVF9SVU5OSU5HOiBbMCwxXVxyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdHF1YW50aXR5ID0gNTtcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRjYXNlIFwiR2F0ZVZhbHZlTG9uZ1wiOlxyXG5cdFx0XHRcdFx0XHRhdHRyaWJ1dGUgPSB7XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdEVUQVQ6ICBbMCwxXSxcclxuXHRcdFx0XHRcdFx0XHRDTUQ6ICBbMCwxXSxcclxuXHRcdFx0XHRcdFx0XHRUTVM6IFswLDFdLFxyXG5cdFx0XHRcdFx0XHRcdEVUQVRfTU9ERTogWzAsMV0sXHJcblx0XHRcdFx0XHRcdFx0RVRBVF9SVU5OSU5HOiBbMCwxXVxyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdHF1YW50aXR5ID0gNTtcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0ZGVmYXVsdDogXHJcblx0XHRcdFx0XHRcdHVudmFsaWQgPSAxO1xyXG5cdFx0XHRcdFx0XHRicmVhaztcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdGNhc2UgXCJJbnN0cnVtZW50XCI6XHJcblx0XHRcdFx0c3dpdGNoKHR5cGVPYmplY3QpXHJcblx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0Y2FzZSBcIkNvbW1vbkluc3RydW1lbnRcIjpcdFxyXG5cdFx0XHRcdFx0XHRhdHRyaWJ1dGUgPSB7XHJcblx0XHRcdFx0XHRcdFx0SEhWOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRIVjogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0TExWOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRMVjogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0VkFMVUU6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdEVUQVQ6IFswLDFdXHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0fVx0XHRcdFxyXG5cdFx0XHRcdFx0XHRxdWFudGl0eSA9IDExO1xyXG5cdFx0XHRcdFx0XHRicmVhaztcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRjYXNlIFwiQmFja0dyb3VuZEdyZWVuXCI6XHRcclxuXHRcdFx0XHRcdFx0YXR0cmlidXRlID0ge1xyXG5cdFx0XHRcdFx0XHRcdEhIVjogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0SFY6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdExMVjogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0TFY6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdFZBTFVFOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRFVEFUOiBbMCwxXVx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdH1cdFx0XHRcclxuXHRcdFx0XHRcdFx0cXVhbnRpdHkgPSAxMTtcclxuXHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHRjYXNlIFwiRklUSW5zdHJ1bWVudFwiOlx0XHJcblx0XHRcdFx0XHRcdGF0dHJpYnV0ZSA9IHtcclxuXHRcdFx0XHRcdFx0XHRISFY6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdEhWOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRMTFY6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdExWOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRWQUxVRTogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0VE9UQUw6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdEVUQVQ6IFswLDFdXHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0fVx0XHRcdFxyXG5cdFx0XHRcdFx0XHRxdWFudGl0eSA9IDEzO1xyXG5cdFx0XHRcdFx0XHRicmVhaztcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdGRlZmF1bHQ6IFxyXG5cdFx0XHRcdFx0XHR1bnZhbGlkID0gMTsgXHJcblx0XHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdH1cdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRicmVhaztcclxuXHJcblx0XHRcdGNhc2UgXCJMZXZlbFwiOlxyXG5cdFx0XHRcdGF0dHJpYnV0ZSA9IHtcclxuXHRcdFx0XHRcdEVUQVQ6IFswLDFdXHRcdFx0XHRcclxuXHRcdFx0XHR9XHRcdFx0XHJcblx0XHRcdFx0cXVhbnRpdHkgPSAxO1xyXG5cdFx0XHRcdGJyZWFrO1xyXG5cdFxyXG5cdFx0XHRjYXNlIFwiV2VpZ2hpbmdcIjpcclxuXHRcdFx0XHRhdHRyaWJ1dGUgPSB7XHJcblx0XHRcdFx0XHRWQUxVRTogWzAsMl0sXHJcblx0XHRcdFx0XHRWQUxVRV9TQVZFOiBbMCwyXSxcclxuXHRcdFx0XHRcdERBVEU6IFswLDJdLFxyXG5cdFx0XHRcdFx0VElNRTogWzAsMl0sXHJcblx0XHRcdFx0XHRIUlY6IFswLDFdLFxyXG5cdFx0XHRcdFx0TFJWOiBbMCwxXSxcclxuXHRcdFx0XHRcdEVUQVQ6IFswLDFdLFx0XHJcblx0XHRcdFx0XHRDTURcdDogWzAsMV0sXHRcdFxyXG5cdFx0XHRcdFx0TUFURVJJQUw6IFswLDFdLFx0XHJcblx0XHRcdFx0XHRCT0lMRVI6IFswLDFdLFx0XHJcblx0XHRcdFx0fVx0XHRcdFxyXG5cdFx0XHRcdHF1YW50aXR5ID0gMTI7XHJcblx0XHRcdFx0YnJlYWs7XHRcdFx0XHRcdFx0XHJcblx0XHRcdGNhc2UgXCJOdW1iZXJcIjpcclxuXHRcdFx0XHRzd2l0Y2godHlwZU9iamVjdClcclxuXHRcdFx0XHR7XHJcblx0XHRcdFx0XHRjYXNlIFwiQm9vbFwiOlxyXG5cdFx0XHRcdFx0XHRhdHRyaWJ1dGUgPSB7XHJcblx0XHRcdFx0XHRcdFx0UkVHOiBbMCwxXSxcclxuXHRcdFx0XHRcdFx0XHRWQUxVRTogWzAsMV1cdFx0XHJcblx0XHRcdFx0XHRcdH1cdFx0XHRcclxuXHRcdFx0XHRcdFx0cXVhbnRpdHkgPSAyO1x0XHRcdFx0XHJcblx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRcdGNhc2UgXCJJbnRlZ2VyXCI6XHJcblx0XHRcdFx0XHRcdGF0dHJpYnV0ZSA9IHtcclxuXHRcdFx0XHRcdFx0XHRWQUxVRTogWzAsMV1cdFx0XHJcblx0XHRcdFx0XHRcdH1cdFx0XHRcclxuXHRcdFx0XHRcdFx0cXVhbnRpdHkgPSAxO1x0XHRcdFx0XHJcblx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRcdGNhc2UgXCJEb3VibGVJbnRlZ2VyXCI6XHJcblx0XHRcdFx0XHRcdGF0dHJpYnV0ZSA9IHtcclxuXHRcdFx0XHRcdFx0XHRWQUxVRTogWzAsMl1cdFx0XHJcblx0XHRcdFx0XHRcdH1cdFx0XHRcclxuXHRcdFx0XHRcdFx0cXVhbnRpdHkgPSAyO1x0XHRcdFx0XHJcblx0XHRcdFx0XHRicmVhaztcdFx0XHRcclxuXHRcdFx0XHRcdGNhc2UgXCJSZWFsXCI6XHJcblx0XHRcdFx0XHRcdGF0dHJpYnV0ZSA9IHtcclxuXHRcdFx0XHRcdFx0XHRWQUxVRTogWzAsMl1cdFx0XHJcblx0XHRcdFx0XHRcdH1cdFx0XHRcclxuXHRcdFx0XHRcdFx0cXVhbnRpdHkgPSAyO1x0XHRcdFx0XHJcblx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRcdGRlZmF1bHQ6IFxyXG5cdFx0XHRcdFx0XHR1bnZhbGlkID0gMTtcclxuXHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFxyXG5cdFx0XHRjYXNlIFwiRUxFQ1RSSUNcIjpcclxuXHRcdFx0XHRhdHRyaWJ1dGUgPSB7XHJcblx0XHRcdFx0XHRFVEFUOiBbMCwxXVx0XHRcdFx0XHJcblx0XHRcdFx0fVx0XHRcdFxyXG5cdFx0XHRcdHF1YW50aXR5ID0gMTtcclxuXHRcdFx0XHRicmVhaztcclxuXHRcdFx0Y2FzZSBcIlBPV0VSTUVURVJcIjpcclxuXHRcdFx0XHRzd2l0Y2godHlwZU9iamVjdClcclxuXHRcdFx0XHR7XHJcblx0XHRcdFx0XHRjYXNlIFwiUG93ZXJNZXRlclwiOlxyXG5cdFx0XHRcdFx0Y2FzZSBcIlBvd2VyTWV0ZXIyMjAwXCI6XHJcblx0XHRcdFx0XHRcdGF0dHJpYnV0ZSA9IHtcclxuXHRcdFx0XHRcdFx0XHRQMTogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0UDI6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdFAzOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRQX1RPVEFMOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRRMTogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0UTI6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdFEzOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRRX1RPVEFMOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRTMTogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0UzI6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdFMzOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRTX1RPVEFMOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRQT1dFUkZBQ1RPUjE6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdFBPV0VSRkFDVE9SMjogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0UE9XRVJGQUNUT1IzOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRQT1dFUkZBQ1RPUl9BVkc6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdEkxOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRJMjogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0STM6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdElfQVZHOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRGUkVROiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRVMTI6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdFUyMzogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0VTMxOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRVX0FWRzogWzAsMl0sXHJcblx0XHRcdFx0XHRcdFx0VjE6IFswLDJdLFxyXG5cdFx0XHRcdFx0XHRcdFYyOiBbMCwyXSxcclxuXHRcdFx0XHRcdFx0XHRWMzogWzAsMl0sXHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0Vl9BVkc6IFswLDJdLFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdEVORVJHWTogWzAsMl0sXHRcdFx0XHJcblx0XHRcdFx0XHRcdH1cdFx0XHRcclxuXHRcdFx0XHRcdFx0cXVhbnRpdHkgPSA2MDtcclxuXHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0ZGVmYXVsdDogXHJcblx0XHRcdFx0XHRcdHVudmFsaWQgPSAxOyBcclxuXHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0fVx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcclxuXHRcdFx0ZGVmYXVsdDpcclxuXHRcdFx0XHR1bnZhbGlkID0gMTtcclxuXHRcdFx0YnJlYWs7XHJcblx0XHR9XHJcblx0XHRpZiAodW52YWxpZD09MSlcclxuXHRcdHtcclxuXHRcdFx0Ly9Ob3RoaW5nXHJcblx0XHR9XHJcblx0XHRlbHNlXHJcblx0XHR7XHJcblx0XHRcdC8vY29uc29sZS5sb2coXCJ0YWcgZGVzY3JpcHRpb25cIiArIGRlc2NyaXB0aW9uKTtcclxuXHRcdFx0VGFnc0ludGVyZmFjZS51cGRhdGUoX2lkLFxyXG5cdFx0XHR7ICRzZXQ6IHtcclxuXHRcdFx0XHRcdHRhZ05hbWUsXHJcblx0XHRcdFx0XHRkZXNjcmlwdGlvbixcclxuXHRcdFx0XHRcdHNlbGVjdFBMQyxcclxuXHRcdFx0XHRcdGRhdGFCbG9jayxcclxuXHRcdFx0XHRcdHR5cGVEYXRhLFx0XHJcblx0XHRcdFx0XHR0eXBlT2JqZWN0LFxyXG5cdFx0XHRcdFx0YWRkcmVzc01vZGJ1cyxcdFx0XHJcblx0XHRcdFx0XHRhbGFybUVuYWJsZSxcclxuXHRcdFx0XHRcdGF0dHJpYnV0ZSxcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRjcmVhdGVEYXRlLFxyXG5cdFx0XHRcdFx0cXVhbnRpdHksXHJcblx0XHRcdFx0XHRzaXRlLFxyXG5cdFx0XHRcdFx0ZGF0YWNoYW5nZVxyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHR9KTtcclxuXHRcdH1cclxuXHR9LFx0XHJcbiAgJ3RhZ2ludGVyZmFjZXMucmVtb3ZlJyh0YXNrSWQpIHtcclxuXHRcdFRhZ3NJbnRlcmZhY2UucmVtb3ZlKHRhc2tJZCk7XHJcbiAgfSxcclxufSkiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSAnYXhpb3MnXHJcblxyXG5leHBvcnQgY29uc3QgdXNlckxvZ2luID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3VzZXJMb2dpbicpO1xyXG5cclxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG5cdE1ldGVvci5tZXRob2RzKHtcclxuXHRcdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFx0XHRcclxuXHRcdGFzeW5jIGdlb2xvY2F0aW9uVG1wKHVzZXJMb2dpbmcpIFxyXG5cdFx0e1xyXG5cdFx0XHR2YXIgZ3Vlc3RBZGRyZXNzID0gYXdhaXQgYXhpb3MuZ2V0KCdodHRwczovL2FwaS5pcGlmeS5vcmc/Zm9ybWF0PWpzb24nKVxyXG5cdFx0XHRpZiAoZ3Vlc3RBZGRyZXNzICE9IG51bGwpXHJcblx0XHRcdHtcclxuXHRcdFx0XHR2YXIgcGFyYSA9ICdodHRwczovL2dlb2xvY2F0aW9uLWRiLmNvbS9qc29uLycgKyBndWVzdEFkZHJlc3MuZGF0YS5pcFxyXG5cdFx0XHRcdGNvbnN0IHJlcyA9ICBhd2FpdCBheGlvcy5nZXQocGFyYSlcclxuXHRcdFx0XHQvL2NvbnNvbGUubG9nKHJlcy5kYXRhKTtcclxuXHRcdFx0XHRpZiAocmVzICE9IG51bGwpXHJcblx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0dmFyIGNvdW50cnlfbmFtZSA9IHJlcy5kYXRhLmNvdW50cnlfbmFtZVxyXG5cdFx0XHRcdFx0dmFyIGNpdHkgXHRcdCA9IHJlcy5kYXRhLmNpdHlcclxuXHRcdFx0XHRcdHZhciBzdGF0ZVx0XHQgPSByZXMuZGF0YS5zdGF0ZVxyXG5cdFx0XHRcdFx0dmFyIGxhdGl0dWRlXHQgPSByZXMuZGF0YS5sYXRpdHVkZVxyXG5cdFx0XHRcdFx0dmFyIGxvbmdpdHVkZSAgICA9IHJlcy5kYXRhLmxvbmdpdHVkZVxyXG5cdFx0XHRcdFx0dmFyIElQdjRcdFx0ID0gcmVzLmRhdGEuSVB2NFxyXG5cdFx0XHRcdFx0XHJcblx0XHRcdFx0XHR2YXIgaGVyZSA9IG5ldyBEYXRlKCk7XHJcblx0XHRcdFx0XHQvLyBzdXBwb3NlIHRoZSBkYXRlIGlzIDc6MDAgVVRDXHJcblx0XHRcdFx0XHR2YXIgdGltZXN0YW1wID0gbmV3IERhdGUoaGVyZS50b0xvY2FsZVN0cmluZygnZW4tVVMnLCB7dGltZVpvbmU6ICdBc2lhL1Rva3lvJ30pKS5nZXRUaW1lKCk7XHJcblx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdHVzZXJMb2dpbi5pbnNlcnQoe1x0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0dGltZXN0YW1wLFxyXG5cdFx0XHRcdFx0XHR1c2VyTG9naW5nLFxyXG5cdFx0XHRcdFx0XHRjb3VudHJ5X25hbWUsXHJcblx0XHRcdFx0XHRcdGNpdHksXHJcblx0XHRcdFx0XHRcdHN0YXRlLFxyXG5cdFx0XHRcdFx0XHRsYXRpdHVkZSxcclxuXHRcdFx0XHRcdFx0bG9uZ2l0dWRlLFxyXG5cdFx0XHRcdFx0XHRJUHY0XHJcblx0XHRcdFx0XHR9KTtcdFx0XHRcdFxyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVx0XHRcdFxyXG5cdFx0fSxcclxuXHRcdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFx0XHRcclxuXHRcdGFzeW5jIGdlb2xvY2F0aW9uKHVzZXJMb2dpbmcpIFxyXG5cdFx0e1xyXG5cdFx0XHRjb25zdCByZXMgPSAgYXdhaXQgYXhpb3MuZ2V0KCdodHRwczovL2lwaW5mby5pby8nKVxyXG5cdFx0XHQvL2NvbnNvbGUubG9nKHJlcyk7XHJcblx0XHRcdGlmIChyZXMgIT0gbnVsbClcclxuXHRcdFx0e1xyXG5cdFx0XHRcdHZhciBsb2NhdGlvbiA9IHJlcy5kYXRhLmxvYy5zcGxpdChcIixcIik7XHJcblx0XHRcdFx0dmFyIGNvdW50cnlfbmFtZSA9IHJlcy5kYXRhLmNvdW50cnlcclxuXHRcdFx0XHR2YXIgY2l0eSBcdFx0ID0gcmVzLmRhdGEuY2l0eVxyXG5cdFx0XHRcdHZhciBzdGF0ZVx0XHQgPSByZXMuZGF0YS5yZWdpb25cdFx0XHRcclxuXHRcdFx0XHR2YXIgbGF0aXR1ZGVcdCA9IFwiXCJcclxuXHRcdFx0XHR2YXIgbG9uZ2l0dWRlICAgID0gXCJcIlxyXG5cdFx0XHRcdGlmIChsb2NhdGlvbi5sZW5ndGg+MSlcclxuXHRcdFx0XHR7XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0bGF0aXR1ZGVcdCA9IGxvY2F0aW9uWzBdXHJcblx0XHRcdFx0XHRsb25naXR1ZGUgICAgPSBsb2NhdGlvblsxXVxyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHR2YXIgSVB2NFx0XHQgPSByZXMuZGF0YS5pcFxyXG5cdFx0XHRcdFxyXG5cdFx0XHRcdHZhciBoZXJlID0gbmV3IERhdGUoKTtcclxuXHRcdFx0XHQvLyBzdXBwb3NlIHRoZSBkYXRlIGlzIDc6MDAgVVRDXHJcblx0XHRcdFx0dmFyIHRpbWVzdGFtcCA9IG5ldyBEYXRlKGhlcmUudG9Mb2NhbGVTdHJpbmcoJ2VuLVVTJywge3RpbWVab25lOiAnQXNpYS9Ub2t5byd9KSkuZ2V0VGltZSgpO1xyXG5cdFx0XHRcdFxyXG5cdFx0XHRcdHVzZXJMb2dpbi5pbnNlcnQoe1x0XHRcdFx0XHRcclxuXHRcdFx0XHRcdHRpbWVzdGFtcCxcclxuXHRcdFx0XHRcdHVzZXJMb2dpbmcsXHJcblx0XHRcdFx0XHRjb3VudHJ5X25hbWUsXHJcblx0XHRcdFx0XHRjaXR5LFxyXG5cdFx0XHRcdFx0c3RhdGUsXHJcblx0XHRcdFx0XHRsYXRpdHVkZSxcclxuXHRcdFx0XHRcdGxvbmdpdHVkZSxcclxuXHRcdFx0XHRcdElQdjRcclxuXHRcdFx0XHR9KTtcdFx0XHRcdFxyXG5cdFx0XHR9XHRcdFx0XHJcblx0XHR9LFxyXG5cdFx0XHJcblx0XHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcdFx0XHJcblx0XHRhc3luYyAnZ2V0dXNlckxvZ2luYXN5bmMnKCkge1xyXG5cdFx0XHQgcmV0dXJuIGF3YWl0IHVzZXJMb2dpbi5yYXdDb2xsZWN0aW9uKCkuYWdncmVnYXRlKFtcclxuXHRcdFx0XHR7JHNvcnQgOiB7IHRpbWVzdGFtcCA6IC0xfSB9LFxyXG5cdFx0XHRcdHskcHJvamVjdDoge1xyXG5cdFx0XHRcdFx0XCJ0aW1lc3RhbXBcIjogeyAkZGF0ZVRvU3RyaW5nOiB7IGZvcm1hdDogXCIlbS0lZCAlSDolTVwiLCBkYXRlOiB7JGFkZCA6IFtuZXcgRGF0ZSgwKSwgXCIkdGltZXN0YW1wXCJdIH0sIHRpbWV6b25lOiBcIkFzaWEvVG9reW9cIiB9IH0sXHJcblx0XHRcdFx0XHRcInVzZXJMb2dpbmdcIjogXCIkdXNlckxvZ2luZ1wiLFxyXG5cdFx0XHRcdFx0XCJjb3VudHJ5X25hbWVcIjogXCIkY291bnRyeV9uYW1lXCIsXHJcblx0XHRcdFx0XHRcImNpdHlcIjogXCIkY2l0eVwiLFxyXG5cdFx0XHRcdFx0XCJzdGF0ZVwiOiBcIiRzdGF0ZVwiLFxyXG5cdFx0XHRcdFx0XCJsYXRpdHVkZVwiOiBcIiRsYXRpdHVkZVwiLFxyXG5cdFx0XHRcdFx0XCJsb25naXR1ZGVcIjogXCIkbG9uZ2l0dWRlXCIsXHJcblx0XHRcdFx0XHRcIklQdjRcIjogXCIkSVB2NFwiLFxyXG5cdFx0XHRcdCAgIH1cclxuXHRcdFx0XHR9XHJcblx0XHRcdF0pLnRvQXJyYXkoKTtcdFxyXG5cdFx0fVxyXG5cdH0pO1xyXG59IiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IHsgQWNjb3VudHMgfSBmcm9tICdtZXRlb3IvYWNjb3VudHMtYmFzZSc7XHJcbmltcG9ydCB7IFJvbGVzIH0gZnJvbSAnbWV0ZW9yL2FsYW5uaW5nOnJvbGVzJztcclxuaW1wb3J0IFJPTEVTIGZyb20gJy4vcm9sZXMuanMnO1xyXG5cclxuaW1wb3J0IGF4aW9zIGZyb20gJ2F4aW9zJ1xyXG4vL2h0dHBzOi8vZ2l0aHViLmNvbS9NZXRlb3ItQ29tbXVuaXR5LVBhY2thZ2VzL21ldGVvci1yb2xlc1xyXG5cclxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG5cdC8vIFRoaXMgY29kZSBvbmx5IHJ1bnMgb24gdGhlIHNlcnZlclxyXG5cdE1ldGVvci5wdWJsaXNoKCd1c2VyRGF0YScsIGZ1bmN0aW9uICgpIHtcclxuXHRcdGlmICghdGhpcy51c2VySWQpIHtcclxuXHRcdFx0cmV0dXJuIG51bGw7XHJcblx0XHR9XHJcblx0XHRyZXR1cm4gTWV0ZW9yLnVzZXJzLmZpbmQodGhpcy51c2VySWQsIHt9KTtcdFx0XHJcblx0fSk7XHJcblx0XHJcblx0TWV0ZW9yLnB1Ymxpc2gobnVsbCwgZnVuY3Rpb24gKCkge1xyXG5cdFx0aWYgKHRoaXMudXNlcklkKSB7XHJcblx0XHRcdHJldHVybiBNZXRlb3Iucm9sZUFzc2lnbm1lbnQuZmluZCh7ICd1c2VyLl9pZCc6IHRoaXMudXNlcklkIH0pO1xyXG5cdFx0fSBlbHNlIHtcclxuXHRcdFx0dGhpcy5yZWFkeSgpXHJcblx0XHR9XHJcblx0fSlcdFxyXG5cclxuXHJcblx0XHJcblx0TWV0ZW9yLm1ldGhvZHMoe1xyXG5cdFx0Z2V0Q2xpZW50SVAoKVxyXG5cdFx0e1xyXG5cdFx0XHRyZXR1cm4gdGhpcy5jb25uZWN0aW9uLmNsaWVudEFkZHJlc3M7XHJcblx0XHR9LFxyXG5cdFx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHRcclxuXHRcdGF1dGhlbnRpY2F0ZVJvdXRlKHNpdGUpIFxyXG5cdFx0e1xyXG5cdFx0XHRcclxuXHRcdFx0aWYgKCEgdGhpcy51c2VySWQpIHtcclxuXHRcdFx0XHRyZXR1cm4gMDtcclxuXHRcdFx0fVx0XHRcclxuXHRcdFx0dmFyIGZsYWcgPSBmYWxzZTtcclxuXHRcdFx0Um9sZXMuZ2V0R3JvdXBzRm9yVXNlcih0aGlzLnVzZXJJZCkuZm9yRWFjaChmdW5jdGlvbihzY29wZSkge1xyXG5cdFx0XHRcdHZhciByb2xlID0gUm9sZXMuZ2V0Um9sZXNGb3JVc2VyKHRoaXMudXNlcklkLHNjb3BlKTtcclxuXHRcdFx0XHRpZiAoUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLHJvbGUsc2l0ZSkpIHtcclxuXHRcdFx0XHRcdGZsYWcgPSB0cnVlO1xyXG5cdFx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHRcdH0gXHRcdFx0XHRcclxuXHRcdFx0fSlcclxuXHRcdFx0aWYgKGZsYWcpIHJldHVybiAxO1xyXG5cdFx0XHRyZXR1cm4gMDtcclxuXHRcdH0sXHRcdFxyXG5cdFx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0XHRhdXRoZW50aWNhdGVSb2xlKCkge1xyXG5cdFx0XHRpZiAoISB0aGlzLnVzZXJJZCkge1xyXG5cdFx0XHRcdHJldHVybiBST0xFUy5OU2NvcGU7XHJcblx0XHRcdH1cclxuXHRcdFx0XHJcblx0XHRcdFxyXG5cdFx0XHRpZiAoTWV0ZW9yLnVzZXIoKSAmJiBNZXRlb3IudXNlcigpLnByb2ZpbGUpIHtcclxuXHRcdFx0XHRpZiAoUm9sZXMudXNlcklzSW5Sb2xlKE1ldGVvci51c2VySWQoKSwgUk9MRVMuT3BlcmF0b3IsICBNZXRlb3IudXNlcigpLnByb2ZpbGUuc2l0ZSkpIFxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdHJldHVybiBST0xFUy5PcGVyYXRvcjtcclxuXHRcdFx0XHR9IGVsc2UgaWYgKFJvbGVzLnVzZXJJc0luUm9sZShNZXRlb3IudXNlcklkKCksIFJPTEVTLlZpZXcsICBNZXRlb3IudXNlcigpLnByb2ZpbGUuc2l0ZSkpIFxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdHJldHVybiBST0xFUy5WaWV3O1xyXG5cdFx0XHRcdH0gZWxzZSBpZiAoUm9sZXMudXNlcklzSW5Sb2xlKE1ldGVvci51c2VySWQoKSwgUk9MRVMuQWRtaW5pc3RyYXRvciwgIE1ldGVvci51c2VyKCkucHJvZmlsZS5zaXRlKSkgXHJcblx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0cmV0dXJuIFJPTEVTLkFkbWluaXN0cmF0b3I7XHJcblx0XHRcdFx0fSAgZWxzZSBpZiAoUm9sZXMudXNlcklzSW5Sb2xlKE1ldGVvci51c2VySWQoKSwgUk9MRVMuT3duZXIsIE1ldGVvci51c2VyKCkucHJvZmlsZS5zaXRlKSkgXHJcblx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0cmV0dXJuIFJPTEVTLk93bmVyO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0XHRyZXR1cm4gUk9MRVMuTlNjb3BlO1xyXG5cdFx0fSxcdFxyXG5cdFx0XHJcblx0XHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcdFx0XHJcblx0XHRhc3luYyBhdXRoZW50aWNhdGVSb2xlYXN5bmMocm9sZXMsc2l0ZSkgXHJcblx0XHR7XHJcblx0XHRcdGlmICghIHRoaXMudXNlcklkKSB7XHJcblx0XHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcclxuXHRcdFx0fVxyXG5cdFx0XHRcclxuXHRcdFx0aWYgKCcqJyA9PT0gcm9sZXMpIHsgLy8gYWxsb3cgYW55IGxvZ2dlZCB1c2VyXHJcblx0XHRcdFx0cmV0dXJuIDE7XHJcblx0XHRcdH1cdFx0XHRcclxuXHRcdFx0cmV0dXJuIGF3YWl0IFJvbGVzLnVzZXJJc0luUm9sZShNZXRlb3IudXNlcklkKCksIFsnT3duZXInXSwgc2l0ZSk7XHJcblx0XHR9LFx0XHRcclxuXHRcdFxyXG5cclxuXHRcdFxyXG5cdFx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0XHRhc3luYyAnbUdldFVzZXInKCkge1xyXG5cdFx0XHRpZiAoISB0aGlzLnVzZXJJZCkge1xyXG5cdFx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XHJcblx0XHRcdH1cclxuXHRcdFx0dmFyIHVzZXIgPSAnJztcclxuXHRcdFx0TWV0ZW9yLnVzZXJzLmZpbmQoeyBfaWQ6IHRoaXMudXNlcklkIH0pLmZvckVhY2goZnVuY3Rpb24oZG9jKSB7XHJcblx0XHRcdFx0dXNlciA9ICBkb2MudXNlcm5hbWVcclxuXHRcdFx0fSk7XHJcblx0XHRcdHJldHVybiB1c2VyO1xyXG5cdFx0XHRcclxuXHRcdH0sXHRcdFxyXG5cdFx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHRcclxuXHRcdCdtQ3JlYXRlVXNlcmFzeW5jJyh1c2VyKSB7XHJcblx0XHRcdGlmICh1c2VyLnVzZXJuYW1lKSB7XHJcblx0XHRcdFx0aWYgKCFSb2xlcy51c2VySXNJblJvbGUoTWV0ZW9yLnVzZXJJZCgpLCBST0xFUy5Pd25lciwgbnVsbCkpIFxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJXYXJuaW5nOiBZb3UgYXJlIG5vdCBhdXRob3JpemVkIHRvIHBlcmZvcm0gdGhpcyBhY3Rpb25cIik7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdGVsc2VcclxuXHRcdFx0XHR7XHJcblx0XHRcdFx0XHRpZiAoTWV0ZW9yLnVzZXJzLmZpbmRPbmUoeyB1c2VybmFtZTp1c2VyLnVzZXJuYW1lfSkhPW51bGwpXHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJUw6BpIGtob+G6o24gxJHDoyBjw7MuIELhuqFuIG5o4bqtcCB0w6BpIGtob+G6o24ga2jDoWMuXCIpO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0ZWxzZSBcclxuXHRcdFx0XHRcdHtcdFx0XHRcclxuXHRcdFx0XHRcdFx0dmFyIGlkID0gQWNjb3VudHMuY3JlYXRlVXNlcih7XHJcblx0XHRcdFx0XHRcdFx0dXNlcm5hbWU6IHVzZXIudXNlcm5hbWUsXHJcblx0XHRcdFx0XHRcdFx0cGFzc3dvcmQ6IHVzZXIucGFzc3dvcmQsXHJcblx0XHRcdFx0XHRcdFx0cHJvZmlsZToge1xyXG5cdFx0XHRcdFx0XHRcdFx0Y29udGFjdDogdXNlci5jb250YWN0XHJcblx0XHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHR9KTtcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0Ly8gaWYgKE1ldGVvci5yb2xlQXNzaWdubWVudC5maW5kKHsgJ3VzZXIuX2lkJzogaWQgfSkuY291bnQoKSA9PT0gMCkge1x0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0Ly8gUm9sZXMuY3JlYXRlUm9sZSh1c2VyLm15cm9sZSwge3VubGVzc0V4aXN0czogdHJ1ZX0pO1xyXG5cdFx0XHRcdFx0XHRcdC8vIFJvbGVzLmFkZFVzZXJzVG9Sb2xlcyhpZCwgdXNlci5teXJvbGUsIHVzZXIuc2l0ZSk7XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdC8vIH1cclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdH0sXHJcblx0XHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHRcdCdtVXBkYXRlVXNlcmFzeW5jJyh1c2VySUQsIHVzZXIpIHtcclxuXHRcdFx0aWYgKCFSb2xlcy51c2VySXNJblJvbGUoTWV0ZW9yLnVzZXJJZCgpLCBST0xFUy5Pd25lciwgbnVsbCkpIFxyXG5cdFx0XHR7XHJcblx0XHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIldhcm5pbmc6IFlvdSBhcmUgbm90IGF1dGhvcml6ZWQgdG8gcGVyZm9ybSB0aGlzIGFjdGlvblwiKTtcclxuXHRcdFx0fVxyXG5cdFx0XHRlbHNlXHJcblx0XHRcdHtcdFx0XHJcblx0XHRcdFx0aWYgKCEgdGhpcy51c2VySWQpIHtcclxuXHRcdFx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdHZhciB1c2VybmFtZT0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUodGhpcy51c2VySWQpLnVzZXJuYW1lO1xyXG5cdFx0XHRcdGlmICgodXNlci51c2VybmFtZT09IHVzZXJuYW1lKSB8fCAodXNlcm5hbWU9PSBcIm15b3duZXJcIikpIHtcclxuXHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0Ly8gVXBkYXRlIGFjY291bnRcclxuXHRcdFx0XHRcdE1ldGVvci51c2Vycy51cGRhdGUodXNlcklELCB7XHJcblx0XHRcdFx0XHRcdCRzZXQ6IHtcclxuXHRcdFx0XHRcdFx0XHRwcm9maWxlOntcclxuXHRcdFx0XHRcdFx0XHRcdGNvbnRhY3Q6IHVzZXIuY29udGFjdFxyXG5cdFx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0fSk7XHJcblx0XHRcdFx0XHQvLyBVcGRhdGUgcGFzc3dvcmRcclxuXHRcdFx0XHRcdGlmICh1c2VyLnBhc3N3b3JkICE9ICcnKSB7XHJcblx0XHRcdFx0XHRcdC8vIGJyb3dzZXIncyBjb25zb2xlXHJcblx0XHRcdFx0XHRcdEFjY291bnRzLnNldFBhc3N3b3JkKHVzZXJJRCwgdXNlci5wYXNzd29yZCwgZnVuY3Rpb24gKGVycikge1xyXG5cdFx0XHRcdFx0XHRcdGlmICghZXJyKSB7XHJcblx0XHRcdFx0XHRcdFx0XHQvL2NvbnNvbGUubG9nKCdDaGFuZ2UgcGFzc3dvcmQgd2FzIGEgc3VjY2VzcyEnKVxyXG5cdFx0XHRcdFx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0XHRcdFx0XHQvL2NvbnNvbGUubG9nKGVycik7XHJcblx0XHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHR9KVxyXG5cdFx0XHRcdFx0fVx0XHRcdFxyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRlbHNlXHJcblx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIldhcm5pbmc6IFlvdSBhcmUgbm90IGF1dGhvcml6ZWQgdG8gcGVyZm9ybSB0aGlzIGFjdGlvblwiKTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdH0sXHJcblx0XHRcclxuXHRcdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFx0XHJcblx0XHQnbVJlbW92ZVVzZXInKHRhc2tJZCkge1xyXG5cdFx0XHRpZiAoIVJvbGVzLnVzZXJJc0luUm9sZShNZXRlb3IudXNlcklkKCksIFJPTEVTLk93bmVyLCBudWxsKSlcclxuXHRcdFx0e1xyXG5cdFx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJXYXJuaW5nOiBZb3UgYXJlIG5vdCBhdXRob3JpemVkIHRvIHBlcmZvcm0gdGhpcyBhY3Rpb25cIik7XHJcblx0XHRcdH1cclxuXHRcdFx0ZWxzZVxyXG5cdFx0XHR7XHRcdFxyXG5cdFx0XHRcdHZhciB1c2VybmFtZT0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUodGFza0lkKS51c2VybmFtZTtcdFx0XHJcblx0XHRcdFx0aWYgKCh1c2VybmFtZT09XCJhZG1pblwiKSB8fCAodXNlcm5hbWU9PVwibXlvd25lclwiKSlcclxuXHRcdFx0XHR7XHJcblx0XHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiQuG6oW4ga2jDtG5nIHRo4buDIHjDs2EgVMOgaSBraG/huqNuIG7DoHlcIik7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdGVsc2VcclxuXHRcdFx0XHR7XHJcblx0XHRcdFx0XHRNZXRlb3IudXNlcnMucmVtb3ZlKHRhc2tJZCk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHR9LFxyXG5cdFx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0XHQnbUFkZFNjb3BlJyh0YXNrSWQsIHVzZXIpIHtcclxuXHRcdFx0aWYgKCFSb2xlcy51c2VySXNJblJvbGUoTWV0ZW9yLnVzZXJJZCgpLCBST0xFUy5Pd25lciwgbnVsbCkpIFxyXG5cdFx0XHR7XHJcblx0XHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIldhcm5pbmc6IFlvdSBhcmUgbm90IGF1dGhvcml6ZWQgdG8gcGVyZm9ybSB0aGlzIGFjdGlvblwiKTtcclxuXHRcdFx0fVxyXG5cdFx0XHRlbHNlXHJcblx0XHRcdHtcdFx0XHJcblx0XHRcdFx0aWYgKCEgdGhpcy51c2VySWQpIHtcclxuXHRcdFx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdFxyXG5cdFx0XHRcdGlmICghUm9sZXMudXNlcklzSW5Sb2xlKHRhc2tJZCwgdXNlci5teXJvbGUsIHVzZXIuc2l0ZSkpXHJcblx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0Um9sZXMuY3JlYXRlUm9sZSh1c2VyLm15cm9sZSwge3VubGVzc0V4aXN0czogdHJ1ZX0pO1xyXG5cdFx0XHRcdFx0Um9sZXMuYWRkVXNlcnNUb1JvbGVzKHRhc2tJZCwgdXNlci5teXJvbGUsIHVzZXIuc2l0ZSk7XHRcclxuXHRcdFx0XHR9IFxyXG5cdFx0XHRcdGVsc2VcclxuXHRcdFx0XHR7XHJcblx0XHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiV2FybmluZzogVGhlIHJvbGUgYXNzaWdubWVudCBhbHJlYWR5IGV4aXN0c1wiKTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdH0sXHRcdFxyXG5cdFx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHRcclxuXHRcdCdtUmVtb3ZlU2NvcGUnKHRhc2tJZCwgdXNlcikge1xyXG5cdFx0XHRpZiAoIVJvbGVzLnVzZXJJc0luUm9sZShNZXRlb3IudXNlcklkKCksIFJPTEVTLk93bmVyLCBudWxsKSlcclxuXHRcdFx0e1xyXG5cdFx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJsb2dnZWQtaW5cIixcIllvdSBhcmUgbm90IHBlcm1pdHRlZC5cIik7XHJcblx0XHRcdH1cclxuXHRcdFx0ZWxzZVxyXG5cdFx0XHR7XHRcdFxyXG5cdFx0XHRcdHZhciB1c2VybmFtZT0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUodGFza0lkKS51c2VybmFtZTtcdFx0XHJcblx0XHRcdFx0aWYgKCh1c2VybmFtZT09XCJhZG1pblwiKSB8fCAodXNlcm5hbWU9PVwibXlvd25lclwiKSl7XHJcblx0XHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiV2FybmluZzogWW91IGFyZSBub3QgYXV0aG9yaXplZCB0byBwZXJmb3JtIHRoaXMgYWN0aW9uXCIpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRlbHNlXHJcblx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0Um9sZXMucmVtb3ZlVXNlcnNGcm9tUm9sZXMgKHRhc2tJZCwgdXNlci5teXJvbGUsIHVzZXIuc2l0ZSk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHR9LFx0XHRcclxuXHR9KTtcclxufVxyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFxyXG5cdCdnZXRSb2xlc1VzZXInKCkgXHJcblx0e1xyXG5cdFx0dmFyIGRhdGFCbG9jayA9IFtdO1xyXG5cdFx0dmFyIG15VGVzdENvbGxlY3Rpb24gPSBNb25nby5Db2xsZWN0aW9ucy5sb29rdXAoJ3JvbGUtYXNzaWdubWVudCcpO1xyXG5cdFx0TWV0ZW9yLm15VGVzdENvbGxlY3Rpb24uZmluZCh7J3VzZXIuX2lkJzogdGhpcy51c2VySWR9KS5mb3JFYWNoKGZ1bmN0aW9uKGRvYykge1xyXG5cdFx0XHRkYXRhQmxvY2sucHVzaCh7XHJcblx0XHRcdFx0X2lkOiAgZG9jLl9pZCxcclxuXHRcdFx0XHRyb2xlOiBkb2Mucm9sZS5faWQsXHJcblx0XHRcdFx0c2l0ZTogZG9jLnNjb3BlXHRcdFx0XHJcblx0XHRcdH0pO1xyXG5cdFx0fSk7XHJcblx0XHRyZXR1cm4gZGF0YUJsb2NrO1xyXG5cdH0sIFxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFxyXG5cdCdtZGF0YWJsb2NrVXNlcicoKSBcclxuXHR7XHJcblx0XHR2YXIgZGF0YUJsb2NrID0gW107XHJcblx0XHRNZXRlb3IudXNlcnMuZmluZCh7fSkuZm9yRWFjaChmdW5jdGlvbihkb2MpIHtcdFx0XHJcblx0XHRcdC8vIGlmIChkb2MudXNlcm5hbWU9PVwibXlvd25lclwiKVxyXG5cdFx0XHQvLyB7XHJcblx0XHRcdFx0Ly8gLy9cclxuXHRcdFx0Ly8gfSBlbHNlXHJcblx0XHRcdHtcclxuXHRcdFx0XHRkYXRhQmxvY2sucHVzaCh7XHJcblx0XHRcdFx0XHRfaWQ6IGRvYy5faWQsXHJcblx0XHRcdFx0XHR1c2VybmFtZTogZG9jLnVzZXJuYW1lLFxyXG5cdFx0XHRcdFx0Y29udGFjdDogZG9jLnByb2ZpbGUuY29udGFjdCxcdFx0XHJcblx0XHRcdFx0fSk7XHRcclxuXHRcdFx0fVxyXG5cdFx0fSk7XHJcblx0XHRyZXR1cm4gZGF0YUJsb2NrO1xyXG5cdH0sIFxyXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cdFxyXG5cdCdtZGF0YWJsb2NrVXNlckxvY2FsJygpIFxyXG5cdHtcclxuXHRcdHZhciBkYXRhQmxvY2sgPSBbXTtcclxuXHRcdE1ldGVvci51c2Vycy5maW5kKHt9KS5mb3JFYWNoKGZ1bmN0aW9uKGRvYykge1x0XHRcclxuXHRcdFx0aWYgKChkb2MudXNlcm5hbWU9PVwibXlvd25lclwiKSB8fCAoZG9jLnVzZXJuYW1lPT1cImFkbWluaXN0cmF0b3JcIikpXHJcblx0XHRcdHtcclxuXHRcdFx0XHQvL1xyXG5cdFx0XHR9IGVsc2VcclxuXHRcdFx0e1xyXG5cdFx0XHRcdGRhdGFCbG9jay5wdXNoKHtcclxuXHRcdFx0XHRcdF9pZDogZG9jLl9pZCxcclxuXHRcdFx0XHRcdHVzZXJuYW1lOiBkb2MudXNlcm5hbWUsXHJcblx0XHRcdFx0XHRjb250YWN0OiBkb2MucHJvZmlsZS5jb250YWN0LFx0XHRcclxuXHRcdFx0XHR9KTtcdFxyXG5cdFx0XHR9XHJcblx0XHR9KTtcclxuXHRcdHJldHVybiBkYXRhQmxvY2s7XHJcblx0fSwgXHJcblx0Ly89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVx0XHJcblx0J21kYXRhYmxvY2tSb2xlJygpIFxyXG5cdHtcclxuXHRcdHZhciBkYXRhQmxvY2sgPSBbXTtcclxuXHRcdHZhciBpbmRleCAgPSAwO1xyXG5cdFx0TWV0ZW9yLnVzZXJzLmZpbmQoe30pLmZvckVhY2goZnVuY3Rpb24oZG9jKSB7XHRcdFx0XHJcblx0XHRcdFJvbGVzLmdldEdyb3Vwc0ZvclVzZXIoZG9jLl9pZCkuZm9yRWFjaChmdW5jdGlvbihzY29wZSkge1x0XHRcclxuXHRcdFx0XHR2YXIgcm9sZSA9IFJvbGVzLmdldFJvbGVzRm9yVXNlcihkb2MuX2lkLHNjb3BlKTtcclxuXHRcdFx0XHRkYXRhQmxvY2sucHVzaCh7XHJcblx0XHRcdFx0XHRpbmRleDogaW5kZXgsXHJcblx0XHRcdFx0XHRfaWQ6IGRvYy5faWQsXHJcblx0XHRcdFx0XHR1c2VybmFtZTogZG9jLnVzZXJuYW1lLFxyXG5cdFx0XHRcdFx0c2l0ZTogc2NvcGUsXHJcblx0XHRcdFx0XHRjb250YWN0OiBkb2MucHJvZmlsZS5jb250YWN0LFxyXG5cdFx0XHRcdFx0bXlyb2xlOnJvbGVcdFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0fSk7XHJcblx0XHRcdFx0aW5kZXggKys7XHJcblx0XHRcdH0pO1xyXG5cdFx0fSk7XHJcblx0XHRyZXR1cm4gZGF0YUJsb2NrO1xyXG5cdH0sXHRcclxuXHQvLz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHRcclxuXHQnbWRhdGFibG9ja1JvbGVMb2NhbCcoKSBcclxuXHR7XHJcblx0XHR2YXIgZGF0YUJsb2NrID0gW107XHJcblx0XHR2YXIgaW5kZXggID0gMDtcclxuXHRcdE1ldGVvci51c2Vycy5maW5kKHt9KS5mb3JFYWNoKGZ1bmN0aW9uKGRvYykge1x0XHRcclxuXHRcdFx0aWYgKChkb2MudXNlcm5hbWU9PVwibXlvd25lclwiKSB8fCAoZG9jLnVzZXJuYW1lPT1cImFkbWluaXN0cmF0b3JcIikpXHJcblx0XHRcdHtcclxuXHRcdFx0XHQvL1xyXG5cdFx0XHR9IGVsc2VcdFxyXG5cdFx0XHR7XHRcdFx0XHRcclxuXHRcdFx0XHRSb2xlcy5nZXRHcm91cHNGb3JVc2VyKGRvYy5faWQpLmZvckVhY2goZnVuY3Rpb24oc2NvcGUpIHtcclxuXHRcdFx0XHRcdHZhciByb2xlID0gUm9sZXMuZ2V0Um9sZXNGb3JVc2VyKGRvYy5faWQsc2NvcGUpO1xyXG5cdFx0XHRcdFx0ZGF0YUJsb2NrLnB1c2goe1xyXG5cdFx0XHRcdFx0XHRpbmRleDogaW5kZXgsXHJcblx0XHRcdFx0XHRcdF9pZDogZG9jLl9pZCxcclxuXHRcdFx0XHRcdFx0dXNlcm5hbWU6IGRvYy51c2VybmFtZSxcclxuXHRcdFx0XHRcdFx0c2l0ZTogc2NvcGUsXHJcblx0XHRcdFx0XHRcdGNvbnRhY3Q6IGRvYy5wcm9maWxlLmNvbnRhY3QsXHJcblx0XHRcdFx0XHRcdG15cm9sZTpyb2xlXHRcdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0fSk7XHJcblx0XHRcdFx0XHRpbmRleCArKztcclxuXHRcdFx0XHR9KTtcclxuXHRcdFx0fVxyXG5cdFx0fSk7XHJcblx0XHRyZXR1cm4gZGF0YUJsb2NrO1xyXG5cdH0sICBcclxuXHRcclxufSk7IiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmltcG9ydCAnL2ltcG9ydHMvYXBpL3NpdGVpbnRlcmZhY2VzLmpzJztcbmltcG9ydCAnL2ltcG9ydHMvYXBpL3BsY2ludGVyZmFjZXMuanMnO1xuaW1wb3J0ICcvaW1wb3J0cy9hcGkvbW9kYnVzaW50ZXJmYWNlcy5qcyc7XG5pbXBvcnQgJy9pbXBvcnRzL2FwaS90YWdpbnRlcmZhY2VzLmpzJztcbmltcG9ydCAnL2ltcG9ydHMvYXBpL2NtZGludGVyZmFjZXMuanMnO1xuaW1wb3J0ICcvaW1wb3J0cy9hcGkvb2JqZWN0c2ludGVyZmFjZXMuanMnO1xuaW1wb3J0ICcvaW1wb3J0cy9hcGkvc2NyZWVuaW50ZXJmYWNlcy5qcydcbmltcG9ydCAnL2ltcG9ydHMvYXBpL2FsYXJtZXZlbnQuanMnO1xuaW1wb3J0ICcvaW1wb3J0cy9hcGkvdGFnaGlzdG9yaWFuLmpzJztcbmltcG9ydCAnL2ltcG9ydHMvYXBpL3RhZ2RhdGFoaXN0b3JpYW4uanMnO1xuaW1wb3J0ICcvaW1wb3J0cy9hcGkvc2hpZnRob3Vyc2ludGVyZmFjZS5qcyc7XG5pbXBvcnQgJy9pbXBvcnRzL2FwaS9iaW9tYXNldmVudC5qcyc7XG5pbXBvcnQgJy9pbXBvcnRzL2FwaS9iaW9tYXNtYXRlcmlhbC5qcyc7XG5pbXBvcnQgJy9pbXBvcnRzL2FwaS9tYXRlcmlhbC5qcyc7XG5cbmltcG9ydCAnL2ltcG9ydHMvYXBpL3VzZXJzLmpzJ1xuaW1wb3J0IFJPTEVTIGZyb20gJy9pbXBvcnRzL2FwaS9yb2xlcy5qcyc7XG5pbXBvcnQgJy9pbXBvcnRzL2FwaS9yb3V0ZWludGVyZmFjZS5qcydcbmltcG9ydCAnL2ltcG9ydHMvYXBpL3NjcmV2ZW50LmpzJztcbmltcG9ydCAnL2ltcG9ydHMvYXBpL3VzZXJsb2dpbi5qcyc7XG5cblxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICAvLyBjb2RlIHRvIHJ1biBvbiBzZXJ2ZXIgYXQgc3RhcnR1cFxuICBpZiAoTWV0ZW9yLnVzZXJzLmZpbmQoKS5mZXRjaCgpLmxlbmd0aCA9PT0gMCkge1xuXG4gICAgY29uc29sZS5sb2coJ0NyZWF0aW5nIHVzZXJzOiAnKTtcblx0dmFyIHVzZXJzID0gW1xuXHRcdHt1c2VybmFtZTogXCJteW93bmVyXCIsXG5cdFx0cGFzc3dvcmQ6IFwic2VydmVyQDIwMjFcIixcblx0XHRyb2xlczogW1JPTEVTLk93bmVyXSxcblx0XHRwcm9maWxlOntcblx0XHRcdGNvbnRhY3Q6IFwiRW5naW5uZXIuLi4uXCJcblx0XHR9fSxcblx0XHR7dXNlcm5hbWU6IFwiYWRtaW5pc3RyYXRvclwiLFxuXHRcdHBhc3N3b3JkOiBcImJpb21hc0AyMDIxXCIsXG5cdFx0cm9sZXM6IFtST0xFUy5Pd25lcl0sXG5cdFx0cHJvZmlsZTp7XG5cdFx0XHRjb250YWN0OiBcIkFkbWluLi5cIlxuXHRcdH19XTtcdFxuXHRcdFxuICAgIC8vXy5lYWNoKHVzZXJzLCBmdW5jdGlvbiAodXNlckRhdGEpIHtcblx0dXNlcnMuZm9yRWFjaChmdW5jdGlvbih1c2VyKSB7XG5cdFx0dmFyIGlkO1xuXHRcdGNvbnNvbGUubG9nKHVzZXIpO1xuXHRcdGlkID0gQWNjb3VudHMuY3JlYXRlVXNlcih7XG5cdFx0XHR1c2VybmFtZTogdXNlci51c2VybmFtZSxcblx0XHRcdHBhc3N3b3JkOiB1c2VyLnBhc3N3b3JkLFxuXHRcdFx0cHJvZmlsZTp7XG5cdFx0XHRcdGNvbnRhY3Q6IHVzZXIucHJvZmlsZS5jb250YWN0LFxuXHRcdFx0fVxuXHRcdH0pOyBcblx0XHRpZiAoTWV0ZW9yLnJvbGVBc3NpZ25tZW50LmZpbmQoeyAndXNlci5faWQnOiBpZCB9KS5jb3VudCgpID09PSAwKSB7XG5cdFx0XHRcblx0XHRcdHVzZXIucm9sZXMuZm9yRWFjaChmdW5jdGlvbiAocm9sZSkge1xuXHRcdFx0XHRSb2xlcy5jcmVhdGVSb2xlKHJvbGUsIHt1bmxlc3NFeGlzdHM6IHRydWV9KTtcblx0XHRcdH0pO1xuXHRcdFx0Um9sZXMuYWRkVXNlcnNUb1JvbGVzKGlkLHVzZXIucm9sZXMsXCJtYW5hZ2VyXCIpO1xuXHRcdFx0Um9sZXMuYWRkVXNlcnNUb1JvbGVzKGlkLHVzZXIucm9sZXMsbnVsbCk7XG5cdFx0fSAgICBcbiAgICB9KTsgIFxuXHR9O1xufSk7XG4iXX0=
